"use client"

import type React from 'react';
import { createContext, useContext, useState, useEffect } from 'react';

interface NotificationPreferences {
  email: {
    enabled: boolean;
    types: {
      new_vote: boolean;
      vote_ending: boolean;
      vote_result: boolean;
      system: boolean;
    };
    priority: {
      high: boolean;
      medium: boolean;
      low: boolean;
    };
  };
  browser: {
    enabled: boolean;
    types: {
      new_vote: boolean;
      vote_ending: boolean;
      vote_result: boolean;
      system: boolean;
    };
    priority: {
      high: boolean;
      medium: boolean;
      low: boolean;
    };
  };
  inApp: {
    enabled: boolean;
    types: {
      new_vote: boolean;
      vote_ending: boolean;
      vote_result: boolean;
      system: boolean;
    };
    toast: boolean;
    sound: boolean;
  };
  timing: {
    quietHours: {
      enabled: boolean;
      start: string; // HH:MM format
      end: string;   // HH:MM format
    };
    frequency: 'immediate' | 'hourly' | 'daily';
  };
}

interface NotificationPreferencesContextType {
  preferences: NotificationPreferences;
  updatePreferences: (newPreferences: Partial<NotificationPreferences>) => void;
  resetToDefaults: () => void;
  exportPreferences: () => string;
  importPreferences: (data: string) => boolean;
}

const defaultPreferences: NotificationPreferences = {
  email: {
    enabled: true,
    types: {
      new_vote: true,
      vote_ending: true,
      vote_result: true,
      system: false
    },
    priority: {
      high: true,
      medium: true,
      low: false
    }
  },
  browser: {
    enabled: true,
    types: {
      new_vote: true,
      vote_ending: true,
      vote_result: false,
      system: false
    },
    priority: {
      high: true,
      medium: false,
      low: false
    }
  },
  inApp: {
    enabled: true,
    types: {
      new_vote: true,
      vote_ending: true,
      vote_result: true,
      system: true
    },
    toast: true,
    sound: false
  },
  timing: {
    quietHours: {
      enabled: false,
      start: '22:00',
      end: '08:00'
    },
    frequency: 'immediate'
  }
};

const NotificationPreferencesContext = createContext<NotificationPreferencesContextType | null>(null);

export function NotificationPreferencesProvider({ children }: { children: React.ReactNode }) {
  const [preferences, setPreferences] = useState<NotificationPreferences>(defaultPreferences);

  // Carica le preferenze dal localStorage all'avvio
  useEffect(() => {
    const saved = localStorage.getItem('notificationPreferences');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setPreferences({ ...defaultPreferences, ...parsed });
      } catch (error) {
        console.error('Errore nel caricamento delle preferenze:', error);
      }
    }
  }, []);

  // Salva le preferenze nel localStorage quando cambiano
  useEffect(() => {
    localStorage.setItem('notificationPreferences', JSON.stringify(preferences));
  }, [preferences]);

  const updatePreferences = (newPreferences: Partial<NotificationPreferences>) => {
    setPreferences(prev => {
      const updated = { ...prev };

      // Deep merge delle preferenze
      Object.keys(newPreferences).forEach(key => {
        const typedKey = key as keyof NotificationPreferences;
        if (typeof newPreferences[typedKey] === 'object' && newPreferences[typedKey] !== null) {
          updated[typedKey] = {
            ...updated[typedKey],
            ...newPreferences[typedKey]
          } as any;
        } else {
          (updated as any)[typedKey] = newPreferences[typedKey];
        }
      });

      return updated;
    });
  };

  const resetToDefaults = () => {
    setPreferences(defaultPreferences);
    localStorage.removeItem('notificationPreferences');
  };

  const exportPreferences = () => {
    return JSON.stringify(preferences, null, 2);
  };

  const importPreferences = (data: string): boolean => {
    try {
      const parsed = JSON.parse(data);
      setPreferences({ ...defaultPreferences, ...parsed });
      return true;
    } catch (error) {
      console.error('Errore nell\'importazione delle preferenze:', error);
      return false;
    }
  };

  return (
    <NotificationPreferencesContext.Provider value={{
      preferences,
      updatePreferences,
      resetToDefaults,
      exportPreferences,
      importPreferences
    }}>
      {children}
    </NotificationPreferencesContext.Provider>
  );
}

export function useNotificationPreferences() {
  const context = useContext(NotificationPreferencesContext);
  if (!context) {
    throw new Error('useNotificationPreferences must be used within a NotificationPreferencesProvider');
  }
  return context;
}

export type { NotificationPreferences };
