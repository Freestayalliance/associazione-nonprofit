"use client"

import type React from 'react';
import { createContext, useContext, useState, useEffect } from 'react';

type NotificationType = 'new_vote' | 'vote_ending' | 'vote_result' | 'system';

interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  actionUrl?: string;
  priority: 'low' | 'medium' | 'high';
}

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  removeNotification: (id: string) => void;
  clearAll: () => void;
}

const NotificationContext = createContext<NotificationContextType | null>(null);

// Dati di esempio per le notifiche
const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'new_vote',
    title: 'Nuova Votazione Disponibile',
    message: 'È aperta la votazione per l\'ammissione di Alessandro Verdi',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 ore fa
    read: false,
    actionUrl: '/votazioni',
    priority: 'high'
  },
  {
    id: '2',
    type: 'vote_ending',
    title: 'Votazione in Scadenza',
    message: 'La votazione per Maria Bianchi scade tra 6 ore',
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 ore fa
    read: false,
    actionUrl: '/votazioni',
    priority: 'medium'
  },
  {
    id: '3',
    type: 'vote_result',
    title: 'Risultato Votazione',
    message: 'Luca Rossi è stato ammesso come nuovo socio (82 voti favorevoli)',
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 giorno fa
    read: true,
    actionUrl: '/votazioni',
    priority: 'medium'
  },
  {
    id: '4',
    type: 'system',
    title: 'Sistema Newsletter Aggiornato',
    message: 'Nuove funzionalità disponibili nel sistema newsletter',
    timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 giorni fa
    read: true,
    actionUrl: '/newsletter',
    priority: 'low'
  }
];

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);

  // Simula aggiornamenti real-time ogni 30 secondi
  useEffect(() => {
    const interval = setInterval(() => {
      // Simula possibili nuove notifiche
      const randomChance = Math.random();

      if (randomChance < 0.1) { // 10% possibilità ogni 30 secondi
        const newNotifications = [
          {
            type: 'vote_ending' as const,
            title: 'Reminder Votazione',
            message: 'Ricorda di votare per Alessandro Verdi - scade oggi!',
            actionUrl: '/votazioni',
            priority: 'medium' as const
          },
          {
            type: 'new_vote' as const,
            title: 'Nuova Proposta',
            message: 'È stata proposta una nuova modifica al regolamento',
            actionUrl: '/votazioni',
            priority: 'high' as const
          }
        ];

        const randomNotification = newNotifications[Math.floor(Math.random() * newNotifications.length)];

        setNotifications(prev => [{
          ...randomNotification,
          id: Date.now().toString(),
          timestamp: new Date(),
          read: false
        }, ...prev]);
      }
    }, 30000); // Ogni 30 secondi

    return () => clearInterval(interval);
  }, []);

  const unreadCount = notifications.filter(n => !n.read).length;

  const addNotification = (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => {
    const newNotification: Notification = {
      ...notification,
      id: Date.now().toString(),
      timestamp: new Date(),
      read: false
    };
    setNotifications(prev => [newNotification, ...prev]);
  };

  const markAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev =>
      prev.map(n => ({ ...n, read: true }))
    );
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearAll = () => {
    setNotifications([]);
  };

  return (
    <NotificationContext.Provider value={{
      notifications,
      unreadCount,
      addNotification,
      markAsRead,
      markAllAsRead,
      removeNotification,
      clearAll
    }}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
}

export type { Notification, NotificationType };
