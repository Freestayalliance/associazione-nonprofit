"use client"

import type React from 'react';
import { createContext, useContext, useState, useEffect } from 'react';

type User = {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user';
};

type AuthContextType = {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
};

const AuthContext = createContext<AuthContextType | null>(null);

// Utenti di esempio per il demo
const DEMO_USERS: User[] = [
  {
    id: '1',
    email: 'admin@associazione.org',
    name: 'Michael Franceschini',
    role: 'admin'
  },
  {
    id: '2',
    email: 'laura@associazione.org',
    name: 'Vittoria Sgura',
    role: 'admin'
  }
];

const DEMO_PASSWORDS: Record<string, string> = {
  'admin@associazione.org': 'admin123',
  'laura@associazione.org': 'laura123'
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Controlla se c'è un utente salvato in localStorage
  useEffect(() => {
    const savedUser = localStorage.getItem('adminUser');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (error) {
        localStorage.removeItem('adminUser');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);

    // Simula una chiamata API
    await new Promise(resolve => setTimeout(resolve, 1000));

    const user = DEMO_USERS.find(u => u.email === email);
    const validPassword = DEMO_PASSWORDS[email] === password;

    if (user && validPassword && user.role === 'admin') {
      setUser(user);
      localStorage.setItem('adminUser', JSON.stringify(user));
      setIsLoading(false);
      return true;
    }

    setIsLoading(false);
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('adminUser');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
