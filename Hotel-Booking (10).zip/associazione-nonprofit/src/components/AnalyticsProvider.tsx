"use client"

import { useEffect } from 'react';
import { usePathname } from 'next/navigation';
import analyticsService from '@/services/AnalyticsService';

export default function AnalyticsProvider({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  useEffect(() => {
    // Inizializza il servizio analytics una sola volta
    analyticsService.initializeTracking();

    // Cleanup al unmount
    return () => {
      analyticsService.destroy();
    };
  }, []);

  useEffect(() => {
    // Track page view ogni volta che cambia la route
    analyticsService.trackPageView();
  }, [pathname]);

  // Integra tracking eventi con le interazioni comuni
  useEffect(() => {
    // Track search nelle pagine
    const handleSearchSubmit = (e: Event) => {
      const form = e.target as HTMLFormElement;
      const searchInput = form.querySelector('input[type="search"], input[name="search"], input[placeholder*="cerca"]') as HTMLInputElement;
      if (searchInput?.value) {
        analyticsService.trackSearch(searchInput.value);
      }
    };

    // Track download di file
    const handleDownloadClick = (e: Event) => {
      const target = e.target as HTMLAnchorElement;
      if (target.href && (target.href.includes('.pdf') || target.href.includes('.doc') || target.href.includes('.zip'))) {
        const filename = target.href.split('/').pop() || 'unknown';
        const extension = filename.split('.').pop() || 'unknown';
        analyticsService.trackDownload(filename, extension);
      }
    };

    // Track form submissions
    const handleFormSubmit = (e: Event) => {
      const form = e.target as HTMLFormElement;
      const formId = form.id || form.className || 'unnamed-form';

      // Determina il tipo di form
      let formType = 'generic';
      if (formId.includes('newsletter')) formType = 'newsletter';
      else if (formId.includes('contact')) formType = 'contact';
      else if (formId.includes('associati')) formType = 'membership';
      else if (formId.includes('login')) formType = 'login';
      else if (formId.includes('vote') || formId.includes('vot')) formType = 'vote';
      else if (formId.includes('comment')) formType = 'comment';

      analyticsService.trackEvent('form', 'submit', formType);
    };

    // Track external links
    const handleExternalLink = (e: Event) => {
      const target = e.target as HTMLAnchorElement;
      if (target.href && !target.href.includes(window.location.hostname)) {
        analyticsService.trackEvent('external-link', 'click', target.href);
      }
    };

    // Track CTA buttons (Call to Action)
    const handleCtaClick = (e: Event) => {
      const target = e.target as HTMLElement;
      const text = target.textContent?.toLowerCase() || '';

      if (text.includes('diventa socio') || text.includes('associati')) {
        analyticsService.trackEvent('cta', 'membership-click', 'become-member');
      } else if (text.includes('newsletter')) {
        analyticsService.trackEvent('cta', 'newsletter-click', 'subscribe');
      } else if (text.includes('dona') || text.includes('sostieni')) {
        analyticsService.trackEvent('cta', 'donation-click', 'support');
      } else if (text.includes('vota') || text.includes('partecipa')) {
        analyticsService.trackEvent('cta', 'participation-click', 'vote');
      }
    };

    // Aggiungi event listeners
    document.addEventListener('submit', handleFormSubmit);
    document.addEventListener('click', handleDownloadClick);
    document.addEventListener('click', handleExternalLink);
    document.addEventListener('click', handleCtaClick);

    // Cleanup
    return () => {
      document.removeEventListener('submit', handleFormSubmit);
      document.removeEventListener('click', handleDownloadClick);
      document.removeEventListener('click', handleExternalLink);
      document.removeEventListener('click', handleCtaClick);
    };
  }, []);

  return <>{children}</>;
}
