"use client"

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useRouter } from 'next/navigation';

interface Notification {
  id: string;
  type: 'new_vote' | 'vote_ending' | 'new_member' | 'system' | 'info';
  voteId?: number;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  actionText?: string;
  actionUrl?: string;
}

export function NotificationBell() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [showFloatingNotification, setShowFloatingNotification] = useState(false);
  const [latestNotification, setLatestNotification] = useState<Notification | null>(null);
  const router = useRouter();

  // Carica notifiche dal localStorage
  useEffect(() => {
    const loadNotifications = () => {
      try {
        const saved = JSON.parse(localStorage.getItem('app-notifications') || '[]');
        const sortedNotifications = saved.sort((a: Notification, b: Notification) =>
          new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        );
        setNotifications(sortedNotifications);

        // Mostra notifica fluttuante per nuove votazioni
        const latestVoteNotification = sortedNotifications.find((n: Notification) =>
          n.type === 'new_vote' && !n.read
        );

        if (latestVoteNotification) {
          setLatestNotification(latestVoteNotification);
          setShowFloatingNotification(true);
        }
      } catch (error) {
        console.error('Errore caricamento notifiche:', error);
      }
    };

    loadNotifications();

    // Controlla nuove notifiche ogni 30 secondi
    const interval = setInterval(loadNotifications, 30000);

    return () => clearInterval(interval);
  }, []);

  // Conteggio notifiche non lette
  const unreadCount = notifications.filter(n => !n.read).length;

  // Marca notifica come letta
  const markAsRead = (notificationId: string) => {
    const updatedNotifications = notifications.map(n =>
      n.id === notificationId ? { ...n, read: true } : n
    );
    setNotifications(updatedNotifications);
    localStorage.setItem('app-notifications', JSON.stringify(updatedNotifications));
  };

  // Gestisce il click su una notifica
  const handleNotificationClick = (notification: Notification) => {
    markAsRead(notification.id);
    if (notification.actionUrl) {
      router.push(notification.actionUrl);
    }
    setIsOpen(false);
  };

  // Chiudi notifica fluttuante
  const closeFloatingNotification = () => {
    setShowFloatingNotification(false);
    if (latestNotification) {
      markAsRead(latestNotification.id);
    }
  };

  // Vai alla votazione dalla notifica fluttuante
  const goToVotazione = () => {
    if (latestNotification) {
      markAsRead(latestNotification.id);
      router.push('/votazioni');
    }
    setShowFloatingNotification(false);
  };

  // Cancella tutte le notifiche
  const clearAllNotifications = () => {
    setNotifications([]);
    localStorage.setItem('app-notifications', JSON.stringify([]));
    setIsOpen(false);
  };

  // Formatta il tempo relativo
  const formatTimeAgo = (timestamp: string) => {
    const now = new Date().getTime();
    const notificationTime = new Date(timestamp).getTime();
    const diffInMinutes = Math.floor((now - notificationTime) / (1000 * 60));

    if (diffInMinutes < 1) return 'Ora';
    if (diffInMinutes < 60) return `${diffInMinutes}m fa`;

    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h fa`;

    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}g fa`;
  };

  // Ottieni icona per tipo notifica
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'new_vote': return '🗳️';
      case 'vote_ending': return '⏰';
      case 'new_member': return '👥';
      case 'system': return '⚙️';
      default: return '📢';
    }
  };

  return (
    <>
      {/* Notifica Fluttuante */}
      {showFloatingNotification && latestNotification && (
        <div style={{
          position: 'fixed',
          top: '80px',
          right: '20px',
          backgroundColor: 'white',
          border: '2px solid #3b82f6',
          borderRadius: '12px',
          padding: '16px 20px',
          boxShadow: '0 10px 25px rgba(0, 0, 0, 0.15)',
          zIndex: 1000,
          minWidth: '300px',
          maxWidth: '350px',
          animation: 'slideInRight 0.3s ease-out'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontSize: '18px' }}>📱</span>
              <h4 style={{
                margin: 0,
                fontSize: '16px',
                fontWeight: 'bold',
                color: '#1f2937'
              }}>
                Nuova Votazione Disponibile
              </h4>
            </div>
            <button
              onClick={closeFloatingNotification}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '18px',
                cursor: 'pointer',
                color: '#9ca3af',
                padding: '0',
                width: '24px',
                height: '24px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              ✕
            </button>
          </div>

          <p style={{
            margin: '0 0 12px 0',
            fontSize: '14px',
            color: '#6b7280',
            lineHeight: '1.4'
          }}>
            È aperta la votazione per l'ammissione di Alessandro Verdi
          </p>

          <button
            onClick={goToVotazione}
            style={{
              backgroundColor: '#3b82f6',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              padding: '8px 16px',
              fontSize: '14px',
              fontWeight: '500',
              cursor: 'pointer',
              width: '100%'
            }}
          >
            Visualizza
          </button>
        </div>
      )}

      {/* Bell Icon con Dropdown */}
      <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="sm" className="relative">
            <span className="text-xl">🔔</span>
            {unreadCount > 0 && (
              <Badge
                className="absolute -top-1 -right-1 bg-red-500 text-white text-xs h-5 w-5 p-0 flex items-center justify-center rounded-full"
              >
                {unreadCount > 9 ? '9+' : unreadCount}
              </Badge>
            )}
          </Button>
        </DropdownMenuTrigger>

        <DropdownMenuContent align="end" className="w-80 max-h-96 overflow-y-auto">
          <DropdownMenuLabel className="flex items-center justify-between">
            <span>🔔 Notifiche</span>
            {notifications.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearAllNotifications}
                className="text-xs h-6 px-2"
              >
                Cancella tutto
              </Button>
            )}
          </DropdownMenuLabel>

          <DropdownMenuSeparator />

          {notifications.length === 0 ? (
            <div className="p-4 text-center text-gray-500">
              <div className="text-2xl mb-2">📭</div>
              <p className="text-sm">Nessuna notifica</p>
            </div>
          ) : (
            notifications.slice(0, 10).map((notification) => (
              <DropdownMenuItem
                key={notification.id}
                className={`p-3 cursor-pointer border-b ${!notification.read ? 'bg-blue-50' : ''}`}
                onClick={() => handleNotificationClick(notification)}
              >
                <div className="flex items-start gap-3 w-full">
                  <span className="text-lg flex-shrink-0">
                    {getNotificationIcon(notification.type)}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium text-sm truncate">
                        {notification.title}
                      </h4>
                      {!notification.read && (
                        <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0" />
                      )}
                    </div>
                    <p className="text-xs text-gray-600 line-clamp-2">
                      {notification.message}
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-gray-400">
                        {formatTimeAgo(notification.timestamp)}
                      </span>
                      {notification.actionText && (
                        <span className="text-xs text-blue-600 font-medium">
                          {notification.actionText}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </DropdownMenuItem>
            ))
          )}

          {notifications.length > 10 && (
            <DropdownMenuItem className="p-3 text-center text-sm text-gray-500">
              E altre {notifications.length - 10} notifiche...
            </DropdownMenuItem>
          )}
        </DropdownMenuContent>
      </DropdownMenu>

      {/* CSS per animazioni */}
      <style jsx global>{`
        @keyframes slideInRight {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }

        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </>
  );
}
