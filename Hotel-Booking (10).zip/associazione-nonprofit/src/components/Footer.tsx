import Link from "next/link"
import { Separator } from "@/components/ui/separator"

export function Footer() {
  return (
    <footer className="bg-gray-50 border-t">
      <div className="container px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Info FREE STAY ALLIANCE */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 rounded-full bg-gradient-to-r from-blue-600 to-green-600 flex items-center justify-center">
                <span className="text-white font-bold text-sm">🏠</span>
              </div>
              <span className="font-bold text-lg">FREE STAY ALLIANCE</span>
            </div>
            <p className="text-sm text-gray-600">
              Un'alleanza globale dedicata al supporto della comunità attraverso trasparenza e partecipazione.
            </p>
          </div>

          {/* Link Rapidi */}
          <div className="space-y-4">
            <h3 className="font-semibold">Link Rapidi</h3>
            <div className="space-y-2">
              <Link href="/chi-siamo" className="block text-sm text-gray-600 hover:text-blue-600">
                Chi Siamo
              </Link>
              <Link href="/associati" className="block text-sm text-gray-600 hover:text-blue-600">
                Diventa Socio
              </Link>
              <Link href="/trasparenza" className="block text-sm text-gray-600 hover:text-blue-600">
                Trasparenza
              </Link>
              <Link href="/blog" className="block text-sm text-gray-600 hover:text-blue-600">
                Blog
              </Link>
            </div>
          </div>

          {/* Partecipazione */}
          <div className="space-y-4">
            <h3 className="font-semibold">Partecipazione</h3>
            <div className="space-y-2">
              <Link href="/newsletter" className="block text-sm text-gray-600 hover:text-blue-600">
                Newsletter
              </Link>
              <Link href="/votazioni" className="block text-sm text-gray-600 hover:text-blue-600">
                Votazioni
              </Link>
              <Link href="/partner" className="block text-sm text-gray-600 hover:text-blue-600">
                Partner Aziendali
              </Link>
              <Link href="/contatti" className="block text-sm text-gray-600 hover:text-blue-600">
                Contatti
              </Link>
            </div>
          </div>

          {/* Contatti */}
          <div className="space-y-4">
            <h3 className="font-semibold">Contatti</h3>
            <div className="space-y-2 text-sm text-gray-600">
              <p>📧 info@associazione.org</p>
              <p>📞 +39 123 456 7890</p>
              <p>📍 Via Roma 123, Milano</p>
            </div>
          </div>
        </div>

        <Separator className="my-8" />

        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-sm text-gray-600">
            © 2024 Associazione. Tutti i diritti riservati.
          </p>
          <div className="flex space-x-4">
            <Link href="/privacy" className="text-sm text-gray-600 hover:text-blue-600">
              Privacy Policy
            </Link>
            <Link href="/trasparenza" className="text-sm text-gray-600 hover:text-blue-600">
              Trasparenza
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
