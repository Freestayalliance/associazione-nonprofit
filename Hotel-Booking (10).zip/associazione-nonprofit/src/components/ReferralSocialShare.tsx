"use client"

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

interface ReferralSocialShareProps {
  referralCode: string;
  userName: string;
  variant?: 'default' | 'compact' | 'floating';
  showTitle?: boolean;
  className?: string;
}

export function ReferralSocialShare({
  referralCode,
  userName,
  variant = 'default',
  showTitle = true,
  className = ""
}: ReferralSocialShareProps) {
  const { toast } = useToast();
  const [shareStats, setShareStats] = useState<Record<string, number>>({});

  // URL base dell'applicazione (in produzione sostituire con il dominio reale)
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://freestayalliance.org';
  const referralUrl = `${baseUrl}/associati?invito=${referralCode}`;

  // Messaggi personalizzati per ogni piattaforma
  const messages = {
    whatsapp: `🏠 Ciao! Ti invito a unirti al FREE STAY ALLIANCE!

Un'associazione trasparente che sta rivoluzionando il mondo nonprofit con:
✅ Trasparenza finanziaria totale
✅ Votazioni democratiche
✅ Community attiva e coinvolta

Usa il mio codice invito: ${referralCode}
${referralUrl}

#Trasparenza #Community #Nonprofit`,

    telegram: `🎯 Hey! Ho scoperto FREE STAY ALLIANCE - un progetto fantastico di trasparenza democratica!

Se ti interessa:
• Partecipazione attiva alle decisioni
• Trasparenza finanziaria completa
• Community di persone motivate

Unisciti con il mio codice: ${referralCode}
${referralUrl}`,

    linkedin: `Ho scoperto un progetto molto interessante: FREE STAY ALLIANCE.

Un'associazione che applica principi di trasparenza totale e partecipazione democratica al mondo nonprofit.

Se sei interessato a progetti innovativi di governance e trasparenza, dai un'occhiata!

Codice invito: ${referralCode}
${referralUrl}

#Innovation #Transparency #Nonprofit #Community`,

    facebook: `🌟 Vi presento FREE STAY ALLIANCE!

Un'associazione che ho scoperto di recente che fa qualcosa di rivoluzionario: trasparenza TOTALE su tutte le finanze e decisioni prese insieme democraticamente.

Se anche voi credete in un mondo più trasparente e partecipativo, questo è il posto giusto!

Il mio codice invito: ${referralCode}
${referralUrl}`,

    twitter: `🚀 Scoperto @FreStayAlliance - trasparenza totale + democrazia partecipativa nel nonprofit!

${referralCode} per unirti alla community

${referralUrl}

#Transparency #Democracy #Innovation #Community`,

    email: {
      subject: `Ti invito a FREE STAY ALLIANCE - Codice: ${referralCode}`,
      body: `Ciao!

Ti scrivo per invitarti a conoscere FREE STAY ALLIANCE, un'associazione che sto seguendo e che trovo molto interessante.

Quello che mi ha colpito di più:
• Trasparenza finanziaria completa - puoi vedere ogni entrata e uscita
• Decisioni prese democraticamente da tutti i soci
• Community attiva e costruttiva
• Quota associativa molto accessibile (€20/anno)

Se ti incuriosisce l'idea di far parte di qualcosa di trasparente e partecipativo, dai un'occhiata!

Il mio codice invito è: ${referralCode}
Link diretto: ${referralUrl}

A presto!
${userName}`
    }
  };

  // Funzioni per aprire le varie piattaforme
  const shareOn = {
    whatsapp: () => {
      const encodedMessage = encodeURIComponent(messages.whatsapp);
      const url = `https://wa.me/?text=${encodedMessage}`;
      window.open(url, '_blank');
      trackShare('whatsapp');
    },

    telegram: () => {
      const encodedMessage = encodeURIComponent(messages.telegram);
      const url = `https://t.me/share/url?url=${encodeURIComponent(referralUrl)}&text=${encodedMessage}`;
      window.open(url, '_blank');
      trackShare('telegram');
    },

    linkedin: () => {
      const encodedMessage = encodeURIComponent(messages.linkedin);
      const url = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(referralUrl)}&summary=${encodedMessage}`;
      window.open(url, '_blank');
      trackShare('linkedin');
    },

    facebook: () => {
      const encodedMessage = encodeURIComponent(messages.facebook);
      const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(referralUrl)}&quote=${encodedMessage}`;
      window.open(url, '_blank');
      trackShare('facebook');
    },

    twitter: () => {
      const encodedMessage = encodeURIComponent(messages.twitter);
      const url = `https://twitter.com/intent/tweet?text=${encodedMessage}`;
      window.open(url, '_blank');
      trackShare('twitter');
    },

    email: () => {
      const subject = encodeURIComponent(messages.email.subject);
      const body = encodeURIComponent(messages.email.body);
      const url = `mailto:?subject=${subject}&body=${body}`;
      window.location.href = url;
      trackShare('email');
    },

    copy: async () => {
      try {
        const textToCopy = `${messages.whatsapp}`;
        await navigator.clipboard.writeText(textToCopy);
        toast({
          title: "📋 Copiato!",
          description: "Il messaggio con il tuo codice è stato copiato negli appunti",
          duration: 3000
        });
        trackShare('copy');
      } catch (error) {
        // Fallback per browser che non supportano clipboard API
        const textArea = document.createElement('textarea');
        textArea.value = `${messages.whatsapp}`;
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
          document.execCommand('copy');
          toast({
            title: "📋 Copiato!",
            description: "Il messaggio con il tuo codice è stato copiato negli appunti",
            duration: 3000
          });
          trackShare('copy');
        } catch (fallbackError) {
          toast({
            title: "❌ Errore",
            description: "Impossibile copiare automaticamente. Seleziona e copia manualmente il testo.",
            variant: "destructive"
          });
        }
        document.body.removeChild(textArea);
      }
    },

    copyLink: async () => {
      try {
        await navigator.clipboard.writeText(referralUrl);
        toast({
          title: "🔗 Link copiato!",
          description: "Il link con il tuo codice referral è stato copiato",
          duration: 3000
        });
        trackShare('copyLink');
      } catch (error) {
        toast({
          title: "❌ Errore",
          description: "Impossibile copiare il link automaticamente",
          variant: "destructive"
        });
      }
    }
  };

  // Tracking delle condivisioni
  const trackShare = (platform: string) => {
    setShareStats(prev => ({
      ...prev,
      [platform]: (prev[platform] || 0) + 1
    }));

    // Salva le statistiche in localStorage
    const key = `referral-shares-${referralCode}`;
    const existing = JSON.parse(localStorage.getItem(key) || '{}');
    existing[platform] = (existing[platform] || 0) + 1;
    existing.lastShared = new Date().toISOString();
    localStorage.setItem(key, JSON.stringify(existing));

    toast({
      title: "📊 Condivisione tracciata!",
      description: `La tua condivisione su ${platform} è stata registrata`,
      duration: 2000
    });
  };

  // Componente compatta per sidebar o widget
  if (variant === 'compact') {
    return (
      <div className={`space-y-2 ${className}`}>
        {showTitle && (
          <div className="text-sm font-medium text-gray-700 mb-2">
            📤 Condividi il tuo codice
          </div>
        )}

        <div className="grid grid-cols-3 gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={shareOn.whatsapp}
            className="flex items-center justify-center p-2 h-8"
            title="Condividi su WhatsApp"
          >
            <span className="text-lg">📱</span>
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={shareOn.telegram}
            className="flex items-center justify-center p-2 h-8"
            title="Condividi su Telegram"
          >
            <span className="text-lg">✈️</span>
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={shareOn.copyLink}
            className="flex items-center justify-center p-2 h-8"
            title="Copia link"
          >
            <span className="text-lg">🔗</span>
          </Button>
        </div>
      </div>
    );
  }

  // Componente floating per mobile
  if (variant === 'floating') {
    return (
      <div className={`fixed bottom-4 right-4 z-50 ${className}`}>
        <div className="bg-white rounded-lg shadow-lg border p-3 space-y-2">
          <div className="text-xs font-medium text-gray-600 text-center">
            Condividi {referralCode}
          </div>
          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={shareOn.whatsapp}
              className="p-1 h-8 w-8"
              title="WhatsApp"
            >
              📱
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={shareOn.copyLink}
              className="p-1 h-8 w-8"
              title="Copia"
            >
              📋
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Componente completa default
  return (
    <Card className={className}>
      {showTitle && (
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            📤 Condividi il Tuo Codice
            <Badge variant="outline">{referralCode}</Badge>
          </CardTitle>
          <CardDescription>
            Invita amici e colleghi usando i tuoi canali preferiti. Ogni piattaforma ha un messaggio ottimizzato!
          </CardDescription>
        </CardHeader>
      )}

      <CardContent className="space-y-6">
        {/* Widget principali */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* WhatsApp - Il più importante */}
          <Button
            onClick={shareOn.whatsapp}
            className="flex items-center justify-start gap-3 h-12 bg-green-600 hover:bg-green-700 text-white"
          >
            <span className="text-2xl">📱</span>
            <div className="text-left">
              <div className="font-semibold">WhatsApp</div>
              <div className="text-xs opacity-90">Condividi con amici</div>
            </div>
          </Button>

          {/* Telegram */}
          <Button
            onClick={shareOn.telegram}
            variant="outline"
            className="flex items-center justify-start gap-3 h-12 border-blue-500 text-blue-600 hover:bg-blue-50"
          >
            <span className="text-2xl">✈️</span>
            <div className="text-left">
              <div className="font-semibold">Telegram</div>
              <div className="text-xs opacity-70">Community tech</div>
            </div>
          </Button>

          {/* LinkedIn */}
          <Button
            onClick={shareOn.linkedin}
            variant="outline"
            className="flex items-center justify-start gap-3 h-12 border-blue-700 text-blue-700 hover:bg-blue-50"
          >
            <span className="text-2xl">💼</span>
            <div className="text-left">
              <div className="font-semibold">LinkedIn</div>
              <div className="text-xs opacity-70">Network professionale</div>
            </div>
          </Button>

          {/* Facebook */}
          <Button
            onClick={shareOn.facebook}
            variant="outline"
            className="flex items-center justify-start gap-3 h-12 border-blue-600 text-blue-600 hover:bg-blue-50"
          >
            <span className="text-2xl">📘</span>
            <div className="text-left">
              <div className="font-semibold">Facebook</div>
              <div className="text-xs opacity-70">Amici e famiglia</div>
            </div>
          </Button>
        </div>

        {/* Azioni secondarie */}
        <div className="flex flex-wrap gap-2">
          <Button
            onClick={shareOn.twitter}
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <span>🐦</span>
            Twitter/X
          </Button>

          <Button
            onClick={shareOn.email}
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <span>📧</span>
            Email
          </Button>

          <Button
            onClick={shareOn.copy}
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <span>📋</span>
            Copia Messaggio
          </Button>

          <Button
            onClick={shareOn.copyLink}
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <span>🔗</span>
            Solo Link
          </Button>
        </div>

        {/* Statistiche condivisioni (se presenti) */}
        {Object.keys(shareStats).length > 0 && (
          <div className="pt-4 border-t">
            <div className="text-sm font-medium text-gray-700 mb-2">
              📊 Le tue condivisioni di oggi:
            </div>
            <div className="flex flex-wrap gap-2">
              {Object.entries(shareStats).map(([platform, count]) => (
                <Badge key={platform} variant="secondary" className="text-xs">
                  {platform}: {count}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Tips per massimizzare le condivisioni */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <h4 className="font-medium text-blue-900 mb-2">💡 Tips per condivisioni efficaci:</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• <strong>WhatsApp:</strong> Perfetto per chat private e gruppi di amici</li>
            <li>• <strong>LinkedIn:</strong> Ideale per colleghi e contatti professionali</li>
            <li>• <strong>Email:</strong> Per inviti formali e dettagliati</li>
            <li>• <strong>Aggiungi contesto:</strong> Spiega perché ti piace il progetto</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}

export default ReferralSocialShare;
