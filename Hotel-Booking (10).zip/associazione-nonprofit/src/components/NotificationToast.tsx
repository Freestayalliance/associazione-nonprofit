"use client"

import { useEffect, useState } from 'react';
import { useNotifications } from '@/contexts/NotificationContext';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Link from 'next/link';

interface ToastNotification {
  id: string;
  title: string;
  message: string;
  type: string;
  priority: string;
  actionUrl?: string;
  show: boolean;
}

const getNotificationIcon = (type: string) => {
  switch (type) {
    case 'new_vote': return '🗳️';
    case 'vote_ending': return '⏰';
    case 'vote_result': return '📊';
    case 'system': return '🔧';
    default: return '🔔';
  }
};

export function NotificationToast() {
  const { notifications } = useNotifications();
  const [toastQueue, setToastQueue] = useState<ToastNotification[]>([]);

  // Monitora nuove notifiche e le aggiunge alla coda toast
  useEffect(() => {
    const latestNotification = notifications[0];
    if (latestNotification && !latestNotification.read) {
      const toastNotification: ToastNotification = {
        id: latestNotification.id,
        title: latestNotification.title,
        message: latestNotification.message,
        type: latestNotification.type,
        priority: latestNotification.priority,
        actionUrl: latestNotification.actionUrl,
        show: true
      };

      setToastQueue(prev => {
        // Evita duplicati
        const exists = prev.some(toast => toast.id === toastNotification.id);
        if (exists) return prev;

        return [toastNotification, ...prev.slice(0, 2)]; // Max 3 toast contemporaneamente
      });

      // Auto-hide dopo 8 secondi (per notifiche ad alta priorità) o 5 secondi
      const autoHideDelay = latestNotification.priority === 'high' ? 8000 : 5000;
      setTimeout(() => {
        setToastQueue(prev => prev.filter(toast => toast.id !== latestNotification.id));
      }, autoHideDelay);
    }
  }, [notifications]);

  const removeToast = (id: string) => {
    setToastQueue(prev => prev.filter(toast => toast.id !== id));
  };

  if (toastQueue.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2">
      {toastQueue.map((toast, index) => (
        <Card
          key={toast.id}
          className={`
            w-80 shadow-lg border-l-4 animate-in slide-in-from-right-full duration-300
            ${toast.priority === 'high' ? 'border-l-red-500 bg-red-50' :
              toast.priority === 'medium' ? 'border-l-yellow-500 bg-yellow-50' :
              'border-l-blue-500 bg-blue-50'}
          `}
          style={{
            transform: `translateY(${index * 10}px)`,
            zIndex: 50 - index
          }}
        >
          <CardContent className="p-4">
            <div className="flex items-start justify-between space-x-3">
              <div className="flex items-start space-x-3 flex-1">
                <div className="text-xl">{getNotificationIcon(toast.type)}</div>

                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold text-sm">{toast.title}</h4>
                    {toast.priority === 'high' && (
                      <Badge className="bg-red-500 text-xs">🔥</Badge>
                    )}
                  </div>

                  <p className="text-xs text-gray-700">{toast.message}</p>

                  <div className="flex gap-2 pt-2">
                    {toast.actionUrl && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-6 px-2 text-xs"
                        asChild
                        onClick={() => removeToast(toast.id)}
                      >
                        <Link href={toast.actionUrl}>
                          Visualizza
                        </Link>
                      </Button>
                    )}
                  </div>
                </div>
              </div>

              <Button
                variant="ghost"
                size="sm"
                className="h-6 w-6 p-0 text-gray-400 hover:text-gray-600"
                onClick={() => removeToast(toast.id)}
              >
                ✕
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
