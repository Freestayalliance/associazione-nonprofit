"use client"

import Link from 'next/link';
import { ChevronRightIcon, HomeIcon } from '@heroicons/react/24/outline';

interface BreadcrumbItem {
  label: string;
  href?: string;
  current?: boolean;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
  className?: string;
}

export default function Breadcrumb({ items, className = '' }: BreadcrumbProps) {
  // Structured data per SEO
  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.label,
      item: item.href ? `${typeof window !== 'undefined' ? window.location.origin : ''}${item.href}` : undefined
    }))
  };

  return (
    <>
      {/* Structured Data per SEO */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />

      {/* Breadcrumb Navigation */}
      <nav
        aria-label="Breadcrumb"
        className={`flex items-center space-x-2 text-sm text-gray-600 ${className}`}
      >
        <ol className="flex items-center space-x-2">
          {items.map((item, index) => (
            <li key={index} className="flex items-center">
              {index === 0 && (
                <HomeIcon className="h-4 w-4 mr-1 text-gray-500" />
              )}

              {item.href && !item.current ? (
                <Link
                  href={item.href}
                  className="hover:text-blue-600 transition-colors duration-200 font-medium"
                  itemProp="item"
                >
                  <span itemProp="name">{item.label}</span>
                </Link>
              ) : (
                <span
                  className={`${item.current ? 'text-gray-900 font-semibold' : 'text-gray-600'}`}
                  aria-current={item.current ? 'page' : undefined}
                  itemProp="name"
                >
                  {item.label}
                </span>
              )}

              {index < items.length - 1 && (
                <ChevronRightIcon className="h-4 w-4 mx-2 text-gray-400" />
              )}
            </li>
          ))}
        </ol>
      </nav>
    </>
  );
}

// Hook per generare breadcrumb automaticamente
export function useBreadcrumb(pathname: string, customItems?: BreadcrumbItem[]): BreadcrumbItem[] {
  if (customItems) return customItems;

  const pathSegments = pathname.split('/').filter(Boolean);
  const breadcrumbItems: BreadcrumbItem[] = [
    { label: 'Home', href: '/' }
  ];

  let currentPath = '';
  for (let i = 0; i < pathSegments.length; i++) {
    currentPath += `/${pathSegments[i]}`;
    const isLast = i === pathSegments.length - 1;

    // Traduci i segmenti del path
    let label = pathSegments[i];
    switch (pathSegments[i]) {
      case 'blog':
        label = 'Blog';
        break;
      case 'admin':
        label = 'Amministrazione';
        break;
      case 'chi-siamo':
        label = 'Chi Siamo';
        break;
      case 'trasparenza':
        label = 'Trasparenza';
        break;
      case 'associati':
        label = 'Diventa Socio';
        break;
      case 'votazioni':
        label = 'Votazioni';
        break;
      case 'newsletter':
        label = 'Newsletter';
        break;
      case 'partner':
        label = 'Partner';
        break;
      case 'contatti':
        label = 'Contatti';
        break;
      case 'documentazione':
        label = 'Documentazione';
        break;
      default:
        // Se è un numero (come ID articolo), prova a recuperare il titolo
        if (/^\d+$/.test(label)) {
          label = `Articolo ${label}`;
        } else {
          label = label.charAt(0).toUpperCase() + label.slice(1);
        }
    }

    breadcrumbItems.push({
      label,
      href: isLast ? undefined : currentPath,
      current: isLast
    });
  }

  return breadcrumbItems;
}
