"use client"

import { useState, useEffect } from 'react';
import PartnerService, { type PartnerInfo, type PartnerTransaction } from '@/services/PartnerService';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export default function PartnerBanner() {
  const [selectedPartners, setSelectedPartners] = useState<PartnerInfo[]>([]);
  const [showPartnerModal, setShowPartnerModal] = useState(false);
  const [selectedPartnerInfo, setSelectedPartnerInfo] = useState<PartnerInfo | null>(null);
  const [partnerTransactions, setPartnerTransactions] = useState<PartnerTransaction[]>([]);

  useEffect(() => {
    loadSelectedPartners();
    loadPartnerTransactions();

    // Carica i dati partner

    // Aggiorna ogni 10 secondi per sincronizzare le selezioni
    const interval = setInterval(() => {
      loadSelectedPartners();
      loadPartnerTransactions();
    }, 10000);

    // Registra callback per aggiornamenti loghi in tempo reale
    const unsubscribeLogo = PartnerService.onLogoUpdate((partnerName) => {
      console.log(`Logo aggiornato per ${partnerName}, ricaricando banner...`);
      loadSelectedPartners();
      loadPartnerTransactions();
    });

    // Ascolta per eventi di storage (quando vengono caricati loghi da altre tab)
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'partner-logos' || e.key === 'selected-partners') {
        // Storage change detected
        loadSelectedPartners();
        loadPartnerTransactions();
      }
    };

    window.addEventListener('storage', handleStorageChange);

    return () => {
      clearInterval(interval);
      unsubscribeLogo();
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  const loadSelectedPartners = () => {
    const partners = PartnerService.getSelectedPartners();
    console.log('📊 Loaded Selected Partners:', partners);
    setSelectedPartners(partners);
  };

  const loadPartnerTransactions = () => {
    const transactions = PartnerService.getPartnerTransactions();
    console.log('📋 Loaded Partner Transactions:', transactions);
    setPartnerTransactions(transactions);
  };

  const handlePartnerClick = (partner: PartnerInfo) => {
    setSelectedPartnerInfo(partner);
    setShowPartnerModal(true);
  };

  const getPartnerStats = (partnerName: string) => {
    const transactions = partnerTransactions.filter(t => t.nome === partnerName);
    const totalAmount = transactions.reduce((sum, t) => sum + t.importo, 0);
    const transactionCount = transactions.length;
    const lastTransaction = transactions.sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime())[0];

    return {
      totalAmount,
      transactionCount,
      lastTransaction,
      transactions
    };
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR'
    }).format(amount);
  };

  // Formatta l'importo in "X volte grazie"
  const formatThanks = (amount: number) => {
    if (amount === 0) return "0 volte grazie";

    // Arrotonda per evitare decimali strani
    const roundedAmount = Math.round(amount);

    // Formatta con separatori delle migliaia
    const formattedAmount = new Intl.NumberFormat('it-IT').format(roundedAmount);

    return `${formattedAmount} volte grazie`;
  };

  // Se non ci sono partner selezionati, mostra partner di default
  const defaultPartners = [
    {
      id: 999,
      nome: 'TechCorp Italia',
      logo: '🏢',
      settore: 'Tecnologia',
      livello: 'Oro',
      selected: true,
      website: 'www.techcorpitalia.it'
    },
    {
      id: 998,
      nome: 'Green Solutions',
      logo: '🌱',
      settore: 'Sostenibilità',
      livello: 'Argento',
      selected: true,
      website: 'www.greensolutions.it'
    },
    {
      id: 997,
      nome: 'Studio Legale Rossi',
      logo: '⚖️',
      settore: 'Legale',
      livello: 'Bronze',
      selected: true,
      website: 'www.studiolegalerossi.it'
    },
    {
      id: 996,
      nome: 'BankCorp Financial',
      logo: '🏦',
      settore: 'Finanziario',
      livello: 'Oro',
      selected: true,
      website: 'www.bankcorpfinancial.it'
    },
    {
      id: 995,
      nome: 'EduTech Academy',
      logo: '📚',
      settore: 'Formazione',
      livello: 'Argento',
      selected: true,
      website: 'www.edutechacademy.it'
    }
  ];

  const partnersToShow = selectedPartners.length > 0 ? selectedPartners : defaultPartners;

  // Duplica l'array per creare l'effetto infinito
  const infinitePartners = [...partnersToShow, ...partnersToShow, ...partnersToShow];

  return (
    <div className="w-full bg-gradient-to-r from-blue-50 via-white to-blue-50 border-b border-blue-100 shadow-sm overflow-hidden relative">
      <style jsx>{`
        @keyframes thanks-glow {
          0%, 100% {
            opacity: 0.7;
            text-shadow: 0 0 5px rgba(34, 197, 94, 0.5);
          }
          50% {
            opacity: 1;
            text-shadow: 0 0 10px rgba(34, 197, 94, 0.8), 0 0 20px rgba(34, 197, 94, 0.3);
          }
        }
        .thanks-text {
          animation: thanks-glow 2s ease-in-out infinite;
        }
      `}</style>
      <div className="relative h-20">
        {/* Contenitore con animazione di scrolling */}
        <div className="absolute top-0 left-0 h-full flex items-center partner-banner-scroll" style={{
          width: `${infinitePartners.length * 250}px`
        }}>
          {infinitePartners.map((partner, index) => {
            const stats = getPartnerStats(partner.nome);
            const thanksText = formatThanks(stats.totalAmount);

            return (
              <div
                key={`${partner.id}-${index}`}
                className="flex items-center gap-3 mx-4 flex-shrink-0 cursor-pointer hover:bg-blue-100 rounded-lg px-3 py-2 transition-colors duration-200"
                onClick={() => handlePartnerClick(partner)}
                title={`Clicca per vedere i dettagli di ${partner.nome}`}
              >
                {/* Logo del partner */}
                <div className="w-25 h-15 rounded-lg overflow-hidden bg-white border-2 border-blue-200 shadow-sm flex items-center justify-center" style={{ width: '100px', height: '60px' }}>
                  {partner.logo ? (
                    partner.logo.startsWith('data:') ? (
                      <img
                        src={partner.logo}
                        alt={partner.nome}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span className="text-xl">{partner.logo}</span>
                    )
                  ) : (
                    <span className="text-xl">🤝</span>
                  )}
                </div>

                {/* Colonna nome + grazie */}
                <div className="flex flex-col items-start justify-center">
                  {/* Nome partner */}
                  <div className="text-sm font-medium text-blue-900 whitespace-nowrap">
                    {partner.nome}
                  </div>

                  {/* X volte grazie - con effetto lampeggiante */}
                  <div className="text-xs font-semibold text-green-600 whitespace-nowrap thanks-text">
                    {thanksText}
                  </div>
                </div>

                {/* Badge livello */}
                <div className={`px-2 py-1 rounded-full text-xs font-medium whitespace-nowrap ${
                  partner.livello === 'Oro' ? 'bg-yellow-100 text-yellow-800' :
                  partner.livello === 'Argento' ? 'bg-gray-100 text-gray-800' :
                  'bg-orange-100 text-orange-800'
                }`}>
                  {partner.livello}
                </div>
              </div>
            );
          })}
        </div>

        {/* Gradient overlay per effetto fade */}
        <div className="absolute top-0 left-0 w-20 h-full bg-gradient-to-r from-blue-50 to-transparent pointer-events-none z-10"></div>
        <div className="absolute top-0 right-0 w-20 h-full bg-gradient-to-l from-blue-50 to-transparent pointer-events-none z-10"></div>
      </div>

      {/* Indicatore partner */}
      <div className="absolute top-2 right-4 text-xs text-blue-600 font-medium flex items-center gap-2">
        🤝 {partnersToShow.length} Partner • Clicca per dettagli
        <button
          onClick={() => {
            console.log('🔄 Force reload banner...');
            loadSelectedPartners();
            loadPartnerTransactions();
          }}
          className="text-xs bg-blue-100 hover:bg-blue-200 px-2 py-1 rounded"
          title="Ricarica banner"
        >
          🔄
        </button>
      </div>

      {/* Modal Informazioni Partner */}
      <Dialog open={showPartnerModal} onOpenChange={setShowPartnerModal}>
        <DialogContent className="max-w-md">
          {selectedPartnerInfo && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3">
                  <div className="rounded-lg overflow-hidden bg-white border-2 border-blue-200 shadow-sm flex items-center justify-center" style={{ width: '100px', height: '60px' }}>
                    {selectedPartnerInfo.logo ? (
                      selectedPartnerInfo.logo.startsWith('data:') ? (
                        <img
                          src={selectedPartnerInfo.logo}
                          alt={selectedPartnerInfo.nome}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-2xl">{selectedPartnerInfo.logo}</span>
                      )
                    ) : (
                      <span className="text-2xl">🤝</span>
                    )}
                  </div>
                  <div>
                    <div className="text-lg font-bold">{selectedPartnerInfo.nome}</div>
                    <div className="text-sm text-gray-600">{selectedPartnerInfo.settore}</div>
                  </div>
                </DialogTitle>
                <DialogDescription>
                  Informazioni dettagliate sul nostro partner
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                {/* Badge Livello */}
                <div className="flex justify-center">
                  <Badge
                    className={
                      selectedPartnerInfo.livello === 'Oro' ? 'bg-yellow-600' :
                      selectedPartnerInfo.livello === 'Argento' ? 'bg-gray-500' :
                      'bg-orange-600'
                    }
                  >
                    Partner {selectedPartnerInfo.livello}
                  </Badge>
                </div>

                {/* Sito Web */}
                {selectedPartnerInfo.website && (
                  <div className="text-center">
                    <a
                      href={`https://${selectedPartnerInfo.website.replace(/^https?:\/\//, '')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-800 font-medium"
                      title={`Visita il sito di ${selectedPartnerInfo.nome}`}
                    >
                      🌐 {selectedPartnerInfo.website}
                    </a>
                  </div>
                )}

                {/* Statistiche Partner */}
                {(() => {
                  const stats = getPartnerStats(selectedPartnerInfo.nome);
                  return (
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-blue-50 rounded-lg">
                        <div className="text-xl font-bold text-blue-600">
                          {formatCurrency(stats.totalAmount)}
                        </div>
                        <div className="text-xs text-blue-800">Contributo Totale</div>
                      </div>

                      <div className="text-center p-3 bg-green-50 rounded-lg">
                        <div className="text-xl font-bold text-green-600">
                          {stats.transactionCount}
                        </div>
                        <div className="text-xs text-green-800">Transazioni</div>
                      </div>
                    </div>
                  );
                })()}

                {/* Ultima Transazione */}
                {(() => {
                  const stats = getPartnerStats(selectedPartnerInfo.nome);
                  if (stats.lastTransaction) {
                    return (
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <h4 className="font-medium text-sm mb-2">📅 Ultima Transazione:</h4>
                        <div className="text-sm text-gray-700">
                          <div><strong>Data:</strong> {new Date(stats.lastTransaction.data).toLocaleDateString('it-IT')}</div>
                          <div><strong>Importo:</strong> {formatCurrency(stats.lastTransaction.importo)}</div>
                          <div><strong>Descrizione:</strong> {stats.lastTransaction.descrizione}</div>
                        </div>
                      </div>
                    );
                  }
                  return null;
                })()}

                {/* Lista Tutte le Transazioni */}
                {(() => {
                  const stats = getPartnerStats(selectedPartnerInfo.nome);
                  if (stats.transactions.length > 1) {
                    return (
                      <div className="max-h-32 overflow-y-auto">
                        <h4 className="font-medium text-sm mb-2">📋 Storico Transazioni:</h4>
                        <div className="space-y-1">
                          {stats.transactions
                            .sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime())
                            .map((transaction, index) => (
                              <div key={index} className="text-xs p-2 bg-white rounded border">
                                <div className="flex justify-between items-center">
                                  <span>{new Date(transaction.data).toLocaleDateString('it-IT')}</span>
                                  <span className="font-bold text-green-600">
                                    {formatCurrency(transaction.importo)}
                                  </span>
                                </div>
                                <div className="text-gray-600 truncate">
                                  {transaction.descrizione}
                                </div>
                              </div>
                            ))}
                        </div>
                      </div>
                    );
                  }
                  return null;
                })()}

                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1" onClick={() => setShowPartnerModal(false)}>
                    Chiudi
                  </Button>
                  <Button className="flex-1" asChild>
                    <a href="/partner" onClick={() => setShowPartnerModal(false)}>
                      Vedi Tutti i Partner
                    </a>
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
