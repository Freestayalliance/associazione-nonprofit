"use client"

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import blogCommentService, { type BlogComment } from '@/services/BlogCommentService';
import Link from "next/link";

interface BlogCommentsProps {
  articoloId: number;
  articoloTitolo: string;
}

export default function BlogComments({ articoloId, articoloTitolo }: BlogCommentsProps) {
  const [commenti, setCommenti] = useState<BlogComment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [risposteA, setRisposteA] = useState<string | undefined>(undefined);
  const [nuovoCommento, setNuovoCommento] = useState({
    autore: '',
    email: '',
    contenuto: '',
    ruolo: 'guest' as 'socio' | 'albergatore' | 'admin' | 'guest'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [userEmail, setUserEmail] = useState<string>('');

  const { toast } = useToast();

  // Carica commenti
  useEffect(() => {
    loadCommenti();
    // Carica email utente salvata per mostrare i suoi commenti in moderazione
    const savedEmail = localStorage.getItem('blog-user-email');
    if (savedEmail) {
      setUserEmail(savedEmail);
    }
  }, [articoloId]);

  const loadCommenti = () => {
    setIsLoading(true);
    try {
      const savedEmail = localStorage.getItem('blog-user-email');
      const commentiData = blogCommentService.getCommentsByArticle(articoloId, false, savedEmail || undefined);
      setCommenti(commentiData);
    } catch (error) {
      console.error('Errore nel caricamento commenti:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Check se l'utente è admin
  const isAdmin = () => {
    try {
      const adminUser = localStorage.getItem('adminUser');
      return adminUser ? JSON.parse(adminUser) : null;
    } catch {
      return null;
    }
  };

  // Conta commenti in moderazione per questo articolo
  const getCommentiInModerazione = () => {
    const allComments = blogCommentService.getAllComments();
    return allComments.filter(c => c.articoloId === articoloId && c.stato === 'in_moderazione').length;
  };

  // Invia nuovo commento
  const inviaCommento = async () => {
    if (!nuovoCommento.autore.trim() || !nuovoCommento.contenuto.trim()) {
      toast({
        title: "Errore",
        description: "Nome e commento sono obbligatori",
        variant: "destructive"
      });
      return;
    }

    if (!nuovoCommento.email.trim() || !nuovoCommento.email.includes('@')) {
      toast({
        title: "Errore",
        description: "Inserisci un indirizzo email valido",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const result = blogCommentService.addComment(
        articoloId,
        nuovoCommento.autore,
        nuovoCommento.email,
        nuovoCommento.contenuto,
        nuovoCommento.ruolo,
        risposteA
      );

      if (result.success) {
        // Salva email utente per future sessioni
        localStorage.setItem('blog-user-email', nuovoCommento.email);
        setUserEmail(nuovoCommento.email);

        toast({
          title: "✅ Commento inviato!",
          description: result.message,
        });

        // Reset form (mantieni email per comodità)
        setNuovoCommento({
          autore: '',
          email: nuovoCommento.email, // Mantieni email
          contenuto: '',
          ruolo: nuovoCommento.ruolo // Mantieni ruolo
        });
        setRisposteA(undefined);
        setShowForm(false);

        // Ricarica commenti
        loadCommenti();
      } else {
        toast({
          title: "Errore",
          description: result.message,
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Errore invio commento:', error);
      toast({
        title: "Errore",
        description: "Errore nell'invio del commento",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Toggle like commento
  const toggleLike = (commentId: string) => {
    const result = blogCommentService.toggleLike(commentId);
    if (result.success) {
      // Aggiorna commenti localmente
      setCommenti(prevCommenti =>
        prevCommenti.map(c =>
          c.id === commentId
            ? { ...c, likes: result.newLikes }
            : c
        )
      );
    }
  };

  // Segnala commento
  const segnalaCommento = (commentId: string) => {
    const motivo = prompt("Motivo della segnalazione:");
    if (!motivo) return;

    const result = blogCommentService.flagComment(commentId, motivo);
    if (result.success) {
      toast({
        title: "Segnalazione inviata",
        description: result.message,
      });
    }
  };

  // Organizza commenti per visualizzazione (commenti principali e risposte)
  const commentiPrincipali = commenti.filter(c => !c.risposteA);

  const getRisposte = (commentId: string): BlogComment[] => {
    return commenti.filter(c => c.risposteA === commentId);
  };

  const getRuoloIcon = (ruolo: string) => {
    switch (ruolo) {
      case 'socio': return '👤';
      case 'albergatore': return '🏨';
      case 'admin': return '👑';
      case 'guest': default: return '👥';
    }
  };

  const getRuoloColor = (ruolo: string) => {
    switch (ruolo) {
      case 'socio': return 'bg-blue-50 text-blue-800';
      case 'albergatore': return 'bg-green-50 text-green-800';
      case 'admin': return 'bg-purple-50 text-purple-800';
      case 'guest': default: return 'bg-gray-50 text-gray-800';
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const commentTime = new Date(timestamp);
    const diffMs = now.getTime() - commentTime.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMins < 1) return 'Ora';
    if (diffMins < 60) return `${diffMins} min fa`;
    if (diffHours < 24) return `${diffHours}h fa`;
    if (diffDays < 7) return `${diffDays}g fa`;
    return commentTime.toLocaleDateString('it-IT');
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Caricamento commenti...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Commenti */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>💬 Commenti ({commenti.length})</span>
            <div className="flex gap-2">
              {isAdmin() && getCommentiInModerazione() > 0 && (
                <Button
                  asChild
                  variant="outline"
                  size="sm"
                  className="bg-yellow-50 border-yellow-300 text-yellow-700 hover:bg-yellow-100"
                >
                  <Link href="/admin/blog?tab=commenti">
                    🛡️ Modera ({getCommentiInModerazione()})
                  </Link>
                </Button>
              )}
              <Button
                onClick={() => setShowForm(!showForm)}
                variant={showForm ? "outline" : "default"}
                size="sm"
              >
                {showForm ? "Annulla" : "💬 Lascia un Commento"}
              </Button>
            </div>
          </CardTitle>
          <CardDescription>
            Partecipa alla discussione su "{articoloTitolo}"
            {isAdmin() && getCommentiInModerazione() > 0 && (
              <span className="text-yellow-600 ml-2">
                • {getCommentiInModerazione()} commenti in attesa di moderazione
              </span>
            )}
          </CardDescription>
        </CardHeader>

        {/* Form Nuovo Commento */}
        {showForm && (
          <CardContent className="border-t">
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="autore">Nome *</Label>
                  <Input
                    id="autore"
                    value={nuovoCommento.autore}
                    onChange={(e) => setNuovoCommento({...nuovoCommento, autore: e.target.value})}
                    placeholder="Il tuo nome"
                    disabled={isSubmitting}
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={nuovoCommento.email}
                    onChange={(e) => setNuovoCommento({...nuovoCommento, email: e.target.value})}
                    placeholder="tua@email.com"
                    disabled={isSubmitting}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="ruolo">Ti identifichi come</Label>
                <Select
                  value={nuovoCommento.ruolo}
                  onValueChange={(value: 'socio' | 'albergatore' | 'admin' | 'guest') =>
                    setNuovoCommento({...nuovoCommento, ruolo: value})
                  }
                  disabled={isSubmitting}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="guest">👥 Visitatore</SelectItem>
                    <SelectItem value="socio">👤 Socio dell'Associazione</SelectItem>
                    <SelectItem value="albergatore">🏨 Albergatore Partner</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="contenuto">
                  Commento * {risposteA && <span className="text-blue-600">(Risposta)</span>}
                </Label>
                <Textarea
                  id="contenuto"
                  value={nuovoCommento.contenuto}
                  onChange={(e) => setNuovoCommento({...nuovoCommento, contenuto: e.target.value})}
                  placeholder={risposteA ? "Scrivi la tua risposta..." : "Condividi la tua opinione..."}
                  rows={4}
                  disabled={isSubmitting}
                  className="resize-none"
                />
                <div className="flex justify-between items-center mt-1">
                  <p className="text-xs text-gray-500">
                    {nuovoCommento.contenuto.length}/1000 caratteri
                  </p>
                  {risposteA && (
                    <Button
                      type="button"
                      variant="link"
                      size="sm"
                      onClick={() => setRisposteA(undefined)}
                      className="text-xs"
                    >
                      Annulla risposta
                    </Button>
                  )}
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={inviaCommento}
                  disabled={isSubmitting}
                  className="flex-1"
                >
                  {isSubmitting ? "Invio..." : "📤 Invia Commento"}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowForm(false);
                    setRisposteA(undefined);
                  }}
                  disabled={isSubmitting}
                >
                  Annulla
                </Button>
              </div>

              <div className="bg-blue-50 p-3 rounded-lg">
                <p className="text-xs text-blue-800">
                  💡 <strong>Sistema di Moderazione:</strong> I commenti sono moderati per garantire un ambiente rispettoso.
                  I tuoi commenti saranno visibili immediatamente per te ma pubblici solo dopo l'approvazione.
                </p>
                <p className="text-xs text-blue-600 mt-1">
                  🛡️ Per approvare commenti: <a href="/admin/blog" className="underline hover:text-blue-800">Area Admin → Blog → Commenti</a>
                </p>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Lista Commenti */}
      {commenti.length > 0 ? (
        <div className="space-y-6">
          {commentiPrincipali.map((commento) => {
            const risposte = getRisposte(commento.id);
            return (
              <Card key={commento.id} className="shadow-sm">
                <CardContent className="p-6">
                  {/* Commento Principale */}
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold">
                          {commento.autore.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{commento.autore}</span>
                            <Badge variant="outline" className={`text-xs ${getRuoloColor(commento.ruolo)}`}>
                              {getRuoloIcon(commento.ruolo)} {commento.ruolo}
                            </Badge>
                          </div>
                          <div className="text-sm text-gray-500">
                            {formatTimeAgo(commento.timestamp)}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="ml-12">
                      <p className="text-gray-800 leading-relaxed">{commento.contenuto}</p>
                      {commento.stato === 'in_moderazione' && commento.email === userEmail && (
                        <div className="mt-2 text-sm text-yellow-600 bg-yellow-50 px-3 py-1 rounded-lg border border-yellow-200">
                          ⏳ Il tuo commento è in moderazione e sarà visibile dopo l'approvazione
                        </div>
                      )}
                    </div>

                    <div className="ml-12 flex items-center gap-4 text-sm">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleLike(commento.id)}
                        className={`h-8 px-3 ${blogCommentService.hasUserLiked(commento.id) ? 'text-blue-600' : 'text-gray-500'}`}
                      >
                        👍 {commento.likes}
                      </Button>

                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setRisposteA(commento.id);
                          setShowForm(true);
                        }}
                        className="h-8 px-3 text-gray-500 hover:text-blue-600"
                      >
                        💬 Rispondi
                      </Button>

                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => segnalaCommento(commento.id)}
                        className="h-8 px-3 text-gray-400 hover:text-red-600"
                      >
                        🚩 Segnala
                      </Button>

                      {isAdmin() && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            if (confirm("Sei sicuro di voler eliminare questo commento? Questa azione non può essere annullata.")) {
                              const result = blogCommentService.deleteComment(commento.id, '', true);
                              if (result.success) {
                                loadCommenti();
                                toast({
                                  title: "🗑️ Commento eliminato",
                                  description: result.message,
                                });
                              }
                            }
                          }}
                          className="h-8 px-3 text-red-400 hover:text-red-600"
                        >
                          🗑️ Elimina
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Risposte */}
                  {risposte.length > 0 && (
                    <div className="mt-6 ml-8 space-y-4 border-l-2 border-gray-100 pl-6">
                      {risposte.map((risposta) => (
                        <div key={risposta.id} className="space-y-3">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-green-500 to-teal-600 flex items-center justify-center text-white font-bold text-sm">
                              {risposta.autore.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-medium text-sm">{risposta.autore}</span>
                                <Badge variant="outline" className={`text-xs ${getRuoloColor(risposta.ruolo)}`}>
                                  {getRuoloIcon(risposta.ruolo)} {risposta.ruolo}
                                </Badge>
                              </div>
                              <div className="text-xs text-gray-500">
                                {formatTimeAgo(risposta.timestamp)}
                              </div>
                            </div>
                          </div>

                          <div className="ml-11">
                            <p className="text-gray-800 text-sm leading-relaxed">{risposta.contenuto}</p>
                            {risposta.stato === 'in_moderazione' && risposta.email === userEmail && (
                              <div className="mt-2 text-xs text-yellow-600 bg-yellow-50 px-2 py-1 rounded border border-yellow-200">
                                ⏳ In moderazione
                              </div>
                            )}
                          </div>

                          <div className="ml-11 flex items-center gap-3 text-xs">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => toggleLike(risposta.id)}
                              className={`h-7 px-2 ${blogCommentService.hasUserLiked(risposta.id) ? 'text-blue-600' : 'text-gray-500'}`}
                            >
                              👍 {risposta.likes}
                            </Button>

                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => segnalaCommento(risposta.id)}
                              className="h-7 px-2 text-gray-400 hover:text-red-600"
                            >
                              🚩 Segnala
                            </Button>

                            {isAdmin() && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  if (confirm("Sei sicuro di voler eliminare questa risposta?")) {
                                    const result = blogCommentService.deleteComment(risposta.id, '', true);
                                    if (result.success) {
                                      loadCommenti();
                                      toast({
                                        title: "🗑️ Risposta eliminata",
                                        description: result.message,
                                      });
                                    }
                                  }
                                }}
                                className="h-7 px-2 text-red-400 hover:text-red-600"
                              >
                                🗑️ Elimina
                              </Button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <div className="text-6xl mb-4">💬</div>
            <h3 className="text-lg font-medium mb-2">Nessun commento ancora</h3>
            <p className="text-gray-600 mb-6">
              Sii il primo a condividere la tua opinione su questo articolo!
            </p>
            <Button onClick={() => setShowForm(true)}>
              ✍️ Scrivi il primo commento
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
