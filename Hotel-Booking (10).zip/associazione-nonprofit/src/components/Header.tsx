"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { NotificationBell } from "@/components/NotificationBell"
import { useNotifications } from "@/contexts/NotificationContext"
import { useState, useEffect } from "react"
import { useRouter } from 'next/navigation'

export function Header() {
  const { notifications } = useNotifications();
  const [adminUser, setAdminUser] = useState<any>(null);
  const [notificationCount, setNotificationCount] = useState(0);
  const router = useRouter();

  // Controlla se l'admin è loggato
  useEffect(() => {
    const checkAdminLogin = () => {
      const savedAdmin = localStorage.getItem('adminUser');
      console.log('🔍 Controllo admin login:', savedAdmin); // Debug log
      if (savedAdmin) {
        try {
          const admin = JSON.parse(savedAdmin);
          console.log('✅ Admin trovato:', admin); // Debug log
          setAdminUser(admin);
        } catch (error) {
          console.error('❌ Errore parsing admin:', error); // Debug log
          localStorage.removeItem('adminUser');
        }
      } else {
        console.log('❌ Nessun admin salvato'); // Debug log
      }
    };

    checkAdminLogin();

    // Controlla ogni 30 secondi per aggiornamenti
    const interval = setInterval(checkAdminLogin, 30000);

    return () => clearInterval(interval);
  }, []);

  // Aggiorna conteggio notifiche
  useEffect(() => {
    const updateNotificationCount = () => {
      try {
        const notifiche = JSON.parse(localStorage.getItem('app-notifications') || '[]');
        const unread = notifiche.filter((n: any) => !n.read).length;
        setNotificationCount(unread);
      } catch (error) {
        console.error('Errore conteggio notifiche:', error);
      }
    };

    // Aggiorna subito e poi ogni secondo
    updateNotificationCount();
    const interval = setInterval(updateNotificationCount, 1000);

    // Ascolta eventi personalizzati
    window.addEventListener('votazioni-aggiornate', updateNotificationCount);

    return () => {
      clearInterval(interval);
      window.removeEventListener('votazioni-aggiornate', updateNotificationCount);
    };
  }, []);

  // Genera notifica Alessandro Verdi se non esiste
  useEffect(() => {
    const timeout = setTimeout(() => {
      try {
        const notifiche = JSON.parse(localStorage.getItem('app-notifications') || '[]');

        const esisteAlessandro = notifiche.some((n: any) =>
          n.type === 'new_vote' && n.message.includes('Alessandro Verdi')
        );

        if (!esisteAlessandro) {
          const notificaAlessandro = {
            id: `vote-alessandro-${Date.now()}`,
            type: 'new_vote',
            voteId: 1001,
            title: 'Nuova Votazione Disponibile',
            message: 'È aperta la votazione per l\'ammissione di Alessandro Verdi',
            timestamp: new Date().toISOString(),
            read: false,
            priority: 'high',
            actionText: 'Visualizza',
            actionUrl: '/votazioni'
          };

          notifiche.unshift(notificaAlessandro);
          localStorage.setItem('app-notifications', JSON.stringify(notifiche));

          // Trigger aggiornamento
          window.dispatchEvent(new Event('votazioni-aggiornate'));
        }
      } catch (error) {
        console.error('Errore generazione notifica header:', error);
      }
    }, 3000); // 3 secondi dopo il caricamento dell'header

    return () => clearTimeout(timeout);
  }, []);

  // Funzione di logout admin
  const handleAdminLogout = () => {
    localStorage.removeItem('adminUser');
    setAdminUser(null);
    router.push('/');
  };

  // Conta le notifiche relative alle votazioni (legacy per compatibilità)
  const voteNotifications = Math.min(notificationCount, 9); // Limita a 9 per UI

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4">
        {/* Logo e Nome FREE STAY ALLIANCE */}
        <Link href="/" className="flex items-center space-x-2">
          <div className="h-8 w-8 rounded-full bg-gradient-to-r from-blue-600 to-green-600 flex items-center justify-center">
            <span className="text-white font-bold text-sm">🏠</span>
          </div>
          <span className="font-bold text-xl">FREE STAY ALLIANCE</span>
        </Link>

        {/* Menu di Navigazione Desktop */}
        <nav className="hidden md:flex flex-col items-center space-y-2">
          {/* Prima riga del menu */}
          <div className="flex items-center space-x-6">
            <Link href="/" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Home
            </Link>
            <Link href="/chi-siamo" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Chi Siamo
            </Link>
            <Link href="/trasparenza" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Trasparenza
            </Link>
            <Link href="/blog" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Blog
            </Link>
            <Link href="/newsletter" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Newsletter
            </Link>
            <Link href="/documentazione" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Documentazione
            </Link>
          </div>

          {/* Seconda riga del menu */}
          <div className="flex items-center space-x-6">
            <Link href="/votazioni" className="text-sm font-medium hover:text-blue-600 transition-colors flex items-center gap-1">
              Votazioni
              {voteNotifications > 0 && (
                <Badge className="bg-red-500 text-white text-xs h-4 w-4 p-0 flex items-center justify-center">
                  {voteNotifications}
                </Badge>
              )}
            </Link>
            <Link href="/partner" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Partner
            </Link>
            <Link href="/contatti" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Contatti
            </Link>
            <Link href="/demo" className="text-sm font-medium hover:text-green-600 transition-colors text-green-600">
              🎮 Demo
            </Link>
            {adminUser ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="text-sm font-medium hover:text-purple-600 transition-colors text-purple-600 flex items-center gap-1 h-auto p-1">
                    👨‍💼 {adminUser.name}
                    <span className="ml-1">▼</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-gradient-to-r from-blue-600 to-green-600 flex items-center justify-center">
                        <span className="text-white font-bold text-sm">👨‍💼</span>
                      </div>
                      <div>
                        <div className="font-medium">{adminUser.name}</div>
                        <div className="text-xs text-gray-500">Amministratore</div>
                      </div>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/admin" className="flex items-center gap-2 w-full">
                      📊 Dashboard
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleAdminLogout} className="flex items-center gap-2 text-red-600 focus:text-red-600">
                    🚪 Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/admin/login" className="text-sm font-medium hover:text-purple-600 transition-colors text-purple-600">
                🔐 Admin
              </Link>
            )}
          </div>
        </nav>

        {/* Notifiche e Bottone Associati */}
        <div className="flex items-center space-x-4">
          <NotificationBell />
          <Button asChild className="bg-blue-600 hover:bg-blue-700">
            <Link href="/associati">
              Diventa Socio
              <Badge variant="secondary" className="ml-2">
                €20/anno
              </Badge>
            </Link>
          </Button>
        </div>

        {/* Menu Mobile - da implementare */}
        <div className="md:hidden">
          <Button variant="ghost" size="sm">
            ☰
          </Button>
        </div>
      </div>
    </header>
  )
}
