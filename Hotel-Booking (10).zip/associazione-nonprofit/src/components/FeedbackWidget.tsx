"use client"

import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

interface FeedbackData {
  id: string;
  timestamp: string;
  page: string;
  rating: number;
  usability: number;
  content: number;
  design: number;
  comments: string;
  wouldRecommend: boolean;
  userType: string;
  email?: string;
}

export function FeedbackWidget({ page = "demo" }: { page?: string }) {
  const [isOpen, setIsOpen] = useState(false);
  const [rating, setRating] = useState(0);
  const [usability, setUsability] = useState(0);
  const [content, setContent] = useState(0);
  const [design, setDesign] = useState(0);
  const [comments, setComments] = useState("");
  const [wouldRecommend, setWouldRecommend] = useState<boolean | null>(null);
  const [userType, setUserType] = useState("");
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  const { toast } = useToast();

  const handleSubmit = () => {
    if (rating === 0) {
      toast({
        title: "Valutazione richiesta",
        description: "Per favore dai una valutazione generale prima di inviare",
        variant: "destructive",
      });
      return;
    }

    const feedback: FeedbackData = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      page,
      rating,
      usability,
      content,
      design,
      comments,
      wouldRecommend: wouldRecommend || false,
      userType,
      email
    };

    // Salva in localStorage
    const existingFeedback = JSON.parse(localStorage.getItem('demo-feedback') || '[]');
    existingFeedback.push(feedback);
    localStorage.setItem('demo-feedback', JSON.stringify(existingFeedback));

    setIsSubmitted(true);
    toast({
      title: "Grazie per il feedback! 🙏",
      description: "Il tuo contributo ci aiuta a migliorare l'esperienza demo",
    });

    // Reset dopo 3 secondi
    setTimeout(() => {
      setIsOpen(false);
      setIsSubmitted(false);
      setRating(0);
      setUsability(0);
      setContent(0);
      setDesign(0);
      setComments("");
      setWouldRecommend(null);
      setUserType("");
      setEmail("");
    }, 3000);
  };

  const StarRating = ({
    value,
    onChange,
    label
  }: {
    value: number;
    onChange: (value: number) => void;
    label: string;
  }) => (
    <div className="flex flex-col gap-2">
      <label className="text-sm font-medium">{label}</label>
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => {
              console.log(`🌟 Clicking star ${star}, current value: ${value}`);
              onChange(star);
            }}
            className={`text-2xl transition-colors cursor-pointer hover:scale-110 transform ${
              star <= value ? 'text-yellow-500' : 'text-gray-300 hover:text-yellow-400'
            }`}
            style={{
              background: 'none',
              border: 'none',
              padding: '2px',
            }}
          >
            ⭐
          </button>
        ))}
      </div>
      {value > 0 && (
        <div className="text-xs text-gray-500">
          Valutazione: {value}/5 stelle
        </div>
      )}
    </div>
  );

  if (!isOpen) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg rounded-full p-4 h-auto"
        >
          <span className="flex items-center gap-2">
            💬 Feedback
          </span>
        </Button>
      </div>
    );
  }

  if (isSubmitted) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <Card className="w-80 shadow-xl border-green-200">
          <CardContent className="p-6 text-center">
            <div className="text-4xl mb-3">🎉</div>
            <h3 className="text-lg font-semibold text-green-800 mb-2">
              Feedback Inviato!
            </h3>
            <p className="text-sm text-green-600">
              Grazie per aver condiviso la tua esperienza con noi
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Card className="w-96 shadow-xl">
        <CardHeader className="pb-4">
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-lg">💬 Feedback Demo</CardTitle>
              <CardDescription>
                Aiutaci a migliorare l'esperienza
              </CardDescription>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(false)}
              className="h-6 w-6 p-0"
            >
              ✕
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4 max-h-96 overflow-y-auto">
          {/* Valutazione Generale */}
          <StarRating
            value={rating}
            onChange={setRating}
            label="🌟 Valutazione Generale"
          />

          {/* Valutazioni Specifiche */}
          <div className="grid grid-cols-1 gap-3 pt-2 border-t">
            <StarRating
              value={usability}
              onChange={setUsability}
              label="🎯 Facilità d'Uso"
            />
            <StarRating
              value={content}
              onChange={setContent}
              label="📝 Qualità Contenuti"
            />
            <StarRating
              value={design}
              onChange={setDesign}
              label="🎨 Design & UI"
            />
          </div>

          {/* Raccomandazione */}
          <div className="pt-2 border-t">
            <label className="text-sm font-medium mb-2 block">
              🤝 Consiglieresti questo demo?
            </label>
            <div className="flex gap-2">
              <Button
                variant={wouldRecommend === true ? "default" : "outline"}
                size="sm"
                onClick={() => setWouldRecommend(true)}
              >
                👍 Sì
              </Button>
              <Button
                variant={wouldRecommend === false ? "default" : "outline"}
                size="sm"
                onClick={() => setWouldRecommend(false)}
              >
                👎 No
              </Button>
            </div>
          </div>

          {/* Tipo di Utente */}
          <div>
            <label className="text-sm font-medium mb-2 block">
              👤 Chi sei? (opzionale)
            </label>
            <div className="flex flex-wrap gap-2">
              {["Sviluppatore", "Designer", "Imprenditore", "Studente", "Altro"].map((type) => (
                <Badge
                  key={type}
                  variant={userType === type ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => setUserType(userType === type ? "" : type)}
                >
                  {type}
                </Badge>
              ))}
            </div>
          </div>

          {/* Commenti */}
          <div>
            <label className="text-sm font-medium mb-2 block">
              💭 Commenti & Suggerimenti
            </label>
            <Textarea
              placeholder="Cosa ti è piaciuto? Cosa potremmo migliorare?"
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              className="min-h-20"
            />
          </div>

          {/* Email (opzionale) */}
          <div>
            <label className="text-sm font-medium mb-2 block">
              📧 Email (opzionale)
            </label>
            <input
              type="email"
              placeholder="per seguire gli aggiornamenti"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
            />
          </div>

          {/* Bottoni */}
          <div className="flex gap-2 pt-2">
            <Button
              onClick={handleSubmit}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              📤 Invia Feedback
            </Button>
            <Button
              variant="outline"
              onClick={() => setIsOpen(false)}
              className="px-4"
            >
              Annulla
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
