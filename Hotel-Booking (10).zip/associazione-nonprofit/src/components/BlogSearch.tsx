"use client"

import { useState, useEffect } from 'react';
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { MagnifyingGlassIcon, XMarkIcon, TagIcon, FunnelIcon } from '@heroicons/react/24/outline';

interface BlogSearchProps {
  onSearch: (filters: SearchFilters) => void;
  categories: string[];
  tags: string[];
  totalArticles: number;
  filteredCount: number;
}

export interface SearchFilters {
  query: string;
  category: string;
  selectedTags: string[];
  author: string;
  sortBy: 'date' | 'views' | 'title' | 'relevance';
  sortOrder: 'desc' | 'asc';
}

const defaultFilters: SearchFilters = {
  query: '',
  category: 'tutti',
  selectedTags: [],
  author: '',
  sortBy: 'date',
  sortOrder: 'desc'
};

export default function BlogSearch({
  onSearch,
  categories,
  tags,
  totalArticles,
  filteredCount
}: BlogSearchProps) {
  const [filters, setFilters] = useState<SearchFilters>(defaultFilters);
  const [isExpanded, setIsExpanded] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      setFilters(prev => ({ ...prev, query: searchQuery }));
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Trigger search when filters change
  useEffect(() => {
    onSearch(filters);
  }, [filters, onSearch]);

  const toggleTag = (tag: string) => {
    setFilters(prev => ({
      ...prev,
      selectedTags: prev.selectedTags.includes(tag)
        ? prev.selectedTags.filter(t => t !== tag)
        : [...prev.selectedTags, tag]
    }));
  };

  const clearFilters = () => {
    setFilters(defaultFilters);
    setSearchQuery('');
    setIsExpanded(false);
  };

  const hasActiveFilters =
    filters.query ||
    filters.category !== 'tutti' ||
    filters.selectedTags.length > 0 ||
    filters.author ||
    filters.sortBy !== 'date' ||
    filters.sortOrder !== 'desc';

  return (
    <Card className="sticky top-4 z-10 shadow-lg">
      <CardContent className="p-6">
        {/* Ricerca principale */}
        <div className="space-y-4">
          <div className="relative">
            <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Cerca articoli per titolo, contenuto o autore..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4"
            />
            {searchQuery && (
              <Button
                variant="ghost"
                size="sm"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                onClick={() => setSearchQuery('')}
              >
                <XMarkIcon className="h-4 w-4" />
              </Button>
            )}
          </div>

          {/* Risultati e filtri toggle */}
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-600">
              {filteredCount === totalArticles ? (
                <span>📰 <strong>{totalArticles}</strong> articoli totali</span>
              ) : (
                <span>
                  🔍 <strong>{filteredCount}</strong> di <strong>{totalArticles}</strong> articoli
                  {hasActiveFilters && <span className="text-blue-600"> (filtrati)</span>}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              {hasActiveFilters && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearFilters}
                  className="text-xs"
                >
                  <XMarkIcon className="h-3 w-3 mr-1" />
                  Reset
                </Button>
              )}

              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsExpanded(!isExpanded)}
                className="text-xs"
              >
                <FunnelIcon className="h-3 w-3 mr-1" />
                Filtri {isExpanded ? '↑' : '↓'}
              </Button>
            </div>
          </div>
        </div>

        {/* Filtri avanzati */}
        {isExpanded && (
          <div className="mt-6 pt-4 border-t space-y-4">
            {/* Categoria e Ordinamento */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Categoria</label>
                <Select value={filters.category} onValueChange={(value) => setFilters(prev => ({ ...prev, category: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tutti">📂 Tutte le categorie</SelectItem>
                    {categories.map(cat => (
                      <SelectItem key={cat} value={cat}>
                        {cat === 'Trasparenza' && '📊'}
                        {cat === 'Tecnologia' && '💻'}
                        {cat === 'Partnership' && '🤝'}
                        {cat === 'Eventi' && '🎉'}
                        {cat === 'Partecipazione' && '🗳️'}
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Ordina per</label>
                <Select value={filters.sortBy} onValueChange={(value: any) => setFilters(prev => ({ ...prev, sortBy: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="date">📅 Data pubblicazione</SelectItem>
                    <SelectItem value="views">👁️ Più letti</SelectItem>
                    <SelectItem value="title">🔤 Titolo A-Z</SelectItem>
                    <SelectItem value="relevance">🎯 Rilevanza</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Ordine</label>
                <Select value={filters.sortOrder} onValueChange={(value: any) => setFilters(prev => ({ ...prev, sortOrder: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="desc">↓ Decrescente</SelectItem>
                    <SelectItem value="asc">↑ Crescente</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Filtro autore */}
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">Autore</label>
              <Input
                type="text"
                placeholder="Filtra per autore..."
                value={filters.author}
                onChange={(e) => setFilters(prev => ({ ...prev, author: e.target.value }))}
              />
            </div>

            {/* Tags */}
            {tags.length > 0 && (
              <div>
                <label className="text-sm font-medium text-gray-700 mb-3 flex items-center">
                  <TagIcon className="h-4 w-4 mr-1" />
                  Tags ({filters.selectedTags.length} selezionati)
                </label>

                {/* Tags selezionati */}
                {filters.selectedTags.length > 0 && (
                  <div className="mb-3 p-3 bg-blue-50 rounded-lg">
                    <div className="text-xs text-blue-700 mb-2 font-medium">Tags selezionati:</div>
                    <div className="flex flex-wrap gap-1">
                      {filters.selectedTags.map(tag => (
                        <Badge
                          key={tag}
                          variant="secondary"
                          className="bg-blue-100 text-blue-800 cursor-pointer hover:bg-blue-200"
                          onClick={() => toggleTag(tag)}
                        >
                          {tag} <XMarkIcon className="h-3 w-3 ml-1" />
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Tutti i tags */}
                <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                  {tags.map(tag => (
                    <Badge
                      key={tag}
                      variant={filters.selectedTags.includes(tag) ? "default" : "outline"}
                      className="cursor-pointer hover:shadow-sm transition-shadow"
                      onClick={() => toggleTag(tag)}
                    >
                      <TagIcon className="h-3 w-3 mr-1" />
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
