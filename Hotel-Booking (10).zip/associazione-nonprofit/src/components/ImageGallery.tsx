"use client"

import { useState } from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import analyticsService from '@/services/AnalyticsService';

interface ImageGalleryProps {
  images: string[];
  title?: string;
}

export default function ImageGallery({ images, title }: ImageGalleryProps) {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);

  if (!images || images.length === 0) return null;

  const openLightbox = (index: number) => {
    setSelectedImage(index);
    setIsLightboxOpen(true);

    // Track analytics
    analyticsService.trackEvent('gallery', 'open-lightbox', `image-${index + 1}`, index);
  };

  const closeLightbox = () => {
    setIsLightboxOpen(false);
    setSelectedImage(null);
  };

  const nextImage = () => {
    if (selectedImage !== null) {
      const newIndex = (selectedImage + 1) % images.length;
      setSelectedImage(newIndex);
      analyticsService.trackEvent('gallery', 'navigate-next', `to-image-${newIndex + 1}`);
    }
  };

  const prevImage = () => {
    if (selectedImage !== null) {
      const newIndex = selectedImage === 0 ? images.length - 1 : selectedImage - 1;
      setSelectedImage(newIndex);
      analyticsService.trackEvent('gallery', 'navigate-prev', `to-image-${newIndex + 1}`);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowRight') nextImage();
    if (e.key === 'ArrowLeft') prevImage();
  };

  return (
    <>
      {/* Galleria Griglia */}
      <Card className="p-6 mb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold flex items-center gap-2">
            📸 Galleria Foto
            {title && <span className="text-gray-600">- {title}</span>}
          </h3>
          <Badge variant="outline">{images.length} foto</Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {images.map((image, index) => (
            <div
              key={index}
              className="relative group cursor-pointer overflow-hidden rounded-lg border"
              onClick={() => openLightbox(index)}
            >
              <img
                src={image}
                alt={`Foto ${index + 1}`}
                className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105"
              />

              {/* Overlay hover */}
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-center justify-center">
                <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="bg-white rounded-full p-3 shadow-lg">
                    <span className="text-2xl">🔍</span>
                  </div>
                </div>
              </div>

              {/* Numero foto */}
              <div className="absolute top-2 right-2 bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
                {index + 1}/{images.length}
              </div>
            </div>
          ))}
        </div>

        <p className="text-sm text-gray-600 mt-4 text-center">
          📸 Clicca su un'immagine per ingrandirla • Usa ← → per navigare
        </p>
      </Card>

      {/* Lightbox */}
      {isLightboxOpen && selectedImage !== null && (
        <div
          className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4"
          onClick={closeLightbox}
          onKeyDown={handleKeyDown}
          tabIndex={0}
          role="dialog"
          aria-label="Galleria foto"
        >
          {/* Pulsante chiudi */}
          <Button
            variant="outline"
            size="sm"
            className="absolute top-4 right-4 z-10 bg-white hover:bg-gray-100"
            onClick={closeLightbox}
          >
            ✕ Chiudi
          </Button>

          {/* Contatore */}
          <div className="absolute top-4 left-4 z-10 bg-black bg-opacity-70 text-white px-3 py-1 rounded">
            {selectedImage + 1} di {images.length}
          </div>

          {/* Navigazione sinistra */}
          {images.length > 1 && (
            <Button
              variant="outline"
              size="lg"
              className="absolute left-4 top-1/2 transform -translate-y-1/2 z-10 bg-white bg-opacity-20 hover:bg-opacity-40 text-white border-white"
              onClick={(e) => {
                e.stopPropagation();
                prevImage();
              }}
            >
              ← Precedente
            </Button>
          )}

          {/* Immagine principale */}
          <div className="max-w-full max-h-full flex items-center justify-center">
            <img
              src={images[selectedImage]}
              alt={`Foto ${selectedImage + 1}`}
              className="max-w-full max-h-full object-contain"
              onClick={(e) => e.stopPropagation()}
            />
          </div>

          {/* Navigazione destra */}
          {images.length > 1 && (
            <Button
              variant="outline"
              size="lg"
              className="absolute right-4 top-1/2 transform -translate-y-1/2 z-10 bg-white bg-opacity-20 hover:bg-opacity-40 text-white border-white"
              onClick={(e) => {
                e.stopPropagation();
                nextImage();
              }}
            >
              Successiva →
            </Button>
          )}

          {/* Thumbnails */}
          {images.length > 1 && (
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-10">
              <div className="flex gap-2 bg-black bg-opacity-70 p-2 rounded-lg max-w-screen-sm overflow-x-auto">
                {images.map((image, index) => (
                  <img
                    key={index}
                    src={image}
                    alt={`Thumbnail ${index + 1}`}
                    className={`w-16 h-16 object-cover rounded cursor-pointer border-2 transition-all ${
                      index === selectedImage
                        ? 'border-white scale-105'
                        : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedImage(index);
                    }}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Istruzioni */}
          <div className="absolute bottom-16 left-1/2 transform -translate-x-1/2 text-white text-sm text-center bg-black bg-opacity-50 px-4 py-2 rounded">
            <p>Usa ← → per navigare • ESC per chiudere • Click esterno per uscire</p>
          </div>
        </div>
      )}
    </>
  );
}
