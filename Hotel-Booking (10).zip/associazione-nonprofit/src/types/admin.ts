// Tipi per il sistema admin
export interface AdminUser {
  id: number;
  email: string;
  name: string;
  role: AdminRole;
  permissions: Permission[];
  loginTime: number;
  keepLoggedIn: boolean;
  lastActivity?: number;
}

export type AdminRole = 'super-admin' | 'admin' | 'moderatore' | 'editor';

export type Permission =
  | 'dashboard:view'
  | 'soci:view' | 'soci:create' | 'soci:edit' | 'soci:delete'
  | 'finanze:view' | 'finanze:create' | 'finanze:edit' | 'finanze:delete'
  | 'blog:view' | 'blog:create' | 'blog:edit' | 'blog:delete'
  | 'newsletter:view' | 'newsletter:send'
  | 'votazioni:view' | 'votazioni:create' | 'votazioni:manage'
  | 'partner:view' | 'partner:create' | 'partner:edit' | 'partner:delete'
  | 'feedback:view'
  | 'system:settings' | 'system:users' | 'system:logs'
  | 'notifications:manage';

export interface RoleDefinition {
  name: string;
  description: string;
  permissions: Permission[];
  color: string;
  icon: string;
}

export const ROLE_DEFINITIONS: Record<AdminRole, RoleDefinition> = {
  'super-admin': {
    name: 'Super Amministratore',
    description: 'Accesso completo a tutte le funzioni',
    permissions: [
      'dashboard:view',
      'soci:view', 'soci:create', 'soci:edit', 'soci:delete',
      'finanze:view', 'finanze:create', 'finanze:edit', 'finanze:delete',
      'blog:view', 'blog:create', 'blog:edit', 'blog:delete',
      'newsletter:view', 'newsletter:send',
      'votazioni:view', 'votazioni:create', 'votazioni:manage',
      'partner:view', 'partner:create', 'partner:edit', 'partner:delete',
      'feedback:view',
      'system:settings', 'system:users', 'system:logs',
      'notifications:manage'
    ],
    color: 'bg-red-600',
    icon: '👑'
  },
  'admin': {
    name: 'Amministratore',
    description: 'Gestione completa eccetto impostazioni sistema',
    permissions: [
      'dashboard:view',
      'soci:view', 'soci:create', 'soci:edit', 'soci:delete',
      'finanze:view', 'finanze:create', 'finanze:edit', 'finanze:delete',
      'blog:view', 'blog:create', 'blog:edit', 'blog:delete',
      'newsletter:view', 'newsletter:send',
      'votazioni:view', 'votazioni:create', 'votazioni:manage',
      'partner:view', 'partner:create', 'partner:edit', 'partner:delete',
      'feedback:view',
      'system:logs'
    ],
    color: 'bg-purple-600',
    icon: '👨‍💼'
  },
  'moderatore': {
    name: 'Moderatore',
    description: 'Gestione contenuti e utenti',
    permissions: [
      'dashboard:view',
      'soci:view', 'soci:edit',
      'finanze:view',
      'blog:view', 'blog:create', 'blog:edit',
      'newsletter:view',
      'votazioni:view', 'votazioni:manage',
      'partner:view', 'partner:edit',
      'feedback:view'
    ],
    color: 'bg-blue-600',
    icon: '🛡️'
  },
  'editor': {
    name: 'Editor',
    description: 'Solo gestione contenuti',
    permissions: [
      'dashboard:view',
      'soci:view',
      'finanze:view',
      'blog:view', 'blog:create', 'blog:edit',
      'newsletter:view',
      'votazioni:view',
      'partner:view',
      'feedback:view'
    ],
    color: 'bg-green-600',
    icon: '✍️'
  }
};

// Utility functions
export function hasPermission(user: AdminUser, permission: Permission): boolean {
  return user.permissions.includes(permission);
}

export function getRoleDefinition(role: AdminRole): RoleDefinition {
  return ROLE_DEFINITIONS[role];
}

export function canAccessRoute(user: AdminUser, route: string): boolean {
  const routePermissions: Record<string, Permission[]> = {
    '/admin': ['dashboard:view'],
    '/admin/soci': ['soci:view'],
    '/admin/finanze': ['finanze:view'],
    '/admin/blog': ['blog:view'],
    '/admin/newsletter': ['newsletter:view'],
    '/admin/votazioni': ['votazioni:view'],
    '/admin/partner': ['partner:view'],
    '/admin/feedback': ['feedback:view'],
    '/admin/profilo': ['dashboard:view'], // Tutti possono vedere il proprio profilo
    '/admin/attivita': ['system:logs'],
    '/admin/impostazioni': ['system:settings']
  };

  const requiredPermissions = routePermissions[route];
  if (!requiredPermissions) return true; // Route non protetta

  return requiredPermissions.some(permission => hasPermission(user, permission));
}
