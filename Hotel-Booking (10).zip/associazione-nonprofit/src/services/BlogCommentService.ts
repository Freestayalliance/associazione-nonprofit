"use client"

interface BlogComment {
  id: string;
  articoloId: number;
  autore: string;
  email: string;
  ruolo: 'socio' | 'albergatore' | 'admin' | 'guest';
  contenuto: string;
  timestamp: string;
  stato: 'approvato' | 'in_moderazione' | 'rifiutato';
  risposteA?: string; // ID del commento padre per le risposte
  likes: number;
  flagged: boolean;
  moderatoreId?: string;
  motivoRifiuto?: string;
}

interface CommentStats {
  totali: number;
  approvati: number;
  inModerazione: number;
  rifiutati: number;
  oggi: number;
  perArticolo: Record<number, number>;
  perRuolo: Record<string, number>;
}

class BlogCommentService {
  private readonly STORAGE_KEY = 'blog-commenti';
  private readonly CONFIG_KEY = 'blog-config';

  constructor() {
    this.initializeStorage();
    this.initializeConfig();
  }

  // Inizializza lo storage con dati di esempio
  private initializeStorage(): void {
    if (!this.isBrowser()) return;

    const existing = localStorage.getItem(this.STORAGE_KEY);
    if (!existing) {
      const exampleComments: BlogComment[] = [
        {
          id: 'comm_001',
          articoloId: 1,
          autore: 'Marco Verdi',
          email: 'marco.verdi@email.com',
          ruolo: 'socio',
          contenuto: 'Articolo molto interessante! La trasparenza è davvero il punto di forza della nostra associazione.',
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          stato: 'approvato',
          likes: 3,
          flagged: false
        },
        {
          id: 'comm_002',
          articoloId: 1,
          autore: 'Anna Rossi',
          email: 'anna.rossi@email.com',
          ruolo: 'socio',
          contenuto: 'Sono d\'accordo con Marco. È importante vedere come vengono utilizzati i fondi.',
          timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
          stato: 'approvato',
          risposteA: 'comm_001',
          likes: 1,
          flagged: false
        },
        {
          id: 'comm_003',
          articoloId: 2,
          autore: 'Hotel Manager',
          email: 'manager@hotel.com',
          ruolo: 'albergatore',
          contenuto: 'Il nuovo sistema di votazione online semplifica molto la partecipazione. Complimenti!',
          timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
          stato: 'in_moderazione',
          likes: 0,
          flagged: false
        },
        {
          id: 'comm_004',
          articoloId: 1,
          autore: 'Giulia Bianchi',
          email: 'giulia.bianchi@email.com',
          ruolo: 'guest',
          contenuto: 'Perfetto! Finalmente un\'associazione che mostra davvero dove vanno i soldi. Continuerò a seguire i vostri progetti.',
          timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
          stato: 'in_moderazione',
          likes: 0,
          flagged: false
        },
        {
          id: 'comm_005',
          articoloId: 3,
          autore: 'Tech Enthusiast',
          email: 'tech@example.com',
          ruolo: 'guest',
          contenuto: 'La partnership con TechCorp è una mossa intelligente. Spero porterà innovazioni concrete per la comunità.',
          timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
          stato: 'in_moderazione',
          likes: 0,
          flagged: false
        }
      ];

      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(exampleComments));
    }
  }

  private isBrowser(): boolean {
    return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
  }

  // Ottiene tutti i commenti
  public getAllComments(): BlogComment[] {
    if (!this.isBrowser()) return [];

    try {
      const comments = localStorage.getItem(this.STORAGE_KEY);
      return comments ? JSON.parse(comments) : [];
    } catch (error) {
      console.error('Errore nel caricamento commenti:', error);
      return [];
    }
  }

  // Ottiene commenti per un articolo specifico
  public getCommentsByArticle(articoloId: number, includeModeration = false, userEmail?: string): BlogComment[] {
    const allComments = this.getAllComments();

    return allComments.filter(comment => {
      if (comment.articoloId !== articoloId) return false;

      if (!includeModeration && comment.stato !== 'approvato') {
        // Mostra sempre i commenti dell'utente corrente anche se in moderazione
        if (userEmail && comment.email === userEmail) {
          return true;
        }
        return false;
      }

      return true;
    }).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }

  // Ottiene risposte a un commento
  public getReplies(commentId: string): BlogComment[] {
    const allComments = this.getAllComments();
    return allComments.filter(comment => comment.risposteA === commentId && comment.stato === 'approvato');
  }

  // Aggiunge un nuovo commento
  public addComment(
    articoloId: number,
    autore: string,
    email: string,
    contenuto: string,
    ruolo: 'socio' | 'albergatore' | 'admin' | 'guest' = 'guest',
    risposteA?: string
  ): { success: boolean; commentId?: string; message: string } {
    if (!this.isBrowser()) {
      return { success: false, message: 'Storage non disponibile' };
    }

    try {
      // Validazione
      if (!contenuto.trim() || contenuto.length < 10) {
        return { success: false, message: 'Il commento deve contenere almeno 10 caratteri' };
      }

      if (contenuto.length > 1000) {
        return { success: false, message: 'Il commento non può superare i 1000 caratteri' };
      }

      // Filtraggio contenuto inappropriato (semplice)
      const paroleVietate = ['spam', 'fake', 'truffa'];
      const contenutoLower = contenuto.toLowerCase();
      const contieneParoleVietate = paroleVietate.some(parola => contenutoLower.includes(parola));

      // Ottieni configurazione approvazione automatica
      const config = this.getConfig();
      const autoApprove = config.autoApproveComments;

      // Determina lo stato del commento
      let statoCommento: 'approvato' | 'in_moderazione';
      if (contieneParoleVietate) {
        // Se contiene parole vietate, sempre in moderazione
        statoCommento = 'in_moderazione';
      } else if (ruolo === 'admin') {
        // Admin sempre approvato
        statoCommento = 'approvato';
      } else if (autoApprove) {
        // Se approvazione automatica è attiva, approva subito
        statoCommento = 'approvato';
      } else {
        // Altrimenti, moderazione manuale
        statoCommento = 'in_moderazione';
      }

      const newComment: BlogComment = {
        id: `comm_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        articoloId,
        autore: autore.trim(),
        email: email.trim(),
        ruolo,
        contenuto: contenuto.trim(),
        timestamp: new Date().toISOString(),
        stato: statoCommento,
        risposteA,
        likes: 0,
        flagged: contieneParoleVietate
      };

      const allComments = this.getAllComments();
      allComments.push(newComment);
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(allComments));

      // Invia notifica ai moderatori se necessario
      if (newComment.stato === 'in_moderazione') {
        this.notifyModerators(newComment);
      }

      return {
        success: true,
        commentId: newComment.id,
        message: newComment.stato === 'approvato'
          ? 'Commento pubblicato!'
          : 'Commento inviato! Sarà visibile dopo la moderazione.'
      };

    } catch (error) {
      console.error('Errore nell\'aggiunta commento:', error);
      return { success: false, message: 'Errore nel salvataggio del commento' };
    }
  }

  // Modera un commento (solo admin)
  public moderateComment(
    commentId: string,
    azione: 'approva' | 'rifiuta',
    moderatoreId: string,
    motivoRifiuto?: string
  ): { success: boolean; message: string } {
    if (!this.isBrowser()) {
      return { success: false, message: 'Storage non disponibile' };
    }

    try {
      const allComments = this.getAllComments();
      const commentIndex = allComments.findIndex(c => c.id === commentId);

      if (commentIndex === -1) {
        return { success: false, message: 'Commento non trovato' };
      }

      allComments[commentIndex] = {
        ...allComments[commentIndex],
        stato: azione === 'approva' ? 'approvato' : 'rifiutato',
        moderatoreId,
        motivoRifiuto: azione === 'rifiuta' ? motivoRifiuto : undefined
      };

      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(allComments));

      return {
        success: true,
        message: `Commento ${azione === 'approva' ? 'approvato' : 'rifiutato'} con successo`
      };

    } catch (error) {
      console.error('Errore nella moderazione:', error);
      return { success: false, message: 'Errore nella moderazione del commento' };
    }
  }

  // Gestisce i like di un commento
  public toggleLike(commentId: string): { success: boolean; newLikes: number } {
    if (!this.isBrowser()) {
      return { success: false, newLikes: 0 };
    }

    try {
      const allComments = this.getAllComments();
      const commentIndex = allComments.findIndex(c => c.id === commentId);

      if (commentIndex === -1) {
        return { success: false, newLikes: 0 };
      }

      // Controllo se l'utente ha già messo like (semplificato)
      const userLikes = JSON.parse(localStorage.getItem('user-comment-likes') || '[]');
      const hasLiked = userLikes.includes(commentId);

      if (hasLiked) {
        // Rimuovi like
        allComments[commentIndex].likes = Math.max(0, allComments[commentIndex].likes - 1);
        const newUserLikes = userLikes.filter((id: string) => id !== commentId);
        localStorage.setItem('user-comment-likes', JSON.stringify(newUserLikes));
      } else {
        // Aggiungi like
        allComments[commentIndex].likes += 1;
        userLikes.push(commentId);
        localStorage.setItem('user-comment-likes', JSON.stringify(userLikes));
      }

      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(allComments));

      return {
        success: true,
        newLikes: allComments[commentIndex].likes
      };

    } catch (error) {
      console.error('Errore nel toggle like:', error);
      return { success: false, newLikes: 0 };
    }
  }

  // Segnala un commento come inappropriato
  public flagComment(commentId: string, motivo: string): { success: boolean; message: string } {
    if (!this.isBrowser()) {
      return { success: false, message: 'Storage non disponibile' };
    }

    try {
      const allComments = this.getAllComments();
      const commentIndex = allComments.findIndex(c => c.id === commentId);

      if (commentIndex === -1) {
        return { success: false, message: 'Commento non trovato' };
      }

      allComments[commentIndex].flagged = true;
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(allComments));

      // Notifica i moderatori
      this.notifyModerators(allComments[commentIndex], `Commento segnalato: ${motivo}`);

      return { success: true, message: 'Commento segnalato ai moderatori' };

    } catch (error) {
      console.error('Errore nella segnalazione:', error);
      return { success: false, message: 'Errore nella segnalazione' };
    }
  }

  // Elimina un commento (solo admin o autore)
  public deleteComment(commentId: string, userEmail: string, isAdmin = false): { success: boolean; message: string } {
    if (!this.isBrowser()) {
      return { success: false, message: 'Storage non disponibile' };
    }

    try {
      const allComments = this.getAllComments();
      const comment = allComments.find(c => c.id === commentId);

      if (!comment) {
        return { success: false, message: 'Commento non trovato' };
      }

      // Controllo permessi
      if (!isAdmin && comment.email !== userEmail) {
        return { success: false, message: 'Non hai i permessi per eliminare questo commento' };
      }

      // Rimuovi il commento e le sue risposte
      const filteredComments = allComments.filter(c => c.id !== commentId && c.risposteA !== commentId);
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(filteredComments));

      return { success: true, message: 'Commento eliminato con successo' };

    } catch (error) {
      console.error('Errore nell\'eliminazione:', error);
      return { success: false, message: 'Errore nell\'eliminazione del commento' };
    }
  }

  // Ottiene statistiche sui commenti
  public getCommentStats(): CommentStats {
    const allComments = this.getAllComments();
    const today = new Date().toDateString();

    const stats: CommentStats = {
      totali: allComments.length,
      approvati: allComments.filter(c => c.stato === 'approvato').length,
      inModerazione: allComments.filter(c => c.stato === 'in_moderazione').length,
      rifiutati: allComments.filter(c => c.stato === 'rifiutato').length,
      oggi: allComments.filter(c => new Date(c.timestamp).toDateString() === today).length,
      perArticolo: {},
      perRuolo: {}
    };

    // Calcola commenti per articolo
    for (const comment of allComments) {
      if (comment.stato === 'approvato') {
        stats.perArticolo[comment.articoloId] = (stats.perArticolo[comment.articoloId] || 0) + 1;
      }
      stats.perRuolo[comment.ruolo] = (stats.perRuolo[comment.ruolo] || 0) + 1;
    }

    return stats;
  }

  // Approva tutti i commenti in moderazione (funzione admin)
  public approveAllPendingComments(moderatoreId: string): { success: boolean; approvedCount: number; message: string } {
    if (!this.isBrowser()) {
      return { success: false, approvedCount: 0, message: 'Storage non disponibile' };
    }

    try {
      const allComments = this.getAllComments();
      const commentsToApprove = allComments.filter(c => c.stato === 'in_moderazione');

      if (commentsToApprove.length === 0) {
        return { success: true, approvedCount: 0, message: 'Nessun commento da approvare' };
      }

      const updatedComments = allComments.map(comment =>
        comment.stato === 'in_moderazione'
          ? { ...comment, stato: 'approvato' as const, moderatoreId }
          : comment
      );

      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(updatedComments));

      return {
        success: true,
        approvedCount: commentsToApprove.length,
        message: `${commentsToApprove.length} commenti approvati automaticamente`
      };

    } catch (error) {
      console.error('Errore nell\'approvazione batch:', error);
      return { success: false, approvedCount: 0, message: 'Errore nell\'approvazione automatica' };
    }
  }

  // Elimina commenti in batch (funzione admin)
  public deleteMultipleComments(commentIds: string[], isAdmin = true): { success: boolean; deletedCount: number; message: string } {
    if (!this.isBrowser()) {
      return { success: false, deletedCount: 0, message: 'Storage non disponibile' };
    }

    if (!isAdmin) {
      return { success: false, deletedCount: 0, message: 'Permessi insufficienti' };
    }

    try {
      const allComments = this.getAllComments();
      const filteredComments = allComments.filter(c =>
        !commentIds.includes(c.id) && !commentIds.includes(c.risposteA || '')
      );

      const deletedCount = allComments.length - filteredComments.length;
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(filteredComments));

      return {
        success: true,
        deletedCount,
        message: `${deletedCount} commenti eliminati`
      };

    } catch (error) {
      console.error('Errore nell\'eliminazione batch:', error);
      return { success: false, deletedCount: 0, message: 'Errore nell\'eliminazione' };
    }
  }

  // Ottiene commenti per moderazione
  public getCommentsForModeration(): BlogComment[] {
    const allComments = this.getAllComments();
    return allComments.filter(c => c.stato === 'in_moderazione' || c.flagged)
                     .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  // Invia notifiche ai moderatori
  private notifyModerators(comment: BlogComment, customMessage?: string): void {
    if (!this.isBrowser()) return;

    try {
      // Integrazione con il sistema di notifiche esistente
      const notification = {
        id: `blog_comment_${Date.now()}`,
        type: 'blog' as const,
        title: 'Nuovo Commento da Moderare',
        message: customMessage || `Nuovo commento di ${comment.autore} sull'articolo ${comment.articoloId}`,
        priority: 'medium' as const,
        timestamp: new Date().toISOString(),
        read: false,
        actionUrl: `/admin/blog?tab=commenti&highlight=${comment.id}`
      };

      // Salva nel sistema notifiche admin
      const existingNotifications = JSON.parse(localStorage.getItem('admin-notifications') || '[]');
      existingNotifications.unshift(notification);
      localStorage.setItem('admin-notifications', JSON.stringify(existingNotifications));

    } catch (error) {
      console.error('Errore nell\'invio notifica:', error);
    }
  }

  // Verifica se l'utente ha messo like a un commento
  public hasUserLiked(commentId: string): boolean {
    if (!this.isBrowser()) return false;

    try {
      const userLikes = JSON.parse(localStorage.getItem('user-comment-likes') || '[]');
      return userLikes.includes(commentId);
    } catch {
      return false;
    }
  }

  // Ottiene il numero totale di commenti per un articolo
  public getCommentCount(articoloId: number): number {
    return this.getCommentsByArticle(articoloId).length;
  }

  // Pulisce commenti vecchi (utility per admin)
  public cleanOldComments(daysOld = 365): { success: boolean; removedCount: number } {
    if (!this.isBrowser()) {
      return { success: false, removedCount: 0 };
    }

    try {
      const allComments = this.getAllComments();
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysOld);

      const filteredComments = allComments.filter(comment => {
        return new Date(comment.timestamp) > cutoffDate;
      });

      const removedCount = allComments.length - filteredComments.length;
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(filteredComments));

      return { success: true, removedCount };

    } catch (error) {
      console.error('Errore nella pulizia commenti:', error);
      return { success: false, removedCount: 0 };
    }
  }

  // Inizializza la configurazione del blog
  private initializeConfig(): void {
    if (!this.isBrowser()) return;

    const existingConfig = localStorage.getItem(this.CONFIG_KEY);
    if (!existingConfig) {
      const defaultConfig = {
        autoApproveComments: false, // Moderazione manuale di default
        allowGuestComments: true,
        requireEmail: true,
        maxCommentLength: 1000,
        enableNotifications: true
      };
      localStorage.setItem(this.CONFIG_KEY, JSON.stringify(defaultConfig));
    }
  }

  // Ottiene la configurazione attuale
  public getConfig(): any {
    if (!this.isBrowser()) return { autoApproveComments: false };

    try {
      const config = localStorage.getItem(this.CONFIG_KEY);
      return config ? JSON.parse(config) : { autoApproveComments: false };
    } catch {
      return { autoApproveComments: false };
    }
  }

  // Aggiorna la configurazione
  public updateConfig(newConfig: any): { success: boolean; message: string } {
    if (!this.isBrowser()) {
      return { success: false, message: 'Storage non disponibile' };
    }

    try {
      const currentConfig = this.getConfig();
      const updatedConfig = { ...currentConfig, ...newConfig };
      localStorage.setItem(this.CONFIG_KEY, JSON.stringify(updatedConfig));

      return {
        success: true,
        message: `Configurazione aggiornata. Approvazione automatica: ${updatedConfig.autoApproveComments ? 'ATTIVA' : 'DISATTIVA'}`
      };
    } catch (error) {
      return { success: false, message: 'Errore nell\'aggiornamento configurazione' };
    }
  }
}

// Esporta un'istanza singleton
export const blogCommentService = new BlogCommentService();
export default blogCommentService;
export type { BlogComment, CommentStats };
