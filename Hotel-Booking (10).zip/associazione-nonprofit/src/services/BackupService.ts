// services/BackupService.ts
"use client"

interface BackupData {
  timestamp: string;
  version: string;
  checksum: string;
  data: {
    soci?: any[];
    transazioni?: any[];
    articoli?: any[];
    commenti?: any[];
    votazioni?: any[];
    notifiche?: any[];
    analytics?: any[];
    configurazioni?: any;
    admin?: any[];
    newsletter?: any[];
    approvazioni?: any[];
    feedback?: any[];
  };
  metadata: {
    size: number;
    createdBy: string;
    type: 'manual' | 'automatic' | 'scheduled';
    description?: string;
    conflictResolution?: string;
  };
}

interface BackupConfig {
  autoBackupEnabled: boolean;
  backupFrequency: 'hourly' | 'daily' | 'weekly' | 'monthly';
  maxBackups: number;
  compressionEnabled: boolean;
  encryptionEnabled: boolean;
  cloudSyncEnabled: boolean;
  notifyOnBackup: boolean;
  dataIntegrityChecks: boolean;
}

interface BackupStats {
  totalBackups: number;
  totalSize: number;
  lastBackup: string | null;
  nextScheduledBackup: string | null;
  successRate: number;
  averageSize: number;
  oldestBackup: string | null;
  integrityChecksPassed: number;
  integrityChecksFailed: number;
}

interface DataIntegrityReport {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  checkedTables: string[];
  summary: {
    totalRecords: number;
    validRecords: number;
    invalidRecords: number;
    missingReferences: number;
    duplicates: number;
  };
}

class BackupService {
  private static instance: BackupService;
  private readonly BACKUP_KEY = 'associazione-backups';
  private readonly CONFIG_KEY = 'backup-config';
  private readonly STATS_KEY = 'backup-stats';
  private readonly SCHEDULE_KEY = 'backup-schedule';
  private readonly MAX_BACKUP_SIZE = 50 * 1024 * 1024; // 50MB
  private readonly CURRENT_VERSION = '1.0.0';

  private constructor() {
    this.initializeScheduling();
  }

  public static getInstance(): BackupService {
    if (!BackupService.instance) {
      BackupService.instance = new BackupService();
    }
    return BackupService.instance;
  }

  private isBrowser(): boolean {
    return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
  }

  // Configurazione Backup
  public getConfig(): BackupConfig {
    if (!this.isBrowser()) return this.getDefaultConfig();

    try {
      const configData = localStorage.getItem(this.CONFIG_KEY);
      if (configData) {
        return { ...this.getDefaultConfig(), ...JSON.parse(configData) };
      }
    } catch (error) {
      console.error('Errore nel caricamento configurazione backup:', error);
    }
    return this.getDefaultConfig();
  }

  private getDefaultConfig(): BackupConfig {
    return {
      autoBackupEnabled: true,
      backupFrequency: 'daily',
      maxBackups: 30,
      compressionEnabled: true,
      encryptionEnabled: false,
      cloudSyncEnabled: false,
      notifyOnBackup: true,
      dataIntegrityChecks: true,
    };
  }

  public updateConfig(newConfig: Partial<BackupConfig>): boolean {
    if (!this.isBrowser()) return false;

    try {
      const currentConfig = this.getConfig();
      const updatedConfig = { ...currentConfig, ...newConfig };
      localStorage.setItem(this.CONFIG_KEY, JSON.stringify(updatedConfig));

      // Rischeduler se necessario
      if (newConfig.autoBackupEnabled !== undefined || newConfig.backupFrequency !== undefined) {
        this.rescheduleBackups();
      }

      return true;
    } catch (error) {
      console.error('Errore nell\'aggiornamento configurazione backup:', error);
      return false;
    }
  }

  // Gestione Backup
  public async createBackup(description?: string, type: 'manual' | 'automatic' = 'manual'): Promise<{ success: boolean; message: string; backupId?: string }> {
    if (!this.isBrowser()) {
      return { success: false, message: 'Backup non disponibile lato server' };
    }

    try {
      // Raccogli tutti i dati
      const data = this.collectAllData();

      // Verifica integrità se abilitata
      const config = this.getConfig();
      if (config.dataIntegrityChecks) {
        const integrityReport = this.checkDataIntegrity(data);
        if (!integrityReport.isValid) {
          return {
            success: false,
            message: `Errori di integrità rilevati: ${integrityReport.errors.join(', ')}`
          };
        }
      }

      // Crea backup
      const backupId = this.generateBackupId();
      const backup: BackupData = {
        timestamp: new Date().toISOString(),
        version: this.CURRENT_VERSION,
        checksum: this.calculateChecksum(data),
        data,
        metadata: {
          size: JSON.stringify(data).length,
          createdBy: this.getCurrentUser(),
          type,
          description: description || `Backup ${type} del ${new Date().toLocaleString('it-IT')}`
        }
      };

      // Comprimi se abilitato
      if (config.compressionEnabled) {
        backup.data = this.compressData(backup.data);
      }

      // Salva backup
      const saved = this.saveBackup(backupId, backup);
      if (!saved) {
        return { success: false, message: 'Errore nel salvataggio del backup' };
      }

      // Aggiorna statistiche
      this.updateStats(backup);

      // Pulisci vecchi backup
      this.cleanOldBackups();

      // Notifica se richiesta
      if (config.notifyOnBackup && type === 'automatic') {
        this.notifyBackupCompleted(backupId, backup);
      }

      return {
        success: true,
        message: `Backup creato con successo (${this.formatBytes(backup.metadata.size)})`,
        backupId
      };

    } catch (error) {
      console.error('Errore nella creazione backup:', error);
      return { success: false, message: `Errore: ${error.message}` };
    }
  }

  public getBackupList(): Array<{ id: string; backup: BackupData }> {
    if (!this.isBrowser()) return [];

    try {
      const backupsData = localStorage.getItem(this.BACKUP_KEY);
      if (backupsData) {
        const backups = JSON.parse(backupsData);
        return Object.entries(backups).map(([id, backup]) => ({
          id,
          backup: backup as BackupData
        })).sort((a, b) => new Date(b.backup.timestamp).getTime() - new Date(a.backup.timestamp).getTime());
      }
    } catch (error) {
      console.error('Errore nel caricamento lista backup:', error);
    }
    return [];
  }

  public async restoreBackup(backupId: string, options?: { selectiveRestore?: string[]; createRestorePoint?: boolean }): Promise<{ success: boolean; message: string }> {
    if (!this.isBrowser()) {
      return { success: false, message: 'Restore non disponibile lato server' };
    }

    try {
      // Carica backup
      const backup = this.loadBackup(backupId);
      if (!backup) {
        return { success: false, message: 'Backup non trovato' };
      }

      // Verifica integrità
      const integrityCheck = this.verifyBackupIntegrity(backup);
      if (!integrityCheck.isValid) {
        return {
          success: false,
          message: `Backup corrotto: ${integrityCheck.errors.join(', ')}`
        };
      }

      // Crea punto di ripristino se richiesto
      if (options?.createRestorePoint !== false) {
        const restorePoint = await this.createBackup('Punto di ripristino prima del restore', 'manual');
        if (!restorePoint.success) {
          return { success: false, message: 'Impossibile creare punto di ripristino' };
        }
      }

      // Decomprimi se necessario
      let dataToRestore = backup.data;
      if (this.isCompressed(backup.data)) {
        dataToRestore = this.decompressData(backup.data);
      }

      // Restore selettivo o completo
      const restoreKeys = options?.selectiveRestore || Object.keys(dataToRestore);
      let restoredCount = 0;

      for (const key of restoreKeys) {
        if (dataToRestore[key]) {
          const storageKey = this.getStorageKeyForData(key);
          if (storageKey) {
            localStorage.setItem(storageKey, JSON.stringify(dataToRestore[key]));
            restoredCount++;
          }
        }
      }

      // Aggiorna statistiche
      this.updateRestoreStats(backup, restoredCount);

      return {
        success: true,
        message: `Restore completato: ${restoredCount} sezioni ripristinate`
      };

    } catch (error) {
      console.error('Errore nel restore backup:', error);
      return { success: false, message: `Errore: ${error.message}` };
    }
  }

  public deleteBackup(backupId: string): { success: boolean; message: string } {
    if (!this.isBrowser()) {
      return { success: false, message: 'Operazione non disponibile lato server' };
    }

    try {
      const backupsData = localStorage.getItem(this.BACKUP_KEY);
      if (backupsData) {
        const backups = JSON.parse(backupsData);
        if (backups[backupId]) {
          delete backups[backupId];
          localStorage.setItem(this.BACKUP_KEY, JSON.stringify(backups));
          return { success: true, message: 'Backup eliminato con successo' };
        }
      }
      return { success: false, message: 'Backup non trovato' };
    } catch (error) {
      console.error('Errore nell\'eliminazione backup:', error);
      return { success: false, message: `Errore: ${error.message}` };
    }
  }

  // Export/Import
  public exportBackup(backupId: string): { success: boolean; message: string; data?: string } {
    if (!this.isBrowser()) {
      return { success: false, message: 'Export non disponibile lato server' };
    }

    try {
      const backup = this.loadBackup(backupId);
      if (!backup) {
        return { success: false, message: 'Backup non trovato' };
      }

      const exportData = {
        backup,
        exportInfo: {
          exportedAt: new Date().toISOString(),
          exportedBy: this.getCurrentUser(),
          associationName: 'Associazione Non-Profit',
          backupServiceVersion: this.CURRENT_VERSION
        }
      };

      const jsonData = JSON.stringify(exportData, null, 2);
      return {
        success: true,
        message: `Export completato (${this.formatBytes(jsonData.length)})`,
        data: jsonData
      };

    } catch (error) {
      console.error('Errore nell\'export backup:', error);
      return { success: false, message: `Errore: ${error.message}` };
    }
  }

  public downloadBackup(backupId: string): void {
    const exportResult = this.exportBackup(backupId);
    if (exportResult.success && exportResult.data) {
      const blob = new Blob([exportResult.data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `associazione-backup-${backupId}-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  }

  public async importBackup(jsonData: string): Promise<{ success: boolean; message: string; backupId?: string }> {
    if (!this.isBrowser()) {
      return { success: false, message: 'Import non disponibile lato server' };
    }

    try {
      const importData = JSON.parse(jsonData);

      // Verifica formato
      if (!importData.backup || !importData.exportInfo) {
        return { success: false, message: 'Formato file non valido' };
      }

      const backup = importData.backup as BackupData;

      // Verifica integrità
      const integrityCheck = this.verifyBackupIntegrity(backup);
      if (!integrityCheck.isValid) {
        return {
          success: false,
          message: `Backup corrotto: ${integrityCheck.errors.join(', ')}`
        };
      }

      // Genera nuovo ID e salva
      const newBackupId = this.generateBackupId();
      backup.metadata = {
        ...backup.metadata,
        type: 'manual',
        description: `Backup importato da ${importData.exportInfo.exportedBy} il ${new Date().toLocaleString('it-IT')}`
      };

      const saved = this.saveBackup(newBackupId, backup);
      if (!saved) {
        return { success: false, message: 'Errore nel salvataggio del backup importato' };
      }

      this.updateStats(backup);

      return {
        success: true,
        message: 'Backup importato con successo',
        backupId: newBackupId
      };

    } catch (error) {
      console.error('Errore nell\'import backup:', error);
      return { success: false, message: `Errore: ${error.message}` };
    }
  }

  // Data Integrity
  public checkDataIntegrity(data?: any): DataIntegrityReport {
    const dataToCheck = data || this.collectAllData();
    const report: DataIntegrityReport = {
      isValid: true,
      errors: [],
      warnings: [],
      checkedTables: [],
      summary: {
        totalRecords: 0,
        validRecords: 0,
        invalidRecords: 0,
        missingReferences: 0,
        duplicates: 0
      }
    };

    try {
      // Verifica soci
      if (dataToCheck.soci) {
        report.checkedTables.push('soci');
        const soci = dataToCheck.soci;
        report.summary.totalRecords += soci.length;

        const emails = new Set();
        for (const socio of soci) {
          if (!socio.email || !socio.nome) {
            report.errors.push(`Socio ${socio.id}: dati obbligatori mancanti`);
            report.summary.invalidRecords++;
          } else if (emails.has(socio.email)) {
            report.errors.push(`Email duplicata: ${socio.email}`);
            report.summary.duplicates++;
          } else {
            emails.add(socio.email);
            report.summary.validRecords++;
          }
        }
      }

      // Verifica transazioni
      if (dataToCheck.transazioni) {
        report.checkedTables.push('transazioni');
        const transazioni = dataToCheck.transazioni;
        report.summary.totalRecords += transazioni.length;

        for (const transazione of transazioni) {
          if (!transazione.importo || !transazione.data || !transazione.descrizione) {
            report.errors.push(`Transazione ${transazione.id}: dati obbligatori mancanti`);
            report.summary.invalidRecords++;
          } else {
            report.summary.validRecords++;
          }
        }
      }

      // Verifica articoli
      if (dataToCheck.articoli) {
        report.checkedTables.push('articoli');
        const articoli = dataToCheck.articoli;
        report.summary.totalRecords += articoli.length;

        for (const articolo of articoli) {
          if (!articolo.titolo || !articolo.contenuto) {
            report.errors.push(`Articolo ${articolo.id}: titolo o contenuto mancante`);
            report.summary.invalidRecords++;
          } else {
            report.summary.validRecords++;
          }
        }
      }

      // Verifica commenti
      if (dataToCheck.commenti) {
        report.checkedTables.push('commenti');
        const commenti = dataToCheck.commenti;
        const articoliIds = new Set(dataToCheck.articoli?.map(a => a.id) || []);

        report.summary.totalRecords += commenti.length;

        for (const commento of commenti) {
          if (!commento.contenuto || !commento.autore) {
            report.errors.push(`Commento ${commento.id}: dati mancanti`);
            report.summary.invalidRecords++;
          } else if (!articoliIds.has(commento.articoloId)) {
            report.errors.push(`Commento ${commento.id}: riferimento articolo non valido`);
            report.summary.missingReferences++;
          } else {
            report.summary.validRecords++;
          }
        }
      }

      // Verifica votazioni
      if (dataToCheck.votazioni) {
        report.checkedTables.push('votazioni');
        const votazioni = dataToCheck.votazioni;
        report.summary.totalRecords += votazioni.length;

        const codici = new Set();
        for (const voto of votazioni) {
          if (!voto.codice || !voto.scelta) {
            report.errors.push(`Voto ${voto.id}: dati mancanti`);
            report.summary.invalidRecords++;
          } else if (codici.has(voto.codice)) {
            report.errors.push(`Codice voto duplicato: ${voto.codice}`);
            report.summary.duplicates++;
          } else {
            codici.add(voto.codice);
            report.summary.validRecords++;
          }
        }
      }

      report.isValid = report.errors.length === 0;

      if (report.summary.duplicates > 0) {
        report.warnings.push(`Rilevati ${report.summary.duplicates} record duplicati`);
      }
      if (report.summary.missingReferences > 0) {
        report.warnings.push(`Rilevati ${report.summary.missingReferences} riferimenti mancanti`);
      }

    } catch (error) {
      report.errors.push(`Errore durante la verifica: ${error.message}`);
      report.isValid = false;
    }

    return report;
  }

  // Statistiche
  public getStats(): BackupStats {
    if (!this.isBrowser()) {
      return this.getDefaultStats();
    }

    try {
      const statsData = localStorage.getItem(this.STATS_KEY);
      if (statsData) {
        return JSON.parse(statsData);
      }
    } catch (error) {
      console.error('Errore nel caricamento statistiche backup:', error);
    }
    return this.getDefaultStats();
  }

  private getDefaultStats(): BackupStats {
    return {
      totalBackups: 0,
      totalSize: 0,
      lastBackup: null,
      nextScheduledBackup: null,
      successRate: 100,
      averageSize: 0,
      oldestBackup: null,
      integrityChecksPassed: 0,
      integrityChecksFailed: 0
    };
  }

  // Metodi Privati Helper
  private collectAllData() {
    if (!this.isBrowser()) return {};

    return {
      soci: this.getLocalStorageData('associazione-soci'),
      transazioni: this.getLocalStorageData('transazioni-finanziarie'),
      articoli: this.getLocalStorageData('blog-articoli'),
      commenti: this.getLocalStorageData('blog-commenti'),
      votazioni: this.getLocalStorageData('voti-soci'),
      notifiche: this.getLocalStorageData('admin-notifications'),
      analytics: this.getLocalStorageData('analytics-data'),
      configurazioni: {
        backupConfig: this.getLocalStorageData('backup-config'),
        blogConfig: this.getLocalStorageData('blog-config'),
        emailConfig: this.getLocalStorageData('email-config')
      },
      admin: this.getLocalStorageData('admin-users'),
      newsletter: this.getLocalStorageData('newsletter-iscritti'),
      approvazioni: this.getLocalStorageData('workflow-approvals'),
      feedback: this.getLocalStorageData('demo-feedback')
    };
  }

  private getLocalStorageData(key: string): any {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  }

  private generateBackupId(): string {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substr(2, 5);
    return `backup-${timestamp}-${random}`;
  }

  private calculateChecksum(data: any): string {
    const str = JSON.stringify(data);
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash).toString(16);
  }

  private saveBackup(backupId: string, backup: BackupData): boolean {
    try {
      const backupsData = localStorage.getItem(this.BACKUP_KEY) || '{}';
      const backups = JSON.parse(backupsData);
      backups[backupId] = backup;
      localStorage.setItem(this.BACKUP_KEY, JSON.stringify(backups));
      return true;
    } catch (error) {
      console.error('Errore nel salvataggio backup:', error);
      return false;
    }
  }

  private loadBackup(backupId: string): BackupData | null {
    try {
      const backupsData = localStorage.getItem(this.BACKUP_KEY);
      if (backupsData) {
        const backups = JSON.parse(backupsData);
        return backups[backupId] || null;
      }
    } catch (error) {
      console.error('Errore nel caricamento backup:', error);
    }
    return null;
  }

  private verifyBackupIntegrity(backup: BackupData): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!backup.timestamp || !backup.version || !backup.data) {
      errors.push('Struttura backup non valida');
    }

    if (backup.checksum) {
      const calculatedChecksum = this.calculateChecksum(backup.data);
      if (calculatedChecksum !== backup.checksum) {
        errors.push('Checksum non corrispondente - backup corrotto');
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  private updateStats(backup: BackupData): void {
    try {
      const stats = this.getStats();
      stats.totalBackups++;
      stats.totalSize += backup.metadata.size;
      stats.lastBackup = backup.timestamp;
      stats.averageSize = stats.totalSize / stats.totalBackups;

      if (!stats.oldestBackup) {
        stats.oldestBackup = backup.timestamp;
      }

      localStorage.setItem(this.STATS_KEY, JSON.stringify(stats));
    } catch (error) {
      console.error('Errore nell\'aggiornamento statistiche:', error);
    }
  }

  private updateRestoreStats(backup: BackupData, restoredCount: number): void {
    // Implementazione per tracking restore statistics
    console.log(`Restore completato: ${restoredCount} sezioni ripristinate da backup ${backup.timestamp}`);
  }

  private cleanOldBackups(): void {
    const config = this.getConfig();
    const backupList = this.getBackupList();

    if (backupList.length > config.maxBackups) {
      const toDelete = backupList.slice(config.maxBackups);
      toDelete.forEach(({ id }) => this.deleteBackup(id));
    }
  }

  private getStorageKeyForData(dataType: string): string | null {
    const mapping: { [key: string]: string } = {
      soci: 'associazione-soci',
      transazioni: 'transazioni-finanziarie',
      articoli: 'blog-articoli',
      commenti: 'blog-commenti',
      votazioni: 'voti-soci',
      notifiche: 'admin-notifications',
      analytics: 'analytics-data',
      admin: 'admin-users',
      newsletter: 'newsletter-iscritti',
      approvazioni: 'workflow-approvals',
      feedback: 'demo-feedback'
    };
    return mapping[dataType] || null;
  }

  private getCurrentUser(): string {
    try {
      const adminData = localStorage.getItem('admin-session');
      if (adminData) {
        const session = JSON.parse(adminData);
        return session.user?.nome || 'Admin';
      }
    } catch {
      // Fallback
    }
    return 'Sistema';
  }

  private compressData(data: any): any {
    // Implementazione semplificata di compressione
    return { __compressed: true, data: JSON.stringify(data) };
  }

  private decompressData(compressedData: any): any {
    if (this.isCompressed(compressedData)) {
      return JSON.parse(compressedData.data);
    }
    return compressedData;
  }

  private isCompressed(data: any): boolean {
    return data && typeof data === 'object' && data.__compressed === true;
  }

  private formatBytes(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  private notifyBackupCompleted(backupId: string, backup: BackupData): void {
    // Integrazione con sistema notifiche esistente
    if (this.isBrowser() && 'Notification' in window && Notification.permission === 'granted') {
      new Notification('Backup Completato', {
        body: `Backup automatico creato con successo (${this.formatBytes(backup.metadata.size)})`,
        icon: '/favicon.ico'
      });
    }
  }

  // Scheduling
  private initializeScheduling(): void {
    if (!this.isBrowser()) return;

    const config = this.getConfig();
    if (config.autoBackupEnabled) {
      this.scheduleNextBackup();
    }
  }

  private scheduleNextBackup(): void {
    const config = this.getConfig();
    const now = new Date();
    let nextBackup: Date;

    switch (config.backupFrequency) {
      case 'hourly':
        nextBackup = new Date(now.getTime() + 60 * 60 * 1000);
        break;
      case 'daily':
        nextBackup = new Date(now);
        nextBackup.setDate(nextBackup.getDate() + 1);
        nextBackup.setHours(2, 0, 0, 0); // 2:00 AM
        break;
      case 'weekly':
        nextBackup = new Date(now);
        nextBackup.setDate(nextBackup.getDate() + (7 - nextBackup.getDay())); // Prossima domenica
        nextBackup.setHours(2, 0, 0, 0);
        break;
      case 'monthly':
        nextBackup = new Date(now.getFullYear(), now.getMonth() + 1, 1, 2, 0, 0);
        break;
      default:
        nextBackup = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    }

    const timeUntilBackup = nextBackup.getTime() - now.getTime();
    setTimeout(() => {
      this.createBackup('Backup automatico programmato', 'automatic');
      this.scheduleNextBackup(); // Riprogramma il prossimo
    }, timeUntilBackup);

    // Aggiorna statistiche con prossimo backup programmato
    const stats = this.getStats();
    stats.nextScheduledBackup = nextBackup.toISOString();
    if (this.isBrowser()) {
      localStorage.setItem(this.STATS_KEY, JSON.stringify(stats));
    }
  }

  private rescheduleBackups(): void {
    // In una implementazione reale, qui cancelleresti i timeout esistenti
    // e riprogrammeresti in base alla nuova configurazione
    this.scheduleNextBackup();
  }
}

export default BackupService.getInstance();
export type { BackupData, BackupConfig, BackupStats, DataIntegrityReport };
