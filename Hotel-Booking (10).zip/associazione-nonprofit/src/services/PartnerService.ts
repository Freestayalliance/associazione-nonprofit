"use client"

// Tipi per il sistema partner
export interface PartnerTransaction {
  id: number;
  data: string;
  descrizione: string;
  categoria: string;
  tipo: string;
  importo: number;
  regione: string;
  nome: string;
  selected?: boolean;
  logo?: string;
  website?: string;
}

export interface PartnerInfo {
  id: number;
  nome: string;
  logo?: string;
  settore: string;
  livello: string;
  email?: string;
  selected: boolean;
  website?: string;
}

class PartnerService {
  private static instance: PartnerService;
  private readonly PARTNERS_KEY = 'selected-partners';
  private readonly PARTNER_LOGOS_KEY = 'partner-logos';
  private logoUpdateCallbacks: ((partnerName: string) => void)[] = [];

  private constructor() {}

  public static getInstance(): PartnerService {
    if (!PartnerService.instance) {
      PartnerService.instance = new PartnerService();
    }
    return PartnerService.instance;
  }

  private isBrowser(): boolean {
    return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
  }

  // Registra callback per aggiornamenti loghi
  public onLogoUpdate(callback: (partnerName: string) => void): () => void {
    this.logoUpdateCallbacks.push(callback);
    // Ritorna funzione per rimuovere il callback
    return () => {
      const index = this.logoUpdateCallbacks.indexOf(callback);
      if (index > -1) {
        this.logoUpdateCallbacks.splice(index, 1);
      }
    };
  }

  // Notifica aggiornamento logo
  private notifyLogoUpdate(partnerName: string): void {
    this.logoUpdateCallbacks.forEach(callback => {
      try {
        callback(partnerName);
      } catch (error) {
        console.error('Errore nel callback di aggiornamento logo:', error);
      }
    });
  }

  // Ottieni tutte le transazioni partner (dai dati di trasparenza)
  public getPartnerTransactions(): PartnerTransaction[] {
    if (!this.isBrowser()) return [];

    try {
      const transactionsData = localStorage.getItem('transazioni-finanziarie');
      if (!transactionsData) return this.getDefaultPartnerTransactions();

      const transactions = JSON.parse(transactionsData);
      const partnerTransactions = transactions.filter((t: any) =>
        t.categoria === 'Partner Aziendali' ||
        t.tipo === 'Partner' ||
        t.nome.includes('TechCorp') ||
        t.nome.includes('Green Solutions') ||
        t.nome.includes('Studio Legale')
      );

      // Aggiungi loghi e stato selezione
      const selectedPartners = this.getSelectedPartners();
      const partnerLogos = this.getPartnerLogos();

      return partnerTransactions.map((t: any, index: number) => ({
        id: t.id || index + 1,
        data: t.data,
        descrizione: t.descrizione,
        categoria: t.categoria,
        tipo: t.tipo,
        importo: t.importo,
        regione: t.regione,
        nome: t.nome,
        selected: selectedPartners.some(p => p.nome === t.nome),
        logo: partnerLogos[t.nome] || t.logo || this.getDefaultLogo(t.nome)
      }));

    } catch (error) {
      console.error('Errore nel caricamento transazioni partner:', error);
      return this.getDefaultPartnerTransactions();
    }
  }

  // Transazioni partner di default
  private getDefaultPartnerTransactions(): PartnerTransaction[] {
    const selectedPartners = this.getSelectedPartners();
    const partnerLogos = this.getPartnerLogos();

    const defaultTransactions = [
      {
        id: 1,
        data: '2024-01-15',
        descrizione: 'Contributo partnership annuale',
        categoria: 'Partner Aziendali',
        tipo: 'Entrata',
        importo: 3000,
        regione: 'Milano',
        nome: 'TechCorp Italia',
        selected: false,
        logo: '🏢',
        website: 'www.techcorpitalia.it'
      },
      {
        id: 2,
        data: '2024-02-10',
        descrizione: 'Supporto digitalizzazione soci',
        categoria: 'Partner Aziendali',
        tipo: 'Entrata',
        importo: 1500,
        regione: 'Roma',
        nome: 'Green Solutions',
        selected: false,
        logo: '🌱',
        website: 'www.greensolutions.it'
      },
      {
        id: 3,
        data: '2024-03-05',
        descrizione: 'Consulenza legale gratuita',
        categoria: 'Partner Aziendali',
        tipo: 'Servizio',
        importo: 800,
        regione: 'Torino',
        nome: 'Studio Legale Rossi',
        selected: false,
        logo: '⚖️',
        website: 'www.studiolegalerossi.it'
      },
      {
        id: 4,
        data: '2024-04-20',
        descrizione: 'Sponsorizzazione evento sociale',
        categoria: 'Partner Aziendali',
        tipo: 'Entrata',
        importo: 2000,
        regione: 'Napoli',
        nome: 'BankCorp Financial',
        selected: false,
        logo: '🏦',
        website: 'www.bankcorpfinancial.it'
      },
      {
        id: 5,
        data: '2024-05-15',
        descrizione: 'Formazione gratuita soci',
        categoria: 'Partner Aziendali',
        tipo: 'Servizio',
        importo: 1200,
        regione: 'Bologna',
        nome: 'EduTech Academy',
        selected: false,
        logo: '📚',
        website: 'www.edutechacademy.it'
      }
    ];

    // Filtra i partner nascosti e sincronizza lo stato selected e loghi per le transazioni default
    const hiddenPartners = this.getHiddenPartners();
    return defaultTransactions
      .filter(transaction => !hiddenPartners.includes(transaction.nome))
      .map(transaction => ({
        ...transaction,
        selected: selectedPartners.some(p => p.nome === transaction.nome),
        logo: partnerLogos[transaction.nome] || transaction.logo || this.getDefaultLogo(transaction.nome)
      }));
  }

  // Logo di default basato sul nome partner
  private getDefaultLogo(partnerName: string): string {
    if (partnerName.includes('Tech')) return '🏢';
    if (partnerName.includes('Green')) return '🌱';
    if (partnerName.includes('Legale')) return '⚖️';
    if (partnerName.includes('Bank')) return '🏦';
    if (partnerName.includes('Edu')) return '📚';
    return '🤝';
  }

  // Gestione partner selezionati
  public getSelectedPartners(): PartnerInfo[] {
    if (!this.isBrowser()) return [];

    try {
      const data = localStorage.getItem(this.PARTNERS_KEY);
      const selectedPartners = data ? JSON.parse(data) : [];
      console.log('🔍 Raw selected partners from localStorage:', selectedPartners);

      // Sincronizza i loghi più recenti
      const partnerLogos = this.getPartnerLogos();
      console.log('🖼️ Available partner logos:', partnerLogos);

      const updatedPartners = selectedPartners.map((partner: PartnerInfo) => ({
        ...partner,
        logo: partnerLogos[partner.nome] || partner.logo || this.getDefaultLogo(partner.nome)
      }));

      console.log('✅ Updated partners with logos:', updatedPartners);

      // Salva la versione aggiornata
      if (updatedPartners.length > 0 && JSON.stringify(selectedPartners) !== JSON.stringify(updatedPartners)) {
        localStorage.setItem(this.PARTNERS_KEY, JSON.stringify(updatedPartners));
        console.log('💾 Saved updated partners to localStorage');
      }

      return updatedPartners;
    } catch (error) {
      console.error('Errore nel caricamento partner selezionati:', error);
      return [];
    }
  }

  public togglePartnerSelection(transaction: PartnerTransaction): boolean {
    if (!this.isBrowser()) return false;

    try {
      const selectedPartners = this.getSelectedPartners();
      const existingIndex = selectedPartners.findIndex(p => p.nome === transaction.nome);

      if (existingIndex >= 0) {
        // Rimuovi dalla selezione
        selectedPartners.splice(existingIndex, 1);
      } else {
        // Aggiungi alla selezione
        const newPartner: PartnerInfo = {
          id: transaction.id,
          nome: transaction.nome,
          logo: transaction.logo,
          settore: this.getPartnerSector(transaction.nome),
          livello: this.getPartnerLevel(transaction.importo),
          selected: true,
          website: transaction.website
        };
        selectedPartners.push(newPartner);
      }

      localStorage.setItem(this.PARTNERS_KEY, JSON.stringify(selectedPartners));
      return existingIndex < 0; // Ritorna true se aggiunto, false se rimosso

    } catch (error) {
      console.error('Errore nel toggle partner:', error);
      return false;
    }
  }

  // Determina settore in base al nome
  private getPartnerSector(name: string): string {
    if (name.includes('Tech')) return 'Tecnologia';
    if (name.includes('Green')) return 'Sostenibilità';
    if (name.includes('Legale')) return 'Legale';
    if (name.includes('Bank')) return 'Finanziario';
    if (name.includes('Edu')) return 'Formazione';
    return 'Generale';
  }

  // Determina livello in base all'importo
  private getPartnerLevel(importo: number): string {
    if (importo >= 2500) return 'Oro';
    if (importo >= 1000) return 'Argento';
    return 'Bronze';
  }

  // Gestione loghi partner
  public getPartnerLogos(): Record<string, string> {
    if (!this.isBrowser()) return {};

    try {
      const data = localStorage.getItem(this.PARTNER_LOGOS_KEY);
      return data ? JSON.parse(data) : {};
    } catch (error) {
      console.error('Errore nel caricamento loghi partner:', error);
      return {};
    }
  }

  public uploadPartnerLogo(partnerName: string, logoFile: File): Promise<string> {
    return new Promise((resolve, reject) => {
      try {
        const reader = new FileReader();
        reader.onload = (e) => {
          if (e.target?.result) {
            const logoDataUrl = e.target.result as string;

            // Salva il logo
            const logos = this.getPartnerLogos();
            logos[partnerName] = logoDataUrl;
            localStorage.setItem(this.PARTNER_LOGOS_KEY, JSON.stringify(logos));

            // Aggiorna anche nei partner selezionati
            const selectedPartners = this.getSelectedPartners();
            const partnerIndex = selectedPartners.findIndex(p => p.nome === partnerName);
            if (partnerIndex >= 0) {
              selectedPartners[partnerIndex].logo = logoDataUrl;
              localStorage.setItem(this.PARTNERS_KEY, JSON.stringify(selectedPartners));
            }

            // Notifica l'aggiornamento
            this.notifyLogoUpdate(partnerName);

            resolve(logoDataUrl);
          } else {
            reject('Errore nella lettura del file');
          }
        };
        reader.onerror = () => reject('Errore nella lettura del file');
        reader.readAsDataURL(logoFile);

      } catch (error) {
        reject('Errore nell\'upload del logo');
      }
    });
  }

  // Aggiungi nuovo partner personalizzato
  public addCustomPartner(partnerData: {
    nome: string;
    descrizione: string;
    importo: number;
    regione: string;
    logo?: string;
    website?: string;
  }): boolean {
    if (!this.isBrowser()) return false;

    try {
      // Carica transazioni esistenti
      const existingTransactions = this.getPartnerTransactions();

      // Crea nuovo ID univoco
      const newId = Math.max(...existingTransactions.map(t => t.id), 0) + 1;

      // Crea nuova transazione partner
      const newTransaction: PartnerTransaction = {
        id: newId,
        data: new Date().toISOString().split('T')[0],
        descrizione: partnerData.descrizione,
        categoria: 'Partner Aziendali',
        tipo: 'Entrata',
        importo: partnerData.importo,
        regione: partnerData.regione,
        nome: partnerData.nome,
        selected: false,
        logo: partnerData.logo || this.getDefaultLogo(partnerData.nome),
        website: partnerData.website
      };

      // Salva in localStorage come transazione finanziaria
      const allTransactions = JSON.parse(localStorage.getItem('transazioni-finanziarie') || '[]');
      allTransactions.push({
        id: newId,
        data: newTransaction.data,
        descrizione: newTransaction.descrizione,
        categoria: newTransaction.categoria,
        tipo: newTransaction.tipo,
        importo: newTransaction.importo,
        regione: newTransaction.regione,
        nome: newTransaction.nome,
        website: newTransaction.website
      });

      localStorage.setItem('transazioni-finanziarie', JSON.stringify(allTransactions));

      // Se ha un logo personalizzato, salvalo
      if (partnerData.logo && partnerData.logo.startsWith('data:')) {
        const logos = this.getPartnerLogos();
        logos[partnerData.nome] = partnerData.logo;
        localStorage.setItem(this.PARTNER_LOGOS_KEY, JSON.stringify(logos));
      }

      return true;
    } catch (error) {
      console.error('Errore nell\'aggiunta partner personalizzato:', error);
      return false;
    }
  }

  // Rimuovi partner dalle selezioni
  public removePartner(partnerName: string): boolean {
    if (!this.isBrowser()) return false;

    try {
      const selectedPartners = this.getSelectedPartners();
      const filteredPartners = selectedPartners.filter(p => p.nome !== partnerName);
      localStorage.setItem(this.PARTNERS_KEY, JSON.stringify(filteredPartners));
      return true;
    } catch (error) {
      console.error('Errore nella rimozione partner:', error);
      return false;
    }
  }

  // Cancella definitivamente partner dal sistema
  public deletePartnerTransaction(transactionId: number): boolean {
    if (!this.isBrowser()) return false;

    try {
      // Rimuovi dalla lista delle transazioni finanziarie
      const transactionsData = localStorage.getItem('transazioni-finanziarie');
      if (transactionsData) {
        const transactions = JSON.parse(transactionsData);
        const filteredTransactions = transactions.filter((t: any) => t.id !== transactionId);
        localStorage.setItem('transazioni-finanziarie', JSON.stringify(filteredTransactions));
      }

      // Trova il nome del partner per rimuoverlo da selezioni e loghi
      const partnerTransactions = this.getPartnerTransactions();
      const partnerToDelete = partnerTransactions.find(t => t.id === transactionId);

      if (partnerToDelete) {
        // Rimuovi dalle selezioni
        this.removePartner(partnerToDelete.nome);

        // Rimuovi il logo
        const logos = this.getPartnerLogos();
        delete logos[partnerToDelete.nome];
        localStorage.setItem(this.PARTNER_LOGOS_KEY, JSON.stringify(logos));

        // Per i partner di default, aggiungili alla lista dei "partner nascosti"
        const hiddenPartners = this.getHiddenPartners();
        if (!hiddenPartners.includes(partnerToDelete.nome)) {
          hiddenPartners.push(partnerToDelete.nome);
          localStorage.setItem('hidden-partners', JSON.stringify(hiddenPartners));
        }

        console.log(`🗑️ Partner ${partnerToDelete.nome} cancellato definitivamente`);
      }

      return true;
    } catch (error) {
      console.error('Errore nella cancellazione partner:', error);
      return false;
    }
  }

  // Ottieni lista partner nascosti
  private getHiddenPartners(): string[] {
    if (!this.isBrowser()) return [];

    try {
      const data = localStorage.getItem('hidden-partners');
      return data ? JSON.parse(data) : [];
    } catch (error) {
      return [];
    }
  }

  // Reset completo
  public clearAllSelections(): boolean {
    if (!this.isBrowser()) return false;

    try {
      localStorage.removeItem(this.PARTNERS_KEY);
      return true;
    } catch (error) {
      console.error('Errore nel reset selezioni:', error);
      return false;
    }
  }

  // Debug: mostra stato completo
  public debugPartnerState() {
    console.log('🔍 === DEBUG PARTNER STATE ===');
    console.log('Selected Partners:', localStorage.getItem(this.PARTNERS_KEY));
    console.log('Partner Logos:', localStorage.getItem(this.PARTNER_LOGOS_KEY));
    console.log('Financial Transactions:', localStorage.getItem('transazioni-finanziarie'));
    console.log('Current Selected:', this.getSelectedPartners());
    console.log('Current Transactions:', this.getPartnerTransactions());
    console.log('=== END DEBUG ===');
  }

  // Force reload: ricarica tutti i dati partner
  public forceReload() {
    // Notifica tutti i callback per aggiornare
    this.logoUpdateCallbacks.forEach(callback => {
      try {
        callback('FORCE_RELOAD');
      } catch (error) {
        console.error('Errore nel callback force reload:', error);
      }
    });
  }

  // Statistiche
  public getPartnerStats() {
    const transactions = this.getPartnerTransactions();
    const selected = this.getSelectedPartners();

    return {
      totalPartners: transactions.length,
      selectedPartners: selected.length,
      totalContribution: transactions.reduce((sum, t) => sum + t.importo, 0),
      selectedContribution: transactions
        .filter(t => selected.some(s => s.nome === t.nome))
        .reduce((sum, t) => sum + t.importo, 0),
      partnersByLevel: {
        oro: selected.filter(p => p.livello === 'Oro').length,
        argento: selected.filter(p => p.livello === 'Argento').length,
        bronze: selected.filter(p => p.livello === 'Bronze').length
      }
    };
  }
}

export default PartnerService.getInstance();
export type { PartnerTransaction, PartnerInfo };
