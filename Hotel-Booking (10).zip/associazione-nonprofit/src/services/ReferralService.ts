"use client"

// Tipi per il sistema referral
export interface ReferralCode {
  id: string;
  code: string;
  userId: string;
  userName: string;
  userEmail: string;
  createdAt: string;
  isActive: boolean;
  totalReferrals: number;
  currentLevel: ReferralLevel;
}

export interface ReferralLevel {
  name: string;
  minReferrals: number;
  badge: string;
  privileges: string[];
  color: string;
}

export interface ReferralRecord {
  id: string;
  referrerCode: string;
  referrerName: string;
  referredUserId: string;
  referredUserName: string;
  referredUserEmail: string;
  referralType: 'member' | 'partner' | 'admin_partner';
  createdAt: string;
  status: 'pending' | 'completed' | 'cancelled';
  rewardGiven: boolean;
}

export interface ReferralStats {
  totalReferrals: number;
  completedReferrals: number;
  pendingReferrals: number;
  currentLevel: ReferralLevel;
  nextLevel: ReferralLevel | null;
  progressToNext: number;
  earnedBadges: string[];
  monthlyStats: Record<string, number>;
}

class ReferralService {
  private static instance: ReferralService;
  private readonly CODES_KEY = 'referral-codes';
  private readonly RECORDS_KEY = 'referral-records';
  private readonly USER_CODES_KEY = 'user-referral-codes';

  // Sistema di badge/traguardi progressivi
  private readonly REFERRAL_BADGES = [
    { name: 'Nuovo', minReferrals: 0, badge: '🆕', color: 'gray', description: 'Appena iscritto' },
    { name: 'Standard', minReferrals: 10, badge: '🔵', color: 'blue', description: '10+ referral' },
    { name: 'Classic', minReferrals: 20, badge: '🟢', color: 'green', description: '20+ referral' },
    { name: 'Bronzo', minReferrals: 50, badge: '🥉', color: 'orange', description: '50+ referral' },
    { name: 'Argento', minReferrals: 100, badge: '🥈', color: 'gray', description: '100+ referral' },
    { name: 'Oro', minReferrals: 200, badge: '🥇', color: 'yellow', description: '200+ referral' },
    { name: 'Platino', minReferrals: 500, badge: '💎', color: 'cyan', description: '500+ referral' },
    { name: 'Diamante', minReferrals: 1000, badge: '💍', color: 'purple', description: '1000+ referral' }
  ];

  // Sistema di tracking referral - SOLO CONTEGGIO
  private readonly REFERRAL_LEVELS: ReferralLevel[] = [
    {
      name: 'Socio',
      minReferrals: 0,
      badge: '🤝',
      privileges: ['Membro della community'],
      color: 'blue'
    }
  ];

  private constructor() {}

  public static getInstance(): ReferralService {
    if (!ReferralService.instance) {
      ReferralService.instance = new ReferralService();
    }
    return ReferralService.instance;
  }

  private isBrowser(): boolean {
    return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
  }

  // Genera codice referral unico
  public generateReferralCode(userEmail: string): string {
    const year = new Date().getFullYear();
    const prefix = 'FSA';
    const userPart = userEmail.substring(0, 3).toUpperCase();
    const randomPart = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `${prefix}-${userPart}${year}-${randomPart}`;
  }

  // Crea nuovo codice referral per utente
  public createReferralCode(userData: {
    userId: string;
    userName: string;
    userEmail: string;
  }): ReferralCode {
    if (!this.isBrowser()) throw new Error('Browser storage not available');

    const code = this.generateReferralCode(userData.userEmail);

    const referralCode: ReferralCode = {
      id: `ref_${Date.now()}`,
      code: code,
      userId: userData.userId,
      userName: userData.userName,
      userEmail: userData.userEmail,
      createdAt: new Date().toISOString(),
      isActive: true,
      totalReferrals: 0,
      currentLevel: this.REFERRAL_LEVELS[0]
    };

    // Salva il codice
    const codes = this.getAllReferralCodes();
    codes.push(referralCode);
    localStorage.setItem(this.CODES_KEY, JSON.stringify(codes));

    // Salva mapping user -> code per lookup veloce
    const userCodes = this.getUserCodeMappings();
    userCodes[userData.userEmail] = code;
    localStorage.setItem(this.USER_CODES_KEY, JSON.stringify(userCodes));

    console.log('🎯 Codice referral creato:', code, 'per:', userData.userName);
    return referralCode;
  }

  // Ottieni codice referral di un utente
  public getUserReferralCode(userEmail: string): string | null {
    if (!this.isBrowser()) return null;

    const userCodes = this.getUserCodeMappings();
    return userCodes[userEmail] || null;
  }

  // Ottieni dati completi codice referral
  public getReferralCodeData(userEmail: string): ReferralCode | null {
    if (!this.isBrowser()) return null;

    const codes = this.getAllReferralCodes();
    return codes.find(code => code.userEmail === userEmail) || null;
  }

  // Verifica se un codice referral esiste ed è valido
  public validateReferralCode(code: string): ReferralCode | null {
    if (!this.isBrowser() || !code) return null;

    const codes = this.getAllReferralCodes();
    const referralCode = codes.find(c => c.code === code && c.isActive);

    console.log('🔍 Validazione codice:', code, 'risultato:', referralCode ? 'VALIDO' : 'NON VALIDO');
    return referralCode || null;
  }

  // Registra un nuovo referral
  public recordReferral(data: {
    referralCode: string;
    referredUserName: string;
    referredUserEmail: string;
    referralType: 'member' | 'partner' | 'admin_partner';
  }): { success: boolean; message: string; referralRecord?: ReferralRecord } {
    if (!this.isBrowser()) {
      return { success: false, message: 'Storage non disponibile' };
    }

    const referralCodeData = this.validateReferralCode(data.referralCode);
    if (!referralCodeData) {
      return { success: false, message: 'Codice referral non valido' };
    }

    // Crea record referral
    const referralRecord: ReferralRecord = {
      id: `rr_${Date.now()}`,
      referrerCode: data.referralCode,
      referrerName: referralCodeData.userName,
      referredUserId: `user_${Date.now()}`,
      referredUserName: data.referredUserName,
      referredUserEmail: data.referredUserEmail,
      referralType: data.referralType,
      createdAt: new Date().toISOString(),
      status: 'pending',
      rewardGiven: false
    };

    // Salva record
    const records = this.getAllReferralRecords();
    records.push(referralRecord);
    localStorage.setItem(this.RECORDS_KEY, JSON.stringify(records));

    console.log('📝 Referral registrato:', referralRecord);

    return {
      success: true,
      message: `Referral registrato per ${referralCodeData.userName}`,
      referralRecord
    };
  }

  // Completa un referral (quando pagamento/registrazione completata)
  public completeReferral(referralRecordId: string): { success: boolean; message?: string } {
    if (!this.isBrowser()) {
      return { success: false };
    }

    try {
      // Aggiorna record referral
      const records = this.getAllReferralRecords();
      const recordIndex = records.findIndex(r => r.id === referralRecordId);

      if (recordIndex === -1) {
        return { success: false };
      }

      records[recordIndex].status = 'completed';
      records[recordIndex].rewardGiven = true;
      localStorage.setItem(this.RECORDS_KEY, JSON.stringify(records));

      const referralRecord = records[recordIndex];

      // Aggiorna contatore referral del referrer
      const codes = this.getAllReferralCodes();
      const codeIndex = codes.findIndex(c => c.code === referralRecord.referrerCode);

      if (codeIndex !== -1) {
        codes[codeIndex].totalReferrals += 1;
        // Il livello rimane sempre "Socio" - nessun level up automatico
        codes[codeIndex].currentLevel = this.REFERRAL_LEVELS[0];
        localStorage.setItem(this.CODES_KEY, JSON.stringify(codes));

        console.log('🎉 Referral completato! Total:', codes[codeIndex].totalReferrals, 'per:', referralRecord.referrerName);

        return {
          success: true,
          message: `Referral completato per ${referralRecord.referrerName}. Total: ${codes[codeIndex].totalReferrals}`
        };
      }

      return { success: true };
    } catch (error) {
      console.error('Errore nel completamento referral:', error);
      return { success: false };
    }
  }

  // Calcola badge basato su numero referral
  public calculateBadge(totalReferrals: number) {
    for (let i = this.REFERRAL_BADGES.length - 1; i >= 0; i--) {
      if (totalReferrals >= this.REFERRAL_BADGES[i].minReferrals) {
        return this.REFERRAL_BADGES[i];
      }
    }
    return this.REFERRAL_BADGES[0];
  }

  // Ottieni tutti i badge disponibili
  public getAllBadges() {
    return this.REFERRAL_BADGES;
  }

  // Calcola livello basato su numero referral - ora sempre "Socio"
  private calculateLevel(totalReferrals: number): ReferralLevel {
    // Tutti i soci hanno lo stesso livello, indipendentemente dai referral
    // I riconoscimenti vengono assegnati dalla community tramite votazione
    return this.REFERRAL_LEVELS[0]; // Sempre "Socio"
  }

  // Ottieni statistiche referral per utente
  public getUserReferralStats(userEmail: string): ReferralStats | null {
    if (!this.isBrowser()) return null;

    const codeData = this.getReferralCodeData(userEmail);
    if (!codeData) return null;

    const records = this.getAllReferralRecords().filter(r => r.referrerCode === codeData.code);
    const completedReferrals = records.filter(r => r.status === 'completed').length;
    const pendingReferrals = records.filter(r => r.status === 'pending').length;

    const currentLevel = this.calculateLevel(codeData.totalReferrals); // Sempre "Socio"

    // Statistiche mensili
    const monthlyStats: Record<string, number> = {};
    for (const record of records) {
      const month = new Date(record.createdAt).toISOString().slice(0, 7);
      monthlyStats[month] = (monthlyStats[month] || 0) + 1;
    }

    return {
      totalReferrals: codeData.totalReferrals,
      completedReferrals,
      pendingReferrals,
      currentLevel,
      nextLevel: null, // Non ci sono livelli successivi
      progressToNext: 100, // Sempre al 100% perché non c'è progressione
      earnedBadges: [currentLevel.badge], // Solo il badge "Socio"
      monthlyStats
    };
  }

  // Ottieni tutti i codici referral
  private getAllReferralCodes(): ReferralCode[] {
    if (!this.isBrowser()) return [];

    try {
      const data = localStorage.getItem(this.CODES_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Errore nel caricamento codici referral:', error);
      return [];
    }
  }

  // Ottieni tutti i record referral
  private getAllReferralRecords(): ReferralRecord[] {
    if (!this.isBrowser()) return [];

    try {
      const data = localStorage.getItem(this.RECORDS_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Errore nel caricamento record referral:', error);
      return [];
    }
  }

  // Ottieni mapping user email -> code
  private getUserCodeMappings(): Record<string, string> {
    if (!this.isBrowser()) return {};

    try {
      const data = localStorage.getItem(this.USER_CODES_KEY);
      return data ? JSON.parse(data) : {};
    } catch (error) {
      console.error('Errore nel caricamento mapping utenti:', error);
      return {};
    }
  }

  // Inizializza codici per soci esistenti
  public initializeExistingUsers(): { created: number; skipped: number } {
    if (!this.isBrowser()) return { created: 0, skipped: 0 };

    let created = 0;
    let skipped = 0;

    try {
      // Genera codici per soci esistenti (se non ce l'hanno già)
      const existingMembers = [
        { userId: 'user_1', userName: 'Marco Rossi', userEmail: 'marco.rossi@email.com' },
        { userId: 'user_2', userName: 'Sofia Verdi', userEmail: 'sofia.verdi@email.com' },
        { userId: 'user_3', userName: 'Alessandro Bianchi', userEmail: 'alessandro.bianchi@email.com' },
        { userId: 'user_4', userName: 'Francesca Neri', userEmail: 'francesca.neri@email.com' },
        { userId: 'user_5', userName: 'Luca Ferrari', userEmail: 'luca.ferrari@email.com' }
      ];

      existingMembers.forEach(member => {
        const existingCode = this.getUserReferralCode(member.userEmail);
        if (!existingCode) {
          this.createReferralCode(member);
          created++;
        } else {
          skipped++;
        }
      });

      console.log(`🎯 Inizializzazione referral completata: ${created} creati, ${skipped} già esistenti`);
      return { created, skipped };
    } catch (error) {
      console.error('Errore nell\'inizializzazione referral:', error);
      return { created: 0, skipped: 0 };
    }
  }

  // Ottieni leaderboard referral
  public getLeaderboard(limit = 10): Array<{
    rank: number;
    userName: string;
    totalReferrals: number;
    level: ReferralLevel;
    badge: string;
  }> {
    if (!this.isBrowser()) return [];

    const codes = this.getAllReferralCodes()
      .sort((a, b) => b.totalReferrals - a.totalReferrals)
      .slice(0, limit);

    return codes.map((code, index) => ({
      rank: index + 1,
      userName: code.userName,
      totalReferrals: code.totalReferrals,
      level: code.currentLevel,
      badge: code.currentLevel.badge
    }));
  }

  // Ottieni leaderboard pubblica completa
  public getPublicLeaderboard(): Array<{
    rank: number;
    code: string;
    userName: string;
    totalReferrals: number;
    completedReferrals: number;
    pendingReferrals: number;
    badge: any;
    totalValue: number; // Valore generato (iscrizioni + eventuali donazioni)
    joinedDate: string;
  }> {
    if (!this.isBrowser()) return [];

    const codes = this.getAllReferralCodes()
      .filter(code => code.isActive && code.totalReferrals >= 0) // Tutti i codici attivi
      .sort((a, b) => b.totalReferrals - a.totalReferrals);

    return codes.map((code, index) => {
      const records = this.getAllReferralRecords().filter(r => r.referrerCode === code.code);
      const completedReferrals = records.filter(r => r.status === 'completed').length;
      const pendingReferrals = records.filter(r => r.status === 'pending').length;

      // Calcola valore totale generato (€20 per iscrizione completata + eventuali donazioni future)
      const membershipValue = completedReferrals * 20; // €20 per iscrizione
      const donationValue = 0; // TODO: Aggiungere quando implementate le donazioni
      const totalValue = membershipValue + donationValue;

      return {
        rank: index + 1,
        code: code.code,
        userName: code.userName,
        totalReferrals: code.totalReferrals,
        completedReferrals,
        pendingReferrals,
        badge: this.calculateBadge(code.totalReferrals),
        totalValue,
        joinedDate: code.createdAt
      };
    });
  }

  // Ottieni statistiche dettagliate per un codice specifico
  public getCodeDetailedStats(code: string): {
    success: boolean;
    data?: {
      code: string;
      userName: string;
      rank: number;
      totalReferrals: number;
      completedReferrals: number;
      pendingReferrals: number;
      badge: any;
      nextBadge: any | null;
      progressToNext: number;
      totalValue: number;
      monthlyBreakdown: Record<string, number>;
      recentReferrals: any[];
      joinedDate: string;
    };
    message: string;
  } {
    if (!this.isBrowser()) {
      return { success: false, message: 'Storage non disponibile' };
    }

    const codeData = this.validateReferralCode(code);
    if (!codeData) {
      return { success: false, message: 'Codice referral non trovato o non valido' };
    }

    const leaderboard = this.getPublicLeaderboard();
    const position = leaderboard.find(entry => entry.code === code);

    if (!position) {
      return { success: false, message: 'Impossibile calcolare la posizione' };
    }

    const records = this.getAllReferralRecords()
      .filter(r => r.referrerCode === code)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const currentBadge = this.calculateBadge(codeData.totalReferrals);
    const nextBadgeIndex = this.REFERRAL_BADGES.findIndex(b => b.name === currentBadge.name) + 1;
    const nextBadge = nextBadgeIndex < this.REFERRAL_BADGES.length ? this.REFERRAL_BADGES[nextBadgeIndex] : null;

    const progressToNext = nextBadge ?
      Math.min(100, ((codeData.totalReferrals - currentBadge.minReferrals) / (nextBadge.minReferrals - currentBadge.minReferrals)) * 100) : 100;

    // Breakdown mensile
    const monthlyBreakdown: Record<string, number> = {};
    for (const record of records) {
      const month = new Date(record.createdAt).toISOString().slice(0, 7);
      monthlyBreakdown[month] = (monthlyBreakdown[month] || 0) + 1;
    }

    return {
      success: true,
      data: {
        code: codeData.code,
        userName: codeData.userName,
        rank: position.rank,
        totalReferrals: codeData.totalReferrals,
        completedReferrals: position.completedReferrals,
        pendingReferrals: position.pendingReferrals,
        badge: currentBadge,
        nextBadge,
        progressToNext,
        totalValue: position.totalValue,
        monthlyBreakdown,
        recentReferrals: records.slice(0, 10), // Ultimi 10 referral
        joinedDate: codeData.createdAt
      },
      message: 'Statistiche caricate con successo'
    };
  }

  // Verifica se utente ha privilegi admin basato su referral
  public hasAdminPrivileges(userEmail: string): boolean {
    // I privilegi admin non sono più automatici basati su referral
    // Devono essere assegnati dalla community tramite votazione
    return false; // Sempre false, i privilegi vengono assegnati manualmente
  }

  // Debug: mostra stato completo
  public debugReferralState() {
    console.log('🔍 === DEBUG REFERRAL STATE ===');
    console.log('Codes:', this.getAllReferralCodes());
    console.log('Records:', this.getAllReferralRecords());
    console.log('User Mappings:', this.getUserCodeMappings());
    console.log('=== END DEBUG ===');
  }
}

export default ReferralService.getInstance();
export type { ReferralCode, ReferralLevel, ReferralRecord, ReferralStats };
