"use client"

interface PageView {
  id: string;
  path: string;
  title: string;
  timestamp: string;
  userAgent: string;
  referrer: string;
  sessionId: string;
  userId?: string;
  duration?: number; // Tempo permanenza in secondi
  exitPath?: string;
  device: 'mobile' | 'tablet' | 'desktop';
  browser: string;
  os: string;
  country?: string;
  language: string;
}

interface UserAction {
  id: string;
  type: 'click' | 'scroll' | 'form_submit' | 'download' | 'vote' | 'comment' | 'like' | 'search';
  target: string;
  value?: string;
  timestamp: string;
  sessionId: string;
  userId?: string;
  path: string;
  metadata?: Record<string, any>;
}

interface UserSession {
  id: string;
  userId?: string;
  startTime: string;
  endTime?: string;
  duration?: number;
  pageViews: number;
  actions: number;
  bounceRate: boolean; // True se solo 1 pagina vista
  device: 'mobile' | 'tablet' | 'desktop';
  browser: string;
  os: string;
  entryPage: string;
  exitPage?: string;
  referrer: string;
  country?: string;
}

interface PerformanceMetric {
  id: string;
  timestamp: string;
  path: string;
  loadTime: number; // ms
  domContentLoaded: number; // ms
  firstContentfulPaint: number; // ms
  largestContentfulPaint: number; // ms
  cumulativeLayoutShift: number;
  firstInputDelay: number; // ms
  timeToInteractive: number; // ms
  networkType?: string;
  connectionSpeed?: string;
}

interface AnalyticsReport {
  period: 'today' | 'week' | 'month' | 'year';
  startDate: string;
  endDate: string;

  // Overview
  totalViews: number;
  uniqueVisitors: number;
  totalSessions: number;
  averageSessionDuration: number;
  bounceRate: number;

  // Popular content
  topPages: Array<{ path: string; title: string; views: number; uniqueViews: number }>;
  topReferrers: Array<{ referrer: string; visits: number }>;

  // User behavior
  deviceBreakdown: Record<string, number>;
  browserBreakdown: Record<string, number>;
  osBreakdown: Record<string, number>;
  languageBreakdown: Record<string, number>;

  // Performance
  averageLoadTime: number;
  performanceScore: number;

  // Engagement
  topActions: Array<{ type: string; count: number }>;
  searchQueries: Array<{ query: string; count: number }>;

  // Growth
  periodComparison: {
    viewsChange: number;
    visitorsChange: number;
    durationChange: number;
    bounceRateChange: number;
  };
}

interface AlertRule {
  id: string;
  name: string;
  type: 'performance' | 'traffic' | 'error' | 'engagement';
  condition: string; // e.g., "loadTime > 5000"
  threshold: number;
  enabled: boolean;
  lastTriggered?: string;
  notificationMethod: 'email' | 'notification' | 'both';
}

class AnalyticsService {
  private currentSession: UserSession | null = null;
  private currentPageView: PageView | null = null;
  private pageLoadTime: number = Date.now();
  private isTracking = false;
  private heartbeatInterval: NodeJS.Timeout | null = null;

  constructor() {
    if (this.isBrowser()) {
      this.initializeTracking();
    }
  }

  private isBrowser(): boolean {
    return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
  }

  // === Inizializzazione ===

  public initializeTracking(): void {
    if (!this.isBrowser() || this.isTracking) return;

    try {
      this.isTracking = true;

      // Inizializza sessione
      this.initializeSession();

      // Track page load
      this.trackPageView();

      // Track performance metrics
      this.trackPerformance();

      // Setup event listeners
      this.setupEventListeners();

      // Heartbeat per aggiornare durata sessione
      this.startHeartbeat();

      console.log('📊 AnalyticsService inizializzato');
    } catch (error) {
      console.error('Errore inizializzazione analytics:', error);
    }
  }

  private initializeSession(): void {
    let sessionId = sessionStorage.getItem('analytics-session-id');

    if (!sessionId) {
      sessionId = this.generateId();
      sessionStorage.setItem('analytics-session-id', sessionId);
    }

    const existingSessions = this.getStoredData<UserSession>('analytics-sessions');
    let session = existingSessions.find(s => s.id === sessionId);

    if (!session) {
      session = {
        id: sessionId,
        userId: this.getCurrentUserId(),
        startTime: new Date().toISOString(),
        pageViews: 0,
        actions: 0,
        bounceRate: true,
        device: this.getDeviceType(),
        browser: this.getBrowser(),
        os: this.getOS(),
        entryPage: window.location.pathname,
        referrer: document.referrer || 'direct',
        country: 'IT' // Placeholder
      };

      existingSessions.push(session);
      this.saveData('analytics-sessions', existingSessions);
    }

    this.currentSession = session;
  }

  // === Tracking Methods ===

  public trackPageView(title?: string): void {
    if (!this.isBrowser() || !this.currentSession) return;

    try {
      // Completa la page view precedente se esiste
      if (this.currentPageView) {
        this.completePageView();
      }

      const pageView: PageView = {
        id: this.generateId(),
        path: window.location.pathname,
        title: title || document.title || window.location.pathname,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        referrer: document.referrer || 'direct',
        sessionId: this.currentSession.id,
        userId: this.getCurrentUserId(),
        device: this.getDeviceType(),
        browser: this.getBrowser(),
        os: this.getOS(),
        language: navigator.language
      };

      // Salva page view
      const pageViews = this.getStoredData<PageView>('analytics-pageviews');
      pageViews.push(pageView);
      this.saveData('analytics-pageviews', pageViews);

      // Aggiorna sessione
      this.currentSession.pageViews++;
      this.currentSession.bounceRate = this.currentSession.pageViews <= 1;
      this.updateSession();

      this.currentPageView = pageView;
      this.pageLoadTime = Date.now();

      console.log('📄 Page view tracked:', pageView.path);
    } catch (error) {
      console.error('Errore tracking page view:', error);
    }
  }

  public trackUserAction(
    type: UserAction['type'],
    target: string,
    value?: string,
    metadata?: Record<string, any>
  ): void {
    if (!this.isBrowser() || !this.currentSession) return;

    try {
      const action: UserAction = {
        id: this.generateId(),
        type,
        target,
        value,
        timestamp: new Date().toISOString(),
        sessionId: this.currentSession.id,
        userId: this.getCurrentUserId(),
        path: window.location.pathname,
        metadata
      };

      // Salva action
      const actions = this.getStoredData<UserAction>('analytics-actions');
      actions.push(action);
      this.saveData('analytics-actions', actions);

      // Aggiorna sessione
      this.currentSession.actions++;
      this.updateSession();

      console.log(`🎯 Action tracked: ${type} - ${target}`);
    } catch (error) {
      console.error('Errore tracking user action:', error);
    }
  }

  public trackPerformance(): void {
    if (!this.isBrowser()) return;

    try {
      // Aspetta che la pagina sia completamente caricata
      window.addEventListener('load', () => {
        setTimeout(() => {
          const perfData = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
          const paintEntries = performance.getEntriesByType('paint');

          if (perfData) {
            const metric: PerformanceMetric = {
              id: this.generateId(),
              timestamp: new Date().toISOString(),
              path: window.location.pathname,
              loadTime: perfData.loadEventEnd - perfData.fetchStart,
              domContentLoaded: perfData.domContentLoadedEventEnd - perfData.fetchStart,
              firstContentfulPaint: paintEntries.find(e => e.name === 'first-contentful-paint')?.startTime || 0,
              largestContentfulPaint: 0, // Richiede observer specifico
              cumulativeLayoutShift: 0, // Richiede observer specifico
              firstInputDelay: 0, // Richiede observer specifico
              timeToInteractive: perfData.domInteractive - perfData.fetchStart,
              networkType: (navigator as any).connection?.effectiveType || 'unknown',
              connectionSpeed: (navigator as any).connection?.downlink || 0
            };

            // Salva performance metric
            const metrics = this.getStoredData<PerformanceMetric>('analytics-performance');
            metrics.push(metric);
            this.saveData('analytics-performance', metrics);

            console.log('⚡ Performance tracked:', metric.loadTime, 'ms');
          }
        }, 1000);
      });
    } catch (error) {
      console.error('Errore tracking performance:', error);
    }
  }

  // === Event Listeners ===

  private setupEventListeners(): void {
    if (!this.isBrowser()) return;

    // Track clicks
    document.addEventListener('click', (e) => {
      const target = e.target as HTMLElement;
      const tagName = target.tagName.toLowerCase();
      const text = target.textContent?.slice(0, 50) || '';
      const href = target.getAttribute('href');

      this.trackUserAction('click', `${tagName}:${text}`, href || undefined, {
        x: e.clientX,
        y: e.clientY,
        button: e.button
      });
    });

    // Track scroll depth
    let maxScroll = 0;
    window.addEventListener('scroll', () => {
      const scrollPercent = Math.round((window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100);
      if (scrollPercent > maxScroll && scrollPercent % 25 === 0) {
        maxScroll = scrollPercent;
        this.trackUserAction('scroll', `${scrollPercent}%`, undefined, {
          scrollY: window.scrollY,
          documentHeight: document.body.scrollHeight,
          viewportHeight: window.innerHeight
        });
      }
    });

    // Track form submissions
    document.addEventListener('submit', (e) => {
      const form = e.target as HTMLFormElement;
      const formName = form.name || form.id || 'unnamed-form';
      this.trackUserAction('form_submit', formName);
    });

    // Track page unload
    window.addEventListener('beforeunload', () => {
      this.completePageView();
      this.endSession();
    });

    // Track visibility change
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.completePageView();
      } else {
        this.trackPageView();
      }
    });
  }

  // === Session Management ===

  private completePageView(): void {
    if (!this.currentPageView) return;

    const duration = Math.floor((Date.now() - this.pageLoadTime) / 1000);
    this.currentPageView.duration = duration;
    this.currentPageView.exitPath = window.location.pathname;

    // Aggiorna in storage
    const pageViews = this.getStoredData<PageView>('analytics-pageviews');
    const index = pageViews.findIndex(pv => pv.id === this.currentPageView?.id);
    if (index !== -1) {
      pageViews[index] = this.currentPageView;
      this.saveData('analytics-pageviews', pageViews);
    }
  }

  private endSession(): void {
    if (!this.currentSession) return;

    this.currentSession.endTime = new Date().toISOString();
    this.currentSession.duration = Math.floor(
      (new Date().getTime() - new Date(this.currentSession.startTime).getTime()) / 1000
    );
    this.currentSession.exitPage = window.location.pathname;

    this.updateSession();
  }

  private updateSession(): void {
    if (!this.currentSession) return;

    const sessions = this.getStoredData<UserSession>('analytics-sessions');
    const index = sessions.findIndex(s => s.id === this.currentSession?.id);
    if (index !== -1) {
      sessions[index] = this.currentSession;
      this.saveData('analytics-sessions', sessions);
    }
  }

  private startHeartbeat(): void {
    this.heartbeatInterval = setInterval(() => {
      if (this.currentSession && !document.hidden) {
        this.updateSession();
      }
    }, 30000); // Aggiorna ogni 30 secondi
  }

  // === Analytics Reports ===

  public generateReport(period: AnalyticsReport['period']): AnalyticsReport {
    const dateRange = this.getDateRange(period);
    const pageViews = this.getPageViewsInRange(dateRange.start, dateRange.end);
    const sessions = this.getSessionsInRange(dateRange.start, dateRange.end);
    const actions = this.getActionsInRange(dateRange.start, dateRange.end);
    const performance = this.getPerformanceInRange(dateRange.start, dateRange.end);

    // Previous period for comparison
    const previousRange = this.getPreviousDateRange(period);
    const previousPageViews = this.getPageViewsInRange(previousRange.start, previousRange.end);
    const previousSessions = this.getSessionsInRange(previousRange.start, previousRange.end);

    return {
      period,
      startDate: dateRange.start,
      endDate: dateRange.end,

      // Overview
      totalViews: pageViews.length,
      uniqueVisitors: new Set(sessions.map(s => s.userId || s.id)).size,
      totalSessions: sessions.length,
      averageSessionDuration: sessions.reduce((sum, s) => sum + (s.duration || 0), 0) / sessions.length || 0,
      bounceRate: sessions.filter(s => s.bounceRate).length / sessions.length * 100 || 0,

      // Popular content
      topPages: this.getTopPages(pageViews),
      topReferrers: this.getTopReferrers(sessions),

      // User behavior
      deviceBreakdown: this.getBreakdown(sessions, 'device'),
      browserBreakdown: this.getBreakdown(sessions, 'browser'),
      osBreakdown: this.getBreakdown(sessions, 'os'),
      languageBreakdown: this.getBreakdown(pageViews, 'language'),

      // Performance
      averageLoadTime: performance.reduce((sum, p) => sum + p.loadTime, 0) / performance.length || 0,
      performanceScore: this.calculatePerformanceScore(performance),

      // Engagement
      topActions: this.getTopActions(actions),
      searchQueries: this.getSearchQueries(actions),

      // Growth comparison
      periodComparison: {
        viewsChange: this.calculatePercentageChange(pageViews.length, previousPageViews.length),
        visitorsChange: this.calculatePercentageChange(
          new Set(sessions.map(s => s.userId || s.id)).size,
          new Set(previousSessions.map(s => s.userId || s.id)).size
        ),
        durationChange: this.calculatePercentageChange(
          sessions.reduce((sum, s) => sum + (s.duration || 0), 0) / sessions.length || 0,
          previousSessions.reduce((sum, s) => sum + (s.duration || 0), 0) / previousSessions.length || 0
        ),
        bounceRateChange: this.calculatePercentageChange(
          sessions.filter(s => s.bounceRate).length / sessions.length * 100 || 0,
          previousSessions.filter(s => s.bounceRate).length / previousSessions.length * 100 || 0
        )
      }
    };
  }

  // === Real-time Methods ===

  public getRealTimeStats(): {
    activeUsers: number;
    currentPageViews: number;
    topActivePages: Array<{ path: string; users: number }>;
    recentActions: UserAction[];
    systemLoad: number;
  } {
    const now = new Date();
    const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);

    const recentPageViews = this.getStoredData<PageView>('analytics-pageviews')
      .filter(pv => new Date(pv.timestamp) > fiveMinutesAgo);

    const recentSessions = this.getStoredData<UserSession>('analytics-sessions')
      .filter(s => new Date(s.startTime) > fiveMinutesAgo && !s.endTime);

    const recentActions = this.getStoredData<UserAction>('analytics-actions')
      .filter(a => new Date(a.timestamp) > fiveMinutesAgo)
      .slice(-10);

    return {
      activeUsers: recentSessions.length,
      currentPageViews: recentPageViews.length,
      topActivePages: this.getTopActivePages(recentPageViews),
      recentActions,
      systemLoad: this.calculateSystemLoad()
    };
  }

  // === Utility Methods ===

  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private getCurrentUserId(): string | undefined {
    // Integrazione con sistema auth esistente
    const adminAuth = localStorage.getItem('admin-auth');
    if (adminAuth) {
      try {
        const auth = JSON.parse(adminAuth);
        return auth.email;
      } catch {}
    }

    const votiAuth = localStorage.getItem('socio-loggato');
    if (votiAuth) {
      try {
        const auth = JSON.parse(votiAuth);
        return auth.email;
      } catch {}
    }

    return undefined;
  }

  private getDeviceType(): 'mobile' | 'tablet' | 'desktop' {
    const userAgent = navigator.userAgent;
    if (/tablet|ipad|playbook|silk/i.test(userAgent)) return 'tablet';
    if (/mobile|iphone|ipod|android|blackberry|opera|mini|windows\sce|palm|smartphone|iemobile/i.test(userAgent)) return 'mobile';
    return 'desktop';
  }

  private getBrowser(): string {
    const userAgent = navigator.userAgent;
    if (userAgent.includes('Chrome')) return 'Chrome';
    if (userAgent.includes('Firefox')) return 'Firefox';
    if (userAgent.includes('Safari')) return 'Safari';
    if (userAgent.includes('Edge')) return 'Edge';
    return 'Other';
  }

  private getOS(): string {
    const userAgent = navigator.userAgent;
    if (userAgent.includes('Windows')) return 'Windows';
    if (userAgent.includes('Mac')) return 'macOS';
    if (userAgent.includes('Linux')) return 'Linux';
    if (userAgent.includes('Android')) return 'Android';
    if (userAgent.includes('iOS')) return 'iOS';
    return 'Other';
  }

  private getStoredData<T>(key: string): T[] {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  private saveData<T>(key: string, data: T[]): void {
    try {
      // Mantieni solo gli ultimi 1000 record per performance
      const limitedData = data.slice(-1000);
      localStorage.setItem(key, JSON.stringify(limitedData));
    } catch (error) {
      console.error(`Errore salvataggio ${key}:`, error);
    }
  }

  private getDateRange(period: AnalyticsReport['period']): { start: string; end: string } {
    const now = new Date();
    const start = new Date();

    switch (period) {
      case 'today':
        start.setHours(0, 0, 0, 0);
        break;
      case 'week':
        start.setDate(now.getDate() - 7);
        break;
      case 'month':
        start.setMonth(now.getMonth() - 1);
        break;
      case 'year':
        start.setFullYear(now.getFullYear() - 1);
        break;
    }

    return {
      start: start.toISOString(),
      end: now.toISOString()
    };
  }

  private getPreviousDateRange(period: AnalyticsReport['period']): { start: string; end: string } {
    const current = this.getDateRange(period);
    const duration = new Date(current.end).getTime() - new Date(current.start).getTime();

    return {
      start: new Date(new Date(current.start).getTime() - duration).toISOString(),
      end: current.start
    };
  }

  private getPageViewsInRange(start: string, end: string): PageView[] {
    return this.getStoredData<PageView>('analytics-pageviews')
      .filter(pv => pv.timestamp >= start && pv.timestamp <= end);
  }

  private getSessionsInRange(start: string, end: string): UserSession[] {
    return this.getStoredData<UserSession>('analytics-sessions')
      .filter(s => s.startTime >= start && s.startTime <= end);
  }

  private getActionsInRange(start: string, end: string): UserAction[] {
    return this.getStoredData<UserAction>('analytics-actions')
      .filter(a => a.timestamp >= start && a.timestamp <= end);
  }

  private getPerformanceInRange(start: string, end: string): PerformanceMetric[] {
    return this.getStoredData<PerformanceMetric>('analytics-performance')
      .filter(p => p.timestamp >= start && p.timestamp <= end);
  }

  private getTopPages(pageViews: PageView[]) {
    const pathCounts: Record<string, { views: number; title: string; uniqueViews: Set<string> }> = {};

    for (const pv of pageViews) {
      if (!pathCounts[pv.path]) {
        pathCounts[pv.path] = { views: 0, title: pv.title, uniqueViews: new Set() };
      }
      pathCounts[pv.path].views++;
      pathCounts[pv.path].uniqueViews.add(pv.sessionId);
    }

    return Object.entries(pathCounts)
      .map(([path, data]) => ({
        path,
        title: data.title,
        views: data.views,
        uniqueViews: data.uniqueViews.size
      }))
      .sort((a, b) => b.views - a.views)
      .slice(0, 10);
  }

  private getTopReferrers(sessions: UserSession[]) {
    const referrerCounts: Record<string, number> = {};

    for (const session of sessions) {
      referrerCounts[session.referrer] = (referrerCounts[session.referrer] || 0) + 1;
    }

    return Object.entries(referrerCounts)
      .map(([referrer, visits]) => ({ referrer, visits }))
      .sort((a, b) => b.visits - a.visits)
      .slice(0, 10);
  }

  private getBreakdown<T extends UserSession | PageView>(data: T[], field: keyof T): Record<string, number> {
    const breakdown: Record<string, number> = {};

    for (const item of data) {
      const value = String(item[field]);
      breakdown[value] = (breakdown[value] || 0) + 1;
    }

    return breakdown;
  }

  private getTopActions(actions: UserAction[]) {
    const actionCounts: Record<string, number> = {};

    for (const action of actions) {
      actionCounts[action.type] = (actionCounts[action.type] || 0) + 1;
    }

    return Object.entries(actionCounts)
      .map(([type, count]) => ({ type, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }

  private getSearchQueries(actions: UserAction[]) {
    const queryActions = actions.filter(a => a.type === 'search' && a.value);
    const queryCounts: Record<string, number> = {};

    for (const action of queryActions) {
      if (action.value) {
        queryCounts[action.value] = (queryCounts[action.value] || 0) + 1;
      }
    }

    return Object.entries(queryCounts)
      .map(([query, count]) => ({ query, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }

  private calculatePercentageChange(current: number, previous: number): number {
    if (previous === 0) return current > 0 ? 100 : 0;
    return Math.round(((current - previous) / previous) * 100);
  }

  private calculatePerformanceScore(metrics: PerformanceMetric[]): number {
    if (metrics.length === 0) return 0;

    const avgLoadTime = metrics.reduce((sum, m) => sum + m.loadTime, 0) / metrics.length;

    // Score basato su load time (0-100)
    if (avgLoadTime <= 1000) return 100;
    if (avgLoadTime <= 2500) return 90;
    if (avgLoadTime <= 4000) return 75;
    if (avgLoadTime <= 5500) return 50;
    return 25;
  }

  private getTopActivePages(pageViews: PageView[]) {
    const pathCounts: Record<string, Set<string>> = {};

    for (const pv of pageViews) {
      if (!pathCounts[pv.path]) {
        pathCounts[pv.path] = new Set();
      }
      pathCounts[pv.path].add(pv.sessionId);
    }

    return Object.entries(pathCounts)
      .map(([path, sessions]) => ({ path, users: sessions.size }))
      .sort((a, b) => b.users - a.users)
      .slice(0, 5);
  }

  private calculateSystemLoad(): number {
    // Simula carico del sistema basato su dati in memoria
    const totalRecords =
      this.getStoredData('analytics-pageviews').length +
      this.getStoredData('analytics-sessions').length +
      this.getStoredData('analytics-actions').length +
      this.getStoredData('analytics-performance').length;

    return Math.min(Math.round((totalRecords / 10000) * 100), 100);
  }

  // === Public API for Manual Tracking ===

  public trackEvent(category: string, action: string, label?: string, value?: number): void {
    this.trackUserAction('click', `${category}:${action}`, label, { category, action, label, value });
  }

  public trackDownload(filename: string, type: string): void {
    this.trackUserAction('download', filename, type);
  }

  public trackSearch(query: string, results?: number): void {
    this.trackUserAction('search', 'search-box', query, { results });
  }

  public trackVote(votationId: string, option: string): void {
    this.trackUserAction('vote', votationId, option);
  }

  public trackComment(articleId: string, commentType: 'new' | 'reply'): void {
    this.trackUserAction('comment', articleId, commentType);
  }

  // === Cleanup ===

  public destroy(): void {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }
    this.completePageView();
    this.endSession();
    this.isTracking = false;
  }
}

// Esporta istanza singleton
export const analyticsService = new AnalyticsService();
export default analyticsService;
export type { AnalyticsReport, PageView, UserAction, UserSession, PerformanceMetric, AlertRule };
