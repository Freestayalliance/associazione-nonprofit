// Tipi per il sistema di approvazione workflow
export type UserRole = 'super-admin' | 'admin' | 'moderatore' | 'editor' | 'socio' | 'guest';
export type WorkflowStatus = 'draft' | 'pending_review' | 'under_review' | 'pending_approval' | 'approved' | 'rejected' | 'revision_required';
export type ApprovalAction = 'submit_for_review' | 'review' | 'approve' | 'reject' | 'request_revision' | 'resubmit';

export interface Permission {
  id: string;
  name: string;
  description: string;
  category: 'voting' | 'admin' | 'content' | 'system';
}

export interface RoleDefinition {
  id: UserRole;
  name: string;
  description: string;
  permissions: string[];
  hierarchyLevel: number; // 1 = massimo, 10 = minimo
  canApprove: boolean;
  canReject: boolean;
  canRequestRevision: boolean;
}

export interface WorkflowStep {
  id: string;
  name: string;
  description: string;
  requiredRole: UserRole;
  requiredPermissions: string[];
  order: number;
  isOptional: boolean;
  autoApprove?: boolean;
}

export interface ApprovalRequest {
  id: string;
  votingId: string;
  votingTitle: string;
  status: WorkflowStatus;
  currentStep: number;
  requestedBy: string;
  requestedAt: string;

  // Workflow tracking
  steps: WorkflowStep[];
  completedSteps: string[];
  pendingSteps: string[];

  // Approvazioni
  approvals: ApprovalAction[];
  rejections: ApprovalAction[];
  revisionRequests: ApprovalAction[];

  // Audit trail
  auditTrail: Array<{
    id: string;
    action: ApprovalAction;
    status: WorkflowStatus;
    userId: string;
    userName: string;
    userRole: UserRole;
    timestamp: string;
    comment?: string;
    attachments?: string[];
  }>;

  // Metadati
  priority: 'low' | 'normal' | 'high' | 'urgent';
  category: 'membership' | 'proposal' | 'budget' | 'board' | 'policy' | 'emergency';
  tags: string[];

  // Scadenze
  deadline?: string;
  reminderSent: boolean;
  escalated: boolean;
}

export interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  category: 'membership' | 'proposal' | 'budget' | 'board' | 'policy' | 'emergency';
  steps: WorkflowStep[];
  isDefault: boolean;
  autoStart: boolean;
}

export interface ApprovalStatistics {
  total: number;
  pending: number;
  approved: number;
  rejected: number;
  overdue: number;

  byStatus: Record<WorkflowStatus, number>;
  byCategory: Record<string, number>;
  byRole: Record<UserRole, number>;

  averageApprovalTime: number;
  bottlenecks: Array<{
    step: string;
    avgTime: number;
    count: number;
  }>;

  recentActivity: ApprovalRequest[];
}

export class WorkflowApprovalService {
  private static instance: WorkflowApprovalService;
  private requests: ApprovalRequest[] = [];
  private templates: WorkflowTemplate[] = [];
  private permissions: Permission[] = [];
  private roles: RoleDefinition[] = [];
  private listeners: ((requests: ApprovalRequest[]) => void)[] = [];

  private constructor() {
    if (typeof window !== 'undefined') {
      this.initializePermissions();
      this.initializeRoles();
      this.initializeTemplates();
      this.loadRequests();
      this.startReminderService();
    }
  }

  static getInstance(): WorkflowApprovalService {
    if (!WorkflowApprovalService.instance) {
      WorkflowApprovalService.instance = new WorkflowApprovalService();
    }
    return WorkflowApprovalService.instance;
  }

  private isBrowser(): boolean {
    return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
  }

  // === INIZIALIZZAZIONE SISTEMA ===

  private initializePermissions(): void {
    this.permissions = [
      // Permessi Votazioni
      { id: 'voting.create', name: 'Creare Votazioni', description: 'Creare nuove votazioni', category: 'voting' },
      { id: 'voting.edit', name: 'Modificare Votazioni', description: 'Modificare votazioni esistenti', category: 'voting' },
      { id: 'voting.delete', name: 'Eliminare Votazioni', description: 'Eliminare votazioni', category: 'voting' },
      { id: 'voting.activate', name: 'Attivare Votazioni', description: 'Pubblicare e attivare votazioni', category: 'voting' },
      { id: 'voting.close', name: 'Chiudere Votazioni', description: 'Chiudere votazioni attive', category: 'voting' },
      { id: 'voting.view_results', name: 'Vedere Risultati', description: 'Visualizzare risultati votazioni', category: 'voting' },

      // Permessi Approvazione
      { id: 'approval.submit', name: 'Inviare per Approvazione', description: 'Sottomettere elementi per approvazione', category: 'admin' },
      { id: 'approval.review', name: 'Revisionare', description: 'Revisionare richieste di approvazione', category: 'admin' },
      { id: 'approval.approve', name: 'Approvare', description: 'Approvare richieste', category: 'admin' },
      { id: 'approval.reject', name: 'Rigettare', description: 'Rigettare richieste', category: 'admin' },
      { id: 'approval.escalate', name: 'Escalation', description: 'Escalare richieste bloccate', category: 'admin' },

      // Permessi Admin
      { id: 'admin.users', name: 'Gestire Utenti', description: 'Gestire utenti e ruoli', category: 'admin' },
      { id: 'admin.settings', name: 'Impostazioni Sistema', description: 'Modificare impostazioni sistema', category: 'admin' },
      { id: 'admin.audit', name: 'Log Audit', description: 'Visualizzare log audit', category: 'admin' },
      { id: 'admin.backup', name: 'Backup', description: 'Gestire backup e restore', category: 'admin' },

      // Permessi Sistema
      { id: 'system.notifications', name: 'Notifiche Sistema', description: 'Inviare notifiche sistema', category: 'system' },
      { id: 'system.maintenance', name: 'Manutenzione', description: 'Modalità manutenzione', category: 'system' },
      { id: 'system.analytics', name: 'Analytics', description: 'Visualizzare analytics avanzati', category: 'system' }
    ];
  }

  private initializeRoles(): void {
    this.roles = [
      {
        id: 'super-admin',
        name: 'Super Amministratore',
        description: 'Accesso completo a tutto il sistema',
        permissions: this.permissions.map(p => p.id),
        hierarchyLevel: 1,
        canApprove: true,
        canReject: true,
        canRequestRevision: true
      },
      {
        id: 'admin',
        name: 'Amministratore',
        description: 'Gestione completa votazioni e utenti',
        permissions: [
          'voting.create', 'voting.edit', 'voting.delete', 'voting.activate', 'voting.close', 'voting.view_results',
          'approval.submit', 'approval.review', 'approval.approve', 'approval.reject',
          'admin.users', 'admin.audit', 'system.notifications'
        ],
        hierarchyLevel: 2,
        canApprove: true,
        canReject: true,
        canRequestRevision: true
      },
      {
        id: 'moderatore',
        name: 'Moderatore',
        description: 'Revisione e gestione contenuti',
        permissions: [
          'voting.create', 'voting.edit', 'voting.view_results',
          'approval.submit', 'approval.review', 'approval.request_revision',
          'admin.audit'
        ],
        hierarchyLevel: 3,
        canApprove: false,
        canReject: false,
        canRequestRevision: true
      },
      {
        id: 'editor',
        name: 'Editor',
        description: 'Creazione e modifica contenuti',
        permissions: [
          'voting.create', 'voting.edit',
          'approval.submit'
        ],
        hierarchyLevel: 4,
        canApprove: false,
        canReject: false,
        canRequestRevision: false
      },
      {
        id: 'socio',
        name: 'Socio',
        description: 'Partecipazione alle votazioni',
        permissions: ['voting.view_results'],
        hierarchyLevel: 5,
        canApprove: false,
        canReject: false,
        canRequestRevision: false
      },
      {
        id: 'guest',
        name: 'Ospite',
        description: 'Accesso limitato in sola lettura',
        permissions: [],
        hierarchyLevel: 6,
        canApprove: false,
        canReject: false,
        canRequestRevision: false
      }
    ];
  }

  private initializeTemplates(): void {
    this.templates = [
      {
        id: 'membership-approval',
        name: 'Approvazione Ammissione Socio',
        description: 'Workflow per approvazione nuovi soci',
        category: 'membership',
        isDefault: true,
        autoStart: true,
        steps: [
          {
            id: 'review',
            name: 'Revisione Documentazione',
            description: 'Verifica completezza documentazione candidato',
            requiredRole: 'moderatore',
            requiredPermissions: ['approval.review'],
            order: 1,
            isOptional: false
          },
          {
            id: 'approval',
            name: 'Approvazione Finale',
            description: 'Approvazione definitiva ammissione',
            requiredRole: 'admin',
            requiredPermissions: ['approval.approve'],
            order: 2,
            isOptional: false
          }
        ]
      },
      {
        id: 'budget-approval',
        name: 'Approvazione Bilancio',
        description: 'Workflow per approvazione bilanci',
        category: 'budget',
        isDefault: true,
        autoStart: false,
        steps: [
          {
            id: 'financial-review',
            name: 'Revisione Finanziaria',
            description: 'Controllo numeri e calcoli',
            requiredRole: 'moderatore',
            requiredPermissions: ['approval.review'],
            order: 1,
            isOptional: false
          },
          {
            id: 'admin-review',
            name: 'Revisione Amministrativa',
            description: 'Controllo conformità normative',
            requiredRole: 'admin',
            requiredPermissions: ['approval.review', 'approval.approve'],
            order: 2,
            isOptional: false
          },
          {
            id: 'final-approval',
            name: 'Approvazione Consiglio',
            description: 'Approvazione finale del consiglio',
            requiredRole: 'super-admin',
            requiredPermissions: ['approval.approve'],
            order: 3,
            isOptional: false
          }
        ]
      },
      {
        id: 'emergency-approval',
        name: 'Approvazione d\'Urgenza',
        description: 'Workflow accelerato per emergenze',
        category: 'emergency',
        isDefault: false,
        autoStart: true,
        steps: [
          {
            id: 'urgent-approval',
            name: 'Approvazione d\'Urgenza',
            description: 'Approvazione immediata per emergenze',
            requiredRole: 'admin',
            requiredPermissions: ['approval.approve'],
            order: 1,
            isOptional: false,
            autoApprove: false
          }
        ]
      }
    ];
  }

  // === GESTIONE RICHIESTE ===

  async createApprovalRequest(
    votingId: string,
    votingTitle: string,
    category: 'membership' | 'proposal' | 'budget' | 'board' | 'policy' | 'emergency',
    requestedBy: string,
    priority: 'low' | 'normal' | 'high' | 'urgent' = 'normal'
  ): Promise<ApprovalRequest> {
    if (!this.isBrowser()) {
      throw new Error('Browser environment required');
    }

    // Trova template appropriato
    const template = this.templates.find(t => t.category === category && t.isDefault) || this.templates[0];

    const request: ApprovalRequest = {
      id: this.generateRequestId(),
      votingId,
      votingTitle,
      status: 'pending_review',
      currentStep: 0,
      requestedBy,
      requestedAt: new Date().toISOString(),

      steps: [...template.steps],
      completedSteps: [],
      pendingSteps: template.steps.map(s => s.id),

      approvals: [],
      rejections: [],
      revisionRequests: [],

      auditTrail: [{
        id: this.generateAuditId(),
        action: 'submit_for_review',
        status: 'pending_review',
        userId: requestedBy,
        userName: await this.getUserName(requestedBy),
        userRole: await this.getUserRole(requestedBy),
        timestamp: new Date().toISOString(),
        comment: `Richiesta di approvazione creata per: ${votingTitle}`
      }],

      priority,
      category,
      tags: [category, priority],
      reminderSent: false,
      escalated: false
    };

    this.requests.push(request);
    this.saveRequests();
    this.notifyListeners();

    // Invia notifiche automatiche
    await this.sendWorkflowNotifications(request, 'submit_for_review');

    return request;
  }

  async processApproval(
    requestId: string,
    action: ApprovalAction,
    userId: string,
    comment?: string
  ): Promise<ApprovalRequest> {
    if (!this.isBrowser()) {
      throw new Error('Browser environment required');
    }

    const request = this.requests.find(r => r.id === requestId);
    if (!request) {
      throw new Error('Richiesta di approvazione non trovata');
    }

    const userRole = await this.getUserRole(userId);
    const userName = await this.getUserName(userId);

    // Verifica permessi
    if (!await this.checkPermission(userRole, action, request)) {
      throw new Error('Permessi insufficienti per questa azione');
    }

    // Aggiorna stato in base all'azione
    const newStatus = this.calculateNewStatus(request, action);
    const currentStep = request.steps[request.currentStep];

    // Aggiungi al trail audit
    const auditEntry = {
      id: this.generateAuditId(),
      action,
      status: newStatus,
      userId,
      userName,
      userRole,
      timestamp: new Date().toISOString(),
      comment
    };

    request.auditTrail.push(auditEntry);

    // Aggiorna stato richiesta
    request.status = newStatus;

    // Gestisci l'azione specifica
    switch (action) {
      case 'approve':
        if (currentStep) {
          request.completedSteps.push(currentStep.id);
          request.pendingSteps = request.pendingSteps.filter(s => s !== currentStep.id);
        }
        request.approvals.push(action);

        // Vai al prossimo step o completa
        if (request.currentStep < request.steps.length - 1) {
          request.currentStep++;
          request.status = 'pending_approval';
        } else {
          request.status = 'approved';
          await this.finalizeApproval(request);
        }
        break;

      case 'reject':
        request.rejections.push(action);
        request.status = 'rejected';
        break;

      case 'request_revision':
        request.revisionRequests.push(action);
        request.status = 'revision_required';
        break;

      case 'resubmit':
        request.status = 'pending_review';
        request.currentStep = 0;
        request.pendingSteps = request.steps.map(s => s.id);
        request.completedSteps = [];
        break;
    }

    this.saveRequests();
    this.notifyListeners();

    // Invia notifiche
    await this.sendWorkflowNotifications(request, action);

    return request;
  }

  private async finalizeApproval(request: ApprovalRequest): Promise<void> {
    try {
      // Integrazione con VotingAdminService
      const { VotingAdminService } = await import('./VotingAdminService');
      const votingService = VotingAdminService.getInstance();

      // Attiva automaticamente la votazione se approvata
      await votingService.activateVoting(request.votingId, 'system-auto-approval');

      // Invia notifica di completamento
      const { AdminNotificationService } = await import('./AdminNotificationService');
      const notificationService = AdminNotificationService.getInstance();

      await notificationService.notifySystemAlert(
        `Votazione "${request.votingTitle}" approvata e attivata automaticamente`
      );
    } catch (error) {
      console.error('Errore finalizzazione approvazione:', error);
    }
  }

  // === PERMESSI E VALIDAZIONE ===

  async checkPermission(userRole: UserRole, action: ApprovalAction, request: ApprovalRequest): Promise<boolean> {
    const role = this.roles.find(r => r.id === userRole);
    if (!role) return false;

    const currentStep = request.steps[request.currentStep];

    // Controllo ruolo richiesto per lo step corrente
    if (currentStep && currentStep.requiredRole !== userRole) {
      // Verifica gerarchia: ruoli superiori possono agire al posto di quelli inferiori
      const currentRoleLevel = role.hierarchyLevel;
      const requiredRole = this.roles.find(r => r.id === currentStep.requiredRole);
      if (!requiredRole || currentRoleLevel > requiredRole.hierarchyLevel) {
        return false;
      }
    }

    // Controllo permessi specifici
    if (currentStep) {
      const hasRequiredPermissions = currentStep.requiredPermissions.every(
        permission => role.permissions.includes(permission)
      );
      if (!hasRequiredPermissions) return false;
    }

    // Controllo azioni specifiche
    switch (action) {
      case 'approve':
        return role.canApprove;
      case 'reject':
        return role.canReject;
      case 'request_revision':
        return role.canRequestRevision;
      case 'submit_for_review':
      case 'resubmit':
        return role.permissions.includes('approval.submit');
      case 'review':
        return role.permissions.includes('approval.review');
      default:
        return false;
    }
  }

  private calculateNewStatus(request: ApprovalRequest, action: ApprovalAction): WorkflowStatus {
    switch (action) {
      case 'submit_for_review':
      case 'resubmit':
        return 'pending_review';
      case 'review':
        return 'under_review';
      case 'approve':
        return request.currentStep >= request.steps.length - 1 ? 'approved' : 'pending_approval';
      case 'reject':
        return 'rejected';
      case 'request_revision':
        return 'revision_required';
      default:
        return request.status;
    }
  }

  // === NOTIFICHE WORKFLOW ===

  private async sendWorkflowNotifications(request: ApprovalRequest, action: ApprovalAction): Promise<void> {
    try {
      const { AdminNotificationService } = await import('./AdminNotificationService');
      const notificationService = AdminNotificationService.getInstance();

      const currentStep = request.steps[request.currentStep];
      let title = '';
      let message = '';

      switch (action) {
        case 'submit_for_review':
          title = '📋 Nuova Richiesta di Approvazione';
          message = `"${request.votingTitle}" è stata sottomessa per approvazione`;
          break;
        case 'approve':
          if (request.status === 'approved') {
            title = '✅ Approvazione Completata';
            message = `"${request.votingTitle}" è stata approvata e attivata`;
          } else {
            title = '👍 Step Approvato';
            message = `Step "${currentStep?.name}" approvato per "${request.votingTitle}"`;
          }
          break;
        case 'reject':
          title = '❌ Richiesta Rigettata';
          message = `"${request.votingTitle}" è stata rigettata`;
          break;
        case 'request_revision':
          title = '📝 Revisione Richiesta';
          message = `Richiesta revisione per "${request.votingTitle}"`;
          break;
      }

      // Invia notifica
      const notification = {
        id: `workflow-${Date.now()}`,
        type: 'system' as const,
        title,
        message,
        priority: request.priority === 'urgent' ? 'urgent' as const : 'normal' as const,
        timestamp: new Date().toISOString(),
        read: false,
        action: {
          text: 'Visualizza',
          url: `/admin/approvazioni/${request.id}`
        }
      };

      // Qui dovresti implementare l'invio delle notifiche ai ruoli appropriati
      console.log('Workflow notification sent:', notification);

    } catch (error) {
      console.error('Errore invio notifiche workflow:', error);
    }
  }

  // === STATISTICHE E REPORTING ===

  getApprovalStatistics(): ApprovalStatistics {
    if (!this.isBrowser()) {
      return {
        total: 0, pending: 0, approved: 0, rejected: 0, overdue: 0,
        byStatus: {} as Record<WorkflowStatus, number>,
        byCategory: {} as Record<string, number>,
        byRole: {} as Record<UserRole, number>,
        averageApprovalTime: 0, bottlenecks: [], recentActivity: []
      };
    }

    const total = this.requests.length;
    const pending = this.requests.filter(r => ['pending_review', 'under_review', 'pending_approval'].includes(r.status)).length;
    const approved = this.requests.filter(r => r.status === 'approved').length;
    const rejected = this.requests.filter(r => r.status === 'rejected').length;

    const now = new Date();
    const overdue = this.requests.filter(r => {
      if (!r.deadline) return false;
      return new Date(r.deadline) < now && !['approved', 'rejected'].includes(r.status);
    }).length;

    const byStatus = this.requests.reduce((acc, req) => {
      acc[req.status] = (acc[req.status] || 0) + 1;
      return acc;
    }, {} as Record<WorkflowStatus, number>);

    const byCategory = this.requests.reduce((acc, req) => {
      acc[req.category] = (acc[req.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Calcola tempo medio di approvazione
    const approvedRequests = this.requests.filter(r => r.status === 'approved');
    const averageApprovalTime = approvedRequests.length > 0
      ? approvedRequests.reduce((sum, req) => {
          const start = new Date(req.requestedAt);
          const end = new Date(req.auditTrail[req.auditTrail.length - 1].timestamp);
          return sum + (end.getTime() - start.getTime());
        }, 0) / approvedRequests.length / (1000 * 60 * 60 * 24) // in giorni
      : 0;

    const recentActivity = this.requests
      .sort((a, b) => new Date(b.requestedAt).getTime() - new Date(a.requestedAt).getTime())
      .slice(0, 10);

    return {
      total, pending, approved, rejected, overdue,
      byStatus, byCategory, byRole: {} as Record<UserRole, number>,
      averageApprovalTime, bottlenecks: [], recentActivity
    };
  }

  // === UTILITY METHODS ===

  private async getUserRole(userId: string): Promise<UserRole> {
    // Simulazione - in produzione useresti un sistema di autenticazione reale
    if (userId === 'admin' || userId === 'system-auto-approval') return 'admin';
    if (userId === 'super-admin') return 'super-admin';
    if (userId === 'moderatore') return 'moderatore';
    return 'editor';
  }

  private async getUserName(userId: string): Promise<string> {
    // Simulazione - in produzione useresti un database utenti
    const userNames: Record<string, string> = {
      'admin': 'Marco Antonelli',
      'super-admin': 'Direttore Generale',
      'moderatore': 'Sara Bianchi',
      'editor': 'Luca Rossi'
    };
    return userNames[userId] || 'Utente Sconosciuto';
  }

  private generateRequestId(): string {
    return `REQ-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private generateAuditId(): string {
    return `AUD-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
  }

  // === PERSISTENZA DATI ===

  private saveRequests(): void {
    if (!this.isBrowser()) return;
    try {
      localStorage.setItem('workflow-approval-requests', JSON.stringify(this.requests));
    } catch (error) {
      console.error('Errore salvataggio richieste approvazione:', error);
    }
  }

  private loadRequests(): void {
    if (!this.isBrowser()) return;
    try {
      const stored = localStorage.getItem('workflow-approval-requests');
      if (stored) {
        this.requests = JSON.parse(stored);
      }
    } catch (error) {
      console.error('Errore caricamento richieste approvazione:', error);
    }
  }

  // === LISTENERS ===

  addListener(listener: (requests: ApprovalRequest[]) => void): () => void {
    this.listeners.push(listener);
    listener(this.requests);

    return () => {
      const index = this.listeners.indexOf(listener);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  private notifyListeners(): void {
    for (const listener of this.listeners) {
      listener(this.requests);
    }
  }

  // === SERVIZIO PROMEMORIA ===

  private startReminderService(): void {
    // Controllo promemoria ogni ora
    setInterval(() => {
      this.checkAndSendReminders();
    }, 60 * 60 * 1000);
  }

  private async checkAndSendReminders(): Promise<void> {
    if (!this.isBrowser()) return;

    const now = new Date();
    const pendingRequests = this.requests.filter(r =>
      ['pending_review', 'pending_approval'].includes(r.status) && !r.reminderSent
    );

    for (const request of pendingRequests) {
      const daysSinceRequest = (now.getTime() - new Date(request.requestedAt).getTime()) / (1000 * 60 * 60 * 24);

      // Invia promemoria dopo 2 giorni per richieste normali, 1 giorno per urgenti
      const reminderThreshold = request.priority === 'urgent' ? 1 : 2;

      if (daysSinceRequest >= reminderThreshold) {
        await this.sendReminderNotification(request);
        request.reminderSent = true;
      }
    }

    this.saveRequests();
  }

  private async sendReminderNotification(request: ApprovalRequest): Promise<void> {
    try {
      const { AdminNotificationService } = await import('./AdminNotificationService');
      const notificationService = AdminNotificationService.getInstance();

      await notificationService.notifySystemAlert(
        `Promemoria: Richiesta di approvazione in sospeso per "${request.votingTitle}"`
      );
    } catch (error) {
      console.error('Errore invio promemoria:', error);
    }
  }

  // === API PUBBLICHE ===

  getRequest(id: string): ApprovalRequest | undefined {
    return this.requests.find(r => r.id === id);
  }

  getAllRequests(): ApprovalRequest[] {
    return [...this.requests].sort((a, b) =>
      new Date(b.requestedAt).getTime() - new Date(a.requestedAt).getTime()
    );
  }

  getPendingRequests(): ApprovalRequest[] {
    return this.requests.filter(r =>
      ['pending_review', 'under_review', 'pending_approval'].includes(r.status)
    );
  }

  getRequestsByUser(userId: string): ApprovalRequest[] {
    return this.requests.filter(r => r.requestedBy === userId);
  }

  getRoles(): RoleDefinition[] {
    return [...this.roles];
  }

  getPermissions(): Permission[] {
    return [...this.permissions];
  }

  getTemplates(): WorkflowTemplate[] {
    return [...this.templates];
  }
}

export default WorkflowApprovalService;
