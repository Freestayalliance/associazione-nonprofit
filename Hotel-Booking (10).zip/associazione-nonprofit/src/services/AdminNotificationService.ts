// Tipi per le notifiche admin
export interface AdminNotification {
  id: string;
  type: 'new_vote' | 'vote_ending' | 'new_member' | 'payment' | 'system' | 'urgent';
  title: string;
  message: string;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  timestamp: string;
  read: boolean;
  action?: {
    text: string;
    url: string;
  };
}

export interface NotificationStats {
  total: number;
  unread: number;
  byType: Record<string, number>;
  byPriority: Record<string, number>;
  recent: AdminNotification[];
}

export class AdminNotificationService {
  private static instance: AdminNotificationService;
  private notifications: AdminNotification[] = [];
  private listeners: ((notifications: AdminNotification[]) => void)[] = [];
  private pollInterval: NodeJS.Timeout | null = null;

  private constructor() {
    // Solo se siamo nel browser
    if (this.isBrowser()) {
      this.notifications = this.getStoredNotifications();
      // Non chiamare checkNotificationPermission nel constructor per evitare problemi SSR
      this.startPolling();
    }
  }

  static getInstance(): AdminNotificationService {
    if (!AdminNotificationService.instance) {
      AdminNotificationService.instance = new AdminNotificationService();
    }
    return AdminNotificationService.instance;
  }

  // Controlla se siamo nel browser
  private isBrowser(): boolean {
    return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
  }

  // Controlla e richiede i permessi per le notifiche
  async checkNotificationPermission(): Promise<boolean> {
    if (!this.isBrowser()) {
      console.log("Browser non disponibile o siamo in SSR");
      return false;
    }

    if (!("Notification" in window)) {
      console.log("Browser non supporta le notifiche desktop");
      return false;
    }

    try {
      if (Notification.permission === "granted") {
        return true;
      }
      if (Notification.permission !== "denied") {
        const permission = await Notification.requestPermission();
        return permission === "granted";
      }
    } catch (error) {
      console.error('Errore richiesta permessi notifiche:', error);
    }

    return false;
  }

  // Invia una notifica desktop
  async sendDesktopNotification(notification: AdminNotification): Promise<boolean> {
    if (!this.isBrowser()) return false;

    const hasPermission = await this.checkNotificationPermission();
    if (!hasPermission) return false;

    try {
      const desktopNotification = new Notification(notification.title, {
        body: notification.message,
        icon: '/favicon.ico',
        badge: '/favicon.ico',
        tag: notification.id,
        requireInteraction: notification.priority === 'urgent'
      });

      // Gestione click
      if (notification.action) {
        desktopNotification.onclick = () => {
          window.focus();
          window.open(notification.action?.url, '_self');
          desktopNotification.close();
        };
      }

      // Auto-chiusura dopo 5 secondi (tranne per quelle urgenti)
      if (notification.priority !== 'urgent') {
        setTimeout(() => {
          desktopNotification.close();
        }, 5000);
      }

      return true;
    } catch (error) {
      console.error('Errore invio notifica desktop:', error);
      return false;
    }
  }

  // Salva notifica nel localStorage
  private saveNotifications(): void {
    if (!this.isBrowser()) return;

    try {
      localStorage.setItem('admin-notifications', JSON.stringify(this.notifications));
    } catch (error) {
      console.error('Errore salvataggio notifiche:', error);
    }
  }

  // Recupera notifiche salvate
  getStoredNotifications(): AdminNotification[] {
    if (!this.isBrowser()) return [];

    try {
      const stored = localStorage.getItem('admin-notifications');
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Errore lettura notifiche:', error);
      return [];
    }
  }

  // Gestione listeners
  addListener(listener: (notifications: AdminNotification[]) => void): () => void {
    this.listeners.push(listener);

    // Invia subito le notifiche attuali
    listener(this.notifications);

    // Ritorna funzione di cleanup
    return () => {
      const index = this.listeners.indexOf(listener);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  // Notifica tutti i listeners
  private notifyListeners(notifications: AdminNotification[]): void {
    for (const listener of this.listeners) {
      listener(notifications);
    }
  }

  // Marca notifica come letta
  markAsRead(notificationId: string): void {
    if (!this.isBrowser()) return;

    const notification = this.notifications.find(n => n.id === notificationId);
    if (notification) {
      notification.read = true;
      this.saveNotifications();
      this.notifyListeners(this.notifications);
    }
  }

  // Marca tutte le notifiche come lette
  markAllAsRead(): void {
    if (!this.isBrowser()) return;

    for (const notification of this.notifications) {
      notification.read = true;
    }
    this.saveNotifications();
    this.notifyListeners(this.notifications);
  }

  // Elimina notifica
  deleteNotification(notificationId: string): void {
    if (!this.isBrowser()) return;

    const index = this.notifications.findIndex(n => n.id === notificationId);
    if (index > -1) {
      this.notifications.splice(index, 1);
      this.saveNotifications();
      this.notifyListeners(this.notifications);
    }
  }

  // Cancella tutte le notifiche
  clearAllNotifications(): void {
    if (!this.isBrowser()) return;

    this.notifications = [];
    this.saveNotifications();
    this.notifyListeners(this.notifications);
  }

  // Avvia il polling per nuove attività
  startPolling(): void {
    if (!this.isBrowser()) return;

    // Ferma polling esistente
    this.stopPolling();

    // Controllo immediato
    if (this.isBrowser()) {
      this.checkForNewActivities();
    }

    // Polling ogni 30 secondi
    this.pollInterval = setInterval(() => {
      if (this.isBrowser()) {
        this.checkForNewActivities();
      }
    }, 30000);
  }

  // Ferma il polling
  stopPolling(): void {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
  }

  // Controlla nuove attività e genera notifiche
  private async checkForNewActivities(): Promise<void> {
    if (!this.isBrowser()) return;

    try {
      // Simula controllo di nuove attività
      const adminUser = this.isBrowser() ? localStorage.getItem('adminUser') : null;
      if (!adminUser) return;

      // Controlla votazioni
      const voti = JSON.parse(this.isBrowser() ? localStorage.getItem('voti-registrati') || '[]' : '[]');
      const lastCheck = this.isBrowser() ? localStorage.getItem('admin-last-check') : null;
      const lastCheckTime = lastCheck ? Number.parseInt(lastCheck) : Date.now() - 60000;

      interface VoteRecord {
        timestamp: string;
      }

      interface FeedbackRecord {
        timestamp: string;
      }

      const newVotes = voti.filter((voto: VoteRecord) =>
        new Date(voto.timestamp).getTime() > lastCheckTime
      );

      if (newVotes.length > 0) {
        this.addNotification({
          id: `new-votes-${Date.now()}`,
          type: 'new_vote',
          title: 'Nuovi Voti Registrati',
          message: `${newVotes.length} nuovi voti sono stati registrati`,
          priority: 'normal',
          timestamp: new Date().toISOString(),
          read: false,
          action: {
            text: 'Visualizza',
            url: '/admin/votazioni'
          }
        });
      }

      // Controlla feedback
      const feedback = JSON.parse(this.isBrowser() ? localStorage.getItem('demo-feedback') || '[]' : '[]');
      const newFeedback = feedback.filter((f: FeedbackRecord) =>
        new Date(f.timestamp).getTime() > lastCheckTime
      );

      if (newFeedback.length > 0) {
        this.addNotification({
          id: `new-feedback-${Date.now()}`,
          type: 'system',
          title: 'Nuovo Feedback',
          message: `${newFeedback.length} nuovi feedback ricevuti`,
          priority: 'low',
          timestamp: new Date().toISOString(),
          read: false,
          action: {
            text: 'Visualizza',
            url: '/admin/feedback'
          }
        });
      }

      // Aggiorna timestamp ultimo controllo
      if (this.isBrowser()) {
        localStorage.setItem('admin-last-check', Date.now().toString());
      }
    } catch (error) {
      console.error('Errore controllo nuove attività:', error);
    }
  }

  // Aggiungi notifica
  private addNotification(notification: AdminNotification): void {
    if (!this.isBrowser()) return;

    this.notifications.push(notification);
    this.saveNotifications();
    this.notifyListeners([notification]);
  }

  // Ottieni statistiche delle notifiche
  getNotificationStats(): NotificationStats {
    if (!this.isBrowser()) {
      return {
        total: 0,
        unread: 0,
        byType: {},
        byPriority: {},
        recent: []
      };
    }

    try {
      const all = this.notifications.length > 0 ? this.notifications : this.getStoredNotifications();
      const unread = all.filter(n => !n.read);

      const byType = all.reduce((acc, notification) => {
        acc[notification.type] = (acc[notification.type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const byPriority = all.reduce((acc, notification) => {
        acc[notification.priority] = (acc[notification.priority] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const recent = all
        .filter(n => {
          const notificationTime = new Date(n.timestamp).getTime();
          const oneDayAgo = Date.now() - (24 * 60 * 60 * 1000);
          return notificationTime > oneDayAgo;
        })
        .slice(0, 10);

      return {
        total: all.length,
        unread: unread.length,
        byType,
        byPriority,
        recent
      };
    } catch (error) {
      console.error('Errore calcolo statistiche notifiche:', error);
      return {
        total: 0,
        unread: 0,
        byType: {},
        byPriority: {},
        recent: []
      };
    }
  }

  // Notifiche di sistema automatiche
  async notifyNewVote(candidateName: string): Promise<void> {
    const notification: AdminNotification = {
      id: `vote-${Date.now()}`,
      title: '🗳️ Nuova Votazione',
      message: `È iniziata la votazione per l'ammissione di ${candidateName}`,
      type: 'new_vote',
      priority: 'normal',
      timestamp: new Date().toISOString(),
      read: false,
      action: {
        text: 'Vai alle Votazioni',
        url: '/admin/votazioni'
      }
    };
    await this.sendDesktopNotification(notification);
  }

  async notifyNewMember(memberName: string): Promise<void> {
    const notification: AdminNotification = {
      id: `member-${Date.now()}`,
      title: '👥 Nuovo Socio',
      message: `${memberName} si è registrato come nuovo socio`,
      type: 'new_member',
      priority: 'normal',
      timestamp: new Date().toISOString(),
      read: false,
      action: {
        text: 'Gestisci Soci',
        url: '/admin/soci'
      }
    };
    await this.sendDesktopNotification(notification);
  }

  async notifyPayment(amount: number, from: string): Promise<void> {
    const notification: AdminNotification = {
      id: `payment-${Date.now()}`,
      title: '💰 Nuovo Pagamento',
      message: `Ricevuto pagamento di €${amount} da ${from}`,
      type: 'payment',
      priority: 'normal',
      timestamp: new Date().toISOString(),
      read: false,
      action: {
        text: 'Vedi Finanze',
        url: '/admin/finanze'
      }
    };
    await this.sendDesktopNotification(notification);
  }

  async notifySystemAlert(message: string): Promise<void> {
    const notification: AdminNotification = {
      id: `system-${Date.now()}`,
      title: '⚠️ Avviso Sistema',
      message,
      type: 'system',
      priority: 'high',
      timestamp: new Date().toISOString(),
      read: false
    };
    await this.sendDesktopNotification(notification);
  }

  async notifyUrgent(title: string, message: string): Promise<void> {
    const notification: AdminNotification = {
      id: `urgent-${Date.now()}`,
      title: `🚨 ${title}`,
      message,
      type: 'urgent',
      priority: 'urgent',
      timestamp: new Date().toISOString(),
      read: false
    };
    await this.sendDesktopNotification(notification);
  }
}

// Export default per compatibilità
export default AdminNotificationService;
