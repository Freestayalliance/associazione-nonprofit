"use client";

// Tipi per la gestione votazioni admin
export type VotingStatus = 'draft' | 'active' | 'closed' | 'archived';
export type VotingType = 'membership' | 'proposal' | 'budget' | 'board' | 'policy' | 'emergency';

// Interfacce per type safety migliorata
export interface PublicVote {
  id: string;
  codice: string;
  votazione: string;
  voto: string;
  data: string;
  timestamp: string;
}

export interface Socio {
  id: number;
  nome: string;
  cognome: string;
  email: string;
  telefono: string;
  stato: 'Attivo' | 'Sospeso' | 'Inattivo';
  // altri campi socio...
}

export interface VotingResult {
  name: string;
  votes: number;
  percentage: number;
}

export interface VotingStats {
  totalVotes: number;
  participationRate: number;
  results: VotingResult[];
  votesPerDay: Array<{ date: string; count: number }>;
}

export interface Candidate {
  id: string;
  name: string;
  description: string;
  profileImage?: string;
  qualifications: string[];
  contactInfo?: string;
  documents?: string[];
}

export interface VotingOption {
  id: string;
  text: string;
  description?: string;
  order: number;
}

export interface AdminVoting {
  id: string;
  title: string;
  description: string;
  type: VotingType;
  status: VotingStatus;
  startDate: string;
  endDate: string;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  approvedBy?: string;

  // Configurazione votazione
  allowMultipleVotes: boolean;
  requiresApproval: boolean;
  isAnonymous: boolean;
  minimumParticipation: number; // percentuale minima partecipazione

  // Candidati o opzioni
  candidates?: Candidate[];
  options?: VotingOption[];

  // Regole di voto
  votingRules: {
    maxSelections: number;
    minSelections: number;
    allowAbstention: boolean;
    requiresMotivation: boolean;
  };

  // Notifiche
  notifications: {
    enableStartNotification: boolean;
    enableReminderNotifications: boolean;
    enableEndNotification: boolean;
    reminderDays: number[];
  };

  // Audit
  auditLog: Array<{
    timestamp: string;
    action: string;
    userId: string;
    details: string;
  }>;
}

export interface VotingResults {
  votingId: string;
  totalVotes: number;
  totalEligibleVoters: number;
  participationRate: number;

  // Risultati per candidato/opzione
  results: Array<{
    candidateId?: string;
    optionId?: string;
    name: string;
    votes: number;
    percentage: number;
  }>;

  // Statistiche aggiuntive
  statistics: {
    abstentions: number;
    invalidVotes: number;
    votesPerDay: Array<{
      date: string;
      count: number;
    }>;
    deviceStats: {
      mobile: number;
      desktop: number;
      tablet: number;
    };
  };
}

export interface VotingFilters {
  status?: VotingStatus[];
  type?: VotingType[];
  dateRange?: {
    start: string;
    end: string;
  };
  searchTerm?: string;
  createdBy?: string;
}

export class VotingAdminService {
  private static instance: VotingAdminService;
  private votings: AdminVoting[] = [];
  private listeners: ((votings: AdminVoting[]) => void)[] = [];

  private constructor() {
    if (typeof window !== 'undefined') {
      this.loadVotings();
      this.initializeDemoData();
    }
  }

  static getInstance(): VotingAdminService {
    if (!VotingAdminService.instance) {
      VotingAdminService.instance = new VotingAdminService();
    }
    return VotingAdminService.instance;
  }

  private isBrowser(): boolean {
    return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
  }

  // === CRUD Operations ===

  async createVoting(voting: Omit<AdminVoting, 'id' | 'createdAt' | 'updatedAt' | 'auditLog'>): Promise<AdminVoting> {
    if (!this.isBrowser()) {
      throw new Error('Browser environment required');
    }

    const newVoting: AdminVoting = {
      ...voting,
      id: this.generateVotingId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      auditLog: [{
        timestamp: new Date().toISOString(),
        action: 'CREATED',
        userId: voting.createdBy,
        details: `Votazione "${voting.title}" creata`
      }]
    };

    this.votings.push(newVoting);
    this.saveVotings();
    this.notifyListeners();

    // Invia notifica se richiesto
    if (newVoting.notifications.enableStartNotification && newVoting.status === 'active') {
      await this.sendVotingNotification(newVoting, 'STARTED');
    }

    return newVoting;
  }

  async updateVoting(id: string, updates: Partial<AdminVoting>, userId: string): Promise<AdminVoting> {
    if (!this.isBrowser()) {
      throw new Error('Browser environment required');
    }

    const index = this.votings.findIndex(v => v.id === id);
    if (index === -1) {
      throw new Error('Votazione non trovata');
    }

    const currentVoting = this.votings[index];
    const updatedVoting: AdminVoting = {
      ...currentVoting,
      ...updates,
      updatedAt: new Date().toISOString(),
      auditLog: [
        ...currentVoting.auditLog,
        {
          timestamp: new Date().toISOString(),
          action: 'UPDATED',
          userId,
          details: `Votazione aggiornata: ${Object.keys(updates).join(', ')}`
        }
      ]
    };

    this.votings[index] = updatedVoting;
    this.saveVotings();
    this.notifyListeners();

    return updatedVoting;
  }

  async deleteVoting(id: string, userId: string): Promise<boolean> {
    if (!this.isBrowser()) {
      throw new Error('Browser environment required');
    }

    const index = this.votings.findIndex(v => v.id === id);
    if (index === -1) {
      return false;
    }

    const voting = this.votings[index];

    // Non permettere eliminazione di votazioni attive
    if (voting.status === 'active') {
      throw new Error('Non è possibile eliminare una votazione attiva');
    }

    this.votings.splice(index, 1);
    this.saveVotings();
    this.notifyListeners();

    return true;
  }

  getVoting(id: string): AdminVoting | undefined {
    return this.votings.find(v => v.id === id);
  }

  getAllVotings(filters?: VotingFilters): AdminVoting[] {
    let filtered = [...this.votings];

    if (filters) {
      if (filters.status?.length) {
        filtered = filtered.filter(v => filters.status?.includes(v.status));
      }

      if (filters.type?.length) {
        filtered = filtered.filter(v => filters.type?.includes(v.type));
      }

      if (filters.dateRange) {
        filtered = filtered.filter(v =>
          v.startDate >= filters.dateRange?.start &&
          v.endDate <= filters.dateRange?.end
        );
      }

      if (filters.searchTerm) {
        const term = filters.searchTerm.toLowerCase();
        filtered = filtered.filter(v =>
          v.title.toLowerCase().includes(term) ||
          v.description.toLowerCase().includes(term)
        );
      }

      if (filters.createdBy) {
        filtered = filtered.filter(v => v.createdBy === filters.createdBy);
      }
    }

    return filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  // === Gestione Stati ===

  async activateVoting(id: string, userId: string): Promise<AdminVoting> {
    return this.updateVotingStatus(id, 'active', userId);
  }

  async closeVoting(id: string, userId: string): Promise<AdminVoting> {
    return this.updateVotingStatus(id, 'closed', userId);
  }

  async archiveVoting(id: string, userId: string): Promise<AdminVoting> {
    return this.updateVotingStatus(id, 'archived', userId);
  }

  private async updateVotingStatus(id: string, status: VotingStatus, userId: string): Promise<AdminVoting> {
    const voting = await this.updateVoting(id, { status }, userId);

    // Invia notifiche in base al nuovo stato
    if (status === 'active' && voting.notifications.enableStartNotification) {
      await this.sendVotingNotification(voting, 'STARTED');
    } else if (status === 'closed' && voting.notifications.enableEndNotification) {
      await this.sendVotingNotification(voting, 'ENDED');
    }

    return voting;
  }

  // === Statistiche e Risultati ===

  getVotingResults(votingId: string): VotingResults | null {
    if (!this.isBrowser()) return null;

    const voting = this.getVoting(votingId);
    if (!voting) return null;

    // Recupera i voti dal sistema pubblico
    const allVotes: PublicVote[] = JSON.parse(localStorage.getItem('voti-registrati') || '[]');
    const votingVotes = allVotes.filter((vote: PublicVote) => vote.votazione === voting.title);

    const totalVotes = votingVotes.length;
    const totalEligibleVoters = this.getTotalEligibleVoters();
    const participationRate = totalEligibleVoters > 0 ? (totalVotes / totalEligibleVoters) * 100 : 0;

    // Calcola risultati per candidato/opzione
    const voteCounts: Record<string, number> = {};
    for (const vote of votingVotes) {
      voteCounts[vote.voto] = (voteCounts[vote.voto] || 0) + 1;
    }

    const results = Object.entries(voteCounts).map(([name, votes]) => ({
      name,
      votes,
      percentage: totalVotes > 0 ? (votes / totalVotes) * 100 : 0
    }));

    // Statistiche per giorno
    const votesPerDay = this.calculateVotesPerDay(votingVotes);

    return {
      votingId,
      totalVotes,
      totalEligibleVoters,
      participationRate,
      results,
      statistics: {
        abstentions: 0, // Da implementare
        invalidVotes: 0, // Da implementare
        votesPerDay,
        deviceStats: {
          mobile: Math.floor(totalVotes * 0.6),
          desktop: Math.floor(totalVotes * 0.3),
          tablet: Math.floor(totalVotes * 0.1)
        }
      }
    };
  }

  // Calcola statistiche e risultati per una votazione specifica (type safe)
  public calculateVotingResults(votingId: string): VotingStats | null {
    const voting = this.getVoting(votingId);
    if (!voting) return null;

    // Recupera i voti dal sistema pubblico
    const allVotes: PublicVote[] = JSON.parse(localStorage.getItem('voti-registrati') || '[]');
    const votingVotes = allVotes.filter((vote: PublicVote) => vote.votazione === voting.title);

    const totalVotes = votingVotes.length;
    const totalEligibleVoters = this.getTotalEligibleVoters();
    const participationRate = totalEligibleVoters > 0 ? (totalVotes / totalEligibleVoters) * 100 : 0;

    // Calcola risultati per candidato/opzione
    const voteCounts: Record<string, number> = {};
    for (const vote of votingVotes) {
      voteCounts[vote.voto] = (voteCounts[vote.voto] || 0) + 1;
    }

    const results: VotingResult[] = Object.entries(voteCounts).map(([name, votes]) => ({
      name,
      votes,
      percentage: totalVotes > 0 ? (votes / totalVotes) * 100 : 0
    }));

    // Statistiche per giorno
    const votesPerDay = this.calculateVotesPerDay(votingVotes);

    return {
      totalVotes,
      participationRate,
      results,
      votesPerDay
    };
  }

  getVotingStatistics(): {
    total: number;
    byStatus: Record<VotingStatus, number>;
    byType: Record<VotingType, number>;
    activeVotings: AdminVoting[];
    upcomingVotings: AdminVoting[];
    recentResults: AdminVoting[];
  } {
    const total = this.votings.length;
    const byStatus = this.votings.reduce((acc, voting) => {
      acc[voting.status] = (acc[voting.status] || 0) + 1;
      return acc;
    }, {} as Record<VotingStatus, number>);

    const byType = this.votings.reduce((acc, voting) => {
      acc[voting.type] = (acc[voting.type] || 0) + 1;
      return acc;
    }, {} as Record<VotingType, number>);

    const now = new Date();
    const activeVotings = this.votings.filter(v => v.status === 'active');
    const upcomingVotings = this.votings.filter(v =>
      v.status === 'draft' && new Date(v.startDate) > now
    );
    const recentResults = this.votings
      .filter(v => v.status === 'closed')
      .sort((a, b) => new Date(b.endDate).getTime() - new Date(a.endDate).getTime())
      .slice(0, 5);

    return {
      total,
      byStatus,
      byType,
      activeVotings,
      upcomingVotings,
      recentResults
    };
  }

  // === Utility Functions ===

  private generateVotingId(): string {
    return `VOT-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private getTotalEligibleVoters(): number {
    if (!this.isBrowser()) return 0;
    const soci: Socio[] = JSON.parse(localStorage.getItem('admin-soci') || '[]');
    return soci.filter((socio: Socio) => socio.stato === 'Attivo').length;
  }

  private calculateVotesPerDay(votes: PublicVote[]): Array<{ date: string; count: number }> {
    const votesByDay: Record<string, number> = {};

    for (const vote of votes) {
      const date = new Date(vote.timestamp).toISOString().split('T')[0];
      votesByDay[date] = (votesByDay[date] || 0) + 1;
    }

    return Object.entries(votesByDay).map(([date, count]) => ({ date, count }));
  }

  private async sendVotingNotification(voting: AdminVoting, type: 'STARTED' | 'ENDED'): Promise<void> {
    // Integrazione con AdminNotificationService
    try {
      const { AdminNotificationService } = await import('./AdminNotificationService');
      const notificationService = AdminNotificationService.getInstance();

      const title = type === 'STARTED' ? '🗳️ Nuova Votazione Attiva' : '📊 Votazione Terminata';
      const message = type === 'STARTED'
        ? `È iniziata la votazione: ${voting.title}`
        : `È terminata la votazione: ${voting.title}`;

      await notificationService.notifyNewVote(voting.title);
    } catch (error) {
      console.error('Errore invio notifica votazione:', error);
    }
  }

  // === Persistenza Dati ===

  private saveVotings(): void {
    if (!this.isBrowser()) return;

    try {
      localStorage.setItem('admin-votings', JSON.stringify(this.votings));
    } catch (error) {
      console.error('Errore salvataggio votazioni:', error);
    }
  }

  private loadVotings(): void {
    if (!this.isBrowser()) return;

    try {
      const stored = localStorage.getItem('admin-votings');
      if (stored) {
        this.votings = JSON.parse(stored);
      }
    } catch (error) {
      console.error('Errore caricamento votazioni:', error);
    }
  }

  // === Listeners ===

  addListener(listener: (votings: AdminVoting[]) => void): () => void {
    this.listeners.push(listener);
    listener(this.votings);

    return () => {
      const index = this.listeners.indexOf(listener);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  private notifyListeners(): void {
    for (const listener of this.listeners) {
      listener(this.votings);
    }
  }

  // === Dati Demo ===

  private initializeDemoData(): void {
    if (this.votings.length === 0) {
      const demoVotings: AdminVoting[] = [
        {
          id: 'VOT-001',
          title: 'Ammissione Alessandro Verdi',
          description: 'Votazione per l\'ammissione di Alessandro Verdi come nuovo socio dell\'associazione',
          type: 'membership',
          status: 'active',
          startDate: new Date().toISOString(),
          endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
          createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
          updatedAt: new Date().toISOString(),
          createdBy: 'admin',
          allowMultipleVotes: false,
          requiresApproval: true,
          isAnonymous: true,
          minimumParticipation: 50,
          candidates: [{
            id: 'cand-001',
            name: 'Alessandro Verdi',
            description: 'Candidato per l\'ammissione come socio',
            qualifications: ['Laurea in Economia', '5 anni esperienza nel settore non-profit'],
            contactInfo: 'alessandro.verdi@email.com'
          }],
          votingRules: {
            maxSelections: 1,
            minSelections: 1,
            allowAbstention: true,
            requiresMotivation: false
          },
          notifications: {
            enableStartNotification: true,
            enableReminderNotifications: true,
            enableEndNotification: true,
            reminderDays: [3, 1]
          },
          auditLog: [{
            timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
            action: 'CREATED',
            userId: 'admin',
            details: 'Votazione creata e attivata'
          }]
        },
        {
          id: 'VOT-002',
          title: 'Approvazione Bilancio 2024',
          description: 'Votazione per l\'approvazione del bilancio preventivo 2024',
          type: 'budget',
          status: 'draft',
          startDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
          endDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(),
          createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          updatedAt: new Date().toISOString(),
          createdBy: 'admin',
          allowMultipleVotes: false,
          requiresApproval: true,
          isAnonymous: false,
          minimumParticipation: 60,
          options: [
            { id: 'opt-001', text: 'Approvo il bilancio', description: 'Approvazione completa', order: 1 },
            { id: 'opt-002', text: 'Approvo con riserve', description: 'Approvazione condizionata', order: 2 },
            { id: 'opt-003', text: 'Non approvo', description: 'Rigetto del bilancio', order: 3 }
          ],
          votingRules: {
            maxSelections: 1,
            minSelections: 1,
            allowAbstention: true,
            requiresMotivation: true
          },
          notifications: {
            enableStartNotification: true,
            enableReminderNotifications: true,
            enableEndNotification: true,
            reminderDays: [5, 2, 1]
          },
          auditLog: [{
            timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
            action: 'CREATED',
            userId: 'admin',
            details: 'Bozza votazione creata'
          }]
        }
      ];

      this.votings = demoVotings;
      this.saveVotings();
    }
  }

  // === Export/Import ===

  exportVotings(): string {
    return JSON.stringify({
      votings: this.votings,
      exportDate: new Date().toISOString(),
      version: '1.0'
    }, null, 2);
  }

  async importVotings(data: string, userId: string): Promise<boolean> {
    try {
      const imported = JSON.parse(data);
      if (imported.votings && Array.isArray(imported.votings)) {
        this.votings = imported.votings;
        this.saveVotings();
        this.notifyListeners();
        return true;
      }
      return false;
    } catch (error) {
      console.error('Errore import votazioni:', error);
      return false;
    }
  }
}

export default VotingAdminService;
