"use client"

// Tipi per il sistema di pagamento
export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: 'requires_payment_method' | 'requires_confirmation' | 'requires_action' | 'processing' | 'requires_capture' | 'canceled' | 'succeeded';
  client_secret: string;
  description?: string;
  metadata?: Record<string, string>;
}

export interface PaymentMethod {
  id: string;
  type: 'card' | 'paypal' | 'bank_transfer';
  card?: {
    brand: string;
    last4: string;
    exp_month: number;
    exp_year: number;
  };
  billing_details?: {
    name: string;
    email: string;
    address?: {
      city: string;
      country: string;
      postal_code: string;
    };
  };
}

export interface PaymentRecord {
  id: string;
  paymentIntentId: string;
  userId: string;
  userEmail: string;
  userName: string;
  amount: number;
  currency: string;
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  description: string;
  paymentMethod?: PaymentMethod;
  createdAt: string;
  completedAt?: string;
  failureReason?: string;
  receiptUrl?: string;
  metadata: {
    type: 'membership_fee' | 'donation' | 'event_ticket';
    period?: 'annual' | 'monthly';
    membershipYear?: string;
  };
}

export interface PaymentConfig {
  stripePublishableKey: string;
  membershipFees: {
    annual: number;
    monthly: number;
  };
  currency: string;
  webhookSecret?: string;
  testMode: boolean;
}

class PaymentService {
  private static instance: PaymentService;
  private readonly PAYMENTS_KEY = 'payment-records';
  private readonly CONFIG_KEY = 'payment-config';

  // Configurazione demo/test
  private readonly DEFAULT_CONFIG: PaymentConfig = {
    stripePublishableKey: 'pk_test_demo_associazione_nonprofit', // In produzione sostituire con chiave reale
    membershipFees: {
      annual: 20.00,
      monthly: 2.00
    },
    currency: 'EUR',
    testMode: true
  };

  private constructor() {}

  public static getInstance(): PaymentService {
    if (!PaymentService.instance) {
      PaymentService.instance = new PaymentService();
    }
    return PaymentService.instance;
  }

  private isBrowser(): boolean {
    return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
  }

  // Configurazione
  public getConfig(): PaymentConfig {
    if (!this.isBrowser()) return this.DEFAULT_CONFIG;

    try {
      const configData = localStorage.getItem(this.CONFIG_KEY);
      if (configData) {
        return { ...this.DEFAULT_CONFIG, ...JSON.parse(configData) };
      }
    } catch (error) {
      console.error('Errore nel caricamento configurazione pagamenti:', error);
    }
    return this.DEFAULT_CONFIG;
  }

  public updateConfig(newConfig: Partial<PaymentConfig>): { success: boolean; message: string } {
    if (!this.isBrowser()) {
      return { success: false, message: 'Storage non disponibile' };
    }

    try {
      const currentConfig = this.getConfig();
      const updatedConfig = { ...currentConfig, ...newConfig };
      localStorage.setItem(this.CONFIG_KEY, JSON.stringify(updatedConfig));
      return { success: true, message: 'Configurazione pagamenti aggiornata' };
    } catch (error) {
      return { success: false, message: 'Errore nell\'aggiornamento configurazione' };
    }
  }

  // Creazione Payment Intent - Overload per supportare entrambe le chiamate
  public async createPaymentIntent(
    paymentDataOrAmount: any,
    description?: string,
    metadata?: PaymentRecord['metadata'],
    userInfo?: { email: string; name: string; id: string }
  ): Promise<{ success: boolean; paymentIntent?: PaymentIntent; error?: string }> {
    try {
      let amount: number;
      let desc: string;
      let meta: any;
      let userEmail: string;

      // Gestisce entrambi i formati di chiamata
      if (typeof paymentDataOrAmount === 'object' && paymentDataOrAmount.amount) {
        // Formato nuovo: createPaymentIntent(paymentData)
        amount = paymentDataOrAmount.amount;
        desc = paymentDataOrAmount.description;
        meta = paymentDataOrAmount.metadata || {};
        userEmail = paymentDataOrAmount.userEmail;
      } else {
        // Formato vecchio: createPaymentIntent(amount, description, metadata, userInfo)
        amount = paymentDataOrAmount;
        desc = description || '';
        meta = metadata || {};
        userEmail = userInfo?.email || '';
      }

      console.log('🔄 Creazione PaymentIntent:', { amount, desc, userEmail });

      // Simula chiamata API Stripe
      await new Promise(resolve => setTimeout(resolve, 500));

      const paymentIntent: PaymentIntent = {
        id: `pi_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        amount: Math.round(amount * 100), // Stripe usa centesimi
        currency: this.getConfig().currency.toLowerCase(),
        status: 'requires_payment_method',
        client_secret: `pi_${Date.now()}_secret_${Math.random().toString(36).substr(2, 12)}`,
        description: desc,
        metadata: {
          userEmail: userEmail,
          ...meta
        }
      };

      // Salva il record di pagamento come pending
      const paymentRecord: PaymentRecord = {
        id: `pay_${Date.now()}`,
        paymentIntentId: paymentIntent.id,
        userId: `user_${Date.now()}`,
        userEmail: userEmail,
        userName: meta.firstName ? `${meta.firstName} ${meta.lastName}` : 'User',
        amount: amount,
        currency: this.getConfig().currency,
        status: 'pending',
        description: desc,
        createdAt: new Date().toISOString(),
        metadata: meta
      };

      this.savePaymentRecord(paymentRecord);

      console.log('✅ PaymentIntent creato:', paymentIntent.id);
      return { success: true, paymentIntent };

    } catch (error) {
      console.error('❌ Errore nella creazione payment intent:', error);
      return { success: false, error: 'Errore nella creazione del pagamento' };
    }
  }

  // Conferma pagamento (simula conferma Stripe)
  public async confirmPayment(
    paymentIntentId: string,
    paymentData: any
  ): Promise<{ success: boolean; paymentIntent?: PaymentIntent; error?: string }> {
    try {
      console.log('🔄 Conferma pagamento:', paymentIntentId, 'tipo:', paymentData.type || 'card');

      // Simula elaborazione pagamento basata sul metodo
      const processingTime = paymentData.type === 'bank_transfer' ? 1000 : 2000;
      await new Promise(resolve => setTimeout(resolve, processingTime));

      // Diverso tasso di successo per metodo
      let successRate = 0.9; // 90% default
      if (paymentData.type === 'bank_transfer') {
        successRate = 0.95; // 95% per bonifico (sempre accettato)
      } else if (paymentData.type === 'paypal') {
        successRate = 0.92; // 92% per PayPal
      }

      const isSuccess = Math.random() < successRate;

      if (isSuccess) {
        let paymentStatus: PaymentIntent['status'] = 'succeeded';
        let description = 'Quota associativa annuale';

        // Gestione specifica per bonifico
        if (paymentData.type === 'bank_transfer') {
          paymentStatus = 'requires_action'; // In attesa del bonifico
          description = 'In attesa di bonifico bancario';
        }

        const updatedPaymentIntent: PaymentIntent = {
          id: paymentIntentId,
          amount: 2000, // 20.00 EUR
          currency: 'eur',
          status: paymentStatus,
          client_secret: `${paymentIntentId}_secret`,
          description: description,
          metadata: {
            paymentMethod: paymentData.type || 'card'
          }
        };

        // Aggiorna il record di pagamento
        const newStatus = paymentData.type === 'bank_transfer' ? 'pending' : 'completed';
        this.updatePaymentStatus(paymentIntentId, newStatus);

        // Aggiorna membership solo se pagamento completato
        if (newStatus === 'completed') {
          this.updateMembershipStatus(paymentIntentId);
        }

        return { success: true, paymentIntent: updatedPaymentIntent };
      } else {
        // Simula fallimento
        let failureReason = 'Pagamento rifiutato';
        if (paymentData.type === 'paypal') {
          failureReason = 'PayPal non disponibile';
        } else if (paymentData.type === 'bank_transfer') {
          failureReason = 'Errore nella richiesta bonifico';
        } else {
          failureReason = 'Carta rifiutata';
        }

        this.updatePaymentStatus(paymentIntentId, 'failed', failureReason);
        return { success: false, error: failureReason };
      }

    } catch (error) {
      console.error('Errore nella conferma pagamento:', error);
      return { success: false, error: 'Errore nell\'elaborazione del pagamento' };
    }
  }

  // Gestione pagamenti salvati
  private savePaymentRecord(payment: PaymentRecord): void {
    if (!this.isBrowser()) return;

    try {
      const payments = this.getPaymentRecords();
      payments.push(payment);
      localStorage.setItem(this.PAYMENTS_KEY, JSON.stringify(payments));
    } catch (error) {
      console.error('Errore nel salvataggio record pagamento:', error);
    }
  }

  public getPaymentRecords(): PaymentRecord[] {
    if (!this.isBrowser()) return [];

    try {
      const paymentsData = localStorage.getItem(this.PAYMENTS_KEY);
      return paymentsData ? JSON.parse(paymentsData) : [];
    } catch (error) {
      console.error('Errore nel caricamento pagamenti:', error);
      return [];
    }
  }

  public getPaymentRecord(paymentIntentId: string): PaymentRecord | null {
    const payments = this.getPaymentRecords();
    return payments.find(p => p.paymentIntentId === paymentIntentId) || null;
  }

  private updatePaymentStatus(
    paymentIntentId: string,
    status: PaymentRecord['status'],
    failureReason?: string
  ): void {
    if (!this.isBrowser()) return;

    try {
      const payments = this.getPaymentRecords();
      const paymentIndex = payments.findIndex(p => p.paymentIntentId === paymentIntentId);

      if (paymentIndex !== -1) {
        payments[paymentIndex].status = status;
        if (status === 'completed') {
          payments[paymentIndex].completedAt = new Date().toISOString();
          payments[paymentIndex].receiptUrl = `#receipt/${paymentIntentId}`;
        }
        if (failureReason) {
          payments[paymentIndex].failureReason = failureReason;
        }

        localStorage.setItem(this.PAYMENTS_KEY, JSON.stringify(payments));
      }
    } catch (error) {
      console.error('Errore nell\'aggiornamento stato pagamento:', error);
    }
  }

  private updateMembershipStatus(paymentIntentId: string): void {
    // Aggiorna lo stato del socio dopo pagamento completato
    const payment = this.getPaymentRecord(paymentIntentId);
    if (!payment || payment.metadata.type !== 'membership_fee') return;

    try {
      // Aggiorna i dati del socio
      const sociData = localStorage.getItem('associazione-soci');
      if (sociData) {
        const soci = JSON.parse(sociData);
        const socioIndex = soci.findIndex((s: any) => s.email === payment.userEmail);

        if (socioIndex !== -1) {
          soci[socioIndex].quotaPagata = true;
          soci[socioIndex].dataUltimoPagamento = new Date().toISOString();
          soci[socioIndex].stato = 'attivo';
          localStorage.setItem('associazione-soci', JSON.stringify(soci));
        }
      }

      // Completa il referral se presente
      this.completeReferralForPayment(paymentIntentId);

      // Aggiungi transazione finanziaria
      const transazioniData = localStorage.getItem('transazioni-finanziarie');
      const transazioni = transazioniData ? JSON.parse(transazioniData) : [];

      const nuovaTransazione = {
        id: Date.now(),
        tipo: 'entrata',
        categoria: 'Quote Soci',
        descrizione: `Quota associativa ${payment.metadata.period} - ${payment.userName}`,
        importo: payment.amount,
        data: new Date().toISOString().split('T')[0],
        regione: 'Online',
        nome: payment.userName,
        metodo: 'Carta di Credito',
        riferimento: payment.paymentIntentId
      };

      transazioni.push(nuovaTransazione);
      localStorage.setItem('transazioni-finanziarie', JSON.stringify(transazioni));

    } catch (error) {
      console.error('Errore nell\'aggiornamento dati socio:', error);
    }
  }

  // Completa referral dopo pagamento confermato
  private completeReferralForPayment(paymentIntentId: string): void {
    try {
      // Cerca l'application associata a questo pagamento
      const applications = JSON.parse(localStorage.getItem('membership-applications') || '[]');
      const application = applications.find((app: any) => app.paymentIntentId === paymentIntentId);

      if (application?.referralRecordId) {
        // Importa dinamicamente ReferralService per evitare dipendenze circolari
        import('./ReferralService').then(({ default: ReferralService }) => {
          const result = ReferralService.completeReferral(application.referralRecordId);

          if (result.success) {
            console.log('🎉 Referral completato per pagamento:', paymentIntentId);
            console.log('📊 Messaggio:', result.message);

            // Non ci sono più level up automatici
            // I riconoscimenti vengono dalla community tramite votazione
          }
        });
      }
    } catch (error) {
      console.error('Errore nel completamento referral:', error);
    }
  }

  // Statistiche pagamenti
  public getPaymentStats(): {
    totalPayments: number;
    completedPayments: number;
    totalRevenue: number;
    pendingPayments: number;
    failedPayments: number;
    revenueByMonth: Record<string, number>;
    paymentsByType: Record<string, number>;
  } {
    const payments = this.getPaymentRecords();

    const stats = {
      totalPayments: payments.length,
      completedPayments: payments.filter(p => p.status === 'completed').length,
      totalRevenue: payments
        .filter(p => p.status === 'completed')
        .reduce((sum, p) => sum + p.amount, 0),
      pendingPayments: payments.filter(p => p.status === 'pending').length,
      failedPayments: payments.filter(p => p.status === 'failed').length,
      revenueByMonth: {} as Record<string, number>,
      paymentsByType: {} as Record<string, number>
    };

    // Revenue per mese
    payments
      .filter(p => p.status === 'completed')
      .forEach(payment => {
        const month = new Date(payment.completedAt || payment.createdAt).toISOString().slice(0, 7);
        stats.revenueByMonth[month] = (stats.revenueByMonth[month] || 0) + payment.amount;
      });

    // Pagamenti per tipo
    payments.forEach(payment => {
      const type = payment.metadata.type;
      stats.paymentsByType[type] = (stats.paymentsByType[type] || 0) + 1;
    });

    return stats;
  }

  // Rimborsi
  public async refundPayment(
    paymentIntentId: string,
    reason?: string
  ): Promise<{ success: boolean; message: string }> {
    try {
      // Simula chiamata API rimborso
      await new Promise(resolve => setTimeout(resolve, 1500));

      this.updatePaymentStatus(paymentIntentId, 'refunded');

      // Aggiorna stato socio
      const payment = this.getPaymentRecord(paymentIntentId);
      if (payment && payment.metadata.type === 'membership_fee') {
        const sociData = localStorage.getItem('associazione-soci');
        if (sociData) {
          const soci = JSON.parse(sociData);
          const socioIndex = soci.findIndex((s: any) => s.email === payment.userEmail);
          if (socioIndex !== -1) {
            soci[socioIndex].quotaPagata = false;
            soci[socioIndex].stato = 'sospeso';
            localStorage.setItem('associazione-soci', JSON.stringify(soci));
          }
        }
      }

      return { success: true, message: 'Rimborso elaborato con successo' };

    } catch (error) {
      console.error('Errore nel rimborso:', error);
      return { success: false, message: 'Errore nell\'elaborazione del rimborso' };
    }
  }

  // Verifica stato pagamento (webhook simulation)
  public handleWebhookEvent(eventType: string, data: any): void {
    switch (eventType) {
      case 'payment_intent.succeeded':
        this.updatePaymentStatus(data.id, 'completed');
        this.updateMembershipStatus(data.id);
        break;
      case 'payment_intent.payment_failed':
        this.updatePaymentStatus(data.id, 'failed', data.last_payment_error?.message);
        break;
      default:
        console.log('Evento webhook non gestito:', eventType);
    }
  }

  // Utility per formattazione prezzi
  public formatPrice(amount: number, currency = 'EUR'): string {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: currency
    }).format(amount);
  }

  // Validazione email e dati
  public validatePaymentData(data: {
    email: string;
    name: string;
    amount: number;
  }): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!data.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.push('Email non valida');
    }

    if (!data.name || data.name.trim().length < 2) {
      errors.push('Nome deve essere di almeno 2 caratteri');
    }

    if (!data.amount || data.amount <= 0) {
      errors.push('Importo deve essere maggiore di zero');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }
}

export default PaymentService.getInstance();
export type { PaymentIntent, PaymentMethod, PaymentRecord, PaymentConfig };
