"use client"

// Chiave pubblica VAPID di esempio - in produzione va generata e mantenuta sicura
const VAPID_PUBLIC_KEY = 'BK6P7HjLJUQ9GJ6rN2FGjM0UzK5bCk9_2E_wQJQqD3VkLm7oP1R0S6X4Y8Z3A1B5C9D7F2G6H8I4J0K3L5M8N1O4P6Q9R2S5T7U0V3W6X9Y2Z5';

class PushNotificationService {
  private registration: ServiceWorkerRegistration | null = null;
  private subscription: PushSubscription | null = null;

  // Converte la chiave VAPID da base64 a Uint8Array
  private urlBase64ToUint8Array(base64String: string): Uint8Array {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
      .replace(/-/g, '+')
      .replace(/_/g, '/');

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);

    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }

  // Controlla se il browser supporta le notifiche
  public isSupported(): boolean {
    return (
      'serviceWorker' in navigator &&
      'PushManager' in window &&
      'Notification' in window
    );
  }

  // Controlla se le notifiche sono abilitate
  public isEnabled(): boolean {
    return Notification.permission === 'granted';
  }

  // Controlla se l'utente è iscritto alle push notifications
  public async isSubscribed(): Promise<boolean> {
    if (!this.isSupported()) return false;

    try {
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription();
      return subscription !== null;
    } catch (error) {
      console.error('Errore nel controllo subscription:', error);
      return false;
    }
  }

  // Registra il service worker
  public async registerServiceWorker(): Promise<boolean> {
    if (!this.isSupported()) {
      console.warn('Service Worker non supportato');
      return false;
    }

    try {
      console.log('Registrazione Service Worker...');
      this.registration = await navigator.serviceWorker.register('/sw.js');

      // Aspetta che il service worker sia pronto
      await navigator.serviceWorker.ready;

      console.log('Service Worker registrato con successo');
      return true;
    } catch (error) {
      console.error('Errore nella registrazione del Service Worker:', error);
      return false;
    }
  }

  // Richiede il permesso per le notifiche
  public async requestPermission(): Promise<NotificationPermission> {
    if (!this.isSupported()) {
      return 'denied';
    }

    try {
      // Se il permesso non è già stato dato, lo richiediamo
      if (Notification.permission === 'default') {
        const permission = await Notification.requestPermission();
        console.log('Permesso notifiche:', permission);
        return permission;
      }

      return Notification.permission;
    } catch (error) {
      console.error('Errore nella richiesta permesso:', error);
      return 'denied';
    }
  }

  // Si iscrive alle push notifications
  public async subscribe(): Promise<PushSubscription | null> {
    if (!this.isSupported() || !this.isEnabled()) {
      return null;
    }

    try {
      // Assicurati che il service worker sia registrato
      if (!this.registration) {
        await this.registerServiceWorker();
      }

      const registration = await navigator.serviceWorker.ready;

      // Controlla se esiste già una subscription
      let subscription = await registration.pushManager.getSubscription();

      if (!subscription) {
        // Crea una nuova subscription
        subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: this.urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
        });

        console.log('Nuova subscription creata:', subscription);
      } else {
        console.log('Subscription esistente trovata:', subscription);
      }

      this.subscription = subscription;

      // Salva la subscription sul server (simulato)
      await this.saveSubscriptionToServer(subscription);

      return subscription;
    } catch (error) {
      console.error('Errore nella subscription:', error);
      return null;
    }
  }

  // Annulla l'iscrizione alle push notifications
  public async unsubscribe(): Promise<boolean> {
    try {
      if (this.subscription) {
        const success = await this.subscription.unsubscribe();
        console.log('Unsubscribe result:', success);

        if (success) {
          this.subscription = null;
          // Rimuovi la subscription dal server
          await this.removeSubscriptionFromServer();
        }

        return success;
      }
      return true;
    } catch (error) {
      console.error('Errore nell\'unsubscribe:', error);
      return false;
    }
  }

  // Salva la subscription sul server (mockup)
  private async saveSubscriptionToServer(subscription: PushSubscription): Promise<void> {
    try {
      // In un'app reale, questa chiamata andrebbe al tuo backend
      const p256dhKey = subscription.getKey('p256dh');
      const authKey = subscription.getKey('auth');

      if (!p256dhKey || !authKey) {
        throw new Error('Impossibile ottenere le chiavi di crittografia dalla subscription');
      }

      const subscriptionData = {
        endpoint: subscription.endpoint,
        keys: {
          p256dh: btoa(String.fromCharCode(...new Uint8Array(p256dhKey))),
          auth: btoa(String.fromCharCode(...new Uint8Array(authKey)))
        },
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent
      };

      // Simula il salvataggio nel localStorage per il demo
      const existingSubscriptions = JSON.parse(localStorage.getItem('pushSubscriptions') || '[]');
      existingSubscriptions.push(subscriptionData);
      localStorage.setItem('pushSubscriptions', JSON.stringify(existingSubscriptions));

      console.log('Subscription salvata sul "server":', subscriptionData);

      // In produzione faresti:
      // await fetch('/api/push/subscribe', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(subscriptionData)
      // });

    } catch (error) {
      console.error('Errore nel salvataggio subscription:', error);
    }
  }

  // Rimuove la subscription dal server (mockup)
  private async removeSubscriptionFromServer(): Promise<void> {
    try {
      // Simula la rimozione dal localStorage
      localStorage.removeItem('pushSubscriptions');
      console.log('Subscription rimossa dal "server"');

      // In produzione faresti:
      // await fetch('/api/push/unsubscribe', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ endpoint: subscription.endpoint })
      // });

    } catch (error) {
      console.error('Errore nella rimozione subscription:', error);
    }
  }

  // Invia una notifica di test
  public async sendTestNotification(): Promise<boolean> {
    if (!this.isEnabled()) {
      return false;
    }

    try {
      // Mostra una notifica locale di test
      if (this.registration) {
        await this.registration.showNotification('Test Notifica', {
          body: 'Questa è una notifica di test per verificare il funzionamento',
          icon: '/favicon.ico',
          badge: '/favicon.ico',
          tag: 'test-notification',
          data: {
            url: '/notifiche'
          },
          actions: [
            {
              action: 'view',
              title: 'Visualizza'
            },
            {
              action: 'dismiss',
              title: 'Ignora'
            }
          ]
        });

        return true;
      }

      return false;
    } catch (error) {
      console.error('Errore nell\'invio notifica di test:', error);
      return false;
    }
  }

  // Simula l'invio di una push notification dal server
  public async simulateServerPush(notificationData: {
    title: string;
    body: string;
    type?: string;
    priority?: string;
    actionUrl?: string;
  }): Promise<boolean> {
    if (!this.isEnabled()) {
      return false;
    }

    try {
      // In un'app reale, il server invierebbe la push notification
      // Qui simuliamo mostrando direttamente la notifica
      if (this.registration) {
        await this.registration.showNotification(notificationData.title, {
          body: notificationData.body,
          icon: '/favicon.ico',
          badge: '/favicon.ico',
          tag: `server-push-${Date.now()}`,
          data: {
            url: notificationData.actionUrl || '/notifiche',
            type: notificationData.type
          },
          requireInteraction: notificationData.priority === 'high',
          vibrate: notificationData.priority === 'high' ? [200, 100, 200] : [100]
        });

        console.log('Push notification simulata:', notificationData);
        return true;
      }

      return false;
    } catch (error) {
      console.error('Errore nella simulazione push:', error);
      return false;
    }
  }

  // Ottiene lo stato attuale delle notifiche
  public async getStatus(): Promise<{
    supported: boolean;
    permission: NotificationPermission;
    subscribed: boolean;
    registration: boolean;
  }> {
    return {
      supported: this.isSupported(),
      permission: Notification.permission,
      subscribed: await this.isSubscribed(),
      registration: this.registration !== null
    };
  }

  // Inizializza il servizio
  public async initialize(): Promise<boolean> {
    try {
      console.log('Inizializzazione PushNotificationService...');

      if (!this.isSupported()) {
        console.warn('Push notifications non supportate');
        return false;
      }

      // Registra il service worker
      const swRegistered = await this.registerServiceWorker();
      if (!swRegistered) {
        return false;
      }

      // Se l'utente ha già dato il permesso, prova a ricreare la subscription
      if (this.isEnabled()) {
        await this.subscribe();
      }

      console.log('PushNotificationService inizializzato con successo');
      return true;
    } catch (error) {
      console.error('Errore nell\'inizializzazione:', error);
      return false;
    }
  }
}

// Esporta un'istanza singleton
export const pushNotificationService = new PushNotificationService();
export default pushNotificationService;
