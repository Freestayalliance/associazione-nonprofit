"use client"

interface EmailTemplate {
  subject: string;
  htmlBody: string;
  textBody: string;
}

interface EmailTemplateData {
  title: string;
  message: string;
  actionUrl?: string;
  recipientName?: string;
  email?: string;
  password?: string;
  tessera?: string;
  associationName?: string;
  supportEmail?: string;
  websiteUrl?: string;
  currentYear?: string;
}

interface EmailNotificationData {
  to: string;
  type: 'new_vote' | 'vote_ending' | 'vote_result' | 'system' | 'credentials' | 'password_reset';
  priority: 'high' | 'medium' | 'low';
  data: EmailTemplateData;
}

interface EmailServiceConfig {
  apiKey: string;
  senderEmail: string;
  senderName: string;
  baseUrl: string;
}

interface SentEmail {
  to: string;
  subject: string;
  type: string;
  timestamp: string;
  success: boolean;
}

interface EmailPreferences {
  email: {
    enabled: boolean;
    types: Record<string, boolean>;
    priority: Record<string, boolean>;
  };
}

class EmailNotificationService {
  private config: EmailServiceConfig;
  private templates: Record<string, EmailTemplate>;

  constructor(config?: Partial<EmailServiceConfig>) {
    this.config = {
      apiKey: process.env.NEXT_PUBLIC_EMAIL_API_KEY || 'demo-api-key',
      senderEmail: 'noreply@associazione.org',
      senderName: 'Associazione Non-Profit',
      baseUrl: process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000',
      ...config
    };

    this.templates = this.initializeTemplates();
  }

  // Inizializza i template email
  private initializeTemplates(): Record<string, EmailTemplate> {
    return {
      new_vote: {
        subject: '🗳️ Nuova Votazione Disponibile - Azione Richiesta',
        htmlBody: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #f8fafc; padding: 20px;">
            <div style="background-color: white; border-radius: 8px; padding: 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
              <!-- Header -->
              <div style="text-align: center; margin-bottom: 30px;">
                <div style="background-color: #2563eb; color: white; width: 60px; height: 60px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 24px; margin-bottom: 15px;">
                  🗳️
                </div>
                <h1 style="color: #1e293b; margin: 0; font-size: 24px;">Nuova Votazione Disponibile</h1>
              </div>

              <!-- Content -->
              <div style="margin-bottom: 30px;">
                <p style="color: #475569; font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
                  Ciao {{recipientName}},
                </p>
                <p style="color: #475569; font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
                  È stata aperta una nuova votazione che richiede la tua partecipazione:
                </p>

                <div style="background-color: #dbeafe; border-left: 4px solid #2563eb; padding: 20px; margin: 20px 0; border-radius: 4px;">
                  <h3 style="color: #1e40af; margin: 0 0 10px 0;">{{title}}</h3>
                  <p style="color: #1e40af; margin: 0; font-size: 14px;">{{message}}</p>
                </div>

                <p style="color: #dc2626; font-weight: bold; font-size: 16px; margin: 20px 0;">
                  ⚠️ La tua partecipazione è importante per il processo democratico dell'associazione.
                </p>
              </div>

              <!-- Action Button -->
              <div style="text-align: center; margin: 30px 0;">
                <a href="{{actionUrl}}" style="background-color: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block; font-size: 16px;">
                  Partecipa alla Votazione
                </a>
              </div>

              <!-- Footer -->
              <div style="border-top: 1px solid #e2e8f0; padding-top: 20px; margin-top: 30px; text-align: center; color: #64748b; font-size: 14px;">
                <p style="margin: 0 0 10px 0;">
                  <strong>Associazione Non-Profit</strong><br>
                  Trasparenza e Partecipazione Democratica
                </p>
                <p style="margin: 0; font-size: 12px;">
                  Questa è una notifica automatica. Se non desideri più ricevere queste email,
                  <a href="{{baseUrl}}/preferenze-notifiche" style="color: #2563eb;">gestisci le tue preferenze</a>.
                </p>
              </div>
            </div>
          </div>
        `,
        textBody: `
NUOVA VOTAZIONE DISPONIBILE

Ciao {{recipientName}},

È stata aperta una nuova votazione che richiede la tua partecipazione:

{{title}}
{{message}}

⚠️ La tua partecipazione è importante per il processo democratico dell'associazione.

Partecipa alla votazione: {{actionUrl}}

---
Associazione Non-Profit
Trasparenza e Partecipazione Democratica

Per gestire le preferenze email: {{baseUrl}}/preferenze-notifiche
        `
      },

      vote_ending: {
        subject: '⏰ Votazione in Scadenza - Ultime Ore per Votare',
        htmlBody: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #fef3c7; padding: 20px;">
            <div style="background-color: white; border-radius: 8px; padding: 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); border-left: 6px solid #f59e0b;">
              <div style="text-align: center; margin-bottom: 30px;">
                <div style="background-color: #f59e0b; color: white; width: 60px; height: 60px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 24px; margin-bottom: 15px;">
                  ⏰
                </div>
                <h1 style="color: #92400e; margin: 0; font-size: 24px;">Votazione in Scadenza!</h1>
              </div>

              <div style="background-color: #fef3c7; border: 2px solid #f59e0b; padding: 20px; margin: 20px 0; border-radius: 8px; text-align: center;">
                <h3 style="color: #92400e; margin: 0 0 10px 0;">{{title}}</h3>
                <p style="color: #92400e; margin: 0; font-weight: bold;">SCADE A BREVE - Non perdere l'opportunità di votare!</p>
              </div>

              <div style="text-align: center; margin: 30px 0;">
                <a href="{{actionUrl}}" style="background-color: #f59e0b; color: white; padding: 15px 40px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block; font-size: 18px; animation: pulse 2s infinite;">
                  VOTA ORA
                </a>
              </div>

              <div style="border-top: 1px solid #f3f4f6; padding-top: 20px; margin-top: 30px; text-align: center; color: #6b7280; font-size: 14px;">
                <p style="margin: 0;">
                  Questa votazione scadrà a breve. La tua partecipazione è fondamentale!
                </p>
              </div>
            </div>
          </div>
        `,
        textBody: `
VOTAZIONE IN SCADENZA!

{{title}}

⚠️ ATTENZIONE: Questa votazione scadrà a breve!

{{message}}

Non perdere l'opportunità di far sentire la tua voce nel processo democratico dell'associazione.

VOTA ORA: {{actionUrl}}

La tua partecipazione è fondamentale!

---
Associazione Non-Profit
        `
      },

      vote_result: {
        subject: '📊 Risultato Votazione - {{title}}',
        htmlBody: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #f0fdf4; padding: 20px;">
            <div style="background-color: white; border-radius: 8px; padding: 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
              <div style="text-align: center; margin-bottom: 30px;">
                <div style="background-color: #16a34a; color: white; width: 60px; height: 60px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 24px; margin-bottom: 15px;">
                  📊
                </div>
                <h1 style="color: #166534; margin: 0; font-size: 24px;">Risultato Votazione</h1>
              </div>

              <div style="background-color: #dcfce7; border-left: 4px solid #16a34a; padding: 20px; margin: 20px 0; border-radius: 4px;">
                <h3 style="color: #166534; margin: 0 0 10px 0;">{{title}}</h3>
                <p style="color: #166534; margin: 0;">{{message}}</p>
              </div>

              <div style="text-align: center; margin: 30px 0;">
                <a href="{{actionUrl}}" style="background-color: #16a34a; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
                  Visualizza Dettagli
                </a>
              </div>

              <div style="border-top: 1px solid #e5e7eb; padding-top: 20px; margin-top: 30px; text-align: center; color: #6b7280; font-size: 14px;">
                <p style="margin: 0;">
                  Grazie per aver partecipato al processo democratico dell'associazione!
                </p>
              </div>
            </div>
          </div>
        `,
        textBody: `
RISULTATO VOTAZIONE

{{title}}

{{message}}

Visualizza i dettagli completi: {{actionUrl}}

Grazie per aver partecipato al processo democratico dell'associazione!

---
Associazione Non-Profit
        `
      },

      system: {
        subject: '🔧 {{title}} - Comunicazione Sistema',
        htmlBody: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background-color: white; border-radius: 8px; padding: 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
              <div style="text-align: center; margin-bottom: 30px;">
                <h1 style="color: #374151; margin: 0; font-size: 24px;">{{title}}</h1>
              </div>

              <div style="color: #4b5563; font-size: 16px; line-height: 1.6; margin-bottom: 30px;">
                {{message}}
              </div>

              {{#actionUrl}}
              <div style="text-align: center; margin: 30px 0;">
                <a href="{{actionUrl}}" style="background-color: #6b7280; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
                  Maggiori Informazioni
                </a>
              </div>
              {{/actionUrl}}

              <div style="border-top: 1px solid #e5e7eb; padding-top: 20px; margin-top: 30px; text-align: center; color: #9ca3af; font-size: 14px;">
                <p style="margin: 0;">Associazione Non-Profit - Sistema di Comunicazione</p>
              </div>
            </div>
          </div>
        `,
        textBody: `
{{title}}

{{message}}

{{#actionUrl}}
Maggiori informazioni: {{actionUrl}}
{{/actionUrl}}

---
Associazione Non-Profit
        `
      },

      credentials: {
        subject: '🔒 Credenziali di Accesso - {{title}}',
        htmlBody: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background-color: white; border-radius: 8px; padding: 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
              <div style="text-align: center; margin-bottom: 30px;">
                <h1 style="color: #374151; margin: 0; font-size: 24px;">{{title}}</h1>
              </div>

              <div style="color: #4b5563; font-size: 16px; line-height: 1.6; margin-bottom: 30px;">
                {{message}}
              </div>

              {{#actionUrl}}
              <div style="text-align: center; margin: 30px 0;">
                <a href="{{actionUrl}}" style="background-color: #6b7280; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
                  Maggiori Informazioni
                </a>
              </div>
              {{/actionUrl}}

              <div style="border-top: 1px solid #e5e7eb; padding-top: 20px; margin-top: 30px; text-align: center; color: #9ca3af; font-size: 14px;">
                <p style="margin: 0;">Associazione Non-Profit - Sistema di Comunicazione</p>
              </div>
            </div>
          </div>
        `,
        textBody: `
{{title}}

{{message}}

{{#actionUrl}}
Maggiori informazioni: {{actionUrl}}
{{/actionUrl}}

---
Associazione Non-Profit
        `
      },

      password_reset: {
        subject: '🔑 Resetta la Password - {{title}}',
        htmlBody: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background-color: white; border-radius: 8px; padding: 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
              <div style="text-align: center; margin-bottom: 30px;">
                <h1 style="color: #374151; margin: 0; font-size: 24px;">{{title}}</h1>
              </div>

              <div style="color: #4b5563; font-size: 16px; line-height: 1.6; margin-bottom: 30px;">
                {{message}}
              </div>

              {{#actionUrl}}
              <div style="text-align: center; margin: 30px 0;">
                <a href="{{actionUrl}}" style="background-color: #6b7280; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
                  Maggiori Informazioni
                </a>
              </div>
              {{/actionUrl}}

              <div style="border-top: 1px solid #e5e7eb; padding-top: 20px; margin-top: 30px; text-align: center; color: #9ca3af; font-size: 14px;">
                <p style="margin: 0;">Associazione Non-Profit - Sistema di Comunicazione</p>
              </div>
            </div>
          </div>
        `,
        textBody: `
{{title}}

{{message}}

{{#actionUrl}}
Maggiori informazioni: {{actionUrl}}
{{/actionUrl}}

---
Associazione Non-Profit
        `
      }
    };
  }

  // Sostituisce i placeholder nel template
  private replacePlaceholders(template: string, data: Record<string, string | undefined>): string {
    return template.replace(/\{\{(\w+)\}\}/g, (match, key) => {
      return data[key] || match;
    });
  }

  // Prepara i dati per il template
  private prepareTemplateData(emailData: EmailNotificationData): Record<string, string | undefined> {
    return {
      ...emailData.data,
      baseUrl: this.config.baseUrl,
      actionUrl: emailData.data.actionUrl || `${this.config.baseUrl}/notifiche`,
      recipientName: emailData.data.recipientName || 'Socio',
      senderName: this.config.senderName
    };
  }

  // Simula l'invio email (in produzione userebbe un servizio reale come SendGrid, Mailgun, etc.)
  private async sendEmailViaAPI(
    to: string,
    subject: string,
    htmlBody: string,
    textBody: string
  ): Promise<boolean> {
    try {
      // Simula la chiamata API per l'invio email
      console.log('📧 Simulazione invio email:');
      console.log('To:', to);
      console.log('Subject:', subject);
      console.log('HTML Body:', `${htmlBody.substring(0, 100)}...`);

      // In produzione faresti qualcosa come:
      /*
      const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.config.apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          personalizations: [{ to: [{ email: to }] }],
          from: {
            email: this.config.senderEmail,
            name: this.config.senderName
          },
          subject: subject,
          content: [
            { type: 'text/plain', value: textBody },
            { type: 'text/html', value: htmlBody }
          ]
        })
      });

      return response.ok;
      */

      // Simula successo dopo un breve delay
      await new Promise(resolve => setTimeout(resolve, 500));

      // Salva nel localStorage per il demo
      const emailLog = {
        to,
        subject,
        htmlBody,
        textBody,
        timestamp: new Date().toISOString(),
        status: 'sent'
      };

      const existingEmails = JSON.parse(localStorage.getItem('sentEmails') || '[]');
      existingEmails.push(emailLog);
      localStorage.setItem('sentEmails', JSON.stringify(existingEmails));

      console.log('✅ Email simulata inviata con successo');
      return true;

    } catch (error) {
      console.error('❌ Errore nell\'invio email:', error);
      return false;
    }
  }

  // Invia notifica email
  public async sendNotification(emailData: EmailNotificationData): Promise<boolean> {
    try {
      const template = this.templates[emailData.type];
      if (!template) {
        console.error('Template non trovato per il tipo:', emailData.type);
        return false;
      }

      const templateData = this.prepareTemplateData(emailData);

      const subject = this.replacePlaceholders(template.subject, templateData);
      const htmlBody = this.replacePlaceholders(template.htmlBody, templateData);
      const textBody = this.replacePlaceholders(template.textBody, templateData);

      return await this.sendEmailViaAPI(emailData.to, subject, htmlBody, textBody);

    } catch (error) {
      console.error('Errore nell\'invio notifica email:', error);
      return false;
    }
  }

  // Invia email di test
  public async sendTestEmail(to: string): Promise<boolean> {
    const testData: EmailNotificationData = {
      to,
      type: 'system',
      priority: 'medium',
      data: {
        title: 'Test Email Notifiche',
        message: 'Questa è un\'email di test per verificare il funzionamento del sistema di notifiche email. Se ricevi questo messaggio, tutto funziona correttamente!',
        recipientName: 'Tester',
        actionUrl: `${this.config.baseUrl}/notifiche`
      }
    };

    return await this.sendNotification(testData);
  }

  // Invia credenziali a nuovo socio
  public async sendCredentials(
    to: string,
    name: string,
    email: string,
    password: string,
    tessera: string
  ): Promise<boolean> {
    const credentialsData: EmailNotificationData = {
      to,
      type: 'credentials',
      priority: 'high',
      data: {
        title: 'Benvenuto nell\'Associazione! 🎉',
        message: `
          <p style="font-size: 16px; color: #374151; margin-bottom: 20px;">
            Caro/a <strong>${name}</strong>,
          </p>

          <p style="font-size: 16px; color: #374151; margin-bottom: 20px;">
            È un piacere darti il benvenuto nell'Associazione Non-Profit!
            La tua registrazione è stata completata con successo.
          </p>

          <div style="background-color: #f3f4f6; border-radius: 8px; padding: 20px; margin: 20px 0;">
            <h3 style="color: #1f2937; margin: 0 0 15px 0; font-size: 18px;">🔑 Le tue credenziali di accesso:</h3>

            <div style="background-color: white; border-radius: 6px; padding: 15px; margin-bottom: 15px;">
              <strong style="color: #374151;">Email:</strong>
              <span style="color: #2563eb; font-family: monospace; background-color: #eff6ff; padding: 2px 6px; border-radius: 4px;">${email}</span>
            </div>

            <div style="background-color: white; border-radius: 6px; padding: 15px; margin-bottom: 15px;">
              <strong style="color: #374151;">Password:</strong>
              <span style="color: #dc2626; font-family: monospace; background-color: #fef2f2; padding: 2px 6px; border-radius: 4px; font-weight: bold;">${password}</span>
            </div>

            <div style="background-color: white; border-radius: 6px; padding: 15px;">
              <strong style="color: #374151;">Numero Tessera:</strong>
              <span style="color: #059669; font-family: monospace; background-color: #ecfdf5; padding: 2px 6px; border-radius: 4px;">${tessera}</span>
            </div>
          </div>

          <div style="background-color: #dbeafe; border-left: 4px solid #2563eb; padding: 15px; margin: 20px 0;">
            <h4 style="color: #1e40af; margin: 0 0 10px 0;">🗳️ Come Partecipare alle Votazioni:</h4>
            <ol style="color: #1e40af; margin: 0; padding-left: 20px;">
              <li>Vai su <strong>/votazioni/login</strong></li>
              <li>Inserisci la tua email e password</li>
              <li>Partecipa alle votazioni democratiche</li>
              <li>Visualizza i risultati su <strong>/votazioni/voti-totali</strong></li>
            </ol>
          </div>

          <p style="font-size: 14px; color: #6b7280; margin-top: 30px;">
            ⚠️ <strong>Importante:</strong> Conserva queste credenziali in un luogo sicuro.
            Se le perdi, contatta un amministratore per il reset.
          </p>
        `,
        recipientName: name,
        email,
        password,
        tessera,
        actionUrl: `${this.config.baseUrl}/votazioni/login`
      }
    };

    return await this.sendNotification(credentialsData);
  }

  // Invia email di reset password
  public async sendPasswordReset(
    to: string,
    name: string,
    newPassword: string,
    tessera: string
  ): Promise<boolean> {
    const resetData: EmailNotificationData = {
      to,
      type: 'password_reset',
      priority: 'high',
      data: {
        title: 'Password Ripristinata 🔄',
        message: `
          <p style="font-size: 16px; color: #374151; margin-bottom: 20px;">
            Caro/a <strong>${name}</strong>,
          </p>

          <p style="font-size: 16px; color: #374151; margin-bottom: 20px;">
            La tua password per l'accesso alle votazioni è stata ripristinata dall'amministrazione.
          </p>

          <div style="background-color: #fef2f2; border-radius: 8px; padding: 20px; margin: 20px 0; border-left: 4px solid #dc2626;">
            <h3 style="color: #991b1b; margin: 0 0 15px 0;">🔑 Nuova Password:</h3>
            <div style="background-color: white; border-radius: 6px; padding: 15px; text-align: center;">
              <span style="color: #dc2626; font-family: monospace; font-size: 18px; font-weight: bold; background-color: #fef2f2; padding: 8px 16px; border-radius: 4px;">${newPassword}</span>
            </div>
          </div>

          <div style="background-color: #f3f4f6; border-radius: 6px; padding: 15px; margin: 20px 0;">
            <strong style="color: #374151;">Accedi con:</strong><br>
            <strong>Email:</strong> ${to}<br>
            <strong>Tessera:</strong> ${tessera}
          </div>

          <p style="font-size: 14px; color: #dc2626; margin-top: 20px;">
            ⚠️ Per sicurezza, ti consigliamo di salvare questa password in un luogo sicuro.
          </p>
        `,
        recipientName: name,
        password: newPassword,
        tessera,
        actionUrl: `${this.config.baseUrl}/votazioni/login`
      }
    };

    return await this.sendNotification(resetData);
  }

  // Genera preview dell'email credenziali
  public generateCredentialsPreview(
    name: string,
    email: string,
    password: string,
    tessera: string
  ): { subject: string; htmlBody: string } {
    const template = this.templates.credentials;
    const templateData = this.prepareTemplateData({
      to: email,
      type: 'credentials',
      priority: 'high',
      data: {
        title: 'Benvenuto nell\'Associazione! 🎉',
        message: `Preview per ${name}`,
        recipientName: name,
        email,
        password,
        tessera,
        actionUrl: `${this.config.baseUrl}/votazioni/login`
      }
    });

    return {
      subject: this.replacePlaceholders(template.subject, templateData),
      htmlBody: this.replacePlaceholders(template.htmlBody, templateData)
    };
  }

  // Ottiene statistiche email inviate (dal demo localStorage)
  public getEmailStats(): {
    totalSent: number;
    sentToday: number;
    byType: Record<string, number>;
    recentEmails: SentEmail[];
  } {
    try {
      const sentEmails: SentEmail[] = JSON.parse(localStorage.getItem('sentEmails') || '[]');
      const today = new Date().toDateString();

      const sentToday = sentEmails.filter((email: SentEmail) =>
        new Date(email.timestamp).toDateString() === today
      ).length;

      const byType = sentEmails.reduce((acc: Record<string, number>, email: SentEmail) => {
        // Estrai il tipo dall'oggetto email (semplificato)
        const type = email.subject.includes('Votazione') ? 'vote' : 'system';
        acc[type] = (acc[type] || 0) + 1;
        return acc;
      }, {});

      return {
        totalSent: sentEmails.length,
        sentToday,
        byType,
        recentEmails: sentEmails.slice(-5).reverse()
      };

    } catch (error) {
      console.error('Errore nel recupero statistiche:', error);
      return {
        totalSent: 0,
        sentToday: 0,
        byType: {},
        recentEmails: []
      };
    }
  }

  // Controlla se l'utente dovrebbe ricevere email per questo tipo/priorità
  public shouldSendEmail(
    preferences: EmailPreferences,
    type: string,
    priority: string
  ): boolean {
    if (!preferences?.email?.enabled) return false;
    if (!preferences.email.types[type]) return false;
    if (!preferences.email.priority[priority]) return false;

    // Controlla le ore di silenzio
    if (preferences.timing?.quietHours?.enabled) {
      const now = new Date();
      const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      const { start, end } = preferences.timing.quietHours;

      if (start <= end) {
        // Stesso giorno (es. 22:00 - 08:00 del giorno dopo)
        if (currentTime >= start && currentTime <= end) return false;
      } else {
        // Attraversa mezzanotte (es. 22:00 - 08:00)
        if (currentTime >= start || currentTime <= end) return false;
      }
    }

    return true;
  }
}

// Esporta un'istanza singleton
export const emailNotificationService = new EmailNotificationService();
export default emailNotificationService;
export type { EmailNotificationData };
