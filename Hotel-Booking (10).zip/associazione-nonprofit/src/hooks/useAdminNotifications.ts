import { useState, useEffect, useCallback } from 'react';
import { AdminNotificationService, type AdminNotification } from '@/services/AdminNotificationService';

export function useAdminNotifications() {
  const [notifications, setNotifications] = useState<AdminNotification[]>([]);
  const [isPermissionGranted, setIsPermissionGranted] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const notificationService = AdminNotificationService.getInstance();

  // Carica notifiche iniziali
  useEffect(() => {
    const loadNotifications = async () => {
      setIsLoading(true);

      try {
        // Controlla permessi
        const permission = await notificationService.checkNotificationPermission();
        setIsPermissionGranted(permission);

        // Carica notifiche salvate
        const stored = notificationService.getStoredNotifications();
        setNotifications(stored);
      } catch (error) {
        console.error('Errore caricamento notifiche:', error);
      }

      setIsLoading(false);
    };

    loadNotifications();
  }, [notificationService]);

  // Ascolta cambiamenti nelle notifiche
  useEffect(() => {
    const unsubscribe = notificationService.addListener(setNotifications);
    return unsubscribe;
  }, [notificationService]);

  // Funzioni di gestione
  const requestPermission = useCallback(async () => {
    const granted = await notificationService.checkNotificationPermission();
    setIsPermissionGranted(granted);
    return granted;
  }, [notificationService]);

  const sendNotification = useCallback(async (notificationData: Omit<AdminNotification, 'id' | 'timestamp'>) => {
    const notification: AdminNotification = {
      id: `custom-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      ...notificationData
    };

    return await notificationService.sendDesktopNotification(notification);
  }, [notificationService]);

  const markAsRead = useCallback((notificationId: string) => {
    notificationService.markAsRead(notificationId);
  }, [notificationService]);

  const markAllAsRead = useCallback(() => {
    notificationService.markAllAsRead();
  }, [notificationService]);

  const deleteNotification = useCallback((notificationId: string) => {
    notificationService.deleteNotification(notificationId);
  }, [notificationService]);

  const clearAll = useCallback(() => {
    notificationService.clearAllNotifications();
  }, [notificationService]);

  // Notifiche pre-configurate
  const notifyNewVote = useCallback(async (candidateName: string) => {
    return await notificationService.notifyNewVote(candidateName);
  }, [notificationService]);

  const notifyNewMember = useCallback(async (memberName: string) => {
    return await notificationService.notifyNewMember(memberName);
  }, [notificationService]);

  const notifyPayment = useCallback(async (amount: number, from: string) => {
    return await notificationService.notifyPayment(amount, from);
  }, [notificationService]);

  const notifySystemAlert = useCallback(async (message: string) => {
    return await notificationService.notifySystemAlert(message);
  }, [notificationService]);

  const notifyUrgent = useCallback(async (title: string, message: string) => {
    return await notificationService.notifyUrgent(title, message);
  }, [notificationService]);

  // Statistiche
  const stats = notificationService.getNotificationStats();
  const unreadCount = notifications.filter(n => !n.read).length;

  return {
    notifications,
    unreadCount,
    stats,
    isPermissionGranted,
    isLoading,

    // Actions
    requestPermission,
    sendNotification,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    clearAll,

    // Pre-configured notifications
    notifyNewVote,
    notifyNewMember,
    notifyPayment,
    notifySystemAlert,
    notifyUrgent
  };
}
