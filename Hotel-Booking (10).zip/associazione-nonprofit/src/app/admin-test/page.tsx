export default function AdminTest() {
  return (
    <html>
      <head>
        <title>Admin Test</title>
      </head>
      <body style={{ fontFamily: 'Arial', padding: '40px', background: '#f0f0f0' }}>
        <div style={{
          background: 'white',
          padding: '40px',
          borderRadius: '10px',
          boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
        }}>
          <h1 style={{ color: 'green', fontSize: '36px', textAlign: 'center' }}>
            ✅ SISTEMA FUNZIONANTE!
          </h1>

          <div style={{
            background: '#e6fffa',
            padding: '20px',
            border: '2px solid #38a169',
            borderRadius: '8px',
            margin: '30px 0',
            textAlign: 'center'
          }}>
            <h2 style={{ color: '#2d3748' }}>🎉 Test Riuscito</h2>
            <p style={{ fontSize: '18px', color: '#4a5568' }}>
              Se vedi questo messaggio, Next.js funziona perfettamente.
            </p>
          </div>

          <div style={{ marginTop: '40px' }}>
            <h3 style={{ color: '#2d3748' }}>🔗 Link di Test:</h3>
            <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap', marginTop: '20px' }}>
              <a href="/" style={{
                background: '#4299e1',
                color: 'white',
                padding: '10px 20px',
                textDecoration: 'none',
                borderRadius: '5px',
                display: 'inline-block'
              }}>
                🏠 Homepage
              </a>

              <a href="/admin/login" style={{
                background: '#48bb78',
                color: 'white',
                padding: '10px 20px',
                textDecoration: 'none',
                borderRadius: '5px',
                display: 'inline-block'
              }}>
                🔑 Login Admin
              </a>

              <a href="/votazioni" style={{
                background: '#ed8936',
                color: 'white',
                padding: '10px 20px',
                textDecoration: 'none',
                borderRadius: '5px',
                display: 'inline-block'
              }}>
                🗳️ Votazioni
              </a>
            </div>
          </div>

          <div style={{
            marginTop: '40px',
            padding: '20px',
            background: '#fff5f5',
            border: '1px solid #fc8181',
            borderRadius: '8px'
          }}>
            <h3 style={{ color: '#c53030' }}>🔧 Informazioni Debug:</h3>
            <ul style={{ color: '#2d3748' }}>
              <li>✅ React funziona</li>
              <li>✅ Next.js funziona</li>
              <li>✅ Routing funziona</li>
              <li>✅ CSS inline funziona</li>
            </ul>
          </div>
        </div>
      </body>
    </html>
  );
}
