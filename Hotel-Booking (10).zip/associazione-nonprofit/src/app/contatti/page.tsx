"use client"

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import Link from "next/link";
import { useState } from "react";

export default function Contatti() {
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    oggetto: "",
    messaggio: ""
  });

  const [inviato, setInviato] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setInviato(true);
    setTimeout(() => setInviato(false), 3000);
  };

  return (
    <div className="container px-4 py-8">
      {/* Hero Section */}
      <section className="text-center py-16 space-y-6">
        <Badge variant="secondary" className="mb-4">
          Contatti
        </Badge>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
          Resta in <span className="text-blue-600">Contatto</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
          Hai domande, suggerimenti o vuoi semplicemente saperne di più?
          Siamo qui per ascoltarti e rispondere a ogni tua necessità.
        </p>
      </section>

      <div className="grid lg:grid-cols-2 gap-12">
        {/* Form di Contatto */}
        <div>
          <Card className="relative overflow-hidden">
            {inviato && (
              <div className="absolute inset-0 bg-green-50 flex items-center justify-center z-10">
                <div className="text-center">
                  <div className="text-6xl mb-4">✅</div>
                  <h3 className="text-2xl font-bold text-green-600 mb-2">Messaggio Inviato!</h3>
                  <p className="text-green-700">Ti risponderemo entro 24 ore.</p>
                </div>
              </div>
            )}

            <CardHeader>
              <CardTitle className="text-2xl">Invia un Messaggio</CardTitle>
              <CardDescription>
                Compila il form e ti risponderemo il prima possibile
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nome">Nome *</Label>
                    <Input
                      id="nome"
                      value={formData.nome}
                      onChange={(e) => setFormData(prev => ({...prev, nome: e.target.value}))}
                      placeholder="Il tuo nome"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData(prev => ({...prev, email: e.target.value}))}
                      placeholder="la-tua-email@esempio.com"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="oggetto">Oggetto *</Label>
                  <select
                    id="oggetto"
                    value={formData.oggetto}
                    onChange={(e) => setFormData(prev => ({...prev, oggetto: e.target.value}))}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    required
                  >
                    <option value="">Seleziona l'argomento...</option>
                    <option value="informazioni">Informazioni generali</option>
                    <option value="associazione">Diventare socio</option>
                    <option value="partnership">Partnership aziendale</option>
                    <option value="trasparenza">Domande sulla trasparenza</option>
                    <option value="votazioni">Sistema di votazione</option>
                    <option value="newsletter">Newsletter e comunicazioni</option>
                    <option value="tecnico">Supporto tecnico</option>
                    <option value="altro">Altro</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="messaggio">Messaggio *</Label>
                  <Textarea
                    id="messaggio"
                    value={formData.messaggio}
                    onChange={(e) => setFormData(prev => ({...prev, messaggio: e.target.value}))}
                    placeholder="Scrivi qui il tuo messaggio..."
                    rows={6}
                    required
                  />
                </div>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Tempi di Risposta</h3>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>📧 Email: entro 24 ore</li>
                    <li>📞 Telefono: Lun-Ven 9:00-18:00</li>
                    <li>⚡ Urgenze: risposta immediata</li>
                  </ul>
                </div>

                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" size="lg">
                  Invia Messaggio
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Informazioni di Contatto */}
        <div className="space-y-8">
          {/* Contatti Diretti */}
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Informazioni di Contatto</CardTitle>
              <CardDescription>
                I nostri canali di comunicazione sempre aperti
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">📧</span>
                </div>
                <div>
                  <h3 className="font-semibold">Email</h3>
                  <p className="text-gray-600">info@associazione.org</p>
                  <p className="text-sm text-gray-500">Risposta entro 24 ore</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">📞</span>
                </div>
                <div>
                  <h3 className="font-semibold">Telefono</h3>
                  <p className="text-gray-600">+39 123 456 7890</p>
                  <p className="text-sm text-gray-500">Lun-Ven 9:00-18:00</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">📍</span>
                </div>
                <div>
                  <h3 className="font-semibold">Indirizzo</h3>
                  <p className="text-gray-600">
                    Via Roma 123<br />
                    20121 Milano (MI)<br />
                    Italia
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">⏰</span>
                </div>
                <div>
                  <h3 className="font-semibold">Orari di Apertura</h3>
                  <p className="text-gray-600">
                    Lunedì - Venerdì: 9:00 - 18:00<br />
                    Sabato: 9:00 - 13:00<br />
                    Domenica: Chiuso
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Team di Riferimento */}
          <Card>
            <CardHeader>
              <CardTitle>Chi Ti Risponderà</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">MA</span>
                </div>
                <div>
                  <h3 className="font-semibold">Michael Franceschini</h3>
                  <p className="text-sm text-gray-600">Presidente - Informazioni generali</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">LR</span>
                </div>
                <div>
                  <h3 className="font-semibold">Vittoria Sgura</h3>
                  <p className="text-sm text-gray-600">Tesoriera - Trasparenza e finanze</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">GB</span>
                </div>
                <div>
                  <h3 className="font-semibold">Ilenya</h3>
                  <p className="text-sm text-gray-600">Segretaria - Comunicazione e soci</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* FAQ Rapide */}
          <Card>
            <CardHeader>
              <CardTitle>Domande Frequenti</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-1">Come posso diventare socio?</h4>
                <p className="text-sm text-gray-600">
                  Visita la nostra <Link href="/associati" className="text-blue-600 hover:underline">
                    pagina associati
                  </Link> per il modulo di registrazione.
                </p>
              </div>

              <div>
                <h4 className="font-semibold mb-1">Dove posso vedere i conti?</h4>
                <p className="text-sm text-gray-600">
                  Tutte le informazioni finanziarie sono nella sezione <Link href="/trasparenza" className="text-blue-600 hover:underline">
                    trasparenza
                  </Link>.
                </p>
              </div>

              <div>
                <h4 className="font-semibold mb-1">Come funzionano le votazioni?</h4>
                <p className="text-sm text-gray-600">
                  Visita la <Link href="/votazioni" className="text-blue-600 hover:underline">
                    pagina votazioni
                  </Link> per tutti i dettagli.
                </p>
              </div>

              <div>
                <h4 className="font-semibold mb-1">Posso visitare la sede?</h4>
                <p className="text-sm text-gray-600">
                  Certo! Prenota un appuntamento chiamandoci o scrivendoci via email.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Mappa e Indicazioni */}
      <section className="py-16">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Come Raggiungerci</CardTitle>
            <CardDescription>
              La nostra sede è facilmente raggiungibile con i mezzi pubblici
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-8">
              {/* Mappa Placeholder */}
              <div className="bg-gray-100 rounded-lg h-64 flex items-center justify-center">
                <div className="text-center text-gray-600">
                  <div className="text-4xl mb-2">🗺️</div>
                  <p>Mappa Interattiva</p>
                  <p className="text-sm">Via Roma 123, Milano</p>
                </div>
              </div>

              {/* Indicazioni */}
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-2">🚇 Metro</h3>
                  <p className="text-sm text-gray-600">
                    Fermata Duomo (Linea Rossa M1) - 5 minuti a piedi<br />
                    Fermata Missori (Linea Gialla M3) - 7 minuti a piedi
                  </p>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">🚌 Autobus</h3>
                  <p className="text-sm text-gray-600">
                    Linee 54, 61, 73 - Fermata Via Roma<br />
                    Linea 94 - Fermata Piazza Missori
                  </p>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">🚗 Auto</h3>
                  <p className="text-sm text-gray-600">
                    Parcheggio a pagamento nelle vicinanze<br />
                    Zona a traffico limitato - verificare orari
                  </p>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">🚲 Bike Sharing</h3>
                  <p className="text-sm text-gray-600">
                    Stazione BikeMi a 2 minuti dalla sede<br />
                    Porta bici disponibili in cortile
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Call to Action */}
      <section className="py-16 text-center">
        <div className="max-w-2xl mx-auto space-y-6">
          <h2 className="text-3xl font-bold">Pronto a Unirti a Noi?</h2>
          <p className="text-gray-600">
            Non aspettare oltre! Diventa parte della nostra community trasparente e democratica.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
              <Link href="/associati">
                Diventa Socio - €20/anno
              </Link>
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link href="/newsletter">
                Iscriviti alla Newsletter
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
