import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import Link from "next/link";

export default function TerminiCondizioni() {
  return (
    <div className="container px-4 py-8">
      {/* Hero Section */}
      <section className="text-center py-16 space-y-6">
        <Badge variant="secondary" className="mb-4">
          Termini e Condizioni
        </Badge>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
          <span className="text-blue-600">Termini e Condizioni</span> di Utilizzo
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
          I termini legali che regolano l'adesione e l'utilizzo dei servizi FreeStay Alliance.
          Chiari, trasparenti e orientati alla protezione di tutti i soci.
        </p>
      </section>

      {/* Premessa */}
      <section className="py-8">
        <Card className="border-2 border-blue-200">
          <CardHeader>
            <CardTitle className="text-2xl text-blue-600 flex items-center gap-2">
              📋 Premessa e Accettazione
            </CardTitle>
            <CardDescription>
              Natura del servizio e modalità di accettazione dei termini
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
              <h3 className="font-bold text-blue-800 mb-4">🏛️ Natura del Servizio</h3>
              <p className="text-blue-700 leading-relaxed mb-4">
                <strong>FreeStay Alliance</strong> è un'associazione non riconosciuta senza scopo di lucro,
                costituita ai sensi del D.Lgs. 117/2017 (Codice del Terzo Settore), con sede legale in
                <strong> Via Aldo Moro 20, 39040 Salorno (BZ), Italia</strong>.
              </p>

              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <span className="text-blue-600 text-lg">🎯</span>
                  <p className="text-blue-700">
                    <strong>Missione principale:</strong> Creazione e gestione di una piattaforma digitale etica
                    per il settore turistico, favorendo l'indipendenza economica degli albergatori
                  </p>
                </div>

                <div className="flex items-start gap-3">
                  <span className="text-blue-600 text-lg">🤝</span>
                  <p className="text-blue-700">
                    <strong>Governance:</strong> Gestione democratica e partecipativa da parte dei soci,
                    con trasparenza totale su decisioni e finanze
                  </p>
                </div>

                <div className="flex items-start gap-3">
                  <span className="text-blue-600 text-lg">🚫</span>
                  <p className="text-blue-700">
                    <strong>Principio base:</strong> Zero commissioni sulla futura piattaforma di prenotazioni,
                    finanziata esclusivamente dai contributi associativi
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <h3 className="font-bold text-green-800 mb-3">✅ Accettazione dei Termini</h3>
              <ul className="space-y-2 text-green-700">
                <li>• <strong>Iscrizione automatica:</strong> L'adesione all'associazione implica accettazione integrale dei presenti termini</li>
                <li>• <strong>Maggiore età:</strong> Possono aderire solo soggetti maggiorenni o enti legalmente costituiti</li>
                <li>• <strong>Capacità giuridica:</strong> Il richiedente dichiara di avere piena capacità di contrarre</li>
                <li>• <strong>Veridicità dati:</strong> Tutte le informazioni fornite devono essere veritiere e aggiornate</li>
              </ul>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <h3 className="font-bold text-yellow-800 mb-2">📅 Versione e Aggiornamenti</h3>
              <div className="grid md:grid-cols-2 gap-4 text-yellow-700">
                <div>
                  <p><strong>Versione:</strong> 1.0</p>
                  <p><strong>Data entrata in vigore:</strong> 26 giugno 2025</p>
                </div>
                <div>
                  <p><strong>Ultimo aggiornamento:</strong> 26 giugno 2025</p>
                  <p><strong>Prossima revisione:</strong> 26 giugno 2026</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Diritti e Obblighi */}
      <section className="py-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              ⚖️ Diritti e Obblighi delle Parti
            </CardTitle>
            <CardDescription>
              Cosa puoi aspettarti dall'associazione e cosa l'associazione si aspetta da te
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">

            {/* Diritti del Socio */}
            <div className="border-l-4 border-green-500 pl-6">
              <h3 className="text-xl font-bold text-green-800 mb-4">✅ Diritti del Socio</h3>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">🗳️ Partecipazione Democratica</h4>
                    <ul className="text-sm space-y-1 text-green-700">
                      <li>• Diritto di voto su tutte le decisioni associative</li>
                      <li>• Partecipazione alle assemblee ordinarie e straordinarie</li>
                      <li>• Diritto di proposta per nuove iniziative</li>
                      <li>• Accesso alle votazioni online sicure</li>
                    </ul>
                  </div>

                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">📊 Trasparenza Totale</h4>
                    <ul className="text-sm space-y-1 text-green-700">
                      <li>• Accesso in tempo reale a bilanci e movimenti</li>
                      <li>• Visibilità completa sui progetti in corso</li>
                      <li>• Report periodici sullo sviluppo della piattaforma</li>
                      <li>• Dashboard personale con statistiche</li>
                    </ul>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">🏨 Benefici Futuri</h4>
                    <ul className="text-sm space-y-1 text-green-700">
                      <li>• Accesso prioritario alla piattaforma di prenotazioni</li>
                      <li>• Zero commissioni sui servizi FreeStay Alliance</li>
                      <li>• Supporto tecnico e formativo dedicato</li>
                      <li>• Networking con altri albergatori soci</li>
                    </ul>
                  </div>

                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">📞 Supporto e Comunicazione</h4>
                    <ul className="text-sm space-y-1 text-green-700">
                      <li>• Newsletter esclusiva con aggiornamenti</li>
                      <li>• Supporto tecnico via email e telefono</li>
                      <li>• Inviti prioritari a eventi e formazioni</li>
                      <li>• Community privata per confronto e aiuto</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Obblighi del Socio */}
            <div className="border-l-4 border-orange-500 pl-6">
              <h3 className="text-xl font-bold text-orange-800 mb-4">📋 Obblighi del Socio</h3>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="bg-orange-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">💰 Contributi Economici</h4>
                    <ul className="text-sm space-y-1 text-orange-700">
                      <li>• <strong>Quota annuale:</strong> €20 per soci ordinari (detraibile 100%)</li>
                      <li>• <strong>Quota fondatori:</strong> €1.000 come da statuto (se applicabile)</li>
                      <li>• <strong>Scadenza:</strong> Entro 30 giorni dalla data di iscrizione</li>
                      <li>• <strong>Rinnovo:</strong> Automatico alla scadenza annuale</li>
                    </ul>
                  </div>

                  <div className="bg-orange-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">🤝 Comportamento Associativo</h4>
                    <ul className="text-sm space-y-1 text-orange-700">
                      <li>• Rispetto dello statuto e del presente regolamento</li>
                      <li>• Partecipazione costruttiva alle attività associative</li>
                      <li>• Promozione dei valori e della missione dell'associazione</li>
                      <li>• Comunicazione rispettosa con altri soci e organi</li>
                    </ul>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-orange-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">📄 Obblighi Informativi</h4>
                    <ul className="text-sm space-y-1 text-orange-700">
                      <li>• Mantenere aggiornati i propri dati anagrafici</li>
                      <li>• Comunicare tempestivamente modifiche rilevanti</li>
                      <li>• Fornire documentazione necessaria se richiesta</li>
                      <li>• Collaborare per verifiche e controlli legittimi</li>
                    </ul>
                  </div>

                  <div className="bg-orange-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">🚫 Divieti Specifici</h4>
                    <ul className="text-sm space-y-1 text-orange-700">
                      <li>• Non utilizzare i servizi per scopi illeciti</li>
                      <li>• Non danneggiare l'immagine dell'associazione</li>
                      <li>• Non divulgare informazioni riservate</li>
                      <li>• Non interferire con il funzionamento dei sistemi</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Procedure di Iscrizione */}
      <section className="py-8">
        <Card className="border-2 border-purple-200">
          <CardHeader>
            <CardTitle className="text-2xl text-purple-600 flex items-center gap-2">
              📝 Procedure di Iscrizione e Membership
            </CardTitle>
            <CardDescription>
              Il processo completo dalla richiesta di adesione alla conferma di socio
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">

            {/* Processo di Adesione */}
            <div className="bg-purple-50 p-6 rounded-lg border border-purple-200">
              <h3 className="font-bold text-purple-800 mb-4">🔄 Processo di Adesione</h3>

              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-2xl text-purple-600">1️⃣</span>
                  </div>
                  <h4 className="font-semibold text-purple-800 mb-2">Richiesta</h4>
                  <ul className="text-sm text-purple-700 space-y-1">
                    <li>• Compilazione modulo online</li>
                    <li>• Motivazione di adesione</li>
                    <li>• Accettazione termini</li>
                    <li>• Pagamento quota</li>
                  </ul>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-2xl text-purple-600">2️⃣</span>
                  </div>
                  <h4 className="font-semibold text-purple-800 mb-2">Valutazione</h4>
                  <ul className="text-sm text-purple-700 space-y-1">
                    <li>• Votazione soci attuali (7 giorni)</li>
                    <li>• Maggioranza semplice richiesta</li>
                    <li>• Verifiche documentali</li>
                    <li>• Controllo requisiti</li>
                  </ul>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-2xl text-purple-600">3️⃣</span>
                  </div>
                  <h4 className="font-semibold text-purple-800 mb-2">Ammissione</h4>
                  <ul className="text-sm text-purple-700 space-y-1">
                    <li>• Notifica esito via email</li>
                    <li>• Attivazione accesso completo</li>
                    <li>• Benvenuto nella community</li>
                    <li>• Primo tutorial di onboarding</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Garanzie e Rimborsi */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <h3 className="font-bold text-green-800 mb-3">✅ Garanzie di Ammissione</h3>
                <ul className="text-sm space-y-2 text-green-700">
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Processo trasparente:</strong> Tutti i voti sono visibili ai soci</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Criteri oggettivi:</strong> Valutazione basata su motivazioni e requisiti</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Non discriminazione:</strong> Nessuna esclusione per motivi arbitrari</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Diritto di ricorso:</strong> Possibilità di appello per decisioni contestate</span>
                  </li>
                </ul>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h3 className="font-bold text-blue-800 mb-3">💰 Politica Rimborsi</h3>
                <ul className="text-sm space-y-2 text-blue-700">
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600">•</span>
                    <span><strong>Rifiuto ammissione:</strong> Rimborso completo entro 7 giorni</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600">•</span>
                    <span><strong>Recesso volontario:</strong> Nessun rimborso per quote già versate</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600">•</span>
                    <span><strong>Esclusione per inadempienza:</strong> Nessun rimborso</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600">•</span>
                    <span><strong>Errori tecnici:</strong> Rimborso completo previa verifica</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Recesso e Cessazione */}
            <div className="bg-gray-50 p-4 rounded-lg border">
              <h3 className="font-bold text-gray-800 mb-3">🚪 Recesso e Cessazione dell'Associazione</h3>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Recesso del Socio:</h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• <strong>Modalità:</strong> Comunicazione scritta via email</li>
                    <li>• <strong>Preavviso:</strong> 30 giorni dalla comunicazione</li>
                    <li>• <strong>Effetto:</strong> Perdita immediata di tutti i diritti</li>
                    <li>• <strong>Obblighi:</strong> Restano dovute le quote in corso</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Esclusione del Socio:</h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• <strong>Cause:</strong> Inadempienza grave o comportamento lesivo</li>
                    <li>• <strong>Procedura:</strong> Delibera del Consiglio Direttivo</li>
                    <li>• <strong>Diritto difesa:</strong> Controdeduzioni scritte entro 15 giorni</li>
                    <li>• <strong>Appello:</strong> Ricorso all'Assemblea dei Soci</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Responsabilità e Limitazioni */}
      <section className="py-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              ⚠️ Responsabilità e Limitazioni
            </CardTitle>
            <CardDescription>
              Chiarimenti sui limiti di responsabilità e gestione dei rischi
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">

            {/* Limitazioni di Responsabilità */}
            <div className="border-l-4 border-red-500 pl-6">
              <h3 className="text-xl font-bold text-red-800 mb-4">🚫 Limitazioni di Responsabilità</h3>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-red-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-red-800 mb-2">🏛️ Responsabilità dell'Associazione</h4>
                  <ul className="text-sm space-y-1 text-red-700">
                    <li>• <strong>Servizi "as-is":</strong> Nessuna garanzia di continuità o perfezione</li>
                    <li>• <strong>Sviluppo piattaforma:</strong> Tempi e funzionalità possono variare</li>
                    <li>• <strong>Risultati economici:</strong> Nessuna garanzia di profitto o risparmio</li>
                    <li>• <strong>Danni indiretti:</strong> Esclusione responsabilità per lucro cessante</li>
                  </ul>
                </div>

                <div className="bg-red-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-red-800 mb-2">👤 Responsabilità del Socio</h4>
                  <ul className="text-sm space-y-1 text-red-700">
                    <li>• <strong>Uso proprio:</strong> Ogni socio utilizza i servizi a proprio rischio</li>
                    <li>• <strong>Decisioni commerciali:</strong> Restano di esclusiva competenza del socio</li>
                    <li>• <strong>Compliance normativa:</strong> Rispetto delle leggi del proprio settore</li>
                    <li>• <strong>Sicurezza dati:</strong> Collaborazione attiva per protezione account</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Forza Maggiore */}
            <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <h3 className="font-bold text-yellow-800 mb-3">⚡ Forza Maggiore e Circostanze Eccezionali</h3>
              <p className="text-yellow-700 mb-3">
                L'associazione non è responsabile per ritardi, interruzioni o impossibilità di prestazione dovuti a:
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                <ul className="text-sm space-y-1 text-yellow-700">
                  <li>• Eventi naturali, epidemie, guerre</li>
                  <li>• Interruzioni di servizi di terze parti</li>
                  <li>• Modifiche normative improvvise</li>
                  <li>• Attacchi informatici o cyber-sicurezza</li>
                </ul>
                <ul className="text-sm space-y-1 text-yellow-700">
                  <li>• Scioperi e agitazioni sindacali</li>
                  <li>• Failure di fornitori critici</li>
                  <li>• Decisioni di autorità pubbliche</li>
                  <li>• Altri eventi non prevedibili o evitabili</li>
                </ul>
              </div>
            </div>

            {/* Indennizzo */}
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <h3 className="font-bold text-blue-800 mb-3">🛡️ Clausola di Indennizzo</h3>
              <p className="text-blue-700 text-sm leading-relaxed">
                Ogni socio si impegna a manlevare e tenere indenne l'associazione da qualsiasi richiesta di risarcimento,
                azione legale, danno o perdita derivante dall'uso improprio dei servizi, dalla violazione dei presenti termini,
                o da attività commerciali svolte in proprio che possano coinvolgere indirettamente l'associazione.
                Il limite massimo di responsabilità dell'associazione verso ogni socio è pari alla quota associativa annuale versata.
              </p>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Proprietà Intellettuale */}
      <section className="py-8">
        <Card className="border-2 border-green-200">
          <CardHeader>
            <CardTitle className="text-2xl text-green-600 flex items-center gap-2">
              ©️ Proprietà Intellettuale e Utilizzo
            </CardTitle>
            <CardDescription>
              Diritti su contenuti, marchi e proprietà della piattaforma
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">

            <div className="grid md:grid-cols-2 gap-6">
              {/* Proprietà dell'Associazione */}
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <h3 className="font-bold text-green-800 mb-3">🏛️ Proprietà dell'Associazione</h3>
                <ul className="text-sm space-y-2 text-green-700">
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Marchio "FreeStay Alliance":</strong> Proprietà esclusiva dell'associazione</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Piattaforma software:</strong> Codice e funzionalità sviluppate per l'associazione</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Database e dati:</strong> Aggregazioni e analisi di proprietà associativa</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Metodologie:</strong> Processi e know-how sviluppati</span>
                  </li>
                </ul>
              </div>

              {/* Diritti dei Soci */}
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h3 className="font-bold text-blue-800 mb-3">👥 Diritti dei Soci</h3>
                <ul className="text-sm space-y-2 text-blue-700">
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600">•</span>
                    <span><strong>Licenza d'uso:</strong> Diritto non esclusivo di utilizzo durante l'associazione</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600">•</span>
                    <span><strong>Dati propri:</strong> Mantenimento proprietà sui propri dati commerciali</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600">•</span>
                    <span><strong>Contributi:</strong> Idee e suggerimenti diventano patrimonio comune</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600">•</span>
                    <span><strong>Uscita:</strong> Cessazione diritti d'uso alla fine dell'associazione</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Utilizzo del Marchio */}
            <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
              <h3 className="font-bold text-purple-800 mb-3">🏷️ Utilizzo del Marchio FreeStay Alliance</h3>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-purple-800 mb-2">✅ Usi Consentiti:</h4>
                  <ul className="text-sm space-y-1 text-purple-700">
                    <li>• Indicazione della propria qualità di socio</li>
                    <li>• Partecipazione a eventi e materiali associativi</li>
                    <li>• Condivisione di contenuti ufficiali dell'associazione</li>
                    <li>• Utilizzo in contesti di networking professionale</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-purple-800 mb-2">❌ Usi Vietati:</h4>
                  <ul className="text-sm space-y-1 text-purple-700">
                    <li>• Utilizzo per scopi commerciali diretti</li>
                    <li>• Modifica o alterazione del marchio</li>
                    <li>• Registrazione di domini contenenti il marchio</li>
                    <li>• Uso in contesti che possano danneggiare l'immagine</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Open Source e Trasparenza */}
            <div className="bg-gray-50 p-4 rounded-lg border">
              <h3 className="font-bold text-gray-800 mb-3">🌐 Politica Open Source e Trasparenza</h3>
              <p className="text-gray-700 text-sm leading-relaxed mb-3">
                In linea con i valori di trasparenza dell'associazione, ci impegniamo a:
              </p>
              <ul className="text-sm space-y-1 text-gray-700">
                <li>• <strong>Codice aperto:</strong> Rendere pubblico il codice della piattaforma quando maturo</li>
                <li>• <strong>Standard aperti:</strong> Utilizzare protocolli e formati non proprietari</li>
                <li>• <strong>Interoperabilità:</strong> Garantire portabilità dei dati dei soci</li>
                <li>• <strong>Community driven:</strong> Permettere contributi esterni allo sviluppo</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Risoluzione Controversie */}
      <section className="py-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              ⚖️ Risoluzione delle Controversie
            </CardTitle>
            <CardDescription>
              Procedure per la gestione di conflitti e dispute
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">

            {/* Procedura Graduale */}
            <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
              <h3 className="font-bold text-blue-800 mb-4">🔄 Procedura Graduale di Risoluzione</h3>

              <div className="grid md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-lg text-blue-600">1️⃣</span>
                  </div>
                  <h4 className="font-semibold text-blue-800 text-sm mb-1">Dialogo Diretto</h4>
                  <p className="text-xs text-blue-700">Comunicazione diretta tra le parti interessate</p>
                </div>

                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-lg text-blue-600">2️⃣</span>
                  </div>
                  <h4 className="font-semibold text-blue-800 text-sm mb-1">Mediazione Interna</h4>
                  <p className="text-xs text-blue-700">Intervento del Consiglio Direttivo</p>
                </div>

                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-lg text-blue-600">3️⃣</span>
                  </div>
                  <h4 className="font-semibold text-blue-800 text-sm mb-1">Mediazione Esterna</h4>
                  <p className="text-xs text-blue-700">Organismo di mediazione civile</p>
                </div>

                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-lg text-blue-600">4️⃣</span>
                  </div>
                  <h4 className="font-semibold text-blue-800 text-sm mb-1">Giudizio Ordinario</h4>
                  <p className="text-xs text-blue-700">Tribunale competente</p>
                </div>
              </div>
            </div>

            {/* Competenza e Giurisdizione */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <h3 className="font-bold text-green-800 mb-3">🏛️ Competenza e Giurisdizione</h3>
                <ul className="text-sm space-y-2 text-green-700">
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Foro competente:</strong> Tribunale di Bolzano per tutte le controversie</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Legge applicabile:</strong> Diritto italiano, Codice del Terzo Settore</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Lingua:</strong> Tutti i procedimenti si svolgono in italiano</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Deroga:</strong> Possibile solo con accordo scritto delle parti</span>
                  </li>
                </ul>
              </div>

              <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                <h3 className="font-bold text-orange-800 mb-3">🤝 Mediazione Obbligatoria</h3>
                <ul className="text-sm space-y-2 text-orange-700">
                  <li className="flex items-start gap-2">
                    <span className="text-orange-600">•</span>
                    <span><strong>Controversie patrimoniali:</strong> Mediazione obbligatoria ex D.Lgs. 28/2010</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-orange-600">•</span>
                    <span><strong>Organismo:</strong> Da scegliere di comune accordo o dal Presidente del Tribunale</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-orange-600">•</span>
                    <span><strong>Durata:</strong> Massimo 4 mesi dalla presentazione dell'istanza</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-orange-600">•</span>
                    <span><strong>Costi:</strong> Ripartiti secondo criteri stabiliti dall'organismo</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Casi Specifici */}
            <div className="bg-gray-50 p-4 rounded-lg border">
              <h3 className="font-bold text-gray-800 mb-3">⚡ Procedure per Casi Specifici</h3>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">💰 Controversie Economiche</h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• Rimborsi quote associative</li>
                    <li>• Addebiti non autorizzati</li>
                    <li>• Compensi per contributi</li>
                    <li>• Danni economici diretti</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">👥 Controversie Associative</h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• Validità delle votazioni</li>
                    <li>• Esclusioni e sanzioni</li>
                    <li>• Interpretazione dello statuto</li>
                    <li>• Diritti e doveri dei soci</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">🔒 Controversie Tecniche</h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• Malfunzionamenti della piattaforma</li>
                    <li>• Sicurezza e privacy dei dati</li>
                    <li>• Proprietà intellettuale</li>
                    <li>• Uso improprio dei servizi</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Clausole Finali */}
      <section className="py-8">
        <Card className="border-2 border-gray-200">
          <CardHeader>
            <CardTitle className="text-2xl text-gray-600 flex items-center gap-2">
              📜 Clausole Finali
            </CardTitle>
            <CardDescription>
              Disposizioni conclusive e modalità di aggiornamento
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">

            <div className="grid md:grid-cols-2 gap-6">
              {/* Modifiche */}
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h3 className="font-bold text-blue-800 mb-3">🔄 Modifiche ai Termini</h3>
                <ul className="text-sm space-y-2 text-blue-700">
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600">•</span>
                    <span><strong>Proposta:</strong> Solo dal Consiglio Direttivo o su richiesta di almeno il 20% dei soci</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600">•</span>
                    <span><strong>Approvazione:</strong> Maggioranza qualificata (2/3) dei soci votanti</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600">•</span>
                    <span><strong>Preavviso:</strong> Comunicazione 30 giorni prima dell'entrata in vigore</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600">•</span>
                    <span><strong>Recesso:</strong> Diritto di recesso entro 30 giorni dalle modifiche sostanziali</span>
                  </li>
                </ul>
              </div>

              {/* Nullità Parziale */}
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <h3 className="font-bold text-green-800 mb-3">⚖️ Nullità Parziale</h3>
                <ul className="text-sm space-y-2 text-green-700">
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Principio:</strong> L'invalidità di singole clausole non compromette il contratto</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Sostituzione:</strong> Clausole nulle sostituite con disposizioni lecite equivalenti</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Buona fede:</strong> Interpretazione sempre orientata al principio di buona fede</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600">•</span>
                    <span><strong>Finalità:</strong> Mantenimento dell'equilibrio contrattuale originario</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Comunicazioni */}
            <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
              <h3 className="font-bold text-purple-800 mb-3">📬 Comunicazioni Ufficiali</h3>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <h4 className="font-semibold text-purple-800 mb-2">📧 Via Email</h4>
                  <ul className="text-sm space-y-1 text-purple-700">
                    <li>• <strong>Associazione:</strong> info@freestayalliance.org</li>
                    <li>• <strong>Legale:</strong> legal@freestayalliance.org</li>
                    <li>• <strong>Effetto:</strong> Dal giorno di invio</li>
                    <li>• <strong>Conferma:</strong> Ricevuta di ritorno</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-purple-800 mb-2">📮 Posta Raccomandata</h4>
                  <ul className="text-sm space-y-1 text-purple-700">
                    <li>• <strong>Indirizzo:</strong> Via Aldo Moro 20, Salorno (BZ)</li>
                    <li>• <strong>Effetto:</strong> Dal giorno di consegna</li>
                    <li>• <strong>Mancata consegna:</strong> Dopo 10 giorni dal deposito</li>
                    <li>• <strong>Uso:</strong> Per comunicazioni formali</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-purple-800 mb-2">🔔 Notifiche In-App</h4>
                  <ul className="text-sm space-y-1 text-purple-700">
                    <li>• <strong>Avvisi:</strong> Comunicazioni di servizio</li>
                    <li>• <strong>Urgenti:</strong> Problemi tecnici o sicurezza</li>
                    <li>• <strong>Backup:</strong> Sempre supportate da email</li>
                    <li>• <strong>Conferma:</strong> Visualizzazione tracciata</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Entrata in Vigore */}
            <div className="bg-gray-50 p-4 rounded-lg border">
              <h3 className="font-bold text-gray-800 mb-3">📅 Entrata in Vigore e Transitorio</h3>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">✅ Nuovi Soci:</h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• I presenti termini si applicano integralmente</li>
                    <li>• Accettazione obbligatoria al momento dell'iscrizione</li>
                    <li>• Nessun diritto acquisito su versioni precedenti</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">🔄 Soci Esistenti:</h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• Periodo di adeguamento di 60 giorni</li>
                    <li>• Mantenimento diritti acquisiti legittimamente</li>
                    <li>• Possibilità di recesso senza penalità</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-green-600 text-white rounded-lg">
        <div className="text-center space-y-6">
          <h2 className="text-3xl font-bold">⚖️ Termini Chiari per una Partnership Solida</h2>
          <p className="text-xl max-w-3xl mx-auto">
            Questi termini garantiscono trasparenza e protezione per tutti i soci del FreeStay Alliance.
            Insieme costruiamo un futuro migliore per il settore turistico italiano.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild className="bg-white text-blue-600 hover:bg-gray-100" size="lg">
              <Link href="/associati">
                🤝 Diventa Socio Ora
              </Link>
            </Button>

            <Button asChild variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600" size="lg">
              <Link href="/privacy">
                🔒 Leggi Privacy Policy
              </Link>
            </Button>
          </div>

          <div className="pt-4">
            <p className="text-sm opacity-90">
              📞 Domande? Contattaci: <strong>legal@freestayalliance.org</strong>
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
