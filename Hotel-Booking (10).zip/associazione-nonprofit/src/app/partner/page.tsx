"use client"

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import Link from "next/link";
import { useState, useEffect } from "react";
import PartnerService, { type PartnerTransaction } from '@/services/PartnerService';
import { useToast } from "@/hooks/use-toast";
import ReferralService from "@/services/ReferralService";

export default function Partner() {
  const { toast } = useToast();
  // Stati per controllo admin
  const [isAdmin, setIsAdmin] = useState(false);

  const [formData, setFormData] = useState({
    nomeAzienda: "",
    nomeContatto: "",
    email: "",
    telefono: "",
    sito: "",
    settore: "",
    tipoPartnership: "",
    messaggio: "",
    codiceInvito: ""
  });

  // Stati per transazioni partner
  const [partnerTransactions, setPartnerTransactions] = useState<PartnerTransaction[]>([]);
  const [selectedPartners, setSelectedPartners] = useState<string[]>([]);
  const [uploadingLogo, setUploadingLogo] = useState<string | null>(null);

  // Stati per form aggiunta partner personalizzato
  const [showAddPartnerForm, setShowAddPartnerForm] = useState(false);
  const [newPartnerData, setNewPartnerData] = useState({
    nome: '',
    descrizione: '',
    importo: '',
    regione: '',
    logo: '',
    website: '',
    codiceInvito: ''
  });

  useEffect(() => {
    loadPartnerTransactions();
    checkAdminStatus();
  }, []);

  const checkAdminStatus = () => {
    if (typeof window !== 'undefined') {
      try {
        const adminUser = localStorage.getItem('adminUser');
        if (adminUser) {
          const user = JSON.parse(adminUser);
          setIsAdmin(user?.role === 'admin');
        }
      } catch (error) {
        setIsAdmin(false);
      }
    }
  };

  const loadPartnerTransactions = () => {
    const transactions = PartnerService.getPartnerTransactions();
    const selected = PartnerService.getSelectedPartners();
    const selectedNames = selected.map(p => p.nome);

    // Sincronizza il campo selected in ogni transazione
    const transactionsWithSelection = transactions.map(transaction => ({
      ...transaction,
      selected: selectedNames.includes(transaction.nome)
    }));

    console.log('🔄 Loading transactions with selection sync:', {
      totalTransactions: transactions.length,
      selectedPartners: selectedNames,
      transactionsWithSelection: transactionsWithSelection
    });

    setPartnerTransactions(transactionsWithSelection);
    setSelectedPartners(selectedNames);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Richiesta inviata! Ti contatteremo entro 48 ore.");
  };

  const handlePartnerToggle = (transaction: PartnerTransaction) => {
    const wasSelected = PartnerService.togglePartnerSelection(transaction);

    if (wasSelected) {
      toast({
        title: "🎯 Partner aggiunto al banner!",
        description: `${transaction.nome} ora appare nel banner in cima al sito`,
        duration: 4000,
      });
    } else {
      toast({
        title: "👋 Partner rimosso dal banner",
        description: `${transaction.nome} non appare più nel banner`,
        duration: 3000,
      });
    }

    loadPartnerTransactions();
  };

  const handleLogoUpload = async (partnerName: string, file: File) => {
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Errore",
        description: "Seleziona un file immagine valido",
        variant: "destructive"
      });
      return;
    }

    if (file.size > 5 * 1024 * 1024) { // 5MB limite
      toast({
        title: "Errore",
        description: "Il file è troppo grande. Massimo 5MB",
        variant: "destructive"
      });
      return;
    }

    setUploadingLogo(partnerName);

    try {
      await PartnerService.uploadPartnerLogo(partnerName, file);
      toast({
        title: "📸 Logo caricato con successo!",
        description: `Logo di ${partnerName} aggiornato. Vedrai la preview nella tabella.`,
        duration: 4000,
      });
      loadPartnerTransactions();
    } catch (error) {
      toast({
        title: "❌ Errore caricamento",
        description: "Errore nel caricamento del logo. Riprova.",
        variant: "destructive"
      });
    } finally {
      setUploadingLogo(null);
    }
  };

  const handleDeletePartner = (transaction: PartnerTransaction) => {
    const confirmDelete = window.confirm(
      `Sei sicuro di voler cancellare definitivamente il partner "${transaction.nome}"?\n\n` +
      `Questa azione:\n` +
      `• Rimuoverà il partner dalla tabella\n` +
      `• Lo toglierà dal banner se selezionato\n` +
      `• Eliminerà il logo caricato\n\n` +
      `L'azione non può essere annullata.`
    );

    if (confirmDelete) {
      try {
        // Rimuovi dalla selezione se presente
        PartnerService.removePartner(transaction.nome);

        // Rimuovi dalla lista delle transazioni
        const success = PartnerService.deletePartnerTransaction(transaction.id);

        if (success) {
          toast({
            title: "🗑️ Partner cancellato",
            description: `${transaction.nome} è stato rimosso definitivamente dal sistema.`,
            duration: 4000,
          });
          loadPartnerTransactions();
        } else {
          throw new Error('Errore nella cancellazione');
        }
      } catch (error) {
        toast({
          title: "❌ Errore cancellazione",
          description: "Errore nella cancellazione del partner. Riprova.",
          variant: "destructive"
        });
      }
    }
  };

  // Gestione aggiunta nuovo partner personalizzato
  const handleAddPartner = async () => {
    if (!newPartnerData.nome || !newPartnerData.descrizione || !newPartnerData.importo || !newPartnerData.regione) {
      toast({
        title: "Errore",
        description: "Nome, descrizione, importo e regione sono obbligatori",
        variant: "destructive"
      });
      return;
    }

    const importo = Number.parseFloat(newPartnerData.importo);
    if (Number.isNaN(importo) || importo <= 0) {
      toast({
        title: "Errore",
        description: "Inserisci un importo valido",
        variant: "destructive"
      });
      return;
    }

    try {
      const success = PartnerService.addCustomPartner({
        nome: newPartnerData.nome,
        descrizione: newPartnerData.descrizione,
        importo: importo,
        regione: newPartnerData.regione,
        logo: newPartnerData.logo,
        website: newPartnerData.website
      });

      if (success) {
        toast({
          title: "🎉 Nuovo partner aggiunto!",
          description: `${newPartnerData.nome} è stato aggiunto con successo. Ora puoi selezionarlo per il banner.`,
          duration: 5000,
        });

        // Reset form
        setNewPartnerData({
          nome: '',
          descrizione: '',
          importo: '',
          regione: '',
          logo: '',
          website: '',
          codiceInvito: ''
        });
        setShowAddPartnerForm(false);
        loadPartnerTransactions();

        // Scorri alla tabella per mostrare il nuovo partner
        setTimeout(() => {
          const table = document.querySelector('table');
          if (table) {
            table.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          }
        }, 500);
      } else {
        throw new Error('Errore nel salvataggio');
      }
    } catch (error) {
      toast({
        title: "Errore",
        description: "Errore nell'aggiunta del partner",
        variant: "destructive"
      });
    }
  };

  const handleNewPartnerLogoUpload = (file: File) => {
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Errore",
        description: "Seleziona un file immagine valido",
        variant: "destructive"
      });
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Errore",
        description: "Il file è troppo grande. Massimo 5MB",
        variant: "destructive"
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        setNewPartnerData(prev => ({
          ...prev,
          logo: e.target?.result as string
        }));
      }
    };
    reader.readAsDataURL(file);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR'
    }).format(amount);
  };

  // Partner attuali di esempio
  const partnerAttuali = [
    {
      nome: "TechCorp Italia",
      logo: "🏢",
      settore: "Tecnologia",
      contributo: "Supporto digitalizzazione",
      livello: "Oro",
      dal: "2024"
    },
    {
      nome: "Green Solutions",
      logo: "🌱",
      settore: "Sostenibilità",
      contributo: "Consulenza ambientale",
      livello: "Argento",
      dal: "2024"
    },
    {
      nome: "Studio Legale Rossi",
      logo: "⚖️",
      settore: "Legale",
      contributo: "Consulenza legale",
      livello: "Bronze",
      dal: "2024"
    }
  ];

  return (
    <div className="container px-4 py-8">
      {/* Hero Section */}
      <section className="text-center py-16 space-y-6">
        <Badge variant="secondary" className="mb-4">
          Partnership Aziendali
        </Badge>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
          Cresciamo <span className="text-blue-600">Insieme</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
          Unisciti alle aziende che supportano la nostra missione di trasparenza
          e partecipazione democratica. Diventa nostro partner strategico.
        </p>
      </section>

      {/* Vantaggi della Partnership */}
      <section className="py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Perché Diventare Partner</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Una partnership con noi significa visibilità, valori condivisi e crescita sostenibile
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <Card className="text-center border-2 hover:border-blue-200 transition-colors">
            <CardHeader>
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">👁️</span>
              </div>
              <CardTitle>Visibilità Autentica</CardTitle>
              <CardDescription>
                La tua azienda sarà associata a valori di trasparenza e responsabilità sociale
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-gray-600 space-y-2">
                <li>• Logo sul nostro sito web</li>
                <li>• Menzioni nelle newsletter</li>
                <li>• Riconoscimento negli eventi</li>
                <li>• Report di impatto sociale</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="text-center border-2 hover:border-blue-200 transition-colors">
            <CardHeader>
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">🤝</span>
              </div>
              <CardTitle>Rete di Valore</CardTitle>
              <CardDescription>
                Entra in contatto con altri partner e la nostra comunità di soci attivi
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-gray-600 space-y-2">
                <li>• Networking con altri partner</li>
                <li>• Accesso agli eventi esclusivi</li>
                <li>• Collaborazioni strategiche</li>
                <li>• Opportunità di co-marketing</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="text-center border-2 hover:border-blue-200 transition-colors">
            <CardHeader>
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">📈</span>
              </div>
              <CardTitle>Impatto Misurabile</CardTitle>
              <CardDescription>
                Ricevi report dettagliati sull'impatto del tuo contributo alla comunità
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-gray-600 space-y-2">
                <li>• Report trimestrali</li>
                <li>• Metriche di impatto sociale</li>
                <li>• Trasparenza totale sui fondi</li>
                <li>• Certificazioni di sostenibilità</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Livelli di Partnership */}
      <section className="py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Livelli di Partnership</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Scegli il livello di collaborazione più adatto alle tue esigenze
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Bronze */}
          <Card className="relative">
            <CardHeader>
              <Badge className="w-fit bg-orange-600">Bronze</Badge>
              <CardTitle className="text-2xl">€500/anno</CardTitle>
              <CardDescription>
                Perfetto per piccole aziende che vogliono iniziare
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✓</span>
                  Logo sul sito web
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✓</span>
                  Menzione nelle newsletter
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✓</span>
                  Report annuale di impatto
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✓</span>
                  Certificato di partnership
                </li>
              </ul>
              <Button className="w-full" variant="outline">
                Scegli Bronze
              </Button>
            </CardContent>
          </Card>

          {/* Silver */}
          <Card className="relative border-2 border-blue-200 scale-105">
            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
              <Badge className="bg-blue-600">Più Popolare</Badge>
            </div>
            <CardHeader>
              <Badge className="w-fit bg-gray-500">Argento</Badge>
              <CardTitle className="text-2xl">€1,500/anno</CardTitle>
              <CardDescription>
                Ideale per aziende in crescita
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✓</span>
                  Tutto del piano Bronze
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✓</span>
                  Logo in homepage
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✓</span>
                  Inviti agli eventi
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✓</span>
                  Report trimestrali
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✓</span>
                  Post sui social media
                </li>
              </ul>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                Scegli Argento
              </Button>
            </CardContent>
          </Card>

          {/* Gold */}
          <Card className="relative">
            <CardHeader>
              <Badge className="w-fit bg-yellow-600">Oro</Badge>
              <CardTitle className="text-2xl">€3,000/anno</CardTitle>
              <CardDescription>
                Per aziende che vogliono il massimo impatto
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✓</span>
                  Tutto del piano Argento
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✓</span>
                  Pagina dedicata sul sito
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✓</span>
                  Sponsorship eventi
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✓</span>
                  Consulenza personalizzata
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✓</span>
                  Co-branding opportunità
                </li>
              </ul>
              <Button className="w-full" variant="outline">
                Scegli Oro
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Partner Attuali */}
      <section className="py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">I Nostri Partner</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Aziende che condividono i nostri valori e supportano la nostra missione
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {partnerAttuali.map((partner) => (
            <Card key={partner.nome} className="text-center">
              <CardHeader>
                <div className="text-6xl mb-4">{partner.logo}</div>
                <CardTitle>{partner.nome}</CardTitle>
                <CardDescription>{partner.settore}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Badge
                    className={
                      partner.livello === 'Oro' ? 'bg-yellow-600' :
                      partner.livello === 'Argento' ? 'bg-gray-500' : 'bg-orange-600'
                    }
                  >
                    Partner {partner.livello}
                  </Badge>
                  <p className="text-sm text-gray-600">{partner.contributo}</p>
                  <p className="text-xs text-gray-500">Partner dal {partner.dal}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <div className="grid lg:grid-cols-2 gap-12">
        {/* Form di Contatto */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Diventa Nostro Partner</CardTitle>
              <CardDescription>
                Compila il form per ricevere maggiori informazioni sulla partnership
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nomeAzienda">Nome Azienda *</Label>
                    <Input
                      id="nomeAzienda"
                      value={formData.nomeAzienda}
                      onChange={(e) => setFormData(prev => ({...prev, nomeAzienda: e.target.value}))}
                      placeholder="La tua azienda"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="settore">Settore</Label>
                    <Input
                      id="settore"
                      value={formData.settore}
                      onChange={(e) => setFormData(prev => ({...prev, settore: e.target.value}))}
                      placeholder="es. Tecnologia"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nomeContatto">Nome Contatto *</Label>
                    <Input
                      id="nomeContatto"
                      value={formData.nomeContatto}
                      onChange={(e) => setFormData(prev => ({...prev, nomeContatto: e.target.value}))}
                      placeholder="Il tuo nome"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="telefono">Telefono</Label>
                    <Input
                      id="telefono"
                      type="tel"
                      value={formData.telefono}
                      onChange={(e) => setFormData(prev => ({...prev, telefono: e.target.value}))}
                      placeholder="+39 123 456 7890"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData(prev => ({...prev, email: e.target.value}))}
                      placeholder="email@azienda.com"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sito">Sito Web</Label>
                    <Input
                      id="sito"
                      value={formData.sito}
                      onChange={(e) => setFormData(prev => ({...prev, sito: e.target.value}))}
                      placeholder="www.azienda.com"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tipoPartnership">Tipo di Partnership</Label>
                  <select
                    id="tipoPartnership"
                    value={formData.tipoPartnership}
                    onChange={(e) => setFormData(prev => ({...prev, tipoPartnership: e.target.value}))}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  >
                    <option value="">Seleziona...</option>
                    <option value="bronze">Bronze - €500/anno</option>
                    <option value="argento">Argento - €1,500/anno</option>
                    <option value="oro">Oro - €3,000/anno</option>
                    <option value="personalizzata">Partnership Personalizzata</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="messaggio">Messaggio</Label>
                  <Textarea
                    id="messaggio"
                    value={formData.messaggio}
                    onChange={(e) => setFormData(prev => ({...prev, messaggio: e.target.value}))}
                    placeholder="Raccontaci della tua azienda e dei tuoi obiettivi..."
                    rows={4}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="codiceInvito">Codice Invito</Label>
                  <Input
                    id="codiceInvito"
                    value={formData.codiceInvito}
                    onChange={(e) => setFormData(prev => ({...prev, codiceInvito: e.target.value}))}
                    placeholder="Codice invito"
                  />
                </div>

                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" size="lg">
                  Invia Richiesta di Partnership
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Informazioni Aggiuntive */}
        <div className="space-y-8">
          {/* Processo */}
          <Card>
            <CardHeader>
              <CardTitle>Come Funziona</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-600 font-bold text-sm">1</span>
                </div>
                <div>
                  <h3 className="font-semibold">Richiesta</h3>
                  <p className="text-sm text-gray-600">Compila il form con le informazioni della tua azienda</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-600 font-bold text-sm">2</span>
                </div>
                <div>
                  <h3 className="font-semibold">Valutazione</h3>
                  <p className="text-sm text-gray-600">Analizziamo la compatibilità con i nostri valori</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-600 font-bold text-sm">3</span>
                </div>
                <div>
                  <h3 className="font-semibold">Incontro</h3>
                  <p className="text-sm text-gray-600">Call conoscitiva per definire i dettagli</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-600 font-bold text-sm">4</span>
                </div>
                <div>
                  <h3 className="font-semibold">Avvio</h3>
                  <p className="text-sm text-gray-600">Firma dell'accordo e inizio della partnership</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* FAQ */}
          <Card>
            <CardHeader>
              <CardTitle>Domande Frequenti</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Quanto dura l'accordo?</h4>
                <p className="text-sm text-gray-600">
                  I contratti hanno durata annuale con rinnovo automatico.
                  È possibile disdire con 30 giorni di preavviso.
                </p>
              </div>

              <Separator />

              <div>
                <h4 className="font-semibold mb-2">Posso personalizzare la partnership?</h4>
                <p className="text-sm text-gray-600">
                  Assolutamente! Offriamo soluzioni su misura per aziende
                  con esigenze specifiche.
                </p>
              </div>

              <Separator />

              <div>
                <h4 className="font-semibold mb-2">Come vengono utilizzati i fondi?</h4>
                <p className="text-sm text-gray-600">
                  Tutti i contributi sono tracciabili nella nostra sezione
                  trasparenza. Riceverai report dettagliati.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Sezione Transazioni Partner */}
      <section className="py-16 border-t bg-gray-50">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-4 mb-4">
            <h2 className="text-3xl font-bold">📊 Registro Transazioni Partner</h2>
            {isAdmin ? (
              <Badge className="bg-green-600 text-white">
                👤 Admin Loggato
              </Badge>
            ) : (
              <Badge variant="outline" className="border-orange-400 text-orange-600">
                🔒 Solo Lettura
              </Badge>
            )}
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Tutte le transazioni e contribuzioni dei nostri partner aziendali.
            {isAdmin ? (
              " Seleziona i partner per mostrarli nel banner globale del sito."
            ) : (
              " Accedi come amministratore per gestire il banner partner."
            )}
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>📊 Contribuzioni Partner ({partnerTransactions.length})</span>
              {isAdmin && (
                <Badge variant="outline">
                  {selectedPartners.length} in evidenza
                </Badge>
              )}
            </CardTitle>
            <CardDescription>
              {isAdmin ? (
                "Utilizza i checkbox per selezionare i partner da mostrare nel banner. Carica i loghi aziendali per una migliore visibilità."
              ) : (
                "Tutte le transazioni e contribuzioni dei nostri partner aziendali. Accedi come amministratore per gestire il banner."
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Form Aggiunta Partner - Solo Admin */}
            {isAdmin && (
              <div className="mb-6 p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-blue-900">
                    ➕ Aggiungi Nuovo Partner
                  </h3>
                  <Button
                    onClick={() => setShowAddPartnerForm(!showAddPartnerForm)}
                    variant="outline"
                    size="sm"
                  >
                    {showAddPartnerForm ? 'Chiudi' : 'Aggiungi Partner'}
                  </Button>
                </div>

                {showAddPartnerForm && (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="newPartnerNome">Nome Partner *</Label>
                      <Input
                        id="newPartnerNome"
                        value={newPartnerData.nome}
                        onChange={(e) => setNewPartnerData(prev => ({...prev, nome: e.target.value}))}
                        placeholder="es. TechCorp Solutions"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="newPartnerDescrizione">Descrizione *</Label>
                      <Input
                        id="newPartnerDescrizione"
                        value={newPartnerData.descrizione}
                        onChange={(e) => setNewPartnerData(prev => ({...prev, descrizione: e.target.value}))}
                        placeholder="es. Sponsorizzazione evento"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="newPartnerImporto">Importo (€) *</Label>
                      <Input
                        id="newPartnerImporto"
                        type="number"
                        value={newPartnerData.importo}
                        onChange={(e) => setNewPartnerData(prev => ({...prev, importo: e.target.value}))}
                        placeholder="1500"
                        min="0"
                        step="0.01"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="newPartnerRegione">Regione *</Label>
                      <Input
                        id="newPartnerRegione"
                        value={newPartnerData.regione}
                        onChange={(e) => setNewPartnerData(prev => ({...prev, regione: e.target.value}))}
                        placeholder="es. Milano"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="newPartnerWebsite">Sito Web (opzionale)</Label>
                      <Input
                        id="newPartnerWebsite"
                        value={newPartnerData.website}
                        onChange={(e) => setNewPartnerData(prev => ({...prev, website: e.target.value}))}
                        placeholder="es. www.azienda.it"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="newPartnerCodiceInvito">Codice Invito (opzionale)</Label>
                      <Input
                        id="newPartnerCodiceInvito"
                        value={newPartnerData.codiceInvito}
                        onChange={(e) => setNewPartnerData(prev => ({...prev, codiceInvito: e.target.value}))}
                        placeholder="es. FSA-MAR2024-A7X9"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="newPartnerLogo">Logo (opzionale)</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          id="newPartnerLogo"
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              handleNewPartnerLogoUpload(file);
                            }
                          }}
                          className="text-sm"
                        />
                        {newPartnerData.logo && (
                          <div className="w-12 h-8 rounded border-2 border-green-400 overflow-hidden bg-white flex items-center justify-center shadow-sm">
                            {newPartnerData.logo.startsWith('data:') ? (
                              <img
                                src={newPartnerData.logo}
                                alt="Preview logo"
                                className="w-full h-full object-cover"
                                title="✅ Logo caricato - preview"
                              />
                            ) : (
                              <span className="text-sm" title="Logo caricato">{newPartnerData.logo}</span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-end">
                      <Button
                        onClick={handleAddPartner}
                        className="w-full bg-blue-600 hover:bg-blue-700"
                      >
                        ➕ Aggiungi Partner
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    {isAdmin && <TableHead className="w-12">Banner</TableHead>}
                    <TableHead>Data</TableHead>
                    <TableHead>Descrizione</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead className="text-right">Importo</TableHead>
                    <TableHead>Regione</TableHead>
                    <TableHead>Nome Partner</TableHead>
                    <TableHead>Sito Web</TableHead>
                    <TableHead className="w-16">Logo</TableHead>
                    {isAdmin && <TableHead className="w-20">Azioni</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {partnerTransactions.map((transaction) => (
                    <TableRow
                      key={transaction.id}
                      className={transaction.selected && isAdmin ? 'bg-blue-50' : ''}
                    >
                      {/* Checkbox selezione - Solo Admin */}
                      {isAdmin && (
                        <TableCell>
                          <div className="flex flex-col items-center">
                            <div
                              className={`w-10 h-10 rounded-lg transition-all duration-200 cursor-pointer flex items-center justify-center hover:scale-105 ${
                                transaction.selected
                                  ? 'bg-blue-600 border-3 border-blue-800 shadow-lg'
                                  : 'bg-white border-2 border-gray-300 hover:border-blue-400 hover:shadow-md'
                              }`}
                              onClick={() => handlePartnerToggle(transaction)}
                              title={transaction.selected ?
                                `✅ ${transaction.nome} è ATTIVO nel banner - clicca per rimuoverlo` :
                                `➕ Aggiungi ${transaction.nome} al banner globale`
                              }
                              style={{
                                backgroundColor: transaction.selected ? '#2563eb' : '#ffffff',
                                borderColor: transaction.selected ? '#1d4ed8' : '#d1d5db',
                                borderWidth: transaction.selected ? '3px' : '2px',
                                boxShadow: transaction.selected ?
                                  '0 4px 12px rgba(37, 99, 235, 0.3)' :
                                  '0 1px 3px 0 rgba(0, 0, 0, 0.1)',
                              }}
                            >
                              {transaction.selected ? (
                                <span className="text-white font-bold text-lg">✓</span>
                              ) : (
                                <span className="text-gray-400 text-lg hover:text-blue-500 transition-colors">+</span>
                              )}
                            </div>
                            {transaction.selected && (
                              <div className="text-xs text-blue-600 font-bold text-center mt-1 bg-blue-100 px-2 py-1 rounded-full">
                                🎯 ATTIVO
                              </div>
                            )}
                          </div>
                        </TableCell>
                      )}

                      {/* Data */}
                      <TableCell className="text-sm">
                        {new Date(transaction.data).toLocaleDateString('it-IT')}
                      </TableCell>

                      {/* Descrizione */}
                      <TableCell>
                        <div className="max-w-xs">
                          <div className="font-medium text-sm">{transaction.descrizione}</div>
                        </div>
                      </TableCell>

                      {/* Categoria */}
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          {transaction.categoria}
                        </Badge>
                      </TableCell>

                      {/* Tipo */}
                      <TableCell>
                        <Badge
                          className={`text-xs ${
                            transaction.tipo === 'Entrata' ? 'bg-green-600' :
                            transaction.tipo === 'Servizio' ? 'bg-blue-600' : 'bg-gray-600'
                          }`}
                        >
                          {transaction.tipo}
                        </Badge>
                      </TableCell>

                      {/* Importo */}
                      <TableCell className="text-right">
                        <div className="font-bold text-green-600">
                          {formatCurrency(transaction.importo)}
                        </div>
                      </TableCell>

                      {/* Regione */}
                      <TableCell className="text-sm text-gray-600">
                        {transaction.regione}
                      </TableCell>

                      {/* Nome Partner */}
                      <TableCell>
                        <div className="font-medium text-sm">{transaction.nome}</div>
                      </TableCell>

                      {/* Sito Web */}
                      <TableCell>
                        {transaction.website ? (
                          <a
                            href={`https://${transaction.website.replace(/^https?:\/\//, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-800 text-sm underline"
                            title={`Visita il sito di ${transaction.nome}`}
                          >
                            🌐 {transaction.website}
                          </a>
                        ) : (
                          <span className="text-gray-400 text-sm">-</span>
                        )}
                      </TableCell>

                      {/* Logo Partner */}
                      <TableCell>
                        <div className="flex items-center justify-center">
                          <div className="relative">
                            <div className="w-12 h-8 rounded overflow-hidden bg-gray-100 border-2 flex items-center justify-center"
                                 style={{
                                   borderColor: transaction.selected ? '#3b82f6' : '#e5e7eb',
                                   boxShadow: transaction.selected ? '0 0 0 2px rgba(59, 130, 246, 0.2)' : 'none'
                                 }}>
                              {transaction.logo ? (
                                transaction.logo.startsWith('data:') ? (
                                  <img
                                    src={transaction.logo}
                                    alt={transaction.nome}
                                    className="w-full h-full object-cover"
                                    title={`Logo di ${transaction.nome}${transaction.selected ? ' • Nel Banner' : ''}`}
                                  />
                                ) : (
                                  <span className="text-sm" title={`${transaction.nome}${transaction.selected ? ' • Nel Banner' : ''}`}>
                                    {transaction.logo}
                                  </span>
                                )
                              ) : (
                                <span className="text-sm text-gray-400" title="Carica logo">📁</span>
                              )}
                            </div>
                            {transaction.selected && (
                              <div className="absolute -top-1 -right-1 w-4 h-4 bg-blue-600 rounded-full flex items-center justify-center">
                                <span className="text-white text-xs">✓</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </TableCell>

                      {/* Azioni Admin - Solo per Admin */}
                      {isAdmin && (
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0"
                              disabled={uploadingLogo === transaction.nome}
                              onClick={() => {
                                const input = document.createElement('input');
                                input.type = 'file';
                                input.accept = 'image/*';
                                input.onchange = (e) => {
                                  const file = (e.target as HTMLInputElement).files?.[0];
                                  if (file) {
                                    handleLogoUpload(transaction.nome, file);
                                  }
                                };
                                input.click();
                              }}
                              title="Carica logo"
                            >
                              {uploadingLogo === transaction.nome ? '⏳' : '📎'}
                            </Button>

                            {/* Preview logo caricato - PIÙ GRANDE e VISIBILE */}
                            {transaction.logo && (
                              <div className="w-12 h-8 rounded-lg border-2 overflow-hidden bg-white shadow-md relative"
                                   style={{
                                     borderColor: transaction.selected ? '#10b981' : '#e5e7eb',
                                     boxShadow: transaction.selected ? '0 0 0 2px rgba(16, 185, 129, 0.2)' : '0 1px 3px 0 rgba(0, 0, 0, 0.1)'
                                   }}>
                                {transaction.logo.startsWith('data:') ? (
                                  <img
                                    src={transaction.logo}
                                    alt="Preview Logo"
                                    className="w-full h-full object-cover"
                                    title={`✅ Logo di ${transaction.nome} caricato${transaction.selected ? ' • Nel Banner' : ''}`}
                                  />
                                ) : (
                                  <span className="text-sm flex items-center justify-center h-full font-medium"
                                        title={`Logo di ${transaction.nome}${transaction.selected ? ' • Nel Banner' : ''}`}>
                                    {transaction.logo}
                                  </span>
                                )}
                                {/* Indicatore verde se selezionato */}
                                {transaction.selected && (
                                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full flex items-center justify-center">
                                    <span className="text-white text-xs">✓</span>
                                  </div>
                                )}
                              </div>
                            )}

                            {transaction.selected && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 text-blue-600"
                                title="Selezionato per banner"
                              >
                                ✓
                              </Button>
                            )}

                            {/* Pulsante cancellazione partner */}
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-800 hover:bg-red-50"
                              onClick={() => handleDeletePartner(transaction)}
                              title={`Cancella ${transaction.nome} definitivamente`}
                            >
                              🗑️
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {partnerTransactions.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  📭 Nessuna transazione partner trovata
                </div>
              )}
            </div>

            {/* Statistiche rapide */}
            {partnerTransactions.length > 0 && (
              <div className="mt-6 pt-6 border-t">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">
                      {partnerTransactions.length}
                    </div>
                    <div className="text-sm text-blue-800">Transazioni Totali</div>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">
                      {formatCurrency(partnerTransactions.reduce((sum, t) => sum + t.importo, 0))}
                    </div>
                    <div className="text-sm text-green-800">Valore Totale</div>
                  </div>
                  <div className="text-center p-3 bg-purple-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">
                      {selectedPartners.length}
                    </div>
                    <div className="text-sm text-purple-800">In Banner</div>
                  </div>
                  <div className="text-center p-3 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">
                      {new Set(partnerTransactions.map(t => t.nome)).size}
                    </div>
                    <div className="text-sm text-orange-800">Partner Unici</div>
                  </div>
                </div>
              </div>
            )}

            {/* Istruzioni */}
            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">
                {isAdmin ? "💡 Controlli Amministratore:" : "💡 Informazioni:"}
              </h4>
              {isAdmin ? (
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• <strong>Checkbox Banner:</strong> Seleziona i partner da mostrare nel banner globale</li>
                  <li>• <strong>Upload Logo:</strong> Clicca su 📎 per caricare il logo aziendale (max 5MB)</li>
                  <li>• <strong>Banner Globale:</strong> I partner selezionati appaiono in fondo a tutte le pagine</li>
                  <li>• <strong>Gestione:</strong> Usa il banner per rimuovere singoli partner o tutti insieme</li>
                </ul>
              ) : (
                <div className="text-sm text-blue-800 space-y-2">
                  <p>Questa sezione mostra tutte le transazioni e contribuzioni dei nostri partner aziendali.</p>
                  <p><strong>🔒 Accesso Amministratore Required:</strong> Per gestire il banner partner e caricare loghi, è necessario effettuare il login come amministratore.</p>
                  <p>
                    <strong>Come accedere:</strong>
                    <a href="/admin/login" className="underline ml-1 hover:text-blue-600">
                      Vai alla pagina di login admin
                    </a>
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
