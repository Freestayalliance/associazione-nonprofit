export default function AdminUltraSimple() {
  return (
    <html>
      <head>
        <title>Admin Ultra Simple</title>
      </head>
      <body style={{
        margin: 0,
        padding: 0,
        fontFamily: 'Arial, sans-serif',
        backgroundColor: '#e0f2fe'
      }}>
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: '#e0f2fe',
          zIndex: 1000
        }}>
          <div style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            backgroundColor: 'white',
            padding: '50px',
            borderRadius: '10px',
            border: '5px solid #0284c7',
            textAlign: 'center',
            minWidth: '400px'
          }}>
            <h1 style={{
              color: '#0f172a',
              fontSize: '32px',
              marginBottom: '20px'
            }}>
              🔧 DIAGNOSI ADMIN
            </h1>

            <div style={{
              backgroundColor: '#dcfce7',
              padding: '20px',
              borderRadius: '8px',
              border: '2px solid #16a34a',
              marginBottom: '30px'
            }}>
              <h2 style={{
                color: '#166534',
                fontSize: '24px',
                margin: '0 0 10px 0'
              }}>
                ✅ SE VEDI QUESTO, IL ROUTING FUNZIONA!
              </h2>
              <p style={{
                color: '#15803d',
                margin: 0,
                fontSize: '16px'
              }}>
                Questo significa che Next.js e il routing admin funzionano correttamente
              </p>
            </div>

            <div style={{
              backgroundColor: '#fef3c7',
              padding: '20px',
              borderRadius: '8px',
              border: '2px solid #f59e0b',
              marginBottom: '30px'
            }}>
              <h3 style={{
                color: '#92400e',
                fontSize: '18px',
                margin: '0 0 15px 0'
              }}>
                🧪 TEST DI CONTROLLO:
              </h3>
              <p style={{
                color: '#78350f',
                margin: '5px 0',
                fontSize: '14px'
              }}>
                ✅ HTML rendering: FUNZIONA
              </p>
              <p style={{
                color: '#78350f',
                margin: '5px 0',
                fontSize: '14px'
              }}>
                ✅ CSS styling: FUNZIONA
              </p>
              <p style={{
                color: '#78350f',
                margin: '5px 0',
                fontSize: '14px'
              }}>
                ✅ Next.js routing: FUNZIONA
              </p>
              <p style={{
                color: '#dc2626',
                margin: '5px 0',
                fontSize: '14px',
                fontWeight: 'bold'
              }}>
                ❌ Problema: Componenti shadcn/ui o React hooks
              </p>
            </div>

            <div style={{
              display: 'flex',
              gap: '15px',
              justifyContent: 'center',
              flexWrap: 'wrap'
            }}>
              <a
                href="/"
                style={{
                  backgroundColor: '#3b82f6',
                  color: 'white',
                  padding: '12px 24px',
                  textDecoration: 'none',
                  borderRadius: '6px',
                  fontWeight: 'bold',
                  display: 'inline-block'
                }}
              >
                🏠 Homepage
              </a>

              <a
                href="/admin/login"
                style={{
                  backgroundColor: '#dc2626',
                  color: 'white',
                  padding: '12px 24px',
                  textDecoration: 'none',
                  borderRadius: '6px',
                  fontWeight: 'bold',
                  display: 'inline-block'
                }}
              >
                🔴 Test Login Problematico
              </a>
            </div>

            <div style={{
              marginTop: '30px',
              padding: '15px',
              backgroundColor: '#fef2f2',
              borderRadius: '6px',
              border: '1px solid #fca5a5'
            }}>
              <h4 style={{
                color: '#991b1b',
                fontSize: '16px',
                margin: '0 0 10px 0'
              }}>
                🔍 PROSSIMO PASSO:
              </h4>
              <p style={{
                color: '#7f1d1d',
                margin: 0,
                fontSize: '14px'
              }}>
                Se vedi questa pagina ma /admin/login è bianca,
                il problema è nei componenti UI (Card, Button, Input, ecc.)
              </p>
            </div>
          </div>
        </div>
      </body>
    </html>
  );
}
