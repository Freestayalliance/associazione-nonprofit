"use client"

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import ReferralService from "@/services/ReferralService";
import ReferralSocialShare from "@/components/ReferralSocialShare";

export default function ReferralLeaderboard() {
  const { toast } = useToast();

  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [searchCode, setSearchCode] = useState("");
  const [codeStats, setCodeStats] = useState<any>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [badges, setBadges] = useState<any[]>([]);

  useEffect(() => {
    loadLeaderboard();
    loadBadges();
  }, []);

  const loadLeaderboard = () => {
    try {
      const data = ReferralService.getPublicLeaderboard();
      setLeaderboard(data);
      console.log('📊 Leaderboard caricata:', data);
    } catch (error) {
      console.error('Errore caricamento leaderboard:', error);
    }
  };

  const loadBadges = () => {
    try {
      const allBadges = ReferralService.getAllBadges();
      setBadges(allBadges);
    } catch (error) {
      console.error('Errore caricamento badge:', error);
    }
  };

  const handleSearchCode = async () => {
    if (!searchCode.trim()) {
      toast({
        title: "Errore",
        description: "Inserisci un codice referral",
        variant: "destructive"
      });
      return;
    }

    setIsSearching(true);

    try {
      const result = ReferralService.getCodeDetailedStats(searchCode.trim());

      if (result.success && result.data) {
        setCodeStats(result.data);
        toast({
          title: "✅ Codice trovato!",
          description: `Statistiche per ${result.data.userName}`,
          duration: 3000
        });
      } else {
        setCodeStats(null);
        toast({
          title: "❌ Codice non trovato",
          description: result.message,
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Errore ricerca codice:', error);
      toast({
        title: "Errore",
        description: "Errore nella ricerca del codice",
        variant: "destructive"
      });
    } finally {
      setIsSearching(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('it-IT', {
      style: 'currency',
      currency: 'EUR'
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('it-IT');
  };

  const getBadgeColor = (color: string) => {
    const colors: Record<string, string> = {
      gray: 'bg-gray-100 text-gray-800',
      blue: 'bg-blue-100 text-blue-800',
      green: 'bg-green-100 text-green-800',
      orange: 'bg-orange-100 text-orange-800',
      yellow: 'bg-yellow-100 text-yellow-800',
      cyan: 'bg-cyan-100 text-cyan-800',
      purple: 'bg-purple-100 text-purple-800'
    };
    return colors[color] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="container px-4 py-8">
      {/* Hero Section */}
      <section className="text-center py-16 space-y-6">
        <Badge variant="secondary" className="mb-4">
          Leaderboard Referral
        </Badge>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
          🏆 Classifica <span className="text-blue-600">Trasparente</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
          Scopri chi sta contribuendo di più alla crescita del FREE STAY ALLIANCE.
          Tutti i referral sono tracciati in modo trasparente e i riconoscimenti vengono decisi dalla community.
        </p>
      </section>

      {/* Search Section */}
      <section className="py-8">
        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle className="text-center">🔍 Cerca il Tuo Codice</CardTitle>
            <CardDescription className="text-center">
              Inserisci il tuo codice referral per vedere le tue statistiche dettagliate
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4">
              <div className="flex-1">
                <Label htmlFor="searchCode">Codice Referral</Label>
                <Input
                  id="searchCode"
                  value={searchCode}
                  onChange={(e) => setSearchCode(e.target.value.toUpperCase())}
                  placeholder="es. FSA-MAR2024-A7X9"
                  className="font-mono"
                />
              </div>
              <div className="flex items-end">
                <Button
                  onClick={handleSearchCode}
                  disabled={isSearching}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {isSearching ? "🔄 Ricerca..." : "🔍 Cerca"}
                </Button>
              </div>
            </div>

            {/* Risultati ricerca */}
            {codeStats && (
              <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-bold text-blue-900">{codeStats.userName}</h3>
                    <p className="text-sm text-blue-700">Codice: {codeStats.code}</p>
                  </div>
                  <div className="text-right">
                    <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getBadgeColor(codeStats.badge.color)}`}>
                      {codeStats.badge.badge} {codeStats.badge.name}
                    </div>
                    <p className="text-sm text-blue-600 mt-1">#{codeStats.rank} in classifica</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div className="text-center p-3 bg-white rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{codeStats.totalReferrals}</div>
                    <div className="text-xs text-gray-600">Referral Totali</div>
                  </div>
                  <div className="text-center p-3 bg-white rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{codeStats.completedReferrals}</div>
                    <div className="text-xs text-gray-600">Completati</div>
                  </div>
                  <div className="text-center p-3 bg-white rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{codeStats.pendingReferrals}</div>
                    <div className="text-xs text-gray-600">In Attesa</div>
                  </div>
                  <div className="text-center p-3 bg-white rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">{formatCurrency(codeStats.totalValue)}</div>
                    <div className="text-xs text-gray-600">Valore Generato</div>
                  </div>
                </div>

                {/* Progresso verso prossimo badge */}
                {codeStats.nextBadge && (
                  <div className="mt-4">
                    <div className="flex justify-between text-sm mb-2">
                      <span>Progresso verso {codeStats.nextBadge.badge} {codeStats.nextBadge.name}</span>
                      <span>{Math.round(codeStats.progressToNext)}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${codeStats.progressToNext}%` }}
                      ></div>
                    </div>
                    <p className="text-xs text-gray-600 mt-1">
                      {codeStats.nextBadge.minReferrals - codeStats.totalReferrals} referral mancanti
                    </p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </section>

      {/* Social Sharing Section */}
      {codeStats && (
        <section className="py-16 bg-gradient-to-r from-blue-50 to-green-50">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">📤 Condividi il Tuo Successo</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Hai un codice referral fantastico! Condividilo sui tuoi canali preferiti per invitare più persone nella community.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <ReferralSocialShare
              referralCode={codeStats.code}
              userName={codeStats.userName}
            />
          </div>
        </section>
      )}

      {/* Badge System */}
      <section className="py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">🏅 Sistema Badge</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Ecco tutti i traguardi che puoi raggiungere invitando nuovi membri nella community
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
          {badges.map((badge, index) => (
            <Card key={index} className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="text-4xl mb-2">{badge.badge}</div>
                <div className={`text-sm font-medium px-2 py-1 rounded-full ${getBadgeColor(badge.color)}`}>
                  {badge.name}
                </div>
                <div className="text-xs text-gray-600 mt-2">{badge.minReferrals}+ referral</div>
                <div className="text-xs text-gray-500 mt-1">{badge.description}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Leaderboard */}
      <section className="py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">🏆 Classifica Generale</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            I soci che hanno contribuito di più alla crescita della community
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>📊 Top Contributors ({leaderboard.length})</span>
              <Badge variant="outline">Aggiornato in tempo reale</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {leaderboard.length > 0 ? (
              <div className="space-y-3">
                {leaderboard.slice(0, 50).map((entry, index) => (
                  <div
                    key={entry.code}
                    className={`flex items-center justify-between p-4 rounded-lg border transition-colors hover:bg-gray-50 ${
                      index < 3 ? 'bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200' : 'border-gray-200'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg ${
                        index === 0 ? 'bg-yellow-500 text-white' :
                        index === 1 ? 'bg-gray-400 text-white' :
                        index === 2 ? 'bg-orange-600 text-white' :
                        'bg-gray-100 text-gray-700'
                      }`}>
                        {index < 3 ? (index === 0 ? '🥇' : index === 1 ? '🥈' : '🥉') : entry.rank}
                      </div>

                      <div>
                        <div className="font-semibold text-gray-900">{entry.userName}</div>
                        <div className="text-sm text-gray-600">
                          Iscritto il {formatDate(entry.joinedDate)}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">{entry.totalReferrals}</div>
                        <div className="text-xs text-gray-600">Referral</div>
                      </div>

                      <div className="text-center">
                        <div className="text-lg font-bold text-green-600">{entry.completedReferrals}</div>
                        <div className="text-xs text-gray-600">Completati</div>
                      </div>

                      <div className="text-center">
                        <div className="text-lg font-bold text-purple-600">{formatCurrency(entry.totalValue)}</div>
                        <div className="text-xs text-gray-600">Generato</div>
                      </div>

                      <div className={`px-3 py-1 rounded-full text-sm font-medium ${getBadgeColor(entry.badge.color)}`}>
                        {entry.badge.badge} {entry.badge.name}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-gray-500">
                📭 Nessun referral ancora registrato
              </div>
            )}
          </CardContent>
        </Card>
      </section>

      {/* Info Section */}
      <section className="py-16 bg-gray-50 rounded-lg mt-16">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold mb-4">💡 Come Funziona</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">📤</span>
            </div>
            <h3 className="font-semibold mb-2">Invita Nuovi Soci</h3>
            <p className="text-sm text-gray-600">
              Condividi il tuo codice referral con amici e colleghi interessati al progetto
            </p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">📊</span>
            </div>
            <h3 className="font-semibold mb-2">Trackng Trasparente</h3>
            <p className="text-sm text-gray-600">
              Ogni referral viene tracciato pubblicamente e contribuisce alla tua posizione in classifica
            </p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">🏆</span>
            </div>
            <h3 className="font-semibold mb-2">Riconoscimenti Community</h3>
            <p className="text-sm text-gray-600">
              I premi e benefit vengono decisi democraticamente dalla community attraverso votazioni
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
