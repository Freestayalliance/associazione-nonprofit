"use client"

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { FeedbackWidget } from '@/components/FeedbackWidget';

export default function Free4StayPrenotazione() {
  const [searchParams, setSearchParams] = useState({
    destinazione: 'Destinazione selezionata',
    checkin: '',
    checkout: '',
    ospiti: '2'
  });
  const [nights, setNights] = useState(2);

  useEffect(() => {
    // Leggi parametri dall'URL
    const urlParams = new URLSearchParams(window.location.search);
    const params = {
      destinazione: urlParams.get('destinazione') || 'Destinazione selezionata',
      checkin: urlParams.get('checkin') || '',
      checkout: urlParams.get('checkout') || '',
      ospiti: urlParams.get('ospiti') || '2'
    };
    setSearchParams(params);

    // Calcola numero di notti
    if (params.checkin && params.checkout) {
      const checkinDate = new Date(params.checkin);
      const checkoutDate = new Date(params.checkout);
      const timeDiff = checkoutDate.getTime() - checkinDate.getTime();
      const calculatedNights = Math.ceil(timeDiff / (1000 * 3600 * 24));
      setNights(calculatedNights > 0 ? calculatedNights : 2);
    }
  }, []);

  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('it-IT', {
      day: 'numeric',
      month: 'long'
    });
  };

  const calculateTotalPrice = (pricePerNight: number) => {
    return (pricePerNight * nights).toLocaleString('it-IT');
  };

  const createBookingUrl = (hotel: { name: string; room: string; pricePerNight: number }) => {
    const params = new URLSearchParams({
      destinazione: searchParams.destinazione,
      checkin: searchParams.checkin,
      checkout: searchParams.checkout,
      ospiti: searchParams.ospiti,
      hotel: hotel.name,
      room: hotel.room,
      price: hotel.pricePerNight.toString()
    });
    return `/demo/free4stay/conferma?${params.toString()}`;
  };

  const hotels = [
    {
      name: "Hotel Falco",
      location: "Dolomiti, Alto Adige",
      description: "Eleganza montana con vista mozzafiato sulle cime dolomitiche",
      pricePerNight: 180,
      room: "Suite panoramica",
      features: ["Spa & Wellness", "Ristorante gourmet", "Escursioni guidate"],
      available: true,
      phone: "+39 347 123 4567",
      owner: "famiglia Oberhofer"
    },
    {
      name: "Hotel Miralago",
      location: "Lago di Garda, Veneto",
      description: "Direttamente sul lago con spiaggia privata e atmosfera romantica",
      pricePerNight: 156,
      room: "Camera vista lago",
      features: ["Spiaggia privata", "Centro benessere", "Noleggio barche"],
      available: true,
      phone: "+39 345 789 0123",
      owner: "Marco e Ilenya"
    },
    {
      name: "Hotel Vetta",
      location: "Gran Sasso, Abruzzo",
      description: "Rifugio moderno in quota per gli amanti della montagna selvaggia",
      pricePerNight: 95,
      room: "Camera montagna",
      features: ["Cucina tipica", "Guide alpine", "Sci di fondo"],
      available: true,
      phone: "+39 348 456 7890",
      owner: "Luigi Montanari"
    },
    {
      name: "Hotel Volo",
      location: "Cinque Terre, Liguria",
      description: "Tra mare e cielo, un nido sospeso tra i terrazzamenti di Monterosso",
      pricePerNight: 220,
      room: "Terrazza vista mare",
      features: ["Terrazza panoramica", "Cucina ligure", "Trekking"],
      available: false, // Al completo
      phone: "+39 342 654 3210",
      owner: "Anna Marittima"
    },
    {
      name: "Hotel Borgo Antico",
      location: "Val d'Orcia, Toscana",
      description: "Dimora storica immersa nei paesaggi UNESCO della Toscana",
      pricePerNight: 165,
      room: "Camera nel borgo",
      features: ["Degustazioni vino", "Cooking class", "Bike tour"],
      available: true,
      phone: "+39 346 987 6543",
      owner: "famiglia Rossi"
    }
  ];

  return (
    <div style={{
      fontFamily: "Arial, sans-serif",
      margin: "20px",
      backgroundColor: "#f9f9f9",
      color: "#333",
      minHeight: "100vh"
    }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        <header style={{ textAlign: "center", marginBottom: "30px" }}>
          <h1 style={{ color: "#1b5e20", fontSize: "2.5em", marginBottom: "10px" }}>
            Hotel Disponibili
          </h1>
          <p style={{ fontSize: "1.2em", color: "#666" }}>
            La prima piattaforma etica di prenotazione, senza commissioni.<br />
            <strong>📅 {searchParams.checkin && searchParams.checkout ?
              `${formatDate(searchParams.checkin)} - ${formatDate(searchParams.checkout)}` :
              'Date da selezionare'}</strong> •
            <strong>👤 {searchParams.ospiti} {Number.parseInt(searchParams.ospiti) === 1 ? 'ospite' : 'ospiti'}</strong> •
            <strong>🛌 {nights} {nights === 1 ? 'notte' : 'notti'}</strong>
          </p>
        </header>

        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(350px, 1fr))",
          gap: "25px",
          marginBottom: "40px"
        }}>
          {hotels.map((hotel, index) => (
            <div key={index} style={{
              background: "white",
              borderRadius: "12px",
              padding: "25px",
              boxShadow: "0 4px 15px rgba(0,0,0,0.1)",
              border: hotel.available ? "2px solid #e8f5e9" : "2px solid #ffebee",
              position: "relative"
            }}>
              {!hotel.available && (
                <div style={{
                  position: "absolute",
                  top: "15px",
                  right: "15px",
                  background: "#ff5722",
                  color: "white",
                  padding: "5px 10px",
                  borderRadius: "15px",
                  fontSize: "0.8em",
                  fontWeight: "bold"
                }}>
                  AL COMPLETO
                </div>
              )}

              <h2 style={{
                color: "#1b5e20",
                marginBottom: "8px",
                fontSize: "1.4em"
              }}>
                {hotel.name}
              </h2>

              <p style={{
                color: "#666",
                fontSize: "0.9em",
                marginBottom: "12px",
                fontWeight: "bold"
              }}>
                📍 {hotel.location}
              </p>

              <p style={{
                marginBottom: "15px",
                lineHeight: "1.5",
                color: "#555"
              }}>
                {hotel.description}
              </p>

              <div style={{ marginBottom: "15px" }}>
                <p style={{ marginBottom: "8px" }}>
                  <strong>🛌 Camera:</strong> {hotel.room}<br />
                  <strong>💶 Prezzo:</strong> <span style={{ color: "#1b5e20", fontWeight: "bold", fontSize: "1.2em" }}>€{calculateTotalPrice(hotel.pricePerNight)}</span> ({nights} {nights === 1 ? 'notte' : 'notti'})
                </p>
              </div>

              <div style={{ marginBottom: "20px" }}>
                <p style={{ fontWeight: "bold", marginBottom: "8px", color: "#333" }}>
                  ✨ Servizi inclusi:
                </p>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "5px" }}>
                  {hotel.features.map((feature, i) => (
                    <span key={i} style={{
                      background: "#f1f8e9",
                      color: "#2e7d32",
                      padding: "3px 8px",
                      borderRadius: "10px",
                      fontSize: "0.8em",
                      border: "1px solid #c8e6c9"
                    }}>
                      {feature}
                    </span>
                  ))}
                </div>
              </div>

              <div style={{
                background: "#f8f9fa",
                padding: "12px",
                borderRadius: "8px",
                marginBottom: "15px",
                fontSize: "0.9em"
              }}>
                <p style={{ margin: "0", color: "#555" }}>
                  <strong>📞 Contatto diretto:</strong> {hotel.phone}<br />
                  <strong>👨‍💼 Gestito da:</strong> {hotel.owner}
                </p>
              </div>

              {hotel.available ? (
                <Link href={createBookingUrl(hotel)}>
                  <button
                    style={{
                      backgroundColor: "#1b5e20",
                      color: "white",
                      padding: "12px 20px",
                      border: "none",
                      borderRadius: "6px",
                      cursor: "pointer",
                      fontSize: "1em",
                      fontWeight: "bold",
                      width: "100%",
                      transition: "background-color 0.3s"
                    }}
                    onMouseOver={(e) => (e.target as HTMLElement).style.backgroundColor = "#2e7d32"}
                    onMouseOut={(e) => (e.target as HTMLElement).style.backgroundColor = "#1b5e20"}
                  >
                    PRENOTA ORA - ZERO COMMISSIONI
                  </button>
                </Link>
              ) : (
                <Link href="/demo/free4stay/al-completo">
                  <button
                    style={{
                      backgroundColor: "#ff5722",
                      color: "white",
                      padding: "12px 20px",
                      border: "none",
                      borderRadius: "6px",
                      cursor: "pointer",
                      fontSize: "1em",
                      fontWeight: "bold",
                      width: "100%"
                    }}
                  >
                    VEDI CONTATTI DIRETTI
                  </button>
                </Link>
              )}
            </div>
          ))}
        </div>

        <div style={{
          background: "#e8f5e9",
          padding: "25px",
          borderRadius: "12px",
          marginBottom: "30px",
          border: "2px solid #4caf50",
          textAlign: "center"
        }}>
          <h3 style={{ color: "#1b5e20", marginBottom: "15px" }}>
            🙏 GRAZIE. STAI SCEGLIENDO LA LIBERTÀ.
          </h3>
          <p style={{ marginBottom: "10px", lineHeight: "1.6" }}>
            Stai aiutando famiglie a lavorare meglio.<br />
            Stai proteggendo l'ospitalità indipendente.<br />
            Stai dicendo no ai giganti che vogliono controllare il turismo.
          </p>
          <p style={{
            fontStyle: "italic",
            fontWeight: "bold",
            color: "#2e7d32",
            fontSize: "1.1em"
          }}>
            "Ogni notte che prenoti qui è un mattone in più nella libertà di chi ti accoglie."
          </p>
        </div>

        <div style={{ textAlign: "center", marginBottom: "20px" }}>
          <Link href="/demo/free4stay">
            <button
              style={{
                backgroundColor: "#666",
                color: "white",
                padding: "10px 20px",
                border: "none",
                borderRadius: "6px",
                cursor: "pointer",
                fontSize: "0.9em",
                marginRight: "10px"
              }}
            >
              ← Nuova Ricerca
            </button>
          </Link>
          <Link href="/demo">
            <button
              style={{
                backgroundColor: "#999",
                color: "white",
                padding: "10px 20px",
                border: "none",
                borderRadius: "6px",
                cursor: "pointer",
                fontSize: "0.9em"
              }}
            >
              ← Torna alla Demo
            </button>
          </Link>
        </div>

        <footer style={{
          marginTop: "40px",
          fontSize: "0.9em",
          color: "#777",
          textAlign: "center",
          padding: "20px"
        }}>
          <p>
            Powered by <strong>FreeStay Alliance</strong> – Un progetto indipendente per la libertà degli albergatori italiani.
          </p>
        </footer>
      </div>

      {/* Widget Feedback */}
      <FeedbackWidget page="free4stay-hotels" />
    </div>
  );
}
