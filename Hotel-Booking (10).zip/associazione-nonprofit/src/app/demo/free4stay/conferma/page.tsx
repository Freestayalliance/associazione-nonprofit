"use client"

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { FeedbackWidget } from '@/components/FeedbackWidget';

export default function Free4StayConferma() {
  const [bookingDetails, setBookingDetails] = useState({
    destinazione: 'Destinazione selezionata',
    checkin: '',
    checkout: '',
    ospiti: '2',
    nights: 2,
    hotelName: 'Hotel Selezionato',
    roomType: 'Camera standard',
    totalPrice: '156',
    pricePerNight: 156
  });

  useEffect(() => {
    // Leggi parametri dall'URL
    const urlParams = new URLSearchParams(window.location.search);
    const destinazione = urlParams.get('destinazione') || 'Destinazione selezionata';
    const checkin = urlParams.get('checkin') || '';
    const checkout = urlParams.get('checkout') || '';
    const ospiti = urlParams.get('ospiti') || '2';
    const hotelName = urlParams.get('hotel') || 'Hotel Selezionato';
    const roomType = urlParams.get('room') || 'Camera standard';
    const pricePerNight = Number.parseInt(urlParams.get('price') || '156');

    // Calcola numero di notti
    let nights = 2;
    if (checkin && checkout) {
      const checkinDate = new Date(checkin);
      const checkoutDate = new Date(checkout);
      const timeDiff = checkoutDate.getTime() - checkinDate.getTime();
      const calculatedNights = Math.ceil(timeDiff / (1000 * 3600 * 24));
      nights = calculatedNights > 0 ? calculatedNights : 2;
    }

    const totalPrice = (pricePerNight * nights).toLocaleString('it-IT');

    setBookingDetails({
      destinazione,
      checkin,
      checkout,
      ospiti,
      nights,
      hotelName,
      roomType,
      totalPrice,
      pricePerNight
    });
  }, []);

  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('it-IT', {
      day: 'numeric',
      month: 'long'
    });
  };

  return (
    <div style={{
      fontFamily: "Arial, sans-serif",
      margin: "40px",
      backgroundColor: "#f4fef6",
      color: "#2e7d32"
    }}>
      <div style={{
        background: "white",
        padding: "30px",
        borderRadius: "8px",
        boxShadow: "0 0 12px rgba(0,0,0,0.1)",
        maxWidth: "600px",
        margin: "auto"
      }}>
        <h1 style={{ color: "#1b5e20" }}>✅ Prenotazione Confermata!</h1>
        <p>
          Grazie per aver scelto di prenotare con <strong>Free4Stay</strong>.
        </p>
        <p>
          Hai appena supportato la libertà di un albergatore indipendente. Il 100% dell'importo che hai versato andrà direttamente a <strong>{bookingDetails.hotelName}</strong>, senza nessuna commissione.
        </p>

        <h3>📋 Dettagli della prenotazione</h3>
        <p>
          <strong>Hotel:</strong> {bookingDetails.hotelName} – {bookingDetails.destinazione}<br />
          <strong>Date:</strong> {bookingDetails.checkin && bookingDetails.checkout ?
            `${formatDate(bookingDetails.checkin)} – ${formatDate(bookingDetails.checkout)}` :
            'Date da confermare'}<br />
          <strong>Camera:</strong> {bookingDetails.roomType}<br />
          <strong>Ospiti:</strong> {bookingDetails.ospiti} {Number.parseInt(bookingDetails.ospiti) === 1 ? 'ospite' : 'ospiti'}<br />
          <strong>Durata:</strong> {bookingDetails.nights} {bookingDetails.nights === 1 ? 'notte' : 'notti'}<br />
          <strong>Importo:</strong> €{bookingDetails.totalPrice}
        </p>

        <p>Riceverai a breve una email di conferma diretta dall'hotel.</p>

        <p>
          <em>"Ogni notte che prenoti qui è un passo in più verso la libertà del turismo italiano."</em>
        </p>

        <div style={{ display: "flex", gap: "10px", marginTop: "20px", flexWrap: "wrap" }}>
          <Link href="/demo/free4stay/prenotazione">
            <button
              style={{
                backgroundColor: "#1b5e20",
                color: "white",
                padding: "12px 25px",
                textDecoration: "none",
                borderRadius: "4px",
                border: "none",
                cursor: "pointer",
                display: "inline-block"
              }}
            >
              TORNA AGLI HOTEL
            </button>
          </Link>

          <Link href="/demo/free4stay">
            <button
              style={{
                backgroundColor: "#388e3c",
                color: "white",
                padding: "12px 25px",
                textDecoration: "none",
                borderRadius: "4px",
                border: "none",
                cursor: "pointer",
                display: "inline-block"
              }}
            >
              NUOVA RICERCA
            </button>
          </Link>

          <Link href="/demo">
            <button
              style={{
                backgroundColor: "#666",
                color: "white",
                padding: "12px 25px",
                textDecoration: "none",
                borderRadius: "4px",
                border: "none",
                cursor: "pointer",
                display: "inline-block"
              }}
            >
              TORNA ALLA DEMO
            </button>
          </Link>
        </div>
      </div>

      <footer style={{
        marginTop: "50px",
        fontSize: "0.9em",
        textAlign: "center",
        color: "#666"
      }}>
        <p>FreeStay Alliance – Turismo senza commissioni. Turismo con cuore.</p>
      </footer>

      {/* Widget Feedback */}
      <FeedbackWidget page="free4stay-confirmation" />
    </div>
  );
}
