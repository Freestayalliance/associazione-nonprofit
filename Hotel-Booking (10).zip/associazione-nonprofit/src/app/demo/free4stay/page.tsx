"use client"

import Link from 'next/link';
import { useState } from 'react';
import { FeedbackWidget } from '@/components/FeedbackWidget';

export default function Free4StayHomepage() {
  const [destinazione, setDestinazione] = useState('');
  const [checkin, setCheckin] = useState('');
  const [checkout, setCheckout] = useState('');
  const [ospiti, setOspiti] = useState('2');

  const handleSearch = () => {
    // Crea URL con parametri di ricerca
    const searchParams = new URLSearchParams({
      destinazione: destinazione || 'Destinazione selezionata',
      checkin: checkin || '',
      checkout: checkout || '',
      ospiti: ospiti || '2'
    });

    window.location.href = `/demo/free4stay/prenotazione?${searchParams.toString()}`;
  };
  return (
    <div style={{ fontFamily: "'Segoe UI', sans-serif", margin: 0, backgroundColor: "#f3fdf4", color: "#2e7d32" }}>
      <header style={{ backgroundColor: "#1b5e20", color: "white", padding: "30px 50px", textAlign: "center" }}>
        <h1 style={{ margin: 0, fontSize: "2.5em" }}>Free4Stay</h1>
        <p style={{ fontSize: "1.2em", marginTop: "10px" }}>
          La prima piattaforma di prenotazione etica, senza commissioni. Libera. Italiana. Vera.
        </p>
      </header>

      <section style={{ textAlign: "center", padding: "50px 20px", backgroundColor: "#ffffff" }}>
        <div style={{
          display: "inline-block",
          textAlign: "left",
          maxWidth: "600px",
          width: "100%",
          background: "#f1f8e9",
          padding: "30px",
          borderRadius: "10px",
          boxShadow: "0 2px 12px rgba(0,0,0,0.1)"
        }}>
          <form>
            <label style={{ display: "block", margin: "10px 0 5px", color: "#33691e" }} htmlFor="destinazione">
              Dove vuoi andare?
            </label>
            <input
              style={{
                width: "100%",
                padding: "10px",
                border: "1px solid #c5e1a5",
                borderRadius: "5px",
                marginBottom: "15px"
              }}
              type="text"
              id="destinazione"
              name="destinazione"
              placeholder="Es. Val di Non, Dolomiti, Lago di Garda"
              value={destinazione}
              onChange={(e) => setDestinazione(e.target.value)}
            />

            <label style={{ display: "block", margin: "10px 0 5px", color: "#33691e" }} htmlFor="checkin">
              Check-in
            </label>
            <input
              style={{
                width: "100%",
                padding: "10px",
                border: "1px solid #c5e1a5",
                borderRadius: "5px",
                marginBottom: "15px"
              }}
              type="date"
              id="checkin"
              name="checkin"
              value={checkin}
              onChange={(e) => setCheckin(e.target.value)}
            />

            <label style={{ display: "block", margin: "10px 0 5px", color: "#33691e" }} htmlFor="checkout">
              Check-out
            </label>
            <input
              style={{
                width: "100%",
                padding: "10px",
                border: "1px solid #c5e1a5",
                borderRadius: "5px",
                marginBottom: "15px"
              }}
              type="date"
              id="checkout"
              name="checkout"
              value={checkout}
              onChange={(e) => setCheckout(e.target.value)}
            />

            <label style={{ display: "block", margin: "10px 0 5px", color: "#33691e" }} htmlFor="ospiti">
              Ospiti
            </label>
            <input
              style={{
                width: "100%",
                padding: "10px",
                border: "1px solid #c5e1a5",
                borderRadius: "5px",
                marginBottom: "15px"
              }}
              type="number"
              id="ospiti"
              name="ospiti"
              min="1"
              value={ospiti}
              onChange={(e) => setOspiti(e.target.value)}
            />

            <button
              onClick={handleSearch}
              style={{
                backgroundColor: "#388e3c",
                color: "white",
                border: "none",
                padding: "12px 25px",
                borderRadius: "5px",
                cursor: "pointer",
                fontSize: "1em"
              }}
              type="button"
            >
              Cerca hotel
            </button>
          </form>
        </div>
      </section>

      <section style={{ background: "#e8f5e9", padding: "40px 20px", textAlign: "center" }}>
        <h2 style={{ color: "#1b5e20" }}>Perché scegliere Free4Stay?</h2>
        <p style={{ maxWidth: "800px", margin: "10px auto", fontSize: "1.1em" }}>
          ✔️ 100% del pagamento va all'hotel – nessuna commissione<br />
          ✔️ Contatto diretto con i gestori – nessun call center<br />
          ✔️ Progetto italiano, etico, trasparente<br />
          ✔️ Aiuti la libertà del turismo indipendente
        </p>
        <p>
          <em>"Ogni prenotazione è un gesto di libertà."</em>
        </p>
      </section>

      <section style={{ background: "#ffffff", padding: "30px 20px", textAlign: "center", borderTop: "1px solid #e0e0e0" }}>
        <Link href="/demo">
          <button
            style={{
              backgroundColor: "#666",
              color: "white",
              border: "none",
              padding: "12px 25px",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "1em",
              marginRight: "10px"
            }}
          >
            ← Torna alla Demo Principale
          </button>
        </Link>
      </section>

      <footer style={{
        backgroundColor: "#e0e0e0",
        padding: "30px 20px",
        textAlign: "center",
        fontSize: "0.9em",
        color: "#555"
      }}>
        <p>
          © 2025 FreeStay Alliance – Tutti i diritti riservati.<br />
          Unisciti al cambiamento. Difendiamo il turismo italiano.
        </p>
      </footer>

      {/* Widget Feedback */}
      <FeedbackWidget page="free4stay-homepage" />
    </div>
  );
}
