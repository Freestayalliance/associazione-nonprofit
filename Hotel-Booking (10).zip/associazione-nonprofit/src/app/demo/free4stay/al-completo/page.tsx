"use client"

import Link from 'next/link';
import { FeedbackWidget } from '@/components/FeedbackWidget';

export default function Free4StayAlCompleto() {
  return (
    <div style={{
      fontFamily: "Arial, sans-serif",
      margin: "40px",
      backgroundColor: "#fff8f0",
      color: "#d84315",
      minHeight: "100vh",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }}>
      <div style={{
        background: "white",
        padding: "40px",
        borderRadius: "12px",
        boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
        maxWidth: "600px",
        textAlign: "center",
        border: "2px solid #ffcc80"
      }}>
        <h1 style={{
          color: "#e65100",
          fontSize: "2.5em",
          marginBottom: "20px"
        }}>
          😢 Hotel al completo
        </h1>

        <div style={{
          background: "#e8f5e9",
          padding: "20px",
          borderRadius: "8px",
          marginBottom: "30px",
          border: "2px solid #4caf50"
        }}>
          <h3 style={{ color: "#2e7d32", marginBottom: "15px" }}>
            🤝 Contatta direttamente:
          </h3>
          <p style={{ fontSize: "1.2em", margin: "10px 0", color: "#1b5e20" }}>
            <strong>📞 +39 342 654 3210</strong>
          </p>
          <p style={{ margin: "10px 0", color: "#1b5e20" }}>
            <strong>👨‍💼 Proprietario:</strong> Anna Marittima
          </p>
          <p style={{ margin: "10px 0", color: "#1b5e20" }}>
            <strong>📧 Email:</strong> anna.marittima@hotel-volo.it
          </p>
        </div>

        <div style={{
          background: "#fff3e0",
          padding: "20px",
          borderRadius: "8px",
          marginBottom: "30px",
          borderLeft: "5px solid #ff9800"
        }}>
          <p style={{
            fontSize: "1.3em",
            fontStyle: "italic",
            color: "#e65100",
            fontWeight: "bold",
            margin: 0
          }}>
            "Con Free4Stay parli con persone vere. Sempre."
          </p>
        </div>

        <div style={{
          background: "#f3e5f5",
          padding: "25px",
          borderRadius: "10px",
          marginBottom: "30px",
          border: "2px dashed #9c27b0"
        }}>
          <h3 style={{ color: "#7b1fa2", marginBottom: "15px" }}>
            🤔 Guardate la differenza della risposta se "al completo" con altre piattaforme...
          </h3>
          <p style={{ color: "#7b1fa2", fontSize: "1.1em", lineHeight: "1.6" }}>
            <strong>Notate qualche differenza?</strong>
          </p>

          <div style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "20px",
            marginTop: "20px",
            textAlign: "left"
          }}>
            <div style={{
              background: "#ffebee",
              padding: "15px",
              borderRadius: "8px",
              border: "1px solid #ef5350"
            }}>
              <h4 style={{ color: "#c62828", marginBottom: "10px" }}>
                ❌ Altre Piattaforme:
              </h4>
              <ul style={{ color: "#c62828", fontSize: "0.9em", margin: 0, paddingLeft: "20px" }}>
                <li>"Non disponibile"</li>
                <li>Nessun contatto</li>
                <li>Solo algoritmi</li>
                <li>Proposte alternative</li>
              </ul>
            </div>

            <div style={{
              background: "#e8f5e9",
              padding: "15px",
              borderRadius: "8px",
              border: "1px solid #4caf50"
            }}>
              <h4 style={{ color: "#2e7d32", marginBottom: "10px" }}>
                ✅ Free4Stay:
              </h4>
              <ul style={{ color: "#2e7d32", fontSize: "0.9em", margin: 0, paddingLeft: "20px" }}>
                <li>Contatto diretto</li>
                <li>Numero del proprietario</li>
                <li>Persone vere</li>
                <li>Relazione umana</li>
              </ul>
            </div>
          </div>
        </div>

        <div style={{ display: "flex", gap: "15px", justifyContent: "center", flexWrap: "wrap" }}>
          <Link href="/demo/free4stay/prenotazione">
            <button
              style={{
                backgroundColor: "#4caf50",
                color: "white",
                padding: "12px 25px",
                borderRadius: "6px",
                border: "none",
                cursor: "pointer",
                fontSize: "1em",
                fontWeight: "bold"
              }}
            >
              🏨 Torna agli Hotel
            </button>
          </Link>

          <Link href="/demo/free4stay">
            <button
              style={{
                backgroundColor: "#2196f3",
                color: "white",
                padding: "12px 25px",
                borderRadius: "6px",
                border: "none",
                cursor: "pointer",
                fontSize: "1em"
              }}
            >
              🔍 Nuova Ricerca
            </button>
          </Link>

          <Link href="/demo">
            <button
              style={{
                backgroundColor: "#666",
                color: "white",
                padding: "12px 25px",
                borderRadius: "6px",
                border: "none",
                cursor: "pointer",
                fontSize: "1em"
              }}
            >
              ← Torna alla Demo
            </button>
          </Link>
        </div>
      </div>

      {/* Widget Feedback */}
      <FeedbackWidget page="free4stay-full-booked" />
    </div>
  );
}
