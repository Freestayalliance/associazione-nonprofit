import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FeedbackWidget } from "@/components/FeedbackWidget";
import Link from "next/link";

export default function Demo() {
  return (
    <div className="container px-4 py-8">
      {/* Hero Section */}
      <section className="text-center py-16 space-y-6">
        <Badge variant="secondary" className="mb-4">
          Demo & Test
        </Badge>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
          Area <span className="text-green-600">Demo</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
          Esplora il demo completo della piattaforma Free4Stay.
          Perfetto per testare l'esperienza utente senza impegno.
        </p>
      </section>



      {/* Esempi Free4Stay */}
      <section className="mt-12">
        <Card className="border-2 border-green-200">
          <CardHeader>
            <CardTitle className="text-2xl text-green-600 flex items-center gap-2">
              🌍 Esempi di Riferimento - Free4Stay
            </CardTitle>
            <CardDescription>
              Prova il flusso completo di una piattaforma di prenotazione etica
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-green-50 p-4 rounded-lg">
              <h4 className="font-semibold text-green-800 mb-2">🏨 Free4Stay Demo</h4>
              <p className="text-sm text-green-700 mb-3">
                Piattaforma di prenotazione hotel etica, senza commissioni.
                Scegli tra 5 hotel italiani e vivi l'esperienza completa dal contatto diretto alla prenotazione.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="text-green-700 border-green-300">
                  ✔️ Zero commissioni
                </Badge>
                <Badge variant="outline" className="text-green-700 border-green-300">
                  ✔️ Contatto diretto
                </Badge>
                <Badge variant="outline" className="text-green-700 border-green-300">
                  ✔️ Progetto etico
                </Badge>
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Homepage */}
              <Card className="border border-green-200 hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    🏠 Homepage
                  </CardTitle>
                  <CardDescription className="text-sm">
                    Ricerca hotel per destinazione
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Form di ricerca con destinazione, date e ospiti.
                    Messaggio etico e valori aziendali.
                  </p>
                  <Button asChild className="w-full bg-green-600 hover:bg-green-700">
                    <Link href="/demo/free4stay">
                      🔍 Inizia Ricerca
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Prenotazione */}
              <Card className="border border-orange-200 hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    🏨 Prenotazione
                  </CardTitle>
                  <CardDescription className="text-sm">
                    Dettagli hotel e prenotazione
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Scegli tra 5 hotel disponibili: Falco, Miralago, Vetta, Volo e Borgo Antico.
                    Prezzi diversi e contatti diretti per ogni struttura.
                  </p>
                  <Button asChild className="w-full bg-orange-600 hover:bg-orange-700">
                    <Link href="/demo/free4stay/prenotazione">
                      🛌 Vedi Hotel
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Conferma */}
              <Card className="border border-blue-200 hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    ✅ Conferma
                  </CardTitle>
                  <CardDescription className="text-sm">
                    Prenotazione completata
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Conferma prenotazione con dettagli e
                    messaggi motivazionali sulla scelta etica.
                  </p>
                  <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                    <Link href="/demo/free4stay/conferma">
                      📋 Vedi Conferma
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Al Completo */}
              <Card className="border border-red-200 hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    😢 Al Completo
                  </CardTitle>
                  <CardDescription className="text-sm">
                    La differenza con altre piattaforme
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Quando l'hotel è al completo, Free4Stay fornisce
                    contatti diretti invece di un semplice "non disponibile".
                  </p>
                  <Button asChild className="w-full bg-red-600 hover:bg-red-700">
                    <Link href="/demo/free4stay/al-completo">
                      📞 Vedi Contatti
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div className="bg-amber-50 p-4 rounded-lg border-l-4 border-amber-400">
              <h4 className="font-semibold text-amber-800 mb-2">🎯 Obiettivo della Demo</h4>
              <p className="text-sm text-amber-700">
                Questa demo mostra come realizzare un'esperienza utente fluida e coinvolgente
                per una piattaforma con forti valori etici. Scopri 5 hotel diversi (dalle Dolomiti alle Cinque Terre),
                nota i messaggi motivazionali, la trasparenza sui costi e l'enfasi sul supporto agli operatori locali.
              </p>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Note Tecniche */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>📋 Note per il Test</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-2">💾 Persistenza Dati</h4>
              <p className="text-sm text-gray-600">
                Tutti i dati sono salvati in memoria locale. Le modifiche
                che fai rimangono attive fino al refresh della pagina.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">🔄 Reset Demo</h4>
              <p className="text-sm text-gray-600">
                Per resettare tutti i dati demo, semplicemente
                ricarica la pagina (F5 o Ctrl+R).
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">🌐 Funzionalità</h4>
              <p className="text-sm text-gray-600">
                Tutte le funzionalità base sono implementate. I form
                mostrano messaggi di conferma ma non inviano email reali.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">📱 Responsive</h4>
              <p className="text-sm text-gray-600">
                Il sito è ottimizzato per tutti i dispositivi.
                Prova a ridimensionare la finestra o usare il tuo telefono.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Feedback */}
      <Card className="mt-8 bg-green-50 border-green-200">
        <CardHeader>
          <CardTitle className="text-green-800">💬 Feedback e Valutazione</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-green-700 mb-4">
            Dopo aver esplorato il demo, condividi la tua esperienza usando il widget di feedback
            che trovi in basso a destra su ogni pagina!
          </p>
          <div className="grid md:grid-cols-2 gap-4 mb-4">
            <div className="bg-white p-4 rounded-lg border border-green-200">
              <h4 className="font-semibold text-green-800 mb-2">🌟 Cosa Valutare</h4>
              <ul className="text-sm text-green-700 space-y-1">
                <li>• Facilità d'uso e navigazione</li>
                <li>• Qualità dei contenuti</li>
                <li>• Design e interfaccia utente</li>
                <li>• Esperienza complessiva</li>
              </ul>
            </div>
            <div className="bg-white p-4 rounded-lg border border-green-200">
              <h4 className="font-semibold text-green-800 mb-2">📝 Come Aiutarci</h4>
              <ul className="text-sm text-green-700 space-y-1">
                <li>• Condividi cosa ti è piaciuto</li>
                <li>• Suggerisci miglioramenti</li>
                <li>• Indica il tuo profilo professionale</li>
                <li>• Lascia commenti dettagliati</li>
              </ul>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 bg-white rounded-lg border border-green-200">
            <div className="text-2xl">👉</div>
            <p className="text-sm text-green-700">
              <strong>Cerca il bottone "💬 Feedback" in basso a destra</strong> durante la navigazione
              per condividere la tua opinione su ogni sezione del demo!
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Widget Feedback */}
      <FeedbackWidget page="demo-main" />
    </div>
  );
}
