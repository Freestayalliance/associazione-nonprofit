"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useNotifications } from '@/contexts/NotificationContext';
import Link from 'next/link';
import { useState } from 'react';

const getNotificationIcon = (type: string) => {
  switch (type) {
    case 'new_vote': return '🗳️';
    case 'vote_ending': return '⏰';
    case 'vote_result': return '📊';
    case 'system': return '🔧';
    default: return '🔔';
  }
};

const getPriorityBadge = (priority: string) => {
  switch (priority) {
    case 'high':
      return <Badge className="bg-red-500">🔥 Alta</Badge>;
    case 'medium':
      return <Badge className="bg-yellow-500">⚡ Media</Badge>;
    case 'low':
      return <Badge variant="secondary">💭 Bassa</Badge>;
    default:
      return <Badge variant="secondary">Normale</Badge>;
  }
};

const getTypeLabel = (type: string) => {
  switch (type) {
    case 'new_vote': return 'Nuova Votazione';
    case 'vote_ending': return 'Votazione in Scadenza';
    case 'vote_result': return 'Risultato Votazione';
    case 'system': return 'Sistema';
    default: return 'Generale';
  }
};

const formatDateTime = (date: Date) => {
  return new Intl.DateTimeFormat('it-IT', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(date);
};

export default function NotifichePage() {
  const { notifications, unreadCount, markAsRead, markAllAsRead, removeNotification, clearAll } = useNotifications();
  const [filter, setFilter] = useState<'all' | 'unread' | 'read'>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  const filteredNotifications = notifications.filter(notification => {
    const readFilter = filter === 'all' ||
                      (filter === 'unread' && !notification.read) ||
                      (filter === 'read' && notification.read);

    const notificationTypeFilter = typeFilter === 'all' || notification.type === typeFilter;

    return readFilter && notificationTypeFilter;
  });

  const handleNotificationClick = (notification: any) => {
    if (!notification.read) {
      markAsRead(notification.id);
    }
  };

  return (
    <div className="container px-4 py-8">
      {/* Header */}
      <section className="text-center py-16 space-y-6">
        <Badge variant="secondary" className="mb-4">
          Centro Notifiche
        </Badge>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
          Le Tue <span className="text-blue-600">Notifiche</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
          Resta aggiornato su votazioni, risultati e tutte le attività dell'associazione.
        </p>
      </section>

      {/* Statistiche e Azioni */}
      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <Card className="text-center">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Totali</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{notifications.length}</div>
            <p className="text-sm text-gray-600">Notifiche</p>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Non Lette</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600">{unreadCount}</div>
            <p className="text-sm text-gray-600">Da leggere</p>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Votazioni</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">
              {notifications.filter(n => n.type.includes('vote')).length}
            </div>
            <p className="text-sm text-gray-600">Relative ai voti</p>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Alta Priorità</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600">
              {notifications.filter(n => n.priority === 'high').length}
            </div>
            <p className="text-sm text-gray-600">Urgenti</p>
          </CardContent>
        </Card>
      </div>

      {/* Controlli e Filtri */}
      <Card className="mb-8">
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle>Gestisci Notifiche</CardTitle>
              <CardDescription>
                Filtra e gestisci le tue notifiche
              </CardDescription>
            </div>
            <div className="flex gap-2">
              {unreadCount > 0 && (
                <Button variant="outline" onClick={markAllAsRead}>
                  Segna tutte lette ({unreadCount})
                </Button>
              )}
              <Button variant="destructive" onClick={clearAll}>
                Cancella tutte
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            {/* Filtro Stato */}
            <div className="flex gap-2">
              <Button
                variant={filter === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter('all')}
              >
                Tutte ({notifications.length})
              </Button>
              <Button
                variant={filter === 'unread' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter('unread')}
              >
                Non lette ({unreadCount})
              </Button>
              <Button
                variant={filter === 'read' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter('read')}
              >
                Lette ({notifications.length - unreadCount})
              </Button>
            </div>

            {/* Filtro Tipo */}
            <div className="flex gap-2">
              <Button
                variant={typeFilter === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setTypeFilter('all')}
              >
                Tutti i tipi
              </Button>
              <Button
                variant={typeFilter === 'new_vote' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setTypeFilter('new_vote')}
              >
                🗳️ Nuove Votazioni
              </Button>
              <Button
                variant={typeFilter === 'vote_ending' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setTypeFilter('vote_ending')}
              >
                ⏰ Scadenze
              </Button>
              <Button
                variant={typeFilter === 'vote_result' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setTypeFilter('vote_result')}
              >
                📊 Risultati
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista Notifiche */}
      <div className="space-y-4">
        {filteredNotifications.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <span className="text-6xl block mb-4">📭</span>
              <h3 className="text-xl font-semibold mb-2">Nessuna notifica trovata</h3>
              <p className="text-gray-600">
                Non ci sono notifiche che corrispondono ai filtri selezionati.
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredNotifications.map((notification) => (
            <Card
              key={notification.id}
              className={`transition-all hover:shadow-md ${
                !notification.read ? 'border-l-4 border-l-blue-500 bg-blue-50/30' : ''
              }`}
            >
              <CardContent className="p-6">
                <div className="flex items-start justify-between space-x-4">
                  <div className="flex items-start space-x-4 flex-1">
                    <div className="text-3xl">{getNotificationIcon(notification.type)}</div>

                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className={`font-semibold ${!notification.read ? 'text-gray-900' : 'text-gray-700'}`}>
                          {notification.title}
                        </h3>
                        {!notification.read && (
                          <div className="w-2 h-2 bg-blue-600 rounded-full" />
                        )}
                        <Badge variant="outline">{getTypeLabel(notification.type)}</Badge>
                        {getPriorityBadge(notification.priority)}
                      </div>

                      <p className={`${!notification.read ? 'text-gray-800' : 'text-gray-600'}`}>
                        {notification.message}
                      </p>

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-500">
                          {formatDateTime(notification.timestamp)}
                        </span>

                        <div className="flex gap-2">
                          {notification.actionUrl && (
                            <Button
                              variant="outline"
                              size="sm"
                              asChild
                              onClick={() => handleNotificationClick(notification)}
                            >
                              <Link href={notification.actionUrl}>
                                Vai alla pagina
                              </Link>
                            </Button>
                          )}

                          {!notification.read && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => markAsRead(notification.id)}
                            >
                              Segna come letta
                            </Button>
                          )}

                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeNotification(notification.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            Elimina
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Info Sistema Real-time */}
      <Card className="mt-8 bg-green-50 border-green-200">
        <CardContent className="pt-6">
          <div className="flex items-start space-x-3">
            <div className="text-2xl">🔄</div>
            <div>
              <h3 className="font-semibold text-green-800 mb-2">Notifiche Real-Time Attive</h3>
              <p className="text-green-700 text-sm">
                Le notifiche si aggiornano automaticamente ogni 30 secondi.
                Riceverai notifiche immediate per nuove votazioni, scadenze e risultati.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
