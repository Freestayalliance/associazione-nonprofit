import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import Link from "next/link";

export default function PrivacyPolicy() {
  return (
    <div className="container px-4 py-8">
      {/* Hero Section */}
      <section className="text-center py-16 space-y-6">
        <Badge variant="secondary" className="mb-4">
          Privacy Policy
        </Badge>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
          <span className="text-blue-600">Privacy Policy</span> e Trattamento Dati
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
          La nostra informativa completa sui dati personali in conformità al Regolamento GDPR (EU) 2016/679.
          Trasparenza totale su come raccogliamo, utilizziamo e proteggiamo i tuoi dati.
        </p>
      </section>

      {/* Informazioni Generali */}
      <section className="py-8">
        <Card className="border-2 border-blue-200">
          <CardHeader>
            <CardTitle className="text-2xl text-blue-600 flex items-center gap-2">
              🏛️ Titolare del Trattamento
            </CardTitle>
            <CardDescription>
              Informazioni complete sull'associazione e responsabilità del trattamento
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-bold text-blue-800 mb-3">📋 Dati del Titolare</h3>
                <div className="space-y-2 text-blue-700">
                  <p><strong>Denominazione:</strong> FreeStay Alliance</p>
                  <p><strong>Natura giuridica:</strong> Associazione non riconosciuta</p>
                  <p><strong>Sede legale:</strong> Via Aldo Moro 20, 39040 Salorno (BZ), Italia</p>
                  <p><strong>Email:</strong> privacy@freestayalliance.org</p>
                  <p><strong>PEC:</strong> freestayalliance@pec.it</p>
                  <p><strong>Codice Fiscale:</strong> In fase di attribuzione</p>
                </div>
              </div>

              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="font-bold text-green-800 mb-3">👨‍💼 Responsabile Protezione Dati (DPO)</h3>
                <div className="space-y-2 text-green-700">
                  <p><strong>Nome:</strong> Michael Franceschini</p>
                  <p><strong>Qualifica:</strong> Coordinatore Operativo</p>
                  <p><strong>Email DPO:</strong> dpo@freestayalliance.org</p>
                  <p><strong>Telefono:</strong> +39 XXX XXX XXXX</p>
                  <p><strong>Orari:</strong> Lun-Ven 9:00-17:00</p>
                </div>
              </div>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <h3 className="font-bold text-yellow-800 mb-2">⚖️ Base Normativa</h3>
              <p className="text-yellow-700 text-sm">
                Il presente trattamento è effettuato in conformità al <strong>Regolamento UE 2016/679 (GDPR)</strong>,
                al <strong>D.Lgs. 196/2003</strong> (Codice Privacy) così come modificato dal <strong>D.Lgs. 101/2018</strong>,
                e alle disposizioni del <strong>D.Lgs. 117/2017</strong> (Codice del Terzo Settore).
              </p>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Dati Raccolti */}
      <section className="py-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              📊 Dati Personali Raccolti
            </CardTitle>
            <CardDescription>
              Tipologie di dati che raccogliamo e modalità di raccolta
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">

            {/* Dati di Registrazione */}
            <div className="border-l-4 border-blue-500 pl-4">
              <h3 className="text-lg font-bold text-blue-800 mb-3">👤 Dati di Registrazione e Associazione</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Dati Anagrafici:</h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• Nome e cognome</li>
                    <li>• Indirizzo email</li>
                    <li>• Numero di telefono (opzionale)</li>
                    <li>• Data di iscrizione</li>
                    <li>• Motivazione di adesione</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Dati di Fatturazione (se richiesta):</h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• Ragione sociale</li>
                    <li>• Partita IVA</li>
                    <li>• Codice fiscale</li>
                    <li>• Indirizzo completo</li>
                    <li>• Dati bancari (solo per bonifici)</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Dati di Navigazione */}
            <div className="border-l-4 border-green-500 pl-4">
              <h3 className="text-lg font-bold text-green-800 mb-3">🌐 Dati di Navigazione e Tecnici</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Log di Accesso:</h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• Indirizzo IP</li>
                    <li>• Tipo di browser e versione</li>
                    <li>• Sistema operativo</li>
                    <li>• Data e ora di accesso</li>
                    <li>• Pagine visitate</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Cookie e Tracciamento:</h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• Cookie tecnici necessari</li>
                    <li>• Cookie di preferenze</li>
                    <li>• Cookie di sessione</li>
                    <li>• Local storage del browser</li>
                    <li>• Dati di performance (anonimi)</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Dati del Sistema Referral */}
            <div className="border-l-4 border-purple-500 pl-4">
              <h3 className="text-lg font-bold text-purple-800 mb-3">🎯 Dati del Sistema Referral</h3>
              <div className="space-y-2">
                <p className="text-sm text-gray-700 mb-3">
                  Per il funzionamento del sistema di inviti e riconoscimenti della community:
                </p>
                <ul className="text-sm space-y-1 text-gray-700">
                  <li>• Codice referral personale univoco</li>
                  <li>• Cronologia inviti inviati e ricevuti</li>
                  <li>• Statistiche di partecipazione (anonimizzate per la leaderboard pubblica)</li>
                  <li>• Dati di condivisione sui social media (volontaria)</li>
                  <li>• Badge e livelli di riconoscimento raggiunti</li>
                </ul>
              </div>
            </div>

            {/* Dati di Pagamento */}
            <div className="border-l-4 border-orange-500 pl-4">
              <h3 className="text-lg font-bold text-orange-800 mb-3">💳 Dati di Pagamento</h3>
              <div className="bg-orange-50 p-4 rounded-lg">
                <p className="text-sm text-orange-700 mb-2">
                  <strong>⚠️ Importante:</strong> FreeStay Alliance non memorizza mai dati sensibili di pagamento.
                </p>
                <ul className="text-sm space-y-1 text-orange-700">
                  <li>• Importi e date delle transazioni</li>
                  <li>• Metodo di pagamento scelto (senza dettagli sensibili)</li>
                  <li>• Status dei pagamenti</li>
                  <li>• ID transazione per supporto</li>
                  <li>• <strong>I dati delle carte sono gestiti esclusivamente da processori PCI-DSS certificati</strong></li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Finalità del Trattamento */}
      <section className="py-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              🎯 Finalità del Trattamento
            </CardTitle>
            <CardDescription>
              Per quali scopi utilizziamo i tuoi dati personali
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">

            <div className="grid md:grid-cols-2 gap-6">
              {/* Finalità Principali */}
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-blue-800">🏛️ Finalità Associative</h3>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-blue-800 mb-2">1. Gestione Associazione</h4>
                  <p className="text-sm text-blue-700 mb-2"><strong>Base giuridica:</strong> Adempimento contrattuale</p>
                  <ul className="text-sm space-y-1 text-blue-700">
                    <li>• Registrazione e gestione soci</li>
                    <li>• Comunicazioni associative</li>
                    <li>• Organizzazione assemblee e votazioni</li>
                    <li>• Gestione diritti e doveri dei soci</li>
                  </ul>
                </div>

                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-green-800 mb-2">2. Adempimenti Fiscali</h4>
                  <p className="text-sm text-green-700 mb-2"><strong>Base giuridica:</strong> Obbligo legale</p>
                  <ul className="text-sm space-y-1 text-green-700">
                    <li>• Emissione ricevute e fatture</li>
                    <li>• Registrazioni contabili</li>
                    <li>• Dichiarazioni fiscali</li>
                    <li>• Controlli delle autorità competenti</li>
                  </ul>
                </div>

                <div className="bg-purple-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-purple-800 mb-2">3. Sistema Referral</h4>
                  <p className="text-sm text-purple-700 mb-2"><strong>Base giuridica:</strong> Consenso / Interesse legittimo</p>
                  <ul className="text-sm space-y-1 text-purple-700">
                    <li>• Tracciamento inviti e crescita community</li>
                    <li>• Assegnazione badge e riconoscimenti</li>
                    <li>• Statistiche pubbliche (anonime)</li>
                    <li>• Facilitazione social sharing</li>
                  </ul>
                </div>
              </div>

              {/* Finalità Secondarie */}
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-orange-800">📱 Finalità Tecniche</h3>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-800 mb-2">4. Funzionamento Piattaforma</h4>
                  <p className="text-sm text-gray-700 mb-2"><strong>Base giuridica:</strong> Interesse legittimo</p>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• Autenticazione e sicurezza</li>
                    <li>• Personalizzazione esperienza utente</li>
                    <li>• Prevenzione frodi e abusi</li>
                    <li>• Supporto tecnico</li>
                  </ul>
                </div>

                <div className="bg-yellow-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-yellow-800 mb-2">5. Miglioramento Servizi</h4>
                  <p className="text-sm text-yellow-700 mb-2"><strong>Base giuridica:</strong> Interesse legittimo</p>
                  <ul className="text-sm space-y-1 text-yellow-700">
                    <li>• Analisi utilizzo piattaforma (anonime)</li>
                    <li>• Ottimizzazione performance</li>
                    <li>• Sviluppo nuove funzionalità</li>
                    <li>• Ricerca e innovazione</li>
                  </ul>
                </div>

                <div className="bg-teal-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-teal-800 mb-2">6. Comunicazioni Promozionali</h4>
                  <p className="text-sm text-teal-700 mb-2"><strong>Base giuridica:</strong> Consenso specifico</p>
                  <ul className="text-sm space-y-1 text-teal-700">
                    <li>• Newsletter dell'associazione</li>
                    <li>• Aggiornamenti su progetti e iniziative</li>
                    <li>• Inviti a eventi e assemblee</li>
                    <li>• <strong>Solo con tuo consenso esplicito</strong></li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Diritti degli Interessati */}
      <section className="py-8">
        <Card className="border-2 border-green-200">
          <CardHeader>
            <CardTitle className="text-2xl text-green-600 flex items-center gap-2">
              ⚖️ I Tuoi Diritti
            </CardTitle>
            <CardDescription>
              Tutti i diritti che puoi esercitare sui tuoi dati personali secondo il GDPR
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <h4 className="font-bold text-green-800 mb-2">🔍 Diritto di Accesso (Art. 15 GDPR)</h4>
                  <p className="text-sm text-green-700">
                    Puoi richiedere una copia di tutti i dati personali che abbiamo su di te,
                    incluse le finalità del trattamento e i destinatari.
                  </p>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <h4 className="font-bold text-blue-800 mb-2">✏️ Diritto di Rettifica (Art. 16 GDPR)</h4>
                  <p className="text-sm text-blue-700">
                    Puoi chiedere la correzione di dati inesatti o l'integrazione di dati incompleti
                    direttamente dal tuo profilo o contattandoci.
                  </p>
                </div>

                <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                  <h4 className="font-bold text-red-800 mb-2">🗑️ Diritto di Cancellazione (Art. 17 GDPR)</h4>
                  <p className="text-sm text-red-700">
                    Puoi richiedere la cancellazione dei tuoi dati quando non sono più necessari
                    o revochi il consenso (salvo obblighi legali di conservazione).
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                  <h4 className="font-bold text-yellow-800 mb-2">⏸️ Diritto di Limitazione (Art. 18 GDPR)</h4>
                  <p className="text-sm text-yellow-700">
                    Puoi chiedere la limitazione del trattamento in caso di contestazione
                    dell'accuratezza o della liceità del trattamento.
                  </p>
                </div>

                <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                  <h4 className="font-bold text-purple-800 mb-2">📤 Diritto di Portabilità (Art. 20 GDPR)</h4>
                  <p className="text-sm text-purple-700">
                    Puoi richiedere i tuoi dati in formato strutturato e trasferirli a un altro
                    titolare del trattamento (quando tecnicamente possibile).
                  </p>
                </div>

                <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                  <h4 className="font-bold text-orange-800 mb-2">🚫 Diritto di Opposizione (Art. 21 GDPR)</h4>
                  <p className="text-sm text-orange-700">
                    Puoi opporti al trattamento basato su interesse legittimo o per finalità
                    di marketing diretto in qualsiasi momento.
                  </p>
                </div>
              </div>
            </div>

            {/* Come Esercitare i Diritti */}
            <div className="bg-gradient-to-r from-blue-50 to-green-50 p-6 rounded-lg border">
              <h3 className="text-lg font-bold text-blue-800 mb-4">📞 Come Esercitare i Tuoi Diritti</h3>

              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-blue-600 text-xl">📧</span>
                  </div>
                  <h4 className="font-semibold text-blue-800">Email</h4>
                  <p className="text-sm text-blue-700">privacy@freestayalliance.org</p>
                </div>

                <div className="text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-green-600 text-xl">📱</span>
                  </div>
                  <h4 className="font-semibold text-green-800">Area Personale</h4>
                  <p className="text-sm text-green-700">Alcune azioni dal tuo profilo</p>
                </div>

                <div className="text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                    <span className="text-purple-600 text-xl">📄</span>
                  </div>
                  <h4 className="font-semibold text-purple-800">Raccomandata</h4>
                  <p className="text-sm text-purple-700">Via Aldo Moro 20, Salorno (BZ)</p>
                </div>
              </div>

              <div className="mt-4 p-3 bg-yellow-100 rounded border border-yellow-300">
                <p className="text-sm text-yellow-800">
                  <strong>⏱️ Tempi di risposta:</strong> Risponderemo alle tue richieste entro <strong>30 giorni</strong>
                  dalla ricezione. In caso di richieste complesse, il termine può essere esteso a 60 giorni con comunicazione motivata.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Conservazione e Sicurezza */}
      <section className="py-8">
        <div className="grid md:grid-cols-2 gap-8">

          {/* Tempi di Conservazione */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl flex items-center gap-2">
                ⏰ Tempi di Conservazione
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="p-3 bg-blue-50 rounded border border-blue-200">
                  <h4 className="font-semibold text-blue-800">👤 Dati Associativi</h4>
                  <p className="text-sm text-blue-700">
                    <strong>Durante l'associazione + 10 anni</strong><br />
                    Per adempimenti fiscali e normativi del Terzo Settore
                  </p>
                </div>

                <div className="p-3 bg-green-50 rounded border border-green-200">
                  <h4 className="font-semibold text-green-800">💳 Dati di Pagamento</h4>
                  <p className="text-sm text-green-700">
                    <strong>10 anni dalla transazione</strong><br />
                    Per obblighi fiscali e controlli antiriciclaggio
                  </p>
                </div>

                <div className="p-3 bg-purple-50 rounded border border-purple-200">
                  <h4 className="font-semibold text-purple-800">🎯 Dati Referral</h4>
                  <p className="text-sm text-purple-700">
                    <strong>Durante l'associazione + 2 anni</strong><br />
                    Per statistiche e riconoscimenti community
                  </p>
                </div>

                <div className="p-3 bg-gray-50 rounded border border-gray-200">
                  <h4 className="font-semibold text-gray-800">🌐 Log di Navigazione</h4>
                  <p className="text-sm text-gray-700">
                    <strong>12 mesi massimo</strong><br />
                    Per sicurezza e ottimizzazione (anonimi dopo 3 mesi)
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Misure di Sicurezza */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl flex items-center gap-2">
                🔒 Misure di Sicurezza
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="p-3 bg-green-50 rounded border border-green-200">
                  <h4 className="font-semibold text-green-800">🔐 Sicurezza Tecnica</h4>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• Crittografia SSL/TLS per tutte le comunicazioni</li>
                    <li>• Hashing delle password con algoritmi sicuri</li>
                    <li>• Backup crittografati e ridondanti</li>
                    <li>• Monitoraggio 24/7 per attività sospette</li>
                  </ul>
                </div>

                <div className="p-3 bg-blue-50 rounded border border-blue-200">
                  <h4 className="font-semibold text-blue-800">👥 Sicurezza Organizzativa</h4>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>• Accesso limitato al personale autorizzato</li>
                    <li>• Formazione periodica sulla privacy</li>
                    <li>• Procedure di incident response</li>
                    <li>• Audit e verifiche periodiche</li>
                  </ul>
                </div>

                <div className="p-3 bg-yellow-50 rounded border border-yellow-200">
                  <h4 className="font-semibold text-yellow-800">⚠️ Data Breach</h4>
                  <p className="text-sm text-yellow-700">
                    In caso di violazione dei dati, ti informeremo entro <strong>72 ore</strong>
                    se c'è rischio per i tuoi diritti e libertà, con dettagli e misure adottate.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Cookie Policy */}
      <section className="py-8">
        <Card className="border-2 border-orange-200">
          <CardHeader>
            <CardTitle className="text-2xl text-orange-600 flex items-center gap-2">
              🍪 Cookie Policy
            </CardTitle>
            <CardDescription>
              Informazioni sui cookie utilizzati dal nostro sito web
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">

            <div className="grid md:grid-cols-3 gap-6">
              {/* Cookie Tecnici */}
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <h3 className="font-bold text-green-800 mb-3">✅ Cookie Tecnici</h3>
                <p className="text-sm text-green-700 mb-3">
                  <strong>Sempre attivi</strong> - Necessari per il funzionamento del sito
                </p>
                <ul className="text-sm space-y-1 text-green-700">
                  <li>• Sessioni di autenticazione</li>
                  <li>• Preferenze di navigazione</li>
                  <li>• Carrello acquisti</li>
                  <li>• Sicurezza CSRF</li>
                  <li>• Load balancing</li>
                </ul>
              </div>

              {/* Cookie di Preferenze */}
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h3 className="font-bold text-blue-800 mb-3">⚙️ Cookie di Preferenze</h3>
                <p className="text-sm text-blue-700 mb-3">
                  <strong>Con tuo consenso</strong> - Per personalizzare l'esperienza
                </p>
                <ul className="text-sm space-y-1 text-blue-700">
                  <li>• Lingua preferita</li>
                  <li>• Tema chiaro/scuro</li>
                  <li>• Layout preferito</li>
                  <li>• Notifiche abilitate</li>
                  <li>• Impostazioni accessibilità</li>
                </ul>
              </div>

              {/* Cookie di Analytics */}
              <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                <h3 className="font-bold text-purple-800 mb-3">📊 Cookie di Analytics</h3>
                <p className="text-sm text-purple-700 mb-3">
                  <strong>Con tuo consenso</strong> - Per migliorare i servizi
                </p>
                <ul className="text-sm space-y-1 text-purple-700">
                  <li>• Pagine più visitate</li>
                  <li>• Tempo di permanenza</li>
                  <li>• Errori tecnici</li>
                  <li>• Performance del sito</li>
                  <li>• <strong>Dati sempre anonimi</strong></li>
                </ul>
              </div>
            </div>

            {/* Gestione Consensi */}
            <div className="bg-gradient-to-r from-orange-50 to-yellow-50 p-6 rounded-lg border border-orange-200">
              <h3 className="text-lg font-bold text-orange-800 mb-4">🎛️ Gestione dei Consensi</h3>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-orange-800 mb-2">✅ Come Accettare</h4>
                  <ul className="text-sm space-y-1 text-orange-700">
                    <li>• Usa il banner dei cookie alla prima visita</li>
                    <li>• Vai nelle Impostazioni Privacy del tuo profilo</li>
                    <li>• Clicca "Accetta tutti i cookie" per confermare</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-orange-800 mb-2">❌ Come Rifiutare</h4>
                  <ul className="text-sm space-y-1 text-orange-700">
                    <li>• Usa "Rifiuta cookie non necessari" nel banner</li>
                    <li>• Modifica le preferenze in qualsiasi momento</li>
                    <li>• Cancella i cookie dalle impostazioni del browser</li>
                  </ul>
                </div>
              </div>

              <div className="mt-4 p-3 bg-orange-100 rounded border border-orange-300">
                <p className="text-sm text-orange-800">
                  <strong>💡 Ricorda:</strong> Puoi sempre modificare le tue preferenze sui cookie
                  accedendo alla sezione "Privacy e Cookie" del tuo profilo utente.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Trasferimenti Internazionali */}
      <section className="py-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-2">
              🌍 Trasferimenti Internazionali
            </CardTitle>
            <CardDescription>
              Informazioni sui trasferimenti di dati verso paesi terzi
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">

            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <h3 className="font-bold text-blue-800 mb-3">🇪🇺 Trattamento in UE</h3>
              <p className="text-sm text-blue-700">
                I dati personali sono trattati <strong>principalmente all'interno dell'Unione Europea</strong>,
                presso server ubicati in paesi con adeguato livello di protezione secondo la Commissione Europea.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="font-semibold text-gray-800">🔗 Fornitori di Servizi Terzi</h3>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-3 bg-gray-50 rounded border">
                  <h4 className="font-semibold text-gray-800">💳 Processori di Pagamento</h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• <strong>Stripe:</strong> Irlanda (UE) - Adequacy Decision</li>
                    <li>• <strong>PayPal:</strong> Lussemburgo (UE) - Adequacy Decision</li>
                    <li>• Standard Contractual Clauses per servizi USA</li>
                  </ul>
                </div>

                <div className="p-3 bg-gray-50 rounded border">
                  <h4 className="font-semibold text-gray-800">☁️ Servizi Cloud</h4>
                  <ul className="text-sm space-y-1 text-gray-700">
                    <li>• <strong>Hosting:</strong> Server UE con backup in UE</li>
                    <li>• <strong>Email:</strong> Provider europei certificati</li>
                    <li>• Nessun trasferimento verso paesi inadeguati</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <h3 className="font-bold text-yellow-800 mb-2">⚖️ Garanzie Aggiuntive</h3>
              <ul className="text-sm space-y-1 text-yellow-700">
                <li>• Clausole Contrattuali Standard approvate dalla Commissione UE</li>
                <li>• Certificazioni Privacy Shield (dove applicabile)</li>
                <li>• Audit periodici dei fornitori per conformità GDPR</li>
                <li>• Diritto di opposizione a trasferimenti specifici</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Reclami e Contatti */}
      <section className="py-8">
        <div className="grid md:grid-cols-2 gap-8">

          {/* Contatti Privacy */}
          <Card className="border-2 border-green-200">
            <CardHeader>
              <CardTitle className="text-xl text-green-600 flex items-center gap-2">
                📞 Contatti Privacy
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="p-3 bg-green-50 rounded">
                  <h4 className="font-semibold text-green-800">📧 Email Principale</h4>
                  <p className="text-sm text-green-700">privacy@freestayalliance.org</p>
                  <p className="text-xs text-green-600">Risposta entro 48 ore lavorative</p>
                </div>

                <div className="p-3 bg-blue-50 rounded">
                  <h4 className="font-semibold text-blue-800">👨‍💼 Data Protection Officer</h4>
                  <p className="text-sm text-blue-700">dpo@freestayalliance.org</p>
                  <p className="text-xs text-blue-600">Per questioni complesse e legali</p>
                </div>

                <div className="p-3 bg-purple-50 rounded">
                  <h4 className="font-semibold text-purple-800">📮 Posta Tradizionale</h4>
                  <p className="text-sm text-purple-700">
                    FreeStay Alliance - Ufficio Privacy<br />
                    Via Aldo Moro 20<br />
                    39040 Salorno (BZ), Italia
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Reclami e Autorità */}
          <Card className="border-2 border-red-200">
            <CardHeader>
              <CardTitle className="text-xl text-red-600 flex items-center gap-2">
                ⚖️ Reclami e Autorità Garanti
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-red-50 p-4 rounded-lg">
                <h3 className="font-bold text-red-800 mb-3">🇮🇹 Garante per la Protezione dei Dati Personali</h3>
                <div className="text-sm text-red-700 space-y-1">
                  <p><strong>Sito web:</strong> www.gpdp.it</p>
                  <p><strong>Email:</strong> garante@gpdp.it</p>
                  <p><strong>PEC:</strong> protocollo@pec.gpdp.it</p>
                  <p><strong>Telefono:</strong> +39 06 69677.1</p>
                  <p><strong>Indirizzo:</strong> Piazza Venezia 11, 00187 Roma</p>
                </div>
              </div>

              <div className="bg-orange-50 p-4 rounded-lg">
                <h3 className="font-bold text-orange-800 mb-2">📝 Come Presentare Reclamo</h3>
                <ul className="text-sm text-orange-700 space-y-1">
                  <li>• Prova prima a contattarci direttamente</li>
                  <li>• Usa il modulo online sul sito del Garante</li>
                  <li>• Invia una lettera raccomandata</li>
                  <li>• Allega tutta la documentazione rilevante</li>
                </ul>
              </div>

              <div className="bg-blue-50 p-3 rounded">
                <p className="text-sm text-blue-700">
                  <strong>💡 Suggerimento:</strong> Prima di fare reclamo al Garante,
                  contattaci per risolvere la questione in via diretta e amichevole.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Modifiche e Aggiornamenti */}
      <section className="py-8">
        <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200">
          <CardHeader>
            <CardTitle className="text-2xl text-blue-600 flex items-center gap-2">
              🔄 Modifiche e Aggiornamenti
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-bold text-blue-800 mb-3">📅 Versione e Data</h3>
                <div className="bg-white p-4 rounded-lg border">
                  <p className="text-sm"><strong>Versione:</strong> 1.0</p>
                  <p className="text-sm"><strong>Data prima pubblicazione:</strong> 26 giugno 2025</p>
                  <p className="text-sm"><strong>Ultimo aggiornamento:</strong> 26 giugno 2025</p>
                  <p className="text-sm"><strong>Prossima revisione:</strong> 26 dicembre 2025</p>
                </div>
              </div>

              <div>
                <h3 className="font-bold text-purple-800 mb-3">🔔 Notifiche di Modifica</h3>
                <div className="bg-white p-4 rounded-lg border">
                  <ul className="text-sm space-y-2 text-purple-700">
                    <li>• Ti informeremo via email delle modifiche sostanziali</li>
                    <li>• Pubblicheremo avvisi sul sito web</li>
                    <li>• Manterremo lo storico delle versioni precedenti</li>
                    <li>• 30 giorni di preavviso per cambiamenti significativi</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <h3 className="font-bold text-yellow-800 mb-2">⚠️ Importante</h3>
              <p className="text-sm text-yellow-700">
                Continuando a utilizzare i nostri servizi dopo la pubblicazione di modifiche alla Privacy Policy,
                accetti implicitamente le nuove condizioni. Se non sei d'accordo,
                puoi esercitare il diritto di cancellazione contattandoci.
              </p>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-green-600 text-white rounded-lg">
        <div className="text-center space-y-6">
          <h2 className="text-3xl font-bold">🔒 La Tua Privacy è la Nostra Priorità</h2>
          <p className="text-xl max-w-3xl mx-auto">
            Abbiamo costruito FreeStay Alliance con la massima attenzione alla protezione dei dati personali.
            La trasparenza non è solo un valore per la nostra associazione, ma anche per la privacy.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild className="bg-white text-blue-600 hover:bg-gray-100" size="lg">
              <Link href="/associati">
                🤝 Diventa Socio in Sicurezza
              </Link>
            </Button>

            <Button asChild variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600" size="lg">
              <Link href="/contatti">
                📞 Contattaci per Domande
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
