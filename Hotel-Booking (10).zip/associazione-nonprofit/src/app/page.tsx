"use client"

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { useEffect } from "react";

export default function Home() {
  // Genera la notifica per Alessandro Verdi all'avvio
  useEffect(() => {
    const generaNotificaVotazione = () => {
      try {
        const notifiche = JSON.parse(localStorage.getItem('app-notifications') || '[]');

        // Controlla se esiste già la notifica per Alessandro Verdi
        const esisteAlessandro = notifiche.some((n: any) =>
          n.type === 'new_vote' && n.message.includes('Alessandro Verdi')
        );

        if (!esisteAlessandro) {
          const notificaAlessandro = {
            id: `vote-alessandro-${Date.now()}`,
            type: 'new_vote',
            voteId: 1001,
            title: 'Nuova Votazione Disponibile',
            message: 'È aperta la votazione per l\'ammissione di Alessandro Verdi',
            timestamp: new Date().toISOString(),
            read: false,
            priority: 'high',
            actionText: 'Visualizza',
            actionUrl: '/votazioni'
          };

          notifiche.unshift(notificaAlessandro);
          localStorage.setItem('app-notifications', JSON.stringify(notifiche));

          console.log('✅ Notifica per Alessandro Verdi generata');
        }
      } catch (error) {
        console.error('Errore generazione notifica:', error);
      }
    };

    // Genera la notifica dopo 2 secondi dal caricamento della pagina
    const timeout = setTimeout(generaNotificaVotazione, 2000);

    return () => clearTimeout(timeout);
  }, []);

  return (
    <div className="container px-4 py-8">
      {/* Hero Section */}
      <section className="text-center py-16 space-y-6">
        <Badge variant="secondary" className="mb-4">
          Dal 2024 per la comunità
        </Badge>
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
          Trasparenza e <span className="text-blue-600">Partecipazione</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
          Un'alleanza globale dedicata al supporto della comunità attraverso
          la trasparenza finanziaria e la partecipazione democratica di tutti i membri.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center pt-6">
          <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
            <Link href="/associati">
              Diventa Socio - €20/anno
            </Link>
          </Button>
          <Button variant="outline" size="lg" asChild>
            <Link href="/chi-siamo">
              Scopri di più
            </Link>
          </Button>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">La Nostra Mission</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Crediamo in una gestione trasparente e democratica che coinvolga attivamente tutti i membri
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">💰</span>
              </div>
              <CardTitle>Trasparenza Finanziaria</CardTitle>
              <CardDescription>
                Tutte le entrate e uscite sono pubbliche e verificabili da ogni socio
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" asChild className="w-full">
                <Link href="/trasparenza">
                  Vedi i Conti
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🗳️</span>
              </div>
              <CardTitle>Votazioni Democratiche</CardTitle>
              <CardDescription>
                Ogni socio può votare per l'ammissione di nuovi membri e le decisioni importanti
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" asChild className="w-full">
                <Link href="/votazioni">
                  Partecipa
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🤝</span>
              </div>
              <CardTitle>Comunità Attiva</CardTitle>
              <CardDescription>
                Una rete di supporto e collaborazione per tutti i membri della comunità
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" asChild className="w-full">
                <Link href="/blog">
                  Leggi le News
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50 rounded-lg">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">I Nostri Numeri</h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <div className="text-3xl font-bold text-blue-600">150+</div>
            <div className="text-gray-600">Soci Attivi</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-green-600">€12,500</div>
            <div className="text-gray-600">Fondi Raccolti</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-purple-600">25</div>
            <div className="text-gray-600">Progetti Completati</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-orange-600">100%</div>
            <div className="text-gray-600">Trasparenza</div>
          </div>
        </div>
      </section>

      {/* Nuovo Alert per Notifiche */}
      <section className="py-8">
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="py-6">
            <div className="flex items-start space-x-4">
              <div className="text-3xl">🔔</div>
              <div>
                <h3 className="font-semibold text-blue-800 mb-2">Sistema di Notifiche Attivo</h3>
                <div className="text-blue-700 space-y-2">
                  <p>• <strong>Notifiche in tempo reale</strong> per nuove votazioni</p>
                  <p>• <strong>Aggiornamenti automatici</strong> sui risultati</p>
                  <p>• <strong>Clicca sulla campanella</strong> nell'header per vedere le notifiche</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* CTA Section */}
      <section className="py-16 text-center">
        <div className="max-w-2xl mx-auto space-y-6">
          <h2 className="text-3xl font-bold">Unisciti alla Nostra Comunità</h2>
          <p className="text-gray-600">
            Diventando socio contribuirai attivamente alle decisioni dell'associazione
            e avrai accesso completo a tutte le informazioni finanziarie.
          </p>
          <div className="space-y-4">
            <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
              <Link href="/associati">
                Associati Ora - Solo €20/anno
              </Link>
            </Button>
            <p className="text-sm text-gray-500">
              Pagamento sicuro • Accesso immediato • Cancellazione in qualsiasi momento
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
