import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import Link from "next/link";

export default function Progetti() {
  return (
    <div className="container px-4 py-8">
      {/* Hero Section */}
      <section className="text-center py-16 space-y-6">
        <Badge variant="secondary" className="mb-4">
          I Nostri Progetti
        </Badge>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
          Progetti per la <span className="text-blue-600">Comunità</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
          Iniziative concrete che trasformano le idee dei nostri soci in realtà,
          con l'obiettivo di migliorare la vita della nostra comunità.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
          <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
            <Link href="/associati">
              Proponi un Progetto
            </Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link href="/chi-siamo">
              Scopri Chi Siamo
            </Link>
          </Button>
        </div>
      </section>

      {/* Statistiche Progetti */}
      <section className="py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="text-center">
            <CardHeader>
              <CardTitle className="text-3xl font-bold text-blue-600">12</CardTitle>
              <CardDescription>Progetti Completati</CardDescription>
            </CardHeader>
          </Card>
          <Card className="text-center">
            <CardHeader>
              <CardTitle className="text-3xl font-bold text-green-600">€18,500</CardTitle>
              <CardDescription>Investimenti Totali</CardDescription>
            </CardHeader>
          </Card>
          <Card className="text-center">
            <CardHeader>
              <CardTitle className="text-3xl font-bold text-purple-600">850+</CardTitle>
              <CardDescription>Persone Coinvolte</CardDescription>
            </CardHeader>
          </Card>
          <Card className="text-center">
            <CardHeader>
              <CardTitle className="text-3xl font-bold text-orange-600">5</CardTitle>
              <CardDescription>Progetti Attivi</CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>

      {/* Progetti Attivi */}
      <section className="py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">🚀 Progetti Attivi</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            I progetti che stiamo realizzando in questo momento con il supporto dei nostri soci
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Progetto 1 */}
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader>
              <div className="flex justify-between items-start mb-4">
                <Badge className="bg-blue-600">🚀 In Corso</Badge>
                <Badge variant="outline">Budget: €4,200</Badge>
              </div>
              <CardTitle className="text-xl">Digitalizzazione Servizi Locali</CardTitle>
              <CardDescription>
                Creazione di una piattaforma digitale per semplificare l'accesso ai servizi comunali
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Progresso</span>
                    <span>75%</span>
                  </div>
                  <Progress value={75} className="h-2" />
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Inizio:</span> Marzo 2024
                  </div>
                  <div>
                    <span className="font-medium">Fine stimata:</span> Febbraio 2025
                  </div>
                  <div>
                    <span className="font-medium">Team:</span> 8 volontari
                  </div>
                  <div>
                    <span className="font-medium">Beneficiari:</span> 2,500 cittadini
                  </div>
                </div>
                <p className="text-gray-600 text-sm">
                  <strong>Ultimo aggiornamento:</strong> Completata la fase di progettazione UX/UI.
                  Iniziato lo sviluppo del backend con integrazione API comunali.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Progetto 2 */}
          <Card className="border-l-4 border-l-green-500">
            <CardHeader>
              <div className="flex justify-between items-start mb-4">
                <Badge className="bg-green-600">🌱 In Sviluppo</Badge>
                <Badge variant="outline">Budget: €2,800</Badge>
              </div>
              <CardTitle className="text-xl">Supporto Famiglie in Difficoltà</CardTitle>
              <CardDescription>
                Rete di sostegno per famiglie con difficoltà economiche temporanee
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Progresso</span>
                    <span>60%</span>
                  </div>
                  <Progress value={60} className="h-2 bg-green-100" />
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Inizio:</span> Giugno 2024
                  </div>
                  <div>
                    <span className="font-medium">Fine stimata:</span> Marzo 2025
                  </div>
                  <div>
                    <span className="font-medium">Volontari:</span> 12 persone
                  </div>
                  <div>
                    <span className="font-medium">Famiglie aiutate:</span> 23
                  </div>
                </div>
                <p className="text-gray-600 text-sm">
                  <strong>Ultimo aggiornamento:</strong> Creata la rete di volontari.
                  Avviato il primo ciclo di supporto con 15 famiglie della zona.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Progetto 3 */}
          <Card className="border-l-4 border-l-purple-500">
            <CardHeader>
              <div className="flex justify-between items-start mb-4">
                <Badge className="bg-purple-600">📚 Educativo</Badge>
                <Badge variant="outline">Budget: €1,900</Badge>
              </div>
              <CardTitle className="text-xl">Corsi di Alfabetizzazione Digitale</CardTitle>
              <CardDescription>
                Formazione gratuita per anziani e persone con difficoltà tecnologiche
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Progresso</span>
                    <span>85%</span>
                  </div>
                  <Progress value={85} className="h-2 bg-purple-100" />
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Inizio:</span> Agosto 2024
                  </div>
                  <div>
                    <span className="font-medium">Fine stimata:</span> Gennaio 2025
                  </div>
                  <div>
                    <span className="font-medium">Istruttori:</span> 6 volontari
                  </div>
                  <div>
                    <span className="font-medium">Partecipanti:</span> 45 persone
                  </div>
                </div>
                <p className="text-gray-600 text-sm">
                  <strong>Ultimo aggiornamento:</strong> Completati 3 cicli di corsi.
                  Avviato il corso avanzato per smartphone e tablet.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Progetto 4 */}
          <Card className="border-l-4 border-l-orange-500">
            <CardHeader>
              <div className="flex justify-between items-start mb-4">
                <Badge className="bg-orange-600">🌍 Ambientale</Badge>
                <Badge variant="outline">Budget: €3,100</Badge>
              </div>
              <CardTitle className="text-xl">Giardini Comunitari Condivisi</CardTitle>
              <CardDescription>
                Creazione di spazi verdi gestiti dalla comunità per la sostenibilità locale
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Progresso</span>
                    <span>40%</span>
                  </div>
                  <Progress value={40} className="h-2 bg-orange-100" />
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Inizio:</span> Ottobre 2024
                  </div>
                  <div>
                    <span className="font-medium">Fine stimata:</span> Giugno 2025
                  </div>
                  <div>
                    <span className="font-medium">Partecipanti:</span> 35 famiglie
                  </div>
                  <div>
                    <span className="font-medium">Aree coinvolte:</span> 3 quartieri
                  </div>
                </div>
                <p className="text-gray-600 text-sm">
                  <strong>Ultimo aggiornamento:</strong> Ottenute le autorizzazioni comunali.
                  Iniziata la preparazione del terreno nel primo sito.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Progetti Completati */}
      <section className="py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">✅ Progetti Completati</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            I successi che abbiamo raggiunto insieme e l'impatto concreto sulla nostra comunità
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Progetto Completato 1 */}
          <Card>
            <CardHeader>
              <Badge className="bg-green-600 w-fit">✅ Completato</Badge>
              <CardTitle className="text-lg">Wi-Fi Pubblico Gratuito</CardTitle>
              <CardDescription>Installazione di hotspot Wi-Fi in 5 piazze principali</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span>Budget utilizzato:</span>
                  <span className="font-medium">€2,400</span>
                </div>
                <div className="flex justify-between">
                  <span>Durata progetto:</span>
                  <span className="font-medium">4 mesi</span>
                </div>
                <div className="flex justify-between">
                  <span>Utenti giornalieri:</span>
                  <span className="font-medium">150+</span>
                </div>
                <p className="text-gray-600 pt-2">
                  Progetto completato ad Agosto 2024. Connessione stabile e gratuita
                  per cittadini e turisti.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Progetto Completato 2 */}
          <Card>
            <CardHeader>
              <Badge className="bg-green-600 w-fit">✅ Completato</Badge>
              <CardTitle className="text-lg">Banco Alimentare Digitale</CardTitle>
              <CardDescription>App per gestione donazioni e distribuzione cibo</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span>Budget utilizzato:</span>
                  <span className="font-medium">€1,800</span>
                </div>
                <div className="flex justify-between">
                  <span>Durata progetto:</span>
                  <span className="font-medium">3 mesi</span>
                </div>
                <div className="flex justify-between">
                  <span>Famiglie servite:</span>
                  <span className="font-medium">120</span>
                </div>
                <p className="text-gray-600 pt-2">
                  Completato a Settembre 2024. Ridotti gli sprechi del 40%
                  e migliorata l'efficienza delle donazioni.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Progetto Completato 3 */}
          <Card>
            <CardHeader>
              <Badge className="bg-green-600 w-fit">✅ Completato</Badge>
              <CardTitle className="text-lg">Sportello Digitale Anziani</CardTitle>
              <CardDescription>Assistenza personalizzata per servizi online</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span>Budget utilizzato:</span>
                  <span className="font-medium">€1,200</span>
                </div>
                <div className="flex justify-between">
                  <span>Durata progetto:</span>
                  <span className="font-medium">6 mesi</span>
                </div>
                <div className="flex justify-between">
                  <span>Persone assistite:</span>
                  <span className="font-medium">200+</span>
                </div>
                <p className="text-gray-600 pt-2">
                  Completato a Novembre 2024. Oltre il 90% degli utenti
                  ora gestisce autonomamente i servizi digitali.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Come Funziona */}
      <section className="py-16 bg-gray-50 rounded-lg">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">🔄 Come Funziona</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Il processo democratico che trasforma le idee in progetti concreti
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
              <span className="text-2xl font-bold text-blue-600">1</span>
            </div>
            <h3 className="font-semibold">💡 Proposta</h3>
            <p className="text-sm text-gray-600">
              Ogni socio può proporre un progetto attraverso la piattaforma online,
              compilando un form dettagliato con obiettivi e budget stimato.
            </p>
          </div>

          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <span className="text-2xl font-bold text-green-600">2</span>
            </div>
            <h3 className="font-semibold">🗳️ Votazione</h3>
            <p className="text-sm text-gray-600">
              Il progetto viene messo ai voti per 7 giorni. Tutti i soci possono
              esprimere la loro preferenza e lasciare commenti costruttivi.
            </p>
          </div>

          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto">
              <span className="text-2xl font-bold text-purple-600">3</span>
            </div>
            <h3 className="font-semibold">⚖️ Approvazione</h3>
            <p className="text-sm text-gray-600">
              Se il progetto ottiene il 60% di voti favorevoli, viene approvato
              e inizia la fase di pianificazione con il team di coordinamento.
            </p>
          </div>

          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto">
              <span className="text-2xl font-bold text-orange-600">4</span>
            </div>
            <h3 className="font-semibold">🚀 Realizzazione</h3>
            <p className="text-sm text-gray-600">
              Il progetto viene realizzato con aggiornamenti settimanali visibili
              a tutti i soci e un report finale con risultati e impatto.
            </p>
          </div>
        </div>
      </section>

      {/* Categorie Progetti */}
      <section className="py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">📋 Categorie di Progetti</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Le aree di intervento che riteniamo prioritarie per la nostra comunità
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">💻</span>
              </div>
              <CardTitle>Digitalizzazione</CardTitle>
              <CardDescription>Tecnologia al servizio della comunità</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm mb-4">
                Progetti per rendere i servizi pubblici e comunitari più accessibili
                attraverso piattaforme digitali innovative.
              </p>
              <div className="flex justify-between text-sm">
                <span>Progetti completati: <strong>4</strong></span>
                <span>Budget totale: <strong>€8,200</strong></span>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">🤝</span>
              </div>
              <CardTitle>Sostegno Sociale</CardTitle>
              <CardDescription>Aiuto concreto per chi ne ha bisogno</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm mb-4">
                Iniziative di supporto per famiglie in difficoltà, anziani
                e persone in situazioni di fragilità temporanea.
              </p>
              <div className="flex justify-between text-sm">
                <span>Progetti completati: <strong>3</strong></span>
                <span>Budget totale: <strong>€5,400</strong></span>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">📚</span>
              </div>
              <CardTitle>Educazione</CardTitle>
              <CardDescription>Formazione e crescita per tutti</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm mb-4">
                Corsi, workshop e programmi educativi per sviluppare competenze
                digitali, professionali e personali.
              </p>
              <div className="flex justify-between text-sm">
                <span>Progetti completati: <strong>3</strong></span>
                <span>Budget totale: <strong>€3,200</strong></span>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">🌍</span>
              </div>
              <CardTitle>Ambiente</CardTitle>
              <CardDescription>Sostenibilità e tutela del territorio</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm mb-4">
                Progetti per la salvaguardia ambientale, energie rinnovabili
                e promozione di stili di vita sostenibili.
              </p>
              <div className="flex justify-between text-sm">
                <span>Progetti completati: <strong>2</strong></span>
                <span>Budget totale: <strong>€1,700</strong></span>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">🎨</span>
              </div>
              <CardTitle>Cultura</CardTitle>
              <CardDescription>Arte, eventi e tradizioni locali</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm mb-4">
                Iniziative culturali, eventi comunitari e progetti per valorizzare
                le tradizioni e promuovere l'aggregazione sociale.
              </p>
              <div className="flex justify-between text-sm">
                <span>Progetti in corso: <strong>1</strong></span>
                <span>Budget stanziato: <strong>€2,500</strong></span>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-pink-100 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">🏥</span>
              </div>
              <CardTitle>Salute e Benessere</CardTitle>
              <CardDescription>Promozione della salute comunitaria</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm mb-4">
                Programmi di prevenzione, attività sportive e iniziative
                per il benessere fisico e mentale della comunità.
              </p>
              <div className="flex justify-between text-sm">
                <span>Progetti pianificati: <strong>2</strong></span>
                <span>Budget previsto: <strong>€3,800</strong></span>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Impatto e Risultati */}
      <section className="py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">📊 Il Nostro Impatto</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            I numeri che raccontano l'effetto concreto dei nostri progetti sulla comunità
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="text-center border-l-4 border-l-blue-500">
            <CardContent className="pt-6">
              <div className="text-4xl font-bold text-blue-600 mb-2">2,850+</div>
              <div className="text-gray-600">Persone Beneficiarie</div>
              <div className="text-xs text-gray-500 mt-2">Direttamente o indirettamente</div>
            </CardContent>
          </Card>

          <Card className="text-center border-l-4 border-l-green-500">
            <CardContent className="pt-6">
              <div className="text-4xl font-bold text-green-600 mb-2">96%</div>
              <div className="text-gray-600">Progetti Riusciti</div>
              <div className="text-xs text-gray-500 mt-2">Completati nei tempi previsti</div>
            </CardContent>
          </Card>

          <Card className="text-center border-l-4 border-l-purple-500">
            <CardContent className="pt-6">
              <div className="text-4xl font-bold text-purple-600 mb-2">148</div>
              <div className="text-gray-600">Volontari Attivi</div>
              <div className="text-xs text-gray-500 mt-2">Coinvolti nei progetti</div>
            </CardContent>
          </Card>

          <Card className="text-center border-l-4 border-l-orange-500">
            <CardContent className="pt-6">
              <div className="text-4xl font-bold text-orange-600 mb-2">€18,500</div>
              <div className="text-gray-600">Investimenti Totali</div>
              <div className="text-xs text-gray-500 mt-2">Tutti tracciabili e pubblici</div>
            </CardContent>
          </Card>
        </div>

        {/* Testimonianza Impatto */}
        <div className="mt-12">
          <Card className="bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="text-center py-8">
              <div className="text-6xl mb-4">🎯</div>
              <h3 className="text-2xl font-bold mb-4">Il Nostro Obiettivo per il 2025</h3>
              <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
                Raggiungere <strong>5,000 persone beneficiarie</strong> attraverso <strong>20 nuovi progetti</strong>
                con un investimento totale di <strong>€35,000</strong>, mantenendo sempre la totale
                trasparenza e partecipazione democratica.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild className="bg-blue-600 hover:bg-blue-700">
                  <Link href="/associati">
                    Contribuisci ai Progetti
                  </Link>
                </Button>
                <Button asChild variant="outline">
                  <Link href="/trasparenza">
                    Vedi Come Usiamo i Fondi
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-16 text-center">
        <Card className="bg-gradient-to-r from-green-600 to-green-700 text-white">
          <CardContent className="py-12">
            <h2 className="text-3xl font-bold mb-4">Hai un'Idea per un Progetto?</h2>
            <p className="text-green-100 mb-8 max-w-2xl mx-auto">
              La nostra forza sono le idee dei soci. Se hai un progetto che può
              migliorare la vita della comunità, proponicelo! Insieme possiamo realizzarlo.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-white text-green-600 hover:bg-gray-100">
                <Link href="/associati">
                  Diventa Socio e Proponi
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-green-600">
                <Link href="/contatti">
                  Contattaci per Info
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
