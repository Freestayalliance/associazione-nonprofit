"use client"

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function AdminWorking() {
  const router = useRouter();

  useEffect(() => {
    // Controlla se l'admin è già loggato
    const savedAdmin = localStorage.getItem('adminUser');

    if (savedAdmin) {
      try {
        const admin = JSON.parse(savedAdmin);
        // Se è loggato, reindirizza al dashboard admin
        router.push('/admin');
      } catch (error) {
        // Se c'è un errore nel parsing, vai al login
        router.push('/admin/login');
      }
    } else {
      // Se non è loggato, vai al login
      router.push('/admin/login');
    }
  }, [router]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4" />
        <p className="text-gray-600">Reindirizzamento all'area admin...</p>
      </div>
    </div>
  );
}
