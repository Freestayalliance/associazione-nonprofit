"use client"

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useNotifications } from '@/contexts/NotificationContext';

export default function AdminNotifiche() {
  const { notifications, unreadCount, addNotification, markAllAsRead, clearAll } = useNotifications();
  const [newNotification, setNewNotification] = useState({
    type: 'system',
    title: '',
    message: '',
    priority: 'medium',
    actionUrl: ''
  });

  const handleSendNotification = () => {
    if (newNotification.title && newNotification.message) {
      addNotification({
        type: newNotification.type as any,
        title: newNotification.title,
        message: newNotification.message,
        priority: newNotification.priority as any,
        actionUrl: newNotification.actionUrl || undefined
      });

      setNewNotification({
        type: 'system',
        title: '',
        message: '',
        priority: 'medium',
        actionUrl: ''
      });

      alert('Notifica inviata con successo!');
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'new_vote': return 'Nuova Votazione';
      case 'vote_ending': return 'Scadenza Votazione';
      case 'vote_result': return 'Risultato Votazione';
      case 'system': return 'Sistema';
      default: return 'Generale';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-gray-500';
      default: return 'bg-blue-500';
    }
  };

  const formatDateTime = (date: Date) => {
    return new Intl.DateTimeFormat('it-IT', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Centro Notifiche Admin</h1>
        <p className="text-gray-600">Gestisci e invia notifiche ai soci dell'associazione</p>
      </div>

      {/* Statistiche */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Totali</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{notifications.length}</div>
            <p className="text-xs text-muted-foreground">Notifiche inviate</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Non Lette</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{unreadCount}</div>
            <p className="text-xs text-muted-foreground">Da leggere</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Votazioni</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {notifications.filter(n => n.type.includes('vote')).length}
            </div>
            <p className="text-xs text-muted-foreference">Relative ai voti</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Alta Priorità</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {notifications.filter(n => n.priority === 'high').length}
            </div>
            <p className="text-xs text-muted-foreground">Urgenti</p>
          </CardContent>
        </Card>
      </div>

      {/* Invia Nuova Notifica */}
      <Card>
        <CardHeader>
          <CardTitle>Invia Nuova Notifica</CardTitle>
          <CardDescription>
            Crea e invia una notifica a tutti i soci
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="type">Tipo Notifica</Label>
                <Select
                  value={newNotification.type}
                  onValueChange={(value) => setNewNotification({...newNotification, type: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new_vote">🗳️ Nuova Votazione</SelectItem>
                    <SelectItem value="vote_ending">⏰ Scadenza Votazione</SelectItem>
                    <SelectItem value="vote_result">📊 Risultato Votazione</SelectItem>
                    <SelectItem value="system">🔧 Sistema</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="priority">Priorità</Label>
                <Select
                  value={newNotification.priority}
                  onValueChange={(value) => setNewNotification({...newNotification, priority: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high">🔥 Alta (8 sec toast)</SelectItem>
                    <SelectItem value="medium">⚡ Media (5 sec toast)</SelectItem>
                    <SelectItem value="low">💭 Bassa</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="actionUrl">URL Azione (opzionale)</Label>
                <Input
                  id="actionUrl"
                  value={newNotification.actionUrl}
                  onChange={(e) => setNewNotification({...newNotification, actionUrl: e.target.value})}
                  placeholder="/votazioni"
                />
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Titolo</Label>
                <Input
                  id="title"
                  value={newNotification.title}
                  onChange={(e) => setNewNotification({...newNotification, title: e.target.value})}
                  placeholder="Titolo della notifica"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Messaggio</Label>
                <Textarea
                  id="message"
                  value={newNotification.message}
                  onChange={(e) => setNewNotification({...newNotification, message: e.target.value})}
                  placeholder="Contenuto del messaggio..."
                  rows={4}
                />
              </div>

              <Button onClick={handleSendNotification} className="w-full">
                📨 Invia Notifica
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Gestione Notifiche Esistenti */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Notifiche Recenti</CardTitle>
              <CardDescription>
                Ultime notifiche inviate ai soci
              </CardDescription>
            </div>
            <div className="flex gap-2">
              {unreadCount > 0 && (
                <Button variant="outline" onClick={markAllAsRead}>
                  Segna tutte lette
                </Button>
              )}
              <Button variant="destructive" onClick={clearAll}>
                Cancella tutte
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {notifications.slice(0, 10).map((notification) => (
              <div
                key={notification.id}
                className={`
                  p-4 border rounded-lg flex items-start justify-between
                  ${!notification.read ? 'bg-blue-50 border-blue-200' : 'bg-gray-50'}
                `}
              >
                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-medium">{notification.title}</h4>
                    <Badge variant="outline">{getTypeLabel(notification.type)}</Badge>
                    <Badge className={getPriorityColor(notification.priority)}>
                      {notification.priority}
                    </Badge>
                    {!notification.read && (
                      <Badge className="bg-blue-500">Nuovo</Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-600">{notification.message}</p>
                  <p className="text-xs text-gray-500">
                    {formatDateTime(notification.timestamp)}
                  </p>
                </div>
                <div className="text-2xl">
                  {notification.type === 'new_vote' && '🗳️'}
                  {notification.type === 'vote_ending' && '⏰'}
                  {notification.type === 'vote_result' && '📊'}
                  {notification.type === 'system' && '🔧'}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Notifiche Automatiche */}
      <Card className="bg-green-50 border-green-200">
        <CardHeader>
          <CardTitle className="text-green-800">🤖 Sistema Automatico Attivo</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-green-700 text-sm mb-4">
            Il sistema genera automaticamente notifiche per:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-green-700">
            <div>
              • Nuove votazioni aperte<br />
              • Votazioni in scadenza (24h, 6h, 1h)<br />
              • Risultati delle votazioni
            </div>
            <div>
              • Nuovi soci ammessi<br />
              • Aggiornamenti sistema<br />
              • Promemoria importanti
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
