"use client"

export default function TestSemplice() {
  return (
    <div>
      <h1>TEST FUNZIONA!</h1>
      <p>Se vedi questo, Next.js funziona</p>
      <style jsx>{`
        div { padding: 50px; background: yellow; }
        h1 { color: red; font-size: 50px; }
        p { color: blue; font-size: 20px; }
      `}</style>
    </div>
  );
}
