"use client"

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useAdminNotifications } from '@/hooks/useAdminNotifications';

interface ActivityLogEntry {
  id: number;
  userId: number;
  userName: string;
  action: string;
  details: string;
  timestamp: string;
  ip: string;
  userAgent?: string;
  status?: 'success' | 'warning' | 'error';
}

const ACTION_LABELS: Record<string, { label: string; icon: string; color: string }> = {
  'login': { label: 'Login', icon: '🔑', color: 'bg-green-100 text-green-800' },
  'logout': { label: 'Logout', icon: '🚪', color: 'bg-gray-100 text-gray-800' },
  'create': { label: 'Creazione', icon: '➕', color: 'bg-blue-100 text-blue-800' },
  'edit': { label: 'Modifica', icon: '✏️', color: 'bg-yellow-100 text-yellow-800' },
  'delete': { label: 'Eliminazione', icon: '🗑️', color: 'bg-red-100 text-red-800' },
  'view': { label: 'Visualizzazione', icon: '👁️', color: 'bg-purple-100 text-purple-800' },
  'export': { label: 'Export', icon: '📤', color: 'bg-indigo-100 text-indigo-800' },
  'import': { label: 'Import', icon: '📥', color: 'bg-cyan-100 text-cyan-800' },
  'system': { label: 'Sistema', icon: '⚙️', color: 'bg-orange-100 text-orange-800' }
};

export default function LogAttivita() {
  const [activityLog, setActivityLog] = useState<ActivityLogEntry[]>([]);
  const [filteredLog, setFilteredLog] = useState<ActivityLogEntry[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState('all');
  const [userFilter, setUserFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('all');

  const {
    notifySystemAlert,
    sendNotification,
    isPermissionGranted,
    requestPermission
  } = useAdminNotifications();

  // Carica log attività
  useEffect(() => {
    const loadActivityLog = () => {
      const stored = JSON.parse(localStorage.getItem('admin-activity-log') || '[]');

      // Aggiungi attività di esempio se il log è vuoto
      if (stored.length === 0) {
        const sampleActivities: ActivityLogEntry[] = [
          {
            id: 1,
            userId: 1,
            userName: 'Michael Franceschini',
            action: 'login',
            details: 'Login effettuato da Super Admin',
            timestamp: new Date().toISOString(),
            ip: '192.168.1.100',
            status: 'success'
          },
          {
            id: 2,
            userId: 1,
            userName: 'Michael Franceschini',
            action: 'view',
            details: 'Accesso al dashboard amministrativo',
            timestamp: new Date(Date.now() - 300000).toISOString(),
            ip: '192.168.1.100',
            status: 'success'
          },
          {
            id: 3,
            userId: 2,
            userName: 'Vittoria Sgura',
            action: 'edit',
            details: 'Modifica dati socio Alessandro Verdi',
            timestamp: new Date(Date.now() - 600000).toISOString(),
            ip: '192.168.1.102',
            status: 'success'
          },
          {
            id: 4,
            userId: 1,
            userName: 'Michael Franceschini',
            action: 'create',
            details: 'Aggiunta nuova transazione finanziaria',
            timestamp: new Date(Date.now() - 900000).toISOString(),
            ip: '192.168.1.100',
            status: 'success'
          },
          {
            id: 5,
            userId: 3,
            userName: 'Giuseppe Verdi',
            action: 'view',
            details: 'Consultazione feedback demo',
            timestamp: new Date(Date.now() - 1200000).toISOString(),
            ip: '192.168.1.105',
            status: 'success'
          }
        ];

        localStorage.setItem('admin-activity-log', JSON.stringify(sampleActivities));
        setActivityLog(sampleActivities);
      } else {
        setActivityLog(stored);
      }
    };

    loadActivityLog();
  }, []);

  // Filtri
  useEffect(() => {
    let filtered = [...activityLog];

    // Filtro per testo
    if (searchTerm) {
      filtered = filtered.filter(entry =>
        entry.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        entry.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
        entry.action.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filtro per azione
    if (actionFilter !== 'all') {
      filtered = filtered.filter(entry => entry.action === actionFilter);
    }

    // Filtro per utente
    if (userFilter !== 'all') {
      filtered = filtered.filter(entry => entry.userName === userFilter);
    }

    // Filtro per data
    if (dateFilter !== 'all') {
      const now = new Date();
      const filterDate = new Date();

      switch (dateFilter) {
        case 'today':
          filterDate.setHours(0, 0, 0, 0);
          break;
        case 'week':
          filterDate.setDate(now.getDate() - 7);
          break;
        case 'month':
          filterDate.setMonth(now.getMonth() - 1);
          break;
      }

      if (dateFilter !== 'all') {
        filtered = filtered.filter(entry =>
          new Date(entry.timestamp) >= filterDate
        );
      }
    }

    setFilteredLog(filtered.sort((a, b) =>
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    ));
  }, [activityLog, searchTerm, actionFilter, userFilter, dateFilter]);

  const clearLog = () => {
    localStorage.setItem('admin-activity-log', '[]');
    setActivityLog([]);
  };

  const exportLog = () => {
    const dataStr = JSON.stringify(filteredLog, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `admin-log-${new Date().toISOString().split('T')[0]}.json`;
    link.click();

    // Log dell'export
    const newEntry: ActivityLogEntry = {
      id: Date.now(),
      userId: 1,
      userName: 'Sistema',
      action: 'export',
      details: `Export log attività (${filteredLog.length} voci)`,
      timestamp: new Date().toISOString(),
      ip: 'Local',
      status: 'success'
    };

    const updatedLog = [newEntry, ...activityLog];
    setActivityLog(updatedLog);
    localStorage.setItem('admin-activity-log', JSON.stringify(updatedLog));
  };

  const testNotification = async () => {
    if (!isPermissionGranted) {
      const granted = await requestPermission();
      if (!granted) {
        alert('Permessi per le notifiche non concessi');
        return;
      }
    }

    await sendNotification({
      title: '🧪 Test Notifica',
      message: 'Questa è una notifica di test dal log attività',
      type: 'system',
      priority: 'normal',
      read: false
    });
  };

  // Statistiche
  const stats = {
    total: activityLog.length,
    today: activityLog.filter(entry => {
      const today = new Date().toDateString();
      return new Date(entry.timestamp).toDateString() === today;
    }).length,
    byAction: activityLog.reduce((acc, entry) => {
      acc[entry.action] = (acc[entry.action] || 0) + 1;
      return acc;
    }, {} as Record<string, number>),
    uniqueUsers: new Set(activityLog.map(entry => entry.userName)).size
  };

  const uniqueUsers = Array.from(new Set(activityLog.map(entry => entry.userName)));
  const uniqueActions = Array.from(new Set(activityLog.map(entry => entry.action)));

  return (
    <div>
      {/* Header Navigazione Admin */}
      <div style={{
        backgroundColor: '#f8fafc',
        borderBottom: '2px solid #e2e8f0',
        padding: '16px 24px',
        marginBottom: '24px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <a
            href="/admin"
            style={{
              backgroundColor: '#3b82f6',
              color: 'white',
              padding: '8px 16px',
              borderRadius: '6px',
              textDecoration: 'none',
              fontSize: '14px',
              fontWeight: '500',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            ← 📊 Dashboard Admin
          </a>
          <span style={{ color: '#64748b', fontSize: '14px' }}>/</span>
          <span style={{ color: '#334155', fontSize: '14px', fontWeight: '500' }}>📋 Log Attività</span>
        </div>
      </div>

      <div className="space-y-6">
        {/* Header */}
        <div>
        <h1 className="text-3xl font-bold text-gray-900">Log Attività Admin</h1>
        <p className="text-gray-600">Tracciamento di tutte le azioni amministrative</p>
      </div>

      {/* Statistiche */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Attività Totali</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{stats.total}</div>
            <p className="text-sm text-gray-600">{stats.today} oggi</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Utenti Attivi</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{stats.uniqueUsers}</div>
            <p className="text-sm text-gray-600">Amministratori</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Azioni Più Comuni</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              {Object.entries(stats.byAction)
                .sort(([,a], [,b]) => b - a)
                .slice(0, 3)
                .map(([action, count]) => (
                  <div key={action} className="flex justify-between text-sm">
                    <span>{ACTION_LABELS[action]?.label || action}</span>
                    <span className="font-medium">{count}</span>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Test Sistema</CardTitle>
          </CardHeader>
          <CardContent>
            <Button
              onClick={testNotification}
              className="w-full mb-2"
              variant="outline"
            >
              🔔 Test Notifica
            </Button>
            <p className="text-xs text-gray-500">
              Testa le notifiche desktop
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filtri */}
      <Card>
        <CardHeader>
          <CardTitle>Filtri di Ricerca</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div>
              <Input
                placeholder="Cerca utente, azione o dettagli..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div>
              <Select value={actionFilter} onValueChange={setActionFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Tutte le azioni" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tutte le azioni</SelectItem>
                  {uniqueActions.map(action => (
                    <SelectItem key={action} value={action}>
                      {ACTION_LABELS[action]?.icon} {ACTION_LABELS[action]?.label || action}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Select value={userFilter} onValueChange={setUserFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Tutti gli utenti" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tutti gli utenti</SelectItem>
                  {uniqueUsers.map(user => (
                    <SelectItem key={user} value={user}>{user}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Tutte le date" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tutte le date</SelectItem>
                  <SelectItem value="today">Oggi</SelectItem>
                  <SelectItem value="week">Ultima settimana</SelectItem>
                  <SelectItem value="month">Ultimo mese</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2">
              <Button onClick={exportLog} variant="outline" className="flex-1">
                📤 Export
              </Button>
              <Button onClick={clearLog} variant="destructive" size="sm">
                🗑️
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabella Log */}
      <Card>
        <CardHeader>
          <CardTitle>Registro Attività ({filteredLog.length} voci)</CardTitle>
          <CardDescription>
            Lista cronologica di tutte le azioni amministrative
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data/Ora</TableHead>
                <TableHead>Utente</TableHead>
                <TableHead>Azione</TableHead>
                <TableHead>Dettagli</TableHead>
                <TableHead>IP</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLog.map((entry) => (
                <TableRow key={entry.id}>
                  <TableCell className="font-mono text-sm">
                    {new Date(entry.timestamp).toLocaleString('it-IT')}
                  </TableCell>
                  <TableCell>
                    <div className="font-medium">{entry.userName}</div>
                    <div className="text-xs text-gray-500">ID: {entry.userId}</div>
                  </TableCell>
                  <TableCell>
                    <Badge className={ACTION_LABELS[entry.action]?.color || 'bg-gray-100 text-gray-800'}>
                      {ACTION_LABELS[entry.action]?.icon} {ACTION_LABELS[entry.action]?.label || entry.action}
                    </Badge>
                  </TableCell>
                  <TableCell className="max-w-xs">
                    <div className="truncate" title={entry.details}>
                      {entry.details}
                    </div>
                  </TableCell>
                  <TableCell className="font-mono text-sm">
                    {entry.ip}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={entry.status === 'success' ? 'default' :
                              entry.status === 'warning' ? 'secondary' : 'destructive'}
                    >
                      {entry.status === 'success' ? '✅' :
                       entry.status === 'warning' ? '⚠️' :
                       entry.status === 'error' ? '❌' : '❓'}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {filteredLog.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <p>Nessuna attività trovata con i filtri selezionati</p>
            </div>
          )}
        </CardContent>
      </Card>
      </div>
    </div>
  );
}
