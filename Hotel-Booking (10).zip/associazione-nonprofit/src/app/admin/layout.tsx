// Layout admin temporaneamente disabilitato per far funzionare le pagine
export default function AdminRootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
