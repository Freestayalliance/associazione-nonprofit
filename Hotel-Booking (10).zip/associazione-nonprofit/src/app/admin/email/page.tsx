"use client"

import { useState, useEffect } from 'react';

interface EmailStats {
  totalSent: number;
  sentToday: number;
  byType: Record<string, number>;
  recentEmails: EmailInviata[];
}

interface EmailInviata {
  to: string;
  subject: string;
  type: string;
  timestamp: string;
  success: boolean;
}
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { emailNotificationService } from '@/services/EmailNotificationService';

export default function GestioneEmail() {
  const [stats, setStats] = useState<EmailStats>({ totalSent: 0, sentToday: 0, byType: {}, recentEmails: [] });
  const [emailTest, setEmailTest] = useState('');
  const [isInvioInCorso, setIsInvioInCorso] = useState(false);
  const [emailInviate, setEmailInviate] = useState<EmailInviata[]>([]);
  const [previewData, setPreviewData] = useState({
    nome: 'Mario Rossi',
    email: 'mario.rossi@example.com',
    password: 'TestPass123',
    tessera: 'SOC001'
  });
  const [emailPreview, setEmailPreview] = useState<{ subject: string; htmlBody: string } | null>(null);

  const { toast } = useToast();
  const emailService = emailNotificationService;

  useEffect(() => {
    loadEmailStats();
    loadEmailInviate();
  }, []);

  const loadEmailStats = () => {
    const statsData = emailService.getEmailStats();
    setStats(statsData);
  };

  const loadEmailInviate = () => {
    const emails = JSON.parse(localStorage.getItem('sentEmails') || '[]');
    setEmailInviate(emails.slice(-20).reverse()); // Ultime 20 email
  };

  const inviaEmailTest = async () => {
    if (!emailTest) {
      toast({
        title: "Errore",
        description: "Inserisci un indirizzo email per il test",
        variant: "destructive"
      });
      return;
    }

    setIsInvioInCorso(true);

    try {
      const successo = await emailService.sendTestEmail(emailTest);

      if (successo) {
        toast({
          title: "✅ Email test inviata!",
          description: `Email di test inviata a ${emailTest}`,
        });
        loadEmailStats();
        loadEmailInviate();
      } else {
        toast({
          title: "❌ Invio fallito",
          description: "Errore durante l'invio dell'email di test",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Errore invio email test:', error);
      toast({
        title: "Errore",
        description: "Errore durante l'invio dell'email di test",
        variant: "destructive"
      });
    } finally {
      setIsInvioInCorso(false);
    }
  };

  const inviaEmailCredenziali = async () => {
    setIsInvioInCorso(true);

    try {
      const successo = await emailService.sendCredentials(
        previewData.email,
        previewData.nome,
        previewData.email,
        previewData.password,
        previewData.tessera
      );

      if (successo) {
        toast({
          title: "✅ Email credenziali inviata!",
          description: `Email inviata a ${previewData.email}`,
        });
        loadEmailStats();
        loadEmailInviate();
      } else {
        toast({
          title: "❌ Invio fallito",
          description: "Errore durante l'invio dell'email",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Errore invio email credenziali:', error);
      toast({
        title: "Errore",
        description: "Errore durante l'invio dell'email",
        variant: "destructive"
      });
    } finally {
      setIsInvioInCorso(false);
    }
  };

  const generaPreview = () => {
    const preview = emailService.generateCredentialsPreview(
      previewData.nome,
      previewData.email,
      previewData.password,
      previewData.tessera
    );
    setEmailPreview(preview);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'sent':
        return <Badge className="bg-green-600">✅ Inviata</Badge>;
      case 'failed':
        return <Badge variant="destructive">❌ Fallita</Badge>;
      case 'pending':
        return <Badge variant="secondary">⏳ In corso</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getEmailTypeIcon = (subject: string) => {
    if (subject.includes('Credenziali') || subject.includes('Benvenuto')) return '🔑';
    if (subject.includes('Password') || subject.includes('Reset')) return '🔄';
    if (subject.includes('Votazione')) return '🗳️';
    if (subject.includes('Test')) return '🧪';
    return '📧';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Sistema Email</h1>
        <p className="text-gray-600">
          Gestisci email automatiche, monitora invii e configura template
        </p>
      </div>

      {/* Statistiche Email */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Email Totali</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{stats.totalSent || 0}</div>
            <p className="text-sm text-gray-600">Inviate</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Oggi</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{stats.sentToday || 0}</div>
            <p className="text-sm text-gray-600">Inviate oggi</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Credenziali</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-600">
              {(stats.byType && stats.byType.credentials) || 0}
            </div>
            <p className="text-sm text-gray-600">Email automatiche</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Sistema</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">Online</div>
            <p className="text-sm text-gray-600">Servizio attivo</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs Principali */}
      <Tabs defaultValue="test" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="test">🧪 Test Email</TabsTrigger>
          <TabsTrigger value="preview">👁️ Preview</TabsTrigger>
          <TabsTrigger value="log">📋 Log Invii</TabsTrigger>
          <TabsTrigger value="config">⚙️ Configurazione</TabsTrigger>
        </TabsList>

        {/* Tab Test Email */}
        <TabsContent value="test" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>🧪 Test Invio Email</CardTitle>
              <CardDescription>
                Invia email di test per verificare il funzionamento del sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="email-test">Indirizzo Email Test</Label>
                <Input
                  id="email-test"
                  type="email"
                  value={emailTest}
                  onChange={(e) => setEmailTest(e.target.value)}
                  placeholder="test@example.com"
                />
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={inviaEmailTest}
                  disabled={isInvioInCorso}
                  className="flex-1"
                >
                  {isInvioInCorso ? "⏳ Invio..." : "📧 Invia Email Test"}
                </Button>

                <Button
                  onClick={inviaEmailCredenziali}
                  disabled={isInvioInCorso}
                  variant="outline"
                  className="flex-1"
                >
                  {isInvioInCorso ? "⏳ Invio..." : "🔑 Test Credenziali"}
                </Button>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">💡 Tipi di Email Disponibili:</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• <strong>Email Test:</strong> Verifica funzionamento sistema</li>
                  <li>• <strong>Credenziali:</strong> Benvenuto con credenziali di accesso</li>
                  <li>• <strong>Reset Password:</strong> Nuova password generata</li>
                  <li>• <strong>Votazioni:</strong> Notifiche nuove votazioni</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab Preview */}
        <TabsContent value="preview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>👁️ Preview Email Credenziali</CardTitle>
              <CardDescription>
                Anteprima dell'email che ricevono i nuovi soci
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="preview-nome">Nome</Label>
                  <Input
                    id="preview-nome"
                    value={previewData.nome}
                    onChange={(e) => setPreviewData({...previewData, nome: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="preview-email">Email</Label>
                  <Input
                    id="preview-email"
                    type="email"
                    value={previewData.email}
                    onChange={(e) => setPreviewData({...previewData, email: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="preview-password">Password</Label>
                  <Input
                    id="preview-password"
                    value={previewData.password}
                    onChange={(e) => setPreviewData({...previewData, password: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="preview-tessera">Tessera</Label>
                  <Input
                    id="preview-tessera"
                    value={previewData.tessera}
                    onChange={(e) => setPreviewData({...previewData, tessera: e.target.value})}
                  />
                </div>
              </div>

              <Button onClick={generaPreview} className="w-full">
                🔄 Genera Preview
              </Button>

              {emailPreview && (
                <div className="space-y-4">
                  <div>
                    <Label>Oggetto Email:</Label>
                    <div className="p-3 bg-gray-100 rounded border font-mono text-sm">
                      {emailPreview.subject}
                    </div>
                  </div>

                  <div>
                    <Label>Anteprima HTML:</Label>
                    <div
                      className="p-4 bg-white border rounded max-h-96 overflow-auto"
                      dangerouslySetInnerHTML={{ __html: emailPreview.htmlBody }}
                    />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab Log Invii */}
        <TabsContent value="log" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>📋 Log Email Inviate ({emailInviate.length})</CardTitle>
              <CardDescription>
                Cronologia delle ultime email inviate dal sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Destinatario</TableHead>
                    <TableHead>Oggetto</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Stato</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {emailInviate.map((email, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{getEmailTypeIcon(email.subject)}</span>
                        </div>
                      </TableCell>
                      <TableCell>{email.to}</TableCell>
                      <TableCell className="max-w-xs truncate">{email.subject}</TableCell>
                      <TableCell>
                        {new Date(email.timestamp).toLocaleString('it-IT')}
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(email.success ? 'sent' : 'failed')}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {emailInviate.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  📭 Nessuna email inviata ancora
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab Configurazione */}
        <TabsContent value="config" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>⚙️ Configurazione Email</CardTitle>
              <CardDescription>
                Impostazioni del servizio email (modalità demo)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">📧 Configurazione Attuale:</h4>
                <div className="text-sm text-blue-800 space-y-1">
                  <div><strong>Mittente:</strong> noreply@associazione.org</div>
                  <div><strong>Nome:</strong> Associazione Non-Profit</div>
                  <div><strong>Modalità:</strong> Demo (localStorage)</div>
                  <div><strong>Template:</strong> HTML professionale</div>
                </div>
              </div>

              <div className="bg-yellow-50 p-4 rounded-lg">
                <h4 className="font-medium text-yellow-900 mb-2">⚠️ Modalità Demo:</h4>
                <div className="text-sm text-yellow-800">
                  Attualmente il sistema funziona in modalità demo. Le email vengono simulate e salvate nel localStorage del browser.
                  <br/><br/>
                  <strong>Per produzione:</strong> Configurare un servizio email reale (SendGrid, Mailgun, etc.)
                </div>
              </div>

              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-medium text-green-900 mb-2">✅ Funzionalità Attive:</h4>
                <ul className="text-sm text-green-800 space-y-1">
                  <li>• Template email professionali</li>
                  <li>• Invio automatico credenziali nuovi soci</li>
                  <li>• Email reset password</li>
                  <li>• Notifiche votazioni</li>
                  <li>• Log completo invii</li>
                  <li>• Preview template</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
