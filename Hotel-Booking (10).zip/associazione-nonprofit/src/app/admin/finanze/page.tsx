"use client"

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Dati di esempio per le transazioni (sincronizzati con dashboard)
const transazioniEsempio = [
  // Transazioni correnti (2024)
  { id: 1, data: "2024-12-01", tipo: "entrata", descrizione: "Quote associative Dicembre", importo: 400, categoria: "Quote Soci" },
  { id: 2, data: "2024-11-28", tipo: "uscita", descrizione: "Hosting sito web", importo: -25, categoria: "Spese Tecniche" },
  { id: 3, data: "2024-11-25", tipo: "entrata", descrizione: "Donazione Azienda TechCorp", importo: 500, categoria: "Donazioni" },
  { id: 4, data: "2024-11-20", tipo: "uscita", descrizione: "Materiali evento comunitario", importo: -150, categoria: "Eventi" },
  { id: 5, data: "2024-11-15", tipo: "entrata", descrizione: "Quote associative Novembre", importo: 380, categoria: "Quote Soci" },
  { id: 6, data: "2024-11-10", tipo: "uscita", descrizione: "Software contabilità", importo: -45, categoria: "Spese Tecniche" },
  { id: 7, data: "2024-11-05", tipo: "entrata", descrizione: "Vendita merchandise", importo: 120, categoria: "Vendite" },
  { id: 8, data: "2024-10-30", tipo: "uscita", descrizione: "Spese postali", importo: -35, categoria: "Spese Amministrative" },

  // Transazioni storiche 2024 (per totali realistici)
  { id: 9, data: "2024-10-01", tipo: "entrata", descrizione: "Quote associative Ottobre", importo: 360, categoria: "Quote Soci" },
  { id: 10, data: "2024-09-01", tipo: "entrata", descrizione: "Quote associative Settembre", importo: 340, categoria: "Quote Soci" },
  { id: 11, data: "2024-08-01", tipo: "entrata", descrizione: "Quote associative Agosto", importo: 320, categoria: "Quote Soci" },
  { id: 12, data: "2024-07-01", tipo: "entrata", descrizione: "Quote associative Luglio", importo: 300, categoria: "Quote Soci" },
  { id: 13, data: "2024-06-01", tipo: "entrata", descrizione: "Quote associative Giugno", importo: 280, categoria: "Quote Soci" },
  { id: 14, data: "2024-05-01", tipo: "entrata", descrizione: "Quote associative Maggio", importo: 260, categoria: "Quote Soci" },
  { id: 15, data: "2024-04-15", tipo: "entrata", descrizione: "Donazione Partner GreenTech", importo: 1000, categoria: "Donazioni" },
  { id: 16, data: "2024-03-01", tipo: "entrata", descrizione: "Quote associative Marzo", importo: 240, categoria: "Quote Soci" },
  { id: 17, data: "2024-02-01", tipo: "entrata", descrizione: "Quote associative Febbraio", importo: 220, categoria: "Quote Soci" },
  { id: 18, data: "2024-01-01", tipo: "entrata", descrizione: "Quote associative Gennaio", importo: 200, categoria: "Quote Soci" },

  // Uscite storiche
  { id: 19, data: "2024-09-15", tipo: "uscita", descrizione: "Assicurazione annuale", importo: -180, categoria: "Assicurazioni" },
  { id: 20, data: "2024-08-20", tipo: "uscita", descrizione: "Evento estivo", importo: -220, categoria: "Eventi" },
  { id: 21, data: "2024-06-10", tipo: "uscita", descrizione: "Materiali ufficio", importo: -85, categoria: "Spese Amministrative" },
  { id: 22, data: "2024-04-05", tipo: "uscita", descrizione: "Marketing e comunicazione", importo: -120, categoria: "Marketing" },
];

const categorie = [
  "Quote Soci", "Donazioni", "Vendite", "Spese Tecniche",
  "Eventi", "Spese Amministrative", "Assicurazioni", "Marketing"
];

export default function GestioneFinanze() {
  const [transazioni, setTransazioni] = useState(transazioniEsempio);
  const [filtroTipo, setFiltroTipo] = useState('tutti');
  const [nuovaTransazione, setNuovaTransazione] = useState({
    tipo: 'entrata',
    descrizione: '',
    importo: '',
    categoria: '',
    data: new Date().toISOString().split('T')[0]
  });
  const [dialogAperto, setDialogAperto] = useState(false);

  const transazioniFiltrate = transazioni.filter(t =>
    filtroTipo === 'tutti' || t.tipo === filtroTipo
  );

  const handleAggiungiTransazione = () => {
    if (nuovaTransazione.descrizione && nuovaTransazione.importo && nuovaTransazione.categoria) {
      const transazione = {
        id: transazioni.length + 1,
        ...nuovaTransazione,
        importo: nuovaTransazione.tipo === 'uscita'
          ? -Math.abs(Number(nuovaTransazione.importo))
          : Math.abs(Number(nuovaTransazione.importo))
      };
      setTransazioni([transazione, ...transazioni]);
      setNuovaTransazione({
        tipo: 'entrata',
        descrizione: '',
        importo: '',
        categoria: '',
        data: new Date().toISOString().split('T')[0]
      });
      setDialogAperto(false);
    }
  };

  const totaleEntrate = transazioni
    .filter(t => t.importo > 0)
    .reduce((sum, t) => sum + t.importo, 0);

  const totaleUscite = transazioni
    .filter(t => t.importo < 0)
    .reduce((sum, t) => sum + Math.abs(t.importo), 0);

  const saldoAttuale = totaleEntrate - totaleUscite;

  // Raggruppa per categoria
  const entratePorCategoria = transazioni
    .filter(t => t.importo > 0)
    .reduce((acc, t) => {
      acc[t.categoria] = (acc[t.categoria] || 0) + t.importo;
      return acc;
    }, {} as Record<string, number>);

  const uscitePerCategoria = transazioni
    .filter(t => t.importo < 0)
    .reduce((acc, t) => {
      acc[t.categoria] = (acc[t.categoria] || 0) + Math.abs(t.importo);
      return acc;
    }, {} as Record<string, number>);

  return (
    <div>
      {/* Header Navigazione Admin */}
      <div style={{
        backgroundColor: '#f8fafc',
        borderBottom: '2px solid #e2e8f0',
        padding: '16px 24px',
        marginBottom: '24px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <a
            href="/admin"
            style={{
              backgroundColor: '#3b82f6',
              color: 'white',
              padding: '8px 16px',
              borderRadius: '6px',
              textDecoration: 'none',
              fontSize: '14px',
              fontWeight: '500',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            ← 📊 Dashboard Admin
          </a>
          <span style={{ color: '#64748b', fontSize: '14px' }}>/</span>
          <span style={{ color: '#334155', fontSize: '14px', fontWeight: '500' }}>💰 Finanze</span>
        </div>
      </div>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestione Finanze</h1>
          <p className="text-gray-600">Amministra entrate e uscite dell'associazione</p>
        </div>

        <Dialog open={dialogAperto} onOpenChange={setDialogAperto}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              ➕ Nuova Transazione
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Aggiungi Transazione</DialogTitle>
              <DialogDescription>
                Registra una nuova entrata o uscita
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="tipo">Tipo</Label>
                <Select
                  value={nuovaTransazione.tipo}
                  onValueChange={(value) => setNuovaTransazione({...nuovaTransazione, tipo: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="entrata">Entrata</SelectItem>
                    <SelectItem value="uscita">Uscita</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="descrizione">Descrizione</Label>
                <Textarea
                  id="descrizione"
                  value={nuovaTransazione.descrizione}
                  onChange={(e) => setNuovaTransazione({...nuovaTransazione, descrizione: e.target.value})}
                  placeholder="Descrizione della transazione"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="importo">Importo (€)</Label>
                <Input
                  id="importo"
                  type="number"
                  step="0.01"
                  value={nuovaTransazione.importo}
                  onChange={(e) => setNuovaTransazione({...nuovaTransazione, importo: e.target.value})}
                  placeholder="0.00"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="categoria">Categoria</Label>
                <Select
                  value={nuovaTransazione.categoria}
                  onValueChange={(value) => setNuovaTransazione({...nuovaTransazione, categoria: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Seleziona categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    {categorie.map(categoria => (
                      <SelectItem key={categoria} value={categoria}>
                        {categoria}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="data">Data</Label>
                <Input
                  id="data"
                  type="date"
                  value={nuovaTransazione.data}
                  onChange={(e) => setNuovaTransazione({...nuovaTransazione, data: e.target.value})}
                />
              </div>

              <Button onClick={handleAggiungiTransazione} className="w-full">
                Aggiungi Transazione
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Riassunto Finanziario */}
      <div className="grid md:grid-cols-4 gap-6">
        <Card className="text-center">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Saldo Attuale</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-3xl font-bold ${saldoAttuale >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              €{saldoAttuale.toLocaleString()}
            </div>
            <p className="text-sm text-gray-600 mt-2">Aggiornato in tempo reale</p>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Totale Entrate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">
              €{totaleEntrate.toLocaleString()}
            </div>
            <p className="text-sm text-gray-600 mt-2">Quest'anno</p>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Totale Uscite</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600">
              €{totaleUscite.toLocaleString()}
            </div>
            <p className="text-sm text-gray-600 mt-2">Quest'anno</p>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Transazioni</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">
              {transazioni.length}
            </div>
            <p className="text-sm text-gray-600 mt-2">Totali registrate</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Entrate per Categoria */}
        <Card>
          <CardHeader>
            <CardTitle>Entrate per Categoria</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {Object.entries(entratePorCategoria)
              .sort(([,a], [,b]) => b - a)
              .map(([categoria, importo]) => (
                <div key={categoria} className="flex justify-between items-center">
                  <span className="text-gray-600">{categoria}</span>
                  <span className="font-semibold text-green-600">€{importo.toLocaleString()}</span>
                </div>
              ))}
          </CardContent>
        </Card>

        {/* Uscite per Categoria */}
        <Card>
          <CardHeader>
            <CardTitle>Uscite per Categoria</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {Object.entries(uscitePerCategoria)
              .sort(([,a], [,b]) => b - a)
              .map(([categoria, importo]) => (
                <div key={categoria} className="flex justify-between items-center">
                  <span className="text-gray-600">{categoria}</span>
                  <span className="font-semibold text-red-600">€{importo.toLocaleString()}</span>
                </div>
              ))}
          </CardContent>
        </Card>
      </div>

      {/* Tabella Transazioni */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle className="text-2xl">Registro Transazioni</CardTitle>
              <CardDescription>
                Elenco completo di tutte le transazioni
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button
                variant={filtroTipo === "tutti" ? "default" : "outline"}
                size="sm"
                onClick={() => setFiltroTipo("tutti")}
              >
                Tutte
              </Button>
              <Button
                variant={filtroTipo === "entrata" ? "default" : "outline"}
                size="sm"
                onClick={() => setFiltroTipo("entrata")}
                className="bg-green-600 hover:bg-green-700 data-[state=active]:bg-green-600"
              >
                Entrate
              </Button>
              <Button
                variant={filtroTipo === "uscita" ? "default" : "outline"}
                size="sm"
                onClick={() => setFiltroTipo("uscita")}
                className="bg-red-600 hover:bg-red-700 data-[state=active]:bg-red-600"
              >
                Uscite
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead>Descrizione</TableHead>
                <TableHead>Categoria</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead className="text-right">Importo</TableHead>
                <TableHead>Azioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transazioniFiltrate.map((transazione) => (
                <TableRow key={transazione.id}>
                  <TableCell className="font-medium">
                    {new Date(transazione.data).toLocaleDateString('it-IT')}
                  </TableCell>
                  <TableCell>{transazione.descrizione}</TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {transazione.categoria}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={transazione.tipo === "entrata" ? "default" : "destructive"}
                      className={transazione.tipo === "entrata" ? "bg-green-600" : ""}
                    >
                      {transazione.tipo === "entrata" ? "Entrata" : "Uscita"}
                    </Badge>
                  </TableCell>
                  <TableCell className={`text-right font-medium ${
                    transazione.importo > 0 ? "text-green-600" : "text-red-600"
                  }`}>
                    {transazione.importo > 0 ? "+" : ""}€{Math.abs(transazione.importo).toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setTransazioni(transazioni.filter(t => t.id !== transazione.id));
                      }}
                    >
                      Elimina
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      </div>
    </div>
  );
}
