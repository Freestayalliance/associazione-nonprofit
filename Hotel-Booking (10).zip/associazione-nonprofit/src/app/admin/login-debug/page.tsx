export default function AdminLoginDebug() {
  return (
    <>
      <h1>DEBUG LOGIN</h1>
      <div style={{
        position: 'fixed',
        top: '100px',
        left: '50px',
        backgroundColor: 'red',
        color: 'white',
        padding: '20px',
        zIndex: 9999,
        fontSize: '24px',
        border: '5px solid yellow'
      }}>
        SE VEDI QUESTO IL PROBLEMA È RISOLTO!
      </div>
      <p>Test contenuto login</p>
    </>
  );
}
