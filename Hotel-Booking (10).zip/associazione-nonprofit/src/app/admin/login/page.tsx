"use client"

import { useState } from 'react';
import Link from 'next/link';

// Credenziali semplici
const DEMO_USERS: Record<string, { password: string; user: { id: number; email: string; name: string; role: string } }> = {
  'admin@associazione.org': {
    password: 'admin123',
    user: {
      id: 1,
      email: 'admin@associazione.org',
      name: 'Michael Franceschini',
      role: 'admin'
    }
  },
  // 🆕 NUOVO AMMINISTRATORE - Puoi modificare questi dati
  'nuovo.admin@associazione.org': {
    password: 'nuovaPassword123',
    user: {
      id: 2,
      email: 'nuovo.admin@associazione.org',
      name: 'Nuovo Amministratore',
      role: 'admin'
    }
  }
};

export default function AdminLoginFix() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simula una chiamata API
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Prima controlla le credenziali dal sistema di gestione admin
    let userAccount = null;
    const adminLoginData = localStorage.getItem('admin-login-data');
    if (adminLoginData) {
      const loginData = JSON.parse(adminLoginData);
      userAccount = loginData[email];
    }

    // Se non trova nel sistema avanzato, usa quello di base
    if (!userAccount) {
      userAccount = DEMO_USERS[email];
    }

    // Verifica che l'admin sia attivo nel sistema
    const systemAdmins = localStorage.getItem('system-admins');
    let isActive = true;
    if (systemAdmins) {
      const admins = JSON.parse(systemAdmins);
      const admin = admins.find((a: any) => a.email === email);
      isActive = admin ? admin.isActive : true;
    }

    if (userAccount && userAccount.password === password && isActive) {
      // Salva l'utente nel localStorage
      const adminUser = {
        ...userAccount.user,
        loginTime: Date.now(),
        keepLoggedIn: true,
        lastActivity: Date.now()
      };

      localStorage.setItem('adminUser', JSON.stringify(adminUser));

      // Reindirizza alla dashboard admin
      window.location.href = '/admin';
    } else if (!isActive) {
      setError('Account amministratore disattivato');
    } else {
      setError('Email o password non validi');
    }

    setIsLoading(false);
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#f9fafb',
      fontFamily: 'system-ui, -apple-system, sans-serif'
    }}>
      <div style={{
        width: '100%',
        maxWidth: '400px',
        padding: '0 20px'
      }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <Link href="/" style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px',
            marginBottom: '16px',
            textDecoration: 'none',
            color: 'inherit'
          }}>
            <div style={{
              height: '32px',
              width: '32px',
              borderRadius: '50%',
              backgroundColor: '#2563eb',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <span style={{
                color: 'white',
                fontWeight: 'bold',
                fontSize: '14px'
              }}>A</span>
            </div>
            <span style={{
              fontWeight: 'bold',
              fontSize: '20px'
            }}>Associazione</span>
          </Link>
          <h1 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#111827',
            margin: '0 0 8px 0'
          }}>Area Amministrativa</h1>
          <p style={{
            color: '#6b7280',
            margin: 0
          }}>Accedi per gestire il sito</p>
        </div>

        {/* Card Container */}
        <div style={{
          backgroundColor: 'white',
          border: '1px solid #e5e7eb',
          borderRadius: '8px',
          boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
          overflow: 'hidden'
        }}>
          {/* Card Header */}
          <div style={{
            padding: '24px 24px 0 24px'
          }}>
            <h2 style={{
              fontSize: '18px',
              fontWeight: '600',
              color: '#111827',
              margin: '0 0 8px 0'
            }}>Accesso Admin</h2>
            <p style={{
              fontSize: '14px',
              color: '#6b7280',
              margin: '0 0 24px 0'
            }}>
              Inserisci le tue credenziali per accedere al pannello di controllo
            </p>
          </div>

          {/* Card Content */}
          <div style={{ padding: '0 24px 24px 24px' }}>
            <form onSubmit={handleSubmit} style={{ marginBottom: '24px' }}>
              {/* Email Field */}
              <div style={{ marginBottom: '16px' }}>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: '#374151',
                  marginBottom: '8px'
                }}>
                  Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@associazione.org"
                  required
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    border: '1px solid #d1d5db',
                    borderRadius: '6px',
                    fontSize: '14px',
                    boxSizing: 'border-box',
                    outline: 'none',
                    transition: 'border-color 0.2s'
                  }}
                  onFocus={(e) => e.target.style.borderColor = '#2563eb'}
                  onBlur={(e) => e.target.style.borderColor = '#d1d5db'}
                />
              </div>

              {/* Password Field */}
              <div style={{ marginBottom: '16px' }}>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: '#374151',
                  marginBottom: '8px'
                }}>
                  Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    border: '1px solid #d1d5db',
                    borderRadius: '6px',
                    fontSize: '14px',
                    boxSizing: 'border-box',
                    outline: 'none',
                    transition: 'border-color 0.2s'
                  }}
                  onFocus={(e) => e.target.style.borderColor = '#2563eb'}
                  onBlur={(e) => e.target.style.borderColor = '#d1d5db'}
                />
              </div>

              {/* Error Message */}
              {error && (
                <div style={{
                  fontSize: '14px',
                  color: '#dc2626',
                  backgroundColor: '#fef2f2',
                  padding: '12px',
                  borderRadius: '6px',
                  marginBottom: '16px'
                }}>
                  {error}
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                style={{
                  width: '100%',
                  backgroundColor: isLoading ? '#9ca3af' : '#2563eb',
                  color: 'white',
                  padding: '10px 16px',
                  border: 'none',
                  borderRadius: '6px',
                  fontSize: '14px',
                  fontWeight: '500',
                  cursor: isLoading ? 'not-allowed' : 'pointer',
                  transition: 'background-color 0.2s'
                }}
                onMouseOver={(e) => {
                  if (!isLoading) e.currentTarget.style.backgroundColor = '#1d4ed8';
                }}
                onMouseOut={(e) => {
                  if (!isLoading) e.currentTarget.style.backgroundColor = '#2563eb';
                }}
              >
                {isLoading ? 'Accesso in corso...' : 'Accedi'}
              </button>
            </form>

            {/* Demo Credentials */}
            <div style={{
              backgroundColor: '#eff6ff',
              padding: '16px',
              borderRadius: '8px'
            }}>
              <h3 style={{
                fontSize: '16px',
                fontWeight: '600',
                color: '#1e40af',
                margin: '0 0 12px 0'
              }}>🔑 Credenziali Demo:</h3>
              <div style={{
                backgroundColor: 'white',
                padding: '12px',
                borderRadius: '6px',
                border: '1px solid #e5e7eb'
              }}>
                <div style={{
                  fontWeight: '500',
                  color: '#111827',
                  marginBottom: '4px'
                }}>Michael Franceschini</div>
                <div style={{
                  fontSize: '14px',
                  color: '#6b7280',
                  marginBottom: '8px'
                }}>admin@associazione.org</div>
                <div style={{
                  fontSize: '14px',
                  color: '#1d4ed8'
                }}>
                  <strong>Password:</strong> admin123
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{
          textAlign: 'center',
          marginTop: '24px'
        }}>
          <Link href="/" style={{
            fontSize: '14px',
            color: '#2563eb',
            textDecoration: 'none'
          }}>
            ← Torna al sito principale
          </Link>
        </div>
      </div>
    </div>
  );
}
