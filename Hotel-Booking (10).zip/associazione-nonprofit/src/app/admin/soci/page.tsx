"use client"

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

// Funzione per generare password sicura
const generaPasswordSicura = (): string => {
  const caratteri = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let password = '';
  for (let i = 0; i < 8; i++) {
    password += caratteri.charAt(Math.floor(Math.random() * caratteri.length));
  }
  return password;
};

// Funzione per creare credenziali votazione
const creaCredenzialiVotazione = (socio: any, password: string) => {
  // Genera numero tessera univoco
  const numeroTessera = `SOC${String(socio.id).padStart(3, '0')}`;

  // Recupera credenziali esistenti
  const credenzialiEsistenti = JSON.parse(localStorage.getItem('soci-votazioni-credenziali') || '[]');

  // Aggiunge nuove credenziali
  const nuoveCredenziali = {
    id: socio.id,
    email: socio.email,
    password: password,
    nome: socio.nome,
    tessera: numeroTessera,
    dataCreazione: new Date().toISOString(),
    attivo: socio.stato === 'attivo'
  };

  // Controlla se già esistono credenziali per questo socio
  const indiceEsistente = credenzialiEsistenti.findIndex((c: any) => c.email === socio.email);
  if (indiceEsistente >= 0) {
    // Aggiorna credenziali esistenti
    credenzialiEsistenti[indiceEsistente] = nuoveCredenziali;
  } else {
    // Aggiunge nuove credenziali
    credenzialiEsistenti.push(nuoveCredenziali);
  }

  localStorage.setItem('soci-votazioni-credenziali', JSON.stringify(credenzialiEsistenti));
  return { password, tessera: numeroTessera };
};

// Dati di esempio per i soci
const sociEsempio = [
  {
    id: 1,
    nome: 'Michael Franceschini',
    email: 'michael@email.com',
    telefono: '+39 123 456 7890',
    dataIscrizione: '2024-01-15',
    stato: 'attivo',
    quotaPagata: true,
    ruolo: 'presidente'
  },
  {
    id: 2,
    nome: 'Vittoria Sgura',
    email: 'laura@email.com',
    telefono: '+39 098 765 4321',
    dataIscrizione: '2024-01-20',
    stato: 'attivo',
    quotaPagata: true,
    ruolo: 'tesoriera'
  },
  {
    id: 3,
    nome: 'Ilenya',
    email: 'giulia@email.com',
    telefono: '+39 555 123 456',
    dataIscrizione: '2024-02-01',
    stato: 'attivo',
    quotaPagata: true,
    ruolo: 'segretaria'
  },
  {
    id: 4,
    nome: 'Alessandro Verdi',
    email: 'alessandro@email.com',
    telefono: '+39 333 987 654',
    dataIscrizione: '2024-12-01',
    stato: 'in_approvazione',
    quotaPagata: true,
    ruolo: 'socio'
  },
  {
    id: 5,
    nome: 'Maria Neri',
    email: 'maria@email.com',
    telefono: '+39 777 555 333',
    dataIscrizione: '2024-11-15',
    stato: 'sospeso',
    quotaPagata: false,
    ruolo: 'socio'
  }
];

export default function GestioneSoci() {
  const [soci, setSoci] = useState(sociEsempio);
  const [filtroStato, setFiltroStato] = useState('tutti');
  const [ricerca, setRicerca] = useState('');
  const [dialogAperto, setDialogAperto] = useState(false);
  const [nuovoSocio, setNuovoSocio] = useState({
    nome: '',
    email: '',
    telefono: '',
    ruolo: 'socio'
  });
  const { toast } = useToast();

  const sociFiltrati = soci.filter(socio => {
    const corrispondeRicerca = socio.nome.toLowerCase().includes(ricerca.toLowerCase()) ||
                              socio.email.toLowerCase().includes(ricerca.toLowerCase());
    const corrispondeStato = filtroStato === 'tutti' || socio.stato === filtroStato;
    return corrispondeRicerca && corrispondeStato;
  });

  const aggiungiSocio = () => {
    if (!nuovoSocio.nome || !nuovoSocio.email) {
      toast({
        title: "Errore",
        description: "Nome e email sono obbligatori",
        variant: "destructive"
      });
      return;
    }

    // Genera password sicura per le votazioni
    const passwordVotazione = generaPasswordSicura();

    const socio = {
      id: soci.length + 1,
      nome: nuovoSocio.nome,
      email: nuovoSocio.email,
      telefono: nuovoSocio.telefono,
      dataIscrizione: new Date().toISOString().split('T')[0],
      stato: 'attivo' as const,
      quotaPagata: false,
      ruolo: nuovoSocio.ruolo
    };

    // Crea automaticamente le credenziali per le votazioni
    const { password, tessera } = creaCredenzialiVotazione(socio, passwordVotazione);

    setSoci([...soci, socio]);
    setNuovoSocio({ nome: '', email: '', telefono: '', ruolo: 'socio' });
    setDialogAperto(false);

    toast({
      title: "✅ Socio aggiunto!",
      description: `${socio.nome} è stato aggiunto con credenziali per le votazioni`,
    });

    // Mostra le credenziali generate
    setTimeout(() => {
      alert(`🔑 Credenziali generate per ${socio.nome}:\n\nEmail: ${socio.email}\nPassword: ${password}\nTessera: ${tessera}\n\n💡 Il socio può accedere alle votazioni su /votazioni/login`);
    }, 500);
  };

  // Funzione per visualizzare credenziali socio
  const visualizzaCredenziali = (socio: any) => {
    const credenzialiAdmin = JSON.parse(localStorage.getItem('soci-votazioni-credenziali') || '[]');
    const credenziale = credenzialiAdmin.find((c: any) => c.email === socio.email);

    if (credenziale) {
      alert(`🔑 Credenziali di ${socio.nome}:\n\nEmail: ${credenziale.email}\nPassword: ${credenziale.password}\nTessera: ${credenziale.tessera}\nStato: ${credenziale.attivo ? 'Attivo' : 'Disattivato'}\n\n💡 Il socio può usare queste credenziali su /votazioni/login`);
    } else {
      // Cerca nelle credenziali demo esistenti
      const sociDemo = [
        { id: 1, email: 'marco.verdi@email.com', password: 'socio123', nome: 'Marco Verdi', tessera: 'SOC001' },
        { id: 2, email: 'anna.rossi@email.com', password: 'socio456', nome: 'Anna Rossi', tessera: 'SOC002' },
        { id: 3, email: 'giulia.bianchi@email.com', password: 'socio789', nome: 'Ilenya', tessera: 'SOC003' },
        { id: 4, email: 'luca.neri@email.com', password: 'socio999', nome: 'Luca Neri', tessera: 'SOC004' },
      ];
      const demoSocio = sociDemo.find(s => s.email === socio.email);

      if (demoSocio) {
        alert(`🔑 Credenziali Demo di ${socio.nome}:\n\nEmail: ${demoSocio.email}\nPassword: ${demoSocio.password}\nTessera: ${demoSocio.tessera}\nTipo: Account Demo\n\n💡 Il socio può usare queste credenziali su /votazioni/login`);
      } else {
        if (confirm(`❌ Nessuna credenziale di accesso trovata per ${socio.nome}.\n\nVuoi creare le credenziali ora?`)) {
          const nuovaPassword = generaPasswordSicura();
          const { password, tessera } = creaCredenzialiVotazione(socio, nuovaPassword);
          alert(`✅ Credenziali create per ${socio.nome}:\n\nEmail: ${socio.email}\nPassword: ${password}\nTessera: ${tessera}\n\n💡 Il socio può ora accedere alle votazioni su /votazioni/login`);
        }
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Gestione Soci</h1>
        <p className="text-gray-600">
          Visualizza e gestisci i soci dell'associazione e le loro credenziali di accesso
        </p>
      </div>

      {/* Statistiche */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Soci Totali</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{soci.length}</div>
            <p className="text-sm text-gray-600">Registrati</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Soci Attivi</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">
              {soci.filter(s => s.stato === 'attivo').length}
            </div>
            <p className="text-sm text-gray-600">Possono votare</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">In Approvazione</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-yellow-600">
              {soci.filter(s => s.stato === 'in_approvazione').length}
            </div>
            <p className="text-sm text-gray-600">Da approvare</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Quote Pagate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">
              {soci.filter(s => s.quotaPagata).length}
            </div>
            <p className="text-sm text-gray-600">In regola</p>
          </CardContent>
        </Card>
      </div>

      {/* Lista Soci */}
      <Card>
        <CardHeader>
          <CardTitle>Lista Soci ({soci.length})</CardTitle>
          <CardDescription>
            Gestisci i soci dell'associazione
          </CardDescription>
          <div className="flex justify-between items-center">
            <div className="flex gap-4">
              <Input
                placeholder="Cerca per nome..."
                value={ricerca}
                onChange={(e) => setRicerca(e.target.value)}
                className="max-w-sm"
              />
              <Select value={filtroStato} onValueChange={setFiltroStato}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tutti">Tutti ({soci.length})</SelectItem>
                  <SelectItem value="attivo">Attivi ({soci.filter(s => s.stato === 'attivo').length})</SelectItem>
                  <SelectItem value="sospeso">Sospesi ({soci.filter(s => s.stato === 'sospeso').length})</SelectItem>
                  <SelectItem value="in_approvazione">In Approvazione ({soci.filter(s => s.stato === 'in_approvazione').length})</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Dialog open={dialogAperto} onOpenChange={setDialogAperto}>
              <DialogTrigger asChild>
                <Button className="bg-green-600 hover:bg-green-700">
                  ➕ Aggiungi Socio
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Aggiungi Nuovo Socio</DialogTitle>
                  <DialogDescription>
                    Inserisci i dati del nuovo socio
                  </DialogDescription>
                </DialogHeader>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="nome">Nome Completo</Label>
                    <Input
                      id="nome"
                      value={nuovoSocio.nome}
                      onChange={(e) => setNuovoSocio({...nuovoSocio, nome: e.target.value})}
                      placeholder="Mario Rossi"
                    />
                  </div>

                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={nuovoSocio.email}
                      onChange={(e) => setNuovoSocio({...nuovoSocio, email: e.target.value})}
                      placeholder="mario.rossi@email.com"
                    />
                  </div>

                  <div>
                    <Label htmlFor="telefono">Telefono</Label>
                    <Input
                      id="telefono"
                      value={nuovoSocio.telefono}
                      onChange={(e) => setNuovoSocio({...nuovoSocio, telefono: e.target.value})}
                      placeholder="+39 123 456 7890"
                    />
                  </div>

                  <div>
                    <Label htmlFor="ruolo">Ruolo</Label>
                    <Select value={nuovoSocio.ruolo} onValueChange={(value) => setNuovoSocio({...nuovoSocio, ruolo: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="socio">Socio</SelectItem>
                        <SelectItem value="volontario">Volontario</SelectItem>
                        <SelectItem value="tesoriere">Tesoriere</SelectItem>
                        <SelectItem value="segretario">Segretario</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button onClick={aggiungiSocio} className="w-full">
                    Aggiungi Socio
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Socio</TableHead>
                <TableHead>Ruolo</TableHead>
                <TableHead>Stato</TableHead>
                <TableHead>Data Iscrizione</TableHead>
                <TableHead>Azioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sociFiltrati.map((socio) => (
                <TableRow key={socio.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{socio.nome}</div>
                      <div className="text-sm text-gray-600">{socio.email}</div>
                      {socio.telefono && (
                        <div className="text-sm text-gray-500">{socio.telefono}</div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{socio.ruolo}</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        socio.stato === 'attivo' ? 'default' :
                        socio.stato === 'sospeso' ? 'destructive' : 'secondary'
                      }
                    >
                      {socio.stato}
                    </Badge>
                  </TableCell>
                  <TableCell>{socio.dataIscrizione}</TableCell>
                  <TableCell>
                    <div className="flex gap-1 flex-wrap">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => visualizzaCredenziali(socio)}
                        className="text-xs"
                      >
                        🔑 Credenziali
                      </Button>
                      <Button
                        size="sm"
                        variant={socio.stato === 'attivo' ? 'destructive' : 'default'}
                        onClick={() => {
                          const nuovoStato = socio.stato === 'attivo' ? 'sospeso' : 'attivo';
                          setSoci(soci.map(s =>
                            s.id === socio.id
                              ? { ...s, stato: nuovoStato }
                              : s
                          ));
                          toast({
                            title: "Stato aggiornato",
                            description: `${socio.nome} è ora ${nuovoStato}`,
                          });
                        }}
                        className="text-xs"
                      >
                        {socio.stato === 'attivo' ? 'Sospendi' : 'Attiva'}
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
