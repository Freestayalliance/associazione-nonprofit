"use client"

export default function AdminLoginSimple() {
  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#f9fafb',
      fontFamily: 'Arial'
    }}>
      <div style={{
        backgroundColor: 'white',
        padding: '40px',
        borderRadius: '10px',
        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
        width: '100%',
        maxWidth: '400px'
      }}>
        <h1 style={{
          fontSize: '32px',
          fontWeight: 'bold',
          textAlign: 'center',
          color: '#111827',
          marginBottom: '20px'
        }}>
          🔑 Login Admin
        </h1>

        <div style={{
          backgroundColor: '#dcfce7',
          padding: '15px',
          borderRadius: '8px',
          border: '2px solid #16a34a',
          marginBottom: '25px',
          textAlign: 'center'
        }}>
          <p style={{
            color: '#166534',
            fontWeight: 'bold',
            margin: 0
          }}>
            ✅ LOGIN PAGE FUNZIONA!
          </p>
        </div>

        <form style={{ marginBottom: '20px' }}>
          <div style={{ marginBottom: '15px' }}>
            <label style={{
              display: 'block',
              marginBottom: '5px',
              fontWeight: 'bold',
              color: '#374151'
            }}>
              Email:
            </label>
            <input
              type="email"
              style={{
                width: '100%',
                padding: '12px',
                border: '2px solid #d1d5db',
                borderRadius: '6px',
                fontSize: '16px'
              }}
              placeholder="admin@associazione.org"
            />
          </div>

          <div style={{ marginBottom: '20px' }}>
            <label style={{
              display: 'block',
              marginBottom: '5px',
              fontWeight: 'bold',
              color: '#374151'
            }}>
              Password:
            </label>
            <input
              type="password"
              style={{
                width: '100%',
                padding: '12px',
                border: '2px solid #d1d5db',
                borderRadius: '6px',
                fontSize: '16px'
              }}
              placeholder="admin123"
            />
          </div>

          <button
            type="button"
            style={{
              width: '100%',
              backgroundColor: '#3b82f6',
              color: 'white',
              padding: '12px',
              border: 'none',
              borderRadius: '6px',
              fontSize: '16px',
              fontWeight: 'bold',
              cursor: 'pointer'
            }}
            onClick={() => alert('Login semplice funziona! Il problema era nei componenti complessi.')}
          >
            🚀 Test Login
          </button>
        </form>

        <div style={{
          backgroundColor: '#fef3c7',
          padding: '15px',
          borderRadius: '8px',
          border: '1px solid #f59e0b'
        }}>
          <h3 style={{
            color: '#92400e',
            margin: '0 0 10px 0',
            fontSize: '16px'
          }}>
            🧪 Credenziali Demo:
          </h3>
          <p style={{
            margin: '5px 0',
            color: '#78350f',
            fontSize: '14px'
          }}>
            <strong>Email:</strong> admin@associazione.org
          </p>
          <p style={{
            margin: '5px 0',
            color: '#78350f',
            fontSize: '14px'
          }}>
            <strong>Password:</strong> admin123
          </p>
        </div>

        <div style={{ textAlign: 'center', marginTop: '20px' }}>
          <a
            href="/"
            style={{
              color: '#3b82f6',
              textDecoration: 'none',
              fontSize: '14px'
            }}
          >
            ← Torna alla homepage
          </a>
        </div>
      </div>
    </div>
  );
}
