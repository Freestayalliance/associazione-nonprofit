"use client"

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import PaymentService, { type PaymentRecord, type PaymentConfig } from '@/services/PaymentService';

export default function GestionePagamenti() {
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [filteredPayments, setFilteredPayments] = useState<PaymentRecord[]>([]);
  const [config, setConfig] = useState<PaymentConfig | null>(null);
  const [stats, setStats] = useState<any>(null);

  // Filtri e ricerca
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');

  // Stati UI
  const [selectedPayment, setSelectedPayment] = useState<PaymentRecord | null>(null);
  const [showConfigDialog, setShowConfigDialog] = useState(false);
  const [showRefundDialog, setShowRefundDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const { toast } = useToast();

  // Carica dati
  useEffect(() => {
    loadData();
  }, []);

  // Applica filtri
  useEffect(() => {
    applyFilters();
  }, [payments, searchTerm, statusFilter, typeFilter]);

  const loadData = () => {
    const paymentRecords = PaymentService.getPaymentRecords();
    const paymentConfig = PaymentService.getConfig();
    const paymentStats = PaymentService.getPaymentStats();

    setPayments(paymentRecords);
    setConfig(paymentConfig);
    setStats(paymentStats);
  };

  const applyFilters = () => {
    let filtered = [...payments];

    // Filtro per ricerca
    if (searchTerm) {
      filtered = filtered.filter(payment =>
        payment.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        payment.userEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
        payment.paymentIntentId.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filtro per stato
    if (statusFilter !== 'all') {
      filtered = filtered.filter(payment => payment.status === statusFilter);
    }

    // Filtro per tipo
    if (typeFilter !== 'all') {
      filtered = filtered.filter(payment => payment.metadata.type === typeFilter);
    }

    // Ordina per data (più recenti prima)
    filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    setFilteredPayments(filtered);
  };

  const updateConfig = async (newConfig: Partial<PaymentConfig>) => {
    const result = PaymentService.updateConfig(newConfig);

    if (result.success) {
      setConfig(PaymentService.getConfig());
      toast({
        title: "✅ Configurazione Aggiornata",
        description: result.message,
      });
    } else {
      toast({
        title: "Errore",
        description: result.message,
        variant: "destructive"
      });
    }
  };

  const handleRefund = async (paymentIntentId: string) => {
    setIsLoading(true);
    try {
      const result = await PaymentService.refundPayment(paymentIntentId, 'Rimborso richiesto da admin');

      if (result.success) {
        loadData(); // Ricarica i dati
        setShowRefundDialog(false);
        setSelectedPayment(null);

        toast({
          title: "✅ Rimborso Elaborato",
          description: result.message,
        });
      } else {
        toast({
          title: "Errore",
          description: result.message,
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Errore",
        description: "Errore nell'elaborazione del rimborso",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusBadge = (status: PaymentRecord['status']) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-600">✅ Completato</Badge>;
      case 'pending':
        return <Badge variant="secondary">⏳ In Sospeso</Badge>;
      case 'failed':
        return <Badge variant="destructive">❌ Fallito</Badge>;
      case 'refunded':
        return <Badge variant="outline">🔄 Rimborsato</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'membership_fee':
        return <Badge variant="outline" className="bg-blue-50">👥 Quota Socio</Badge>;
      case 'donation':
        return <Badge variant="outline" className="bg-green-50">💝 Donazione</Badge>;
      case 'event_ticket':
        return <Badge variant="outline" className="bg-purple-50">🎫 Biglietto</Badge>;
      default:
        return <Badge variant="outline">{type}</Badge>;
    }
  };

  const exportPayments = () => {
    const dataStr = JSON.stringify(filteredPayments, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `pagamenti-${new Date().toISOString().split('T')[0]}.json`;
    link.click();

    toast({
      title: "📥 Export Completato",
      description: `Esportati ${filteredPayments.length} pagamenti`,
    });
  };

  if (!config || !stats) {
    return (
      <div className="space-y-6">
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Caricamento sistema pagamenti...</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Header Navigazione Admin */}
      <div style={{
        backgroundColor: '#f8fafc',
        borderBottom: '2px solid #e2e8f0',
        padding: '16px 24px',
        marginBottom: '24px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <a
            href="/admin"
            style={{
              backgroundColor: '#3b82f6',
              color: 'white',
              padding: '8px 16px',
              borderRadius: '6px',
              textDecoration: 'none',
              fontSize: '14px',
              fontWeight: '500',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            ← 📊 Dashboard Admin
          </a>
          <span style={{ color: '#64748b', fontSize: '14px' }}>/</span>
          <span style={{ color: '#334155', fontSize: '14px', fontWeight: '500' }}>💳 Gestione Pagamenti</span>
        </div>
      </div>

      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestione Pagamenti</h1>
          <p className="text-gray-600">
            Monitora e gestisci tutti i pagamenti delle quote associative e donazioni
          </p>
        </div>

        {/* Statistiche principali */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Pagamenti Totali</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{stats.totalPayments}</div>
              <p className="text-sm text-gray-600">{stats.completedPayments} completati</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Entrate Totali</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                {PaymentService.formatPrice(stats.totalRevenue)}
              </div>
              <p className="text-sm text-gray-600">Da pagamenti completati</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">In Sospeso</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-yellow-600">{stats.pendingPayments}</div>
              <p className="text-sm text-gray-600">Da elaborare</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Falliti</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-600">{stats.failedPayments}</div>
              <p className="text-sm text-gray-600">Da ricontattare</p>
            </CardContent>
          </Card>
        </div>

        {/* Tabs Principali */}
        <Tabs defaultValue="payments" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="payments">💳 Pagamenti</TabsTrigger>
            <TabsTrigger value="statistics">📊 Statistiche</TabsTrigger>
            <TabsTrigger value="settings">⚙️ Configurazioni</TabsTrigger>
          </TabsList>

          {/* Tab Pagamenti */}
          <TabsContent value="payments" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Lista Pagamenti ({payments.length})</CardTitle>
                <CardDescription>
                  Gestisci tutti i pagamenti delle quote associative
                </CardDescription>

                {/* Filtri */}
                <div className="flex flex-wrap gap-4 pt-4">
                  <div className="flex-1 min-w-[200px]">
                    <Input
                      placeholder="Cerca per nome, email o ID..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>

                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Stato" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tutti</SelectItem>
                      <SelectItem value="completed">Completati</SelectItem>
                      <SelectItem value="pending">In Sospeso</SelectItem>
                      <SelectItem value="failed">Falliti</SelectItem>
                      <SelectItem value="refunded">Rimborsati</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tutti i Tipi</SelectItem>
                      <SelectItem value="membership_fee">Quote Soci</SelectItem>
                      <SelectItem value="donation">Donazioni</SelectItem>
                      <SelectItem value="event_ticket">Biglietti</SelectItem>
                    </SelectContent>
                  </Select>

                  <Button onClick={exportPayments} variant="outline">
                    📤 Export
                  </Button>
                </div>
              </CardHeader>

              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Socio</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Importo</TableHead>
                      <TableHead>Stato</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Azioni</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPayments.map((payment) => (
                      <TableRow key={payment.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{payment.userName}</div>
                            <div className="text-sm text-gray-600">{payment.userEmail}</div>
                            <div className="text-xs text-gray-500">
                              ID: {payment.paymentIntentId.slice(-8).toUpperCase()}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          {getTypeBadge(payment.metadata.type)}
                          {payment.metadata.period && (
                            <Badge variant="outline" className="ml-1 text-xs">
                              {payment.metadata.period === 'annual' ? 'Annuale' : 'Mensile'}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="font-bold">
                            {PaymentService.formatPrice(payment.amount)}
                          </div>
                          <div className="text-xs text-gray-500">{payment.currency.toUpperCase()}</div>
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(payment.status)}
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            {new Date(payment.createdAt).toLocaleDateString('it-IT')}
                          </div>
                          <div className="text-xs text-gray-500">
                            {new Date(payment.createdAt).toLocaleTimeString('it-IT')}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => setSelectedPayment(payment)}
                                >
                                  👁️ Dettagli
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-2xl">
                                <DialogHeader>
                                  <DialogTitle>Dettagli Pagamento</DialogTitle>
                                  <DialogDescription>
                                    Informazioni complete sul pagamento #{payment.paymentIntentId.slice(-8).toUpperCase()}
                                  </DialogDescription>
                                </DialogHeader>

                                {selectedPayment && (
                                  <div className="space-y-4">
                                    <div className="grid grid-cols-2 gap-4">
                                      <div>
                                        <Label>Socio</Label>
                                        <div className="font-medium">{selectedPayment.userName}</div>
                                        <div className="text-sm text-gray-600">{selectedPayment.userEmail}</div>
                                      </div>
                                      <div>
                                        <Label>Importo</Label>
                                        <div className="font-bold text-lg">
                                          {PaymentService.formatPrice(selectedPayment.amount)}
                                        </div>
                                      </div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                      <div>
                                        <Label>Stato</Label>
                                        <div>{getStatusBadge(selectedPayment.status)}</div>
                                      </div>
                                      <div>
                                        <Label>Tipo</Label>
                                        <div>{getTypeBadge(selectedPayment.metadata.type)}</div>
                                      </div>
                                    </div>

                                    <div>
                                      <Label>Descrizione</Label>
                                      <div className="text-sm">{selectedPayment.description}</div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                      <div>
                                        <Label>Data Creazione</Label>
                                        <div className="text-sm">
                                          {new Date(selectedPayment.createdAt).toLocaleString('it-IT')}
                                        </div>
                                      </div>
                                      {selectedPayment.completedAt && (
                                        <div>
                                          <Label>Data Completamento</Label>
                                          <div className="text-sm">
                                            {new Date(selectedPayment.completedAt).toLocaleString('it-IT')}
                                          </div>
                                        </div>
                                      )}
                                    </div>

                                    {selectedPayment.failureReason && (
                                      <div>
                                        <Label>Motivo Fallimento</Label>
                                        <div className="text-sm text-red-600">{selectedPayment.failureReason}</div>
                                      </div>
                                    )}

                                    <div className="bg-gray-50 p-3 rounded-lg">
                                      <Label>ID Transazione</Label>
                                      <div className="font-mono text-sm">{selectedPayment.paymentIntentId}</div>
                                    </div>
                                  </div>
                                )}
                              </DialogContent>
                            </Dialog>

                            {payment.status === 'completed' && (
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => {
                                  setSelectedPayment(payment);
                                  setShowRefundDialog(true);
                                }}
                              >
                                🔄 Rimborsa
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                {filteredPayments.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    📭 Nessun pagamento trovato con i filtri selezionati
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab Statistiche */}
          <TabsContent value="statistics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Pagamenti per Tipo */}
              <Card>
                <CardHeader>
                  <CardTitle>Pagamenti per Tipo</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(stats.paymentsByType).map(([type, count]) => (
                      <div key={type} className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          {getTypeBadge(type)}
                        </div>
                        <Badge variant="outline">{count as number}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Entrate per Mese */}
              <Card>
                <CardHeader>
                  <CardTitle>Entrate per Mese</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(stats.revenueByMonth)
                      .sort(([a], [b]) => b.localeCompare(a))
                      .slice(0, 6)
                      .map(([month, revenue]) => (
                        <div key={month} className="flex justify-between items-center">
                          <span className="text-sm">
                            {new Date(month + '-01').toLocaleDateString('it-IT', {
                              year: 'numeric',
                              month: 'long'
                            })}
                          </span>
                          <span className="font-bold">
                            {PaymentService.formatPrice(revenue as number)}
                          </span>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Riepilogo */}
            <Card>
              <CardHeader>
                <CardTitle>Riepilogo Generale</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">
                      {((stats.completedPayments / stats.totalPayments) * 100).toFixed(1)}%
                    </div>
                    <div className="text-sm text-blue-800">Tasso di Successo</div>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">
                      {PaymentService.formatPrice(stats.totalRevenue / stats.completedPayments || 0)}
                    </div>
                    <div className="text-sm text-green-800">Ticket Medio</div>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">
                      {stats.paymentsByType.membership_fee || 0}
                    </div>
                    <div className="text-sm text-purple-800">Quote Soci</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">
                      {Object.keys(stats.revenueByMonth).length}
                    </div>
                    <div className="text-sm text-orange-800">Mesi Attivi</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab Configurazioni */}
          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Configurazioni Pagamento</CardTitle>
                <CardDescription>
                  Gestisci le impostazioni del sistema di pagamento
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Prezzi */}
                <div>
                  <h4 className="font-medium mb-4">Quote Associative</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="annual-fee">Quota Annuale (€)</Label>
                      <Input
                        id="annual-fee"
                        type="number"
                        step="0.01"
                        value={config.membershipFees.annual}
                        onChange={(e) => updateConfig({
                          membershipFees: {
                            ...config.membershipFees,
                            annual: Number.parseFloat(e.target.value) || 0
                          }
                        })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="monthly-fee">Quota Mensile (€)</Label>
                      <Input
                        id="monthly-fee"
                        type="number"
                        step="0.01"
                        value={config.membershipFees.monthly}
                        onChange={(e) => updateConfig({
                          membershipFees: {
                            ...config.membershipFees,
                            monthly: Number.parseFloat(e.target.value) || 0
                          }
                        })}
                      />
                    </div>
                  </div>
                </div>

                {/* Valuta */}
                <div>
                  <Label htmlFor="currency">Valuta</Label>
                  <Select value={config.currency} onValueChange={(value) => updateConfig({ currency: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="EUR">EUR - Euro</SelectItem>
                      <SelectItem value="USD">USD - Dollaro</SelectItem>
                      <SelectItem value="GBP">GBP - Sterlina</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Modalità Test */}
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="test-mode">Modalità Test</Label>
                    <p className="text-sm text-gray-600">
                      Abilita per utilizzare l'ambiente di test di Stripe
                    </p>
                  </div>
                  <Switch
                    id="test-mode"
                    checked={config.testMode}
                    onCheckedChange={(checked) => updateConfig({ testMode: checked })}
                  />
                </div>

                {/* Chiave API */}
                <div>
                  <Label htmlFor="api-key">Chiave API Stripe</Label>
                  <Input
                    id="api-key"
                    type="password"
                    value={config.stripePublishableKey}
                    onChange={(e) => updateConfig({ stripePublishableKey: e.target.value })}
                    placeholder="pk_test_..."
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Usa le chiavi di test in modalità test, quelle live in produzione
                  </p>
                </div>

                {/* Status attuale */}
                <Alert className={config.testMode ? "border-yellow-200 bg-yellow-50" : "border-green-200 bg-green-50"}>
                  <AlertDescription className={config.testMode ? "text-yellow-800" : "text-green-800"}>
                    <strong>
                      {config.testMode ? "🧪 Modalità Test Attiva" : "🟢 Modalità Produzione"}
                    </strong>
                    <br />
                    {config.testMode
                      ? "I pagamenti sono simulati e non vengono addebitati realmente"
                      : "I pagamenti sono reali e vengono addebitati alle carte"
                    }
                  </AlertDescription>
                </Alert>

                <Button onClick={() => setShowConfigDialog(true)}>
                  💾 Salva Configurazioni
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Dialog Rimborso */}
        <Dialog open={showRefundDialog} onOpenChange={setShowRefundDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Conferma Rimborso</DialogTitle>
              <DialogDescription>
                Sei sicuro di voler rimborsare questo pagamento?
              </DialogDescription>
            </DialogHeader>

            {selectedPayment && (
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="font-medium">{selectedPayment.userName}</div>
                  <div className="text-sm text-gray-600">{selectedPayment.userEmail}</div>
                  <div className="font-bold text-lg mt-2">
                    {PaymentService.formatPrice(selectedPayment.amount)}
                  </div>
                </div>

                <Alert variant="destructive">
                  <AlertDescription>
                    ⚠️ <strong>Attenzione:</strong> Il rimborso modificherà lo stato del socio
                    a "sospeso" e la transazione non potrà essere annullata.
                  </AlertDescription>
                </Alert>

                <div className="flex gap-4">
                  <Button
                    onClick={() => handleRefund(selectedPayment.paymentIntentId)}
                    disabled={isLoading}
                    variant="destructive"
                    className="flex-1"
                  >
                    {isLoading ? "⏳ Elaborazione..." : "🔄 Conferma Rimborso"}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowRefundDialog(false)}
                    className="flex-1"
                  >
                    Annulla
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
