"use client"

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

interface AdminUser {
  id: number;
  email: string;
  name: string;
  role: string;
  createdAt: string;
  lastLogin?: string;
  isActive: boolean;
}

export default function GestioneAmministratori() {
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedAdmin, setSelectedAdmin] = useState<AdminUser | null>(null);

  // Form data
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    role: 'admin',
    password: ''
  });

  const { toast } = useToast();

  // Carica amministratori esistenti
  useEffect(() => {
    loadAdmins();
  }, []);

  const loadAdmins = () => {
    if (typeof window !== 'undefined') {
      const storedAdmins = localStorage.getItem('system-admins');
      if (storedAdmins) {
        setAdmins(JSON.parse(storedAdmins));
      } else {
        // Inizializza con admin di esempio per mostrare il sistema
        const defaultAdmins: AdminUser[] = [
          {
            id: 1,
            email: 'admin@associazione.org',
            name: 'Michael Franceschini',
            role: 'super-admin',
            createdAt: new Date().toISOString(),
            lastLogin: new Date().toISOString(),
            isActive: true
          },
          {
            id: 2,
            email: 'sara.bianchi@associazione.org',
            name: 'Sara Bianchi',
            role: 'admin',
            createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 giorni fa
            lastLogin: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 ore fa
            isActive: true
          },
          {
            id: 3,
            email: 'luca.verdi@associazione.org',
            name: 'Luca Verdi',
            role: 'moderatore',
            createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(), // 14 giorni fa
            lastLogin: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 1 giorno fa
            isActive: true
          },
          {
            id: 4,
            email: 'anna.rossi@associazione.org',
            name: 'Anna Rossi',
            role: 'editor',
            createdAt: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000).toISOString(), // 21 giorni fa
            lastLogin: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 giorni fa
            isActive: false // Disattivata per mostrare la funzionalità
          }
        ];
        setAdmins(defaultAdmins);
        localStorage.setItem('system-admins', JSON.stringify(defaultAdmins));

        // Inizializza anche le credenziali di login per gli admin di esempio
        const loginData = {
          'admin@associazione.org': {
            password: 'admin123',
            user: { id: 1, email: 'admin@associazione.org', name: 'Michael Franceschini', role: 'super-admin' }
          },
          'sara.bianchi@associazione.org': {
            password: 'sara123',
            user: { id: 2, email: 'sara.bianchi@associazione.org', name: 'Sara Bianchi', role: 'admin' }
          },
          'luca.verdi@associazione.org': {
            password: 'luca123',
            user: { id: 3, email: 'luca.verdi@associazione.org', name: 'Luca Verdi', role: 'moderatore' }
          },
          'anna.rossi@associazione.org': {
            password: 'anna123',
            user: { id: 4, email: 'anna.rossi@associazione.org', name: 'Anna Rossi', role: 'editor' }
          }
        };
        localStorage.setItem('admin-login-data', JSON.stringify(loginData));
      }
    }
  };

  const saveAdmins = (newAdmins: AdminUser[]) => {
    setAdmins(newAdmins);
    if (typeof window !== 'undefined') {
      localStorage.setItem('system-admins', JSON.stringify(newAdmins));

      // Aggiorna anche il file delle credenziali di login
      updateLoginCredentials(newAdmins);
    }
  };

  const updateLoginCredentials = (adminList: AdminUser[]) => {
    // Questo è un placeholder - in produzione dovresti avere un'API
    const loginData = JSON.parse(localStorage.getItem('admin-login-data') || '{}');

    adminList.forEach(admin => {
      if (admin.isActive) {
        loginData[admin.email] = {
          password: loginData[admin.email]?.password || 'defaultPassword123', // Mantieni password esistente
          user: {
            id: admin.id,
            email: admin.email,
            name: admin.name,
            role: admin.role
          }
        };
      }
    });

    localStorage.setItem('admin-login-data', JSON.stringify(loginData));
  };

  const addAdmin = () => {
    if (!formData.email || !formData.name || !formData.password) {
      toast({
        title: "Errore",
        description: "Tutti i campi sono obbligatori",
        variant: "destructive"
      });
      return;
    }

    // Controlla se l'email esiste già
    if (admins.some(admin => admin.email === formData.email)) {
      toast({
        title: "Errore",
        description: "Un amministratore con questa email esiste già",
        variant: "destructive"
      });
      return;
    }

    const newAdmin: AdminUser = {
      id: Math.max(...admins.map(a => a.id), 0) + 1,
      email: formData.email,
      name: formData.name,
      role: formData.role,
      createdAt: new Date().toISOString(),
      isActive: true
    };

    const updatedAdmins = [...admins, newAdmin];
    saveAdmins(updatedAdmins);

    // Salva anche la password separatamente per il login
    const loginData = JSON.parse(localStorage.getItem('admin-login-data') || '{}');
    loginData[formData.email] = {
      password: formData.password,
      user: {
        id: newAdmin.id,
        email: newAdmin.email,
        name: newAdmin.name,
        role: newAdmin.role
      }
    };
    localStorage.setItem('admin-login-data', JSON.stringify(loginData));

    setFormData({ email: '', name: '', role: 'admin', password: '' });
    setIsAddDialogOpen(false);

    toast({
      title: "Successo",
      description: `Amministratore ${newAdmin.name} aggiunto con successo`,
    });
  };

  const toggleAdminStatus = (adminId: number) => {
    const updatedAdmins = admins.map(admin =>
      admin.id === adminId
        ? { ...admin, isActive: !admin.isActive }
        : admin
    );
    saveAdmins(updatedAdmins);

    const admin = admins.find(a => a.id === adminId);
    toast({
      title: "Stato aggiornato",
      description: `Amministratore ${admin?.name} ${admin?.isActive ? 'disattivato' : 'attivato'}`,
    });
  };

  const deleteAdmin = (adminId: number) => {
    if (admins.length === 1) {
      toast({
        title: "Errore",
        description: "Non puoi eliminare l'ultimo amministratore",
        variant: "destructive"
      });
      return;
    }

    const admin = admins.find(a => a.id === adminId);
    const updatedAdmins = admins.filter(admin => admin.id !== adminId);
    saveAdmins(updatedAdmins);

    // Rimuovi anche dalle credenziali di login
    const loginData = JSON.parse(localStorage.getItem('admin-login-data') || '{}');
    if (admin) {
      delete loginData[admin.email];
      localStorage.setItem('admin-login-data', JSON.stringify(loginData));
    }

    toast({
      title: "Amministratore eliminato",
      description: `${admin?.name} è stato rimosso dal sistema`,
    });
  };

  const getRoleBadge = (role: string) => {
    const badges = {
      'super-admin': <Badge className="bg-red-600 text-white">🔥 Super Admin</Badge>,
      'admin': <Badge className="bg-blue-600 text-white">👨‍💼 Admin</Badge>,
      'moderatore': <Badge className="bg-yellow-600 text-white">⚖️ Moderatore</Badge>,
      'editor': <Badge className="bg-green-600 text-white">✏️ Editor</Badge>
    };
    return badges[role as keyof typeof badges] || <Badge variant="outline">{role}</Badge>;
  };

  return (
    <div>
      {/* Header Navigazione Admin */}
      <div style={{
        backgroundColor: '#f8fafc',
        borderBottom: '2px solid #e2e8f0',
        padding: '16px 24px',
        marginBottom: '24px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <a
            href="/admin"
            style={{
              backgroundColor: '#3b82f6',
              color: 'white',
              padding: '8px 16px',
              borderRadius: '6px',
              textDecoration: 'none',
              fontSize: '14px',
              fontWeight: '500',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            ← 📊 Dashboard Admin
          </a>
          <span style={{ color: '#64748b', fontSize: '14px' }}>/</span>
          <span style={{ color: '#334155', fontSize: '14px', fontWeight: '500' }}>👤 Gestione Amministratori</span>
        </div>
      </div>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Gestione Amministratori</h1>
            <p className="text-gray-600">Aggiungi, modifica e gestisci gli amministratori del sistema</p>
          </div>

          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-green-600 hover:bg-green-700">
                ➕ Aggiungi Amministratore
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Aggiungi Nuovo Amministratore</DialogTitle>
                <DialogDescription>
                  Inserisci i dati del nuovo amministratore
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    placeholder="admin@associazione.org"
                  />
                </div>

                <div>
                  <Label htmlFor="name">Nome Completo</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="Nome e Cognome"
                  />
                </div>

                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    placeholder="Password sicura"
                  />
                </div>

                <div>
                  <Label htmlFor="role">Ruolo</Label>
                  <Select value={formData.role} onValueChange={(value) => setFormData({...formData, role: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">👨‍💼 Admin</SelectItem>
                      <SelectItem value="moderatore">⚖️ Moderatore</SelectItem>
                      <SelectItem value="editor">✏️ Editor</SelectItem>
                      <SelectItem value="super-admin">🔥 Super Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button onClick={addAdmin} className="w-full">
                  Aggiungi Amministratore
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Statistiche */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Totali</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{admins.length}</div>
              <p className="text-sm text-gray-600">Amministratori</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Attivi</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                {admins.filter(a => a.isActive).length}
              </div>
              <p className="text-sm text-gray-600">In servizio</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Super Admin</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-600">
                {admins.filter(a => a.role === 'super-admin').length}
              </div>
              <p className="text-sm text-gray-600">Accesso totale</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Ultimo Accesso</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-lg font-bold text-purple-600">Oggi</div>
              <p className="text-sm text-gray-600">Attività recente</p>
            </CardContent>
          </Card>
        </div>

        {/* Tabella Amministratori */}
        <Card>
          <CardHeader>
            <CardTitle>Lista Amministratori ({admins.length})</CardTitle>
            <CardDescription>
              Gestisci i permessi e lo stato degli amministratori
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Amministratore</TableHead>
                  <TableHead>Ruolo</TableHead>
                  <TableHead>Stato</TableHead>
                  <TableHead>Aggiunto il</TableHead>
                  <TableHead>Azioni</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {admins.map((admin) => (
                  <TableRow key={admin.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{admin.name}</div>
                        <div className="text-sm text-gray-600">{admin.email}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {getRoleBadge(admin.role)}
                    </TableCell>
                    <TableCell>
                      <Badge variant={admin.isActive ? "default" : "secondary"}>
                        {admin.isActive ? "🟢 Attivo" : "🔴 Disattivo"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        {new Date(admin.createdAt).toLocaleDateString('it-IT')}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => toggleAdminStatus(admin.id)}
                        >
                          {admin.isActive ? "Disattiva" : "Attiva"}
                        </Button>
                        {admins.length > 1 && (
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => deleteAdmin(admin.id)}
                          >
                            Elimina
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Istruzioni */}
        <Card>
          <CardHeader>
            <CardTitle>📖 Come Aggiungere un Amministratore</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">1</div>
                <div>
                  <div className="font-medium">Clicca "Aggiungi Amministratore"</div>
                  <div className="text-sm text-gray-600">Compila il form con email, nome, password e ruolo</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">2</div>
                <div>
                  <div className="font-medium">Il nuovo admin può subito accedere</div>
                  <div className="text-sm text-gray-600">Usa l'email e password che hai impostato su /admin/login</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">3</div>
                <div>
                  <div className="font-medium">Gestisci permessi e stato</div>
                  <div className="text-sm text-gray-600">Puoi attivare/disattivare o eliminare admin dalla tabella</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
