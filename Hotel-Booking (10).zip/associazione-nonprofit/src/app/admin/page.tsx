"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function AdminDashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard Amministrativo</h1>
        <p className="text-gray-600">
          Panoramica generale del sito e delle attività dell'associazione
        </p>
      </div>

      {/* Statistiche principali */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Soci Totali</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">127</div>
            <p className="text-sm text-gray-600">+12 questo mese</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Entrate Mensili</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">€2,540</div>
            <p className="text-sm text-gray-600">Quote associative</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Votazioni Attive</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">3</div>
            <p className="text-sm text-gray-600">In corso</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Articoli Blog</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-600">18</div>
            <p className="text-sm text-gray-600">Pubblicati</p>
          </CardContent>
        </Card>
      </div>

      {/* Azioni rapide */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>👥 Gestione Soci</CardTitle>
            <CardDescription>
              Visualizza e gestisci i soci dell'associazione
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <Link href="/admin/soci">
                Gestisci Soci
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>💰 Finanze</CardTitle>
            <CardDescription>
              Monitora entrate, uscite e bilancio
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <Link href="/admin/finanze">
                Vedi Finanze
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>💬 Feedback Demo</CardTitle>
            <CardDescription>
              Visualizza feedback degli utenti demo
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <Link href="/admin/feedback">
                Vedi Feedback
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>📋 Log Attività</CardTitle>
            <CardDescription>
              Tracciamento azioni amministrative
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <Link href="/admin/attivita">
                Vedi Attività
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>⚙️ Impostazioni Profilo</CardTitle>
            <CardDescription>
              Gestisci account e preferenze
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <Link href="/admin/profilo">
                Modifica Profilo
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>🗳️ Gestione Votazioni</CardTitle>
            <CardDescription>
              Crea e gestisci le votazioni dell'associazione
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <Link href="/admin/votazioni">
                Gestisci Votazioni
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>🔄 Sistema Approvazione</CardTitle>
            <CardDescription>
              Workflow di approvazione per votazioni e proposte
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <Link href="/admin/approvazioni">
                Gestisci Approvazioni
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>👤 Gestione Amministratori</CardTitle>
            <CardDescription>
              Aggiungi, modifica e gestisci gli amministratori del sistema
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <Link href="/admin/gestione-admin">
                Gestisci Admin
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>📧 Sistema Email</CardTitle>
            <CardDescription>
              Configura email automatiche e monitora invii
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <Link href="/admin/email">
                Gestisci Email
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>📝 Gestione Blog</CardTitle>
            <CardDescription>
              Scrivi articoli, gestisci commenti e modera contenuti
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <Link href="/admin/blog">
                Gestisci Blog
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>📊 Dashboard Analytics</CardTitle>
            <CardDescription>
              Performance e statistiche in tempo reale
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <Link href="/admin/analytics">
                Visualizza Analytics
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>📦 Sistema Backup</CardTitle>
            <CardDescription>
              Backup automatici, ripristino dati e verifica integrità
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <Link href="/admin/backup">
                Gestisci Backup
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Attività recenti */}
      <Card>
        <CardHeader>
          <CardTitle>📋 Attività Recenti</CardTitle>
          <CardDescription>
            Ultime azioni sul sito
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between py-2 border-b">
              <div>
                <p className="font-medium">Nuovo socio registrato</p>
                <p className="text-sm text-gray-600">Alessandro Verdi - 2 ore fa</p>
              </div>
              <Badge>Nuovo</Badge>
            </div>
            <div className="flex items-center justify-between py-2 border-b">
              <div>
                <p className="font-medium">Articolo pubblicato</p>
                <p className="text-sm text-gray-600">"I nostri progetti per il 2024" - 5 ore fa</p>
              </div>
              <Badge variant="secondary">Blog</Badge>
            </div>
            <div className="flex items-center justify-between py-2">
              <div>
                <p className="font-medium">Votazione conclusa</p>
                <p className="text-sm text-gray-600">Ammissione Maria Rossi - 1 giorno fa</p>
              </div>
              <Badge variant="outline">Votazione</Badge>
            </div>
          </div>
        </CardContent>
      </Card>


    </div>
  );
}
