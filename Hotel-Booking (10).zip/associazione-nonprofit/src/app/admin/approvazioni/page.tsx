"use client"

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import {
  WorkflowApprovalService,
  type ApprovalRequest,
  type WorkflowStatus,
  type ApprovalAction,
  type UserRole
} from '@/services/WorkflowApprovalService';

export default function GestioneApprovazioni() {
  const [requests, setRequests] = useState<ApprovalRequest[]>([]);
  const [selectedRequest, setSelectedRequest] = useState<ApprovalRequest | null>(null);
  const [actionDialog, setActionDialog] = useState(false);
  const [selectedAction, setSelectedAction] = useState<ApprovalAction | ''>('');
  const [actionComment, setActionComment] = useState('');
  const [detailsDialog, setDetailsDialog] = useState(false);

  const [filtroStato, setFiltroStato] = useState<WorkflowStatus | 'all'>('all');
  const [filtroCategoria, setFiltroCategoria] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const { toast } = useToast();
  const workflowService = WorkflowApprovalService.getInstance();

  // Carica richieste all'avvio
  useEffect(() => {
    const unsubscribe = workflowService.addListener((requests) => {
      setRequests(requests);
    });

    return unsubscribe;
  }, [workflowService]);

  // Simula creazione richiesta di test
  const creaRichiestaTest = async () => {
    try {
      await workflowService.createApprovalRequest(
        `voting-${Date.now()}`,
        `Votazione Test ${new Date().getHours()}:${new Date().getMinutes()}`,
        'membership',
        'admin',
        'normal'
      );

      toast({
        title: "Richiesta di test creata",
        description: "È stata creata una richiesta di approvazione di esempio",
      });
    } catch (error) {
      toast({
        title: "Errore",
        description: "Errore nella creazione della richiesta di test",
        variant: "destructive"
      });
    }
  };

  const processaAzione = async () => {
    if (!selectedRequest || !selectedAction) return;

    try {
      await workflowService.processApproval(
        selectedRequest.id,
        selectedAction,
        'admin', // In produzione questo verrebbe dal sistema di autenticazione
        actionComment || undefined
      );

      setActionDialog(false);
      setSelectedAction('');
      setActionComment('');
      setSelectedRequest(null);

      const actionText = {
        'approve': 'approvata',
        'reject': 'rigettata',
        'request_revision': 'richiesta revisione',
        'review': 'presa in carico per revisione',
        'resubmit': 'riinviata',
        'submit_for_review': 'inviata per revisione'
      }[selectedAction] || 'aggiornata';

      toast({
        title: "Azione completata",
        description: `La richiesta è stata ${actionText}`,
      });
    } catch (error) {
      toast({
        title: "Errore",
        description: (error as Error).message,
        variant: "destructive"
      });
    }
  };

  const getStatoBadge = (stato: WorkflowStatus) => {
    const badges = {
      'draft': <Badge variant="outline">📝 Bozza</Badge>,
      'pending_review': <Badge className="bg-yellow-600 text-white">⏳ In Attesa Revisione</Badge>,
      'under_review': <Badge className="bg-blue-600 text-white">👁️ In Revisione</Badge>,
      'pending_approval': <Badge className="bg-orange-600 text-white">⏰ In Attesa Approvazione</Badge>,
      'approved': <Badge className="bg-green-600 text-white">✅ Approvata</Badge>,
      'rejected': <Badge className="bg-red-600 text-white">❌ Rigettata</Badge>,
      'revision_required': <Badge className="bg-purple-600 text-white">📝 Revisione Richiesta</Badge>
    };
    return badges[stato] || <Badge variant="secondary">{stato}</Badge>;
  };

  const getPriorityBadge = (priority: string) => {
    const badges = {
      'urgent': <Badge className="bg-red-600 text-white">🚨 Urgente</Badge>,
      'high': <Badge className="bg-orange-600 text-white">⚡ Alta</Badge>,
      'normal': <Badge variant="outline">📋 Normale</Badge>,
      'low': <Badge className="bg-gray-600 text-white">🔽 Bassa</Badge>
    };
    return badges[priority as keyof typeof badges] || <Badge variant="secondary">{priority}</Badge>;
  };

  const getCategoryBadge = (category: string) => {
    const badges = {
      'membership': <Badge className="bg-blue-600 text-white">👥 Ammissione</Badge>,
      'proposal': <Badge className="bg-purple-600 text-white">💡 Proposta</Badge>,
      'budget': <Badge className="bg-yellow-600 text-white">💰 Bilancio</Badge>,
      'board': <Badge className="bg-indigo-600 text-white">👨‍💼 Consiglio</Badge>,
      'policy': <Badge className="bg-red-600 text-white">📋 Normativa</Badge>,
      'emergency': <Badge className="bg-orange-600 text-white">🚨 Emergenza</Badge>
    };
    return badges[category as keyof typeof badges] || <Badge variant="secondary">{category}</Badge>;
  };

  // Filtra richieste
  const richiesteFiltrate = requests.filter(r => {
    if (filtroStato !== 'all' && r.status !== filtroStato) return false;
    if (filtroCategoria !== 'all' && r.category !== filtroCategoria) return false;
    if (searchTerm && !r.votingTitle.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    return true;
  });

  const stats = workflowService.getApprovalStatistics();

  return (
    <div>
      {/* Header Navigazione Admin */}
      <div style={{
        backgroundColor: '#f8fafc',
        borderBottom: '2px solid #e2e8f0',
        padding: '16px 24px',
        marginBottom: '24px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <a
            href="/admin"
            style={{
              backgroundColor: '#3b82f6',
              color: 'white',
              padding: '8px 16px',
              borderRadius: '6px',
              textDecoration: 'none',
              fontSize: '14px',
              fontWeight: '500',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            ← 📊 Dashboard Admin
          </a>
          <span style={{ color: '#64748b', fontSize: '14px' }}>/</span>
          <span style={{ color: '#334155', fontSize: '14px', fontWeight: '500' }}>🔄 Sistema Approvazione Workflow</span>
        </div>
      </div>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Sistema Approvazione Workflow</h1>
            <p className="text-gray-600">Gestione completa del workflow di approvazione per votazioni e proposte</p>
          </div>

          <div className="flex gap-2">
            <Button onClick={creaRichiestaTest} variant="outline">
              🧪 Crea Richiesta Test
            </Button>
          </div>
        </div>

        {/* Statistiche Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Totali</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{stats.total}</div>
              <p className="text-sm text-gray-600">Richieste</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">In Sospeso</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600">{stats.pending}</div>
              <p className="text-sm text-gray-600">Da processare</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Approvate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{stats.approved}</div>
              <p className="text-sm text-gray-600">Completate</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Rigettate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-600">{stats.rejected}</div>
              <p className="text-sm text-gray-600">Non approvate</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Scadute</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-600">{stats.overdue}</div>
              <p className="text-sm text-gray-600">In ritardo</p>
            </CardContent>
          </Card>
        </div>

        {/* Filtri */}
        <Card>
          <CardHeader>
            <CardTitle>Filtri e Ricerca</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <div className="flex-1">
                <Label htmlFor="search">Ricerca</Label>
                <Input
                  id="search"
                  placeholder="Cerca per titolo votazione..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="stato">Stato</Label>
                <Select value={filtroStato} onValueChange={(value: WorkflowStatus | 'all') => setFiltroStato(value)}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tutti gli stati</SelectItem>
                    <SelectItem value="pending_review">In Attesa Revisione</SelectItem>
                    <SelectItem value="under_review">In Revisione</SelectItem>
                    <SelectItem value="pending_approval">In Attesa Approvazione</SelectItem>
                    <SelectItem value="approved">Approvate</SelectItem>
                    <SelectItem value="rejected">Rigettate</SelectItem>
                    <SelectItem value="revision_required">Revisione Richiesta</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="categoria">Categoria</Label>
                <Select value={filtroCategoria} onValueChange={setFiltroCategoria}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tutte le categorie</SelectItem>
                    <SelectItem value="membership">Ammissione</SelectItem>
                    <SelectItem value="proposal">Proposta</SelectItem>
                    <SelectItem value="budget">Bilancio</SelectItem>
                    <SelectItem value="board">Consiglio</SelectItem>
                    <SelectItem value="policy">Normative</SelectItem>
                    <SelectItem value="emergency">Emergenza</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabella Richieste */}
        <Card>
          <CardHeader>
            <CardTitle>Richieste di Approvazione ({richiesteFiltrate.length})</CardTitle>
            <CardDescription>
              Gestione completa del workflow di approvazione
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Votazione & Categoria</TableHead>
                  <TableHead>Stato & Priorità</TableHead>
                  <TableHead>Workflow</TableHead>
                  <TableHead>Tempistiche</TableHead>
                  <TableHead>Azioni</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {richiesteFiltrate.map((request) => {
                  const currentStep = request.steps[request.currentStep];
                  const progressPercentage = ((request.completedSteps.length) / request.steps.length) * 100;

                  return (
                    <TableRow key={request.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{request.votingTitle}</div>
                          <div className="text-sm text-gray-600">ID: {request.votingId}</div>
                          <div className="mt-1">{getCategoryBadge(request.category)}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-2">
                          {getStatoBadge(request.status)}
                          {getPriorityBadge(request.priority)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-2">
                          <div className="text-sm">
                            <div>Step {request.currentStep + 1} di {request.steps.length}</div>
                            {currentStep && (
                              <div className="text-blue-600 font-medium">{currentStep.name}</div>
                            )}
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-blue-600 h-2 rounded-full transition-all"
                              style={{ width: `${progressPercentage}%` }}
                            />
                          </div>
                          <div className="text-xs text-gray-600">
                            {request.completedSteps.length} completati, {request.pendingSteps.length} in sospeso
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm space-y-1">
                          <div>Richiesta: {new Date(request.requestedAt).toLocaleDateString('it-IT')}</div>
                          <div>Da: {request.requestedBy}</div>
                          {request.deadline && (
                            <div className="text-red-600">
                              Scadenza: {new Date(request.deadline).toLocaleDateString('it-IT')}
                            </div>
                          )}
                          {request.auditTrail.length > 1 && (
                            <div className="text-gray-600">
                              Ultimo aggiornamento: {new Date(request.auditTrail[request.auditTrail.length - 1].timestamp).toLocaleDateString('it-IT')}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1 flex-wrap">
                          {/* Visualizza dettagli */}
                          <Dialog open={detailsDialog && selectedRequest?.id === request.id} onOpenChange={(open) => {
                            setDetailsDialog(open);
                            if (open) setSelectedRequest(request);
                          }}>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="outline">
                                👁️ Dettagli
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                              <DialogHeader>
                                <DialogTitle>Dettagli Richiesta: {request.votingTitle}</DialogTitle>
                                <DialogDescription>
                                  Storico completo del workflow di approvazione
                                </DialogDescription>
                              </DialogHeader>

                              <Tabs defaultValue="info" className="w-full">
                                <TabsList className="grid w-full grid-cols-3">
                                  <TabsTrigger value="info">Informazioni</TabsTrigger>
                                  <TabsTrigger value="workflow">Workflow</TabsTrigger>
                                  <TabsTrigger value="audit">Audit Trail</TabsTrigger>
                                </TabsList>

                                <TabsContent value="info" className="space-y-4">
                                  <div className="grid grid-cols-2 gap-4">
                                    <div>
                                      <Label>ID Richiesta</Label>
                                      <Input value={request.id} readOnly />
                                    </div>
                                    <div>
                                      <Label>ID Votazione</Label>
                                      <Input value={request.votingId} readOnly />
                                    </div>
                                    <div>
                                      <Label>Stato</Label>
                                      <div className="pt-2">{getStatoBadge(request.status)}</div>
                                    </div>
                                    <div>
                                      <Label>Priorità</Label>
                                      <div className="pt-2">{getPriorityBadge(request.priority)}</div>
                                    </div>
                                    <div>
                                      <Label>Categoria</Label>
                                      <div className="pt-2">{getCategoryBadge(request.category)}</div>
                                    </div>
                                    <div>
                                      <Label>Richiesta da</Label>
                                      <Input value={request.requestedBy} readOnly />
                                    </div>
                                  </div>
                                  <div>
                                    <Label>Tags</Label>
                                    <div className="flex gap-2 mt-2">
                                      {request.tags.map((tag) => (
                                        <Badge key={tag} variant="outline">{tag}</Badge>
                                      ))}
                                    </div>
                                  </div>
                                </TabsContent>

                                <TabsContent value="workflow" className="space-y-4">
                                  <div className="space-y-4">
                                    {request.steps.map((step, index) => {
                                      const isCompleted = request.completedSteps.includes(step.id);
                                      const isCurrent = index === request.currentStep;
                                      const isPending = request.pendingSteps.includes(step.id);

                                      return (
                                        <div key={step.id} className={`p-4 rounded-lg border ${
                                          isCompleted ? 'bg-green-50 border-green-200' :
                                          isCurrent ? 'bg-blue-50 border-blue-200' :
                                          'bg-gray-50 border-gray-200'
                                        }`}>
                                          <div className="flex justify-between items-start">
                                            <div>
                                              <div className="font-medium flex items-center gap-2">
                                                {isCompleted ? '✅' : isCurrent ? '🔄' : '⏳'}
                                                {step.name}
                                              </div>
                                              <div className="text-sm text-gray-600">{step.description}</div>
                                              <div className="text-xs text-gray-500 mt-1">
                                                Ruolo richiesto: {step.requiredRole} | Ordine: {step.order}
                                              </div>
                                            </div>
                                            <Badge variant={isCompleted ? 'default' : isCurrent ? 'destructive' : 'secondary'}>
                                              {isCompleted ? 'Completato' : isCurrent ? 'In Corso' : 'In Attesa'}
                                            </Badge>
                                          </div>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </TabsContent>

                                <TabsContent value="audit" className="space-y-4">
                                  <div className="space-y-3">
                                    {request.auditTrail.map((entry) => (
                                      <div key={entry.id} className="p-3 border rounded-lg">
                                        <div className="flex justify-between items-start">
                                          <div>
                                            <div className="font-medium">{entry.action}</div>
                                            <div className="text-sm text-gray-600">
                                              {entry.userName} ({entry.userRole})
                                            </div>
                                            {entry.comment && (
                                              <div className="text-sm text-gray-800 mt-1 italic">
                                                "{entry.comment}"
                                              </div>
                                            )}
                                          </div>
                                          <div className="text-xs text-gray-500">
                                            {new Date(entry.timestamp).toLocaleString('it-IT')}
                                          </div>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </TabsContent>
                              </Tabs>
                            </DialogContent>
                          </Dialog>

                          {/* Azioni workflow */}
                          {['pending_review', 'under_review', 'pending_approval', 'revision_required'].includes(request.status) && (
                            <Dialog open={actionDialog && selectedRequest?.id === request.id} onOpenChange={(open) => {
                              setActionDialog(open);
                              if (open) setSelectedRequest(request);
                            }}>
                              <DialogTrigger asChild>
                                <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                                  ⚡ Azioni
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Azioni Workflow</DialogTitle>
                                  <DialogDescription>
                                    Scegli l'azione da eseguire per questa richiesta
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div>
                                    <Label>Azione</Label>
                                    <Select value={selectedAction} onValueChange={(value: ApprovalAction) => setSelectedAction(value)}>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Seleziona un'azione" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {request.status === 'pending_review' && (
                                          <SelectItem value="review">👁️ Prendi in Carico</SelectItem>
                                        )}
                                        {['under_review', 'pending_approval'].includes(request.status) && (
                                          <>
                                            <SelectItem value="approve">✅ Approva</SelectItem>
                                            <SelectItem value="reject">❌ Rigetta</SelectItem>
                                            <SelectItem value="request_revision">📝 Richiedi Revisione</SelectItem>
                                          </>
                                        )}
                                        {request.status === 'revision_required' && (
                                          <SelectItem value="resubmit">🔄 Reinvia</SelectItem>
                                        )}
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <div>
                                    <Label>Commento (opzionale)</Label>
                                    <Textarea
                                      value={actionComment}
                                      onChange={(e) => setActionComment(e.target.value)}
                                      placeholder="Aggiungi un commento per questa azione..."
                                      rows={3}
                                    />
                                  </div>
                                  <Button onClick={processaAzione} className="w-full" disabled={!selectedAction}>
                                    Esegui Azione
                                  </Button>
                                </div>
                              </DialogContent>
                            </Dialog>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>

            {richiesteFiltrate.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <p>Nessuna richiesta di approvazione trovata per i filtri selezionati</p>
                <Button onClick={creaRichiestaTest} className="mt-4" variant="outline">
                  🧪 Crea una richiesta di test per iniziare
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Statistiche Avanzate */}
        {stats.total > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Distribuzione per Stato */}
            <Card>
              <CardHeader>
                <CardTitle>Distribuzione per Stato</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(stats.byStatus).map(([status, count]) => (
                    <div key={status} className="flex justify-between items-center">
                      <span className="text-sm">{getStatoBadge(status as WorkflowStatus)}</span>
                      <Badge variant="outline">{count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Distribuzione per Categoria */}
            <Card>
              <CardHeader>
                <CardTitle>Distribuzione per Categoria</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(stats.byCategory).map(([category, count]) => (
                    <div key={category} className="flex justify-between items-center">
                      <span className="text-sm">{getCategoryBadge(category)}</span>
                      <Badge variant="outline">{count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Attività Recente */}
        {stats.recentActivity.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Attività Recente</CardTitle>
              <CardDescription>Ultime richieste elaborate</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {stats.recentActivity.slice(0, 5).map((request) => (
                  <div key={request.id} className="flex justify-between items-center p-3 border rounded-lg">
                    <div>
                      <div className="font-medium">{request.votingTitle}</div>
                      <div className="text-sm text-gray-600">
                        {getCategoryBadge(request.category)} {getStatoBadge(request.status)}
                      </div>
                    </div>
                    <div className="text-sm text-gray-500">
                      {new Date(request.requestedAt).toLocaleDateString('it-IT')}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
