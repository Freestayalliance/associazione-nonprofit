"use client"

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import BackupService, { type BackupData, type BackupConfig, type BackupStats, type DataIntegrityReport } from '@/services/BackupService';

export default function GestioneBackup() {
  const [stats, setStats] = useState<BackupStats | null>(null);
  const [config, setConfig] = useState<BackupConfig | null>(null);
  const [backupList, setBackupList] = useState<Array<{ id: string; backup: BackupData }>>([]);
  const [integrityReport, setIntegrityReport] = useState<DataIntegrityReport | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedBackup, setSelectedBackup] = useState<{ id: string; backup: BackupData } | null>(null);
  const [importData, setImportData] = useState('');
  const [backupDescription, setBackupDescription] = useState('');
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showRestoreDialog, setShowRestoreDialog] = useState(false);
  const [showConfigDialog, setShowConfigDialog] = useState(false);
  const [selectiveRestoreKeys, setSelectiveRestoreKeys] = useState<string[]>([]);

  const { toast } = useToast();

  // Carica dati iniziali
  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setStats(BackupService.getStats());
    setConfig(BackupService.getConfig());
    setBackupList(BackupService.getBackupList());
  };

  // Crea backup manuale
  const createManualBackup = async () => {
    setIsLoading(true);
    try {
      const result = await BackupService.createBackup(
        backupDescription || undefined,
        'manual'
      );

      if (result.success) {
        toast({
          title: "✅ Backup Creato!",
          description: result.message,
        });
        setBackupDescription('');
        loadData();
      } else {
        toast({
          title: "Errore",
          description: result.message,
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Errore",
        description: "Errore nella creazione del backup",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Aggiorna configurazione
  const updateConfiguration = async (newConfig: Partial<BackupConfig>) => {
    const result = BackupService.updateConfig(newConfig);
    if (result) {
      setConfig(BackupService.getConfig());
      toast({
        title: "✅ Configurazione Aggiornata",
        description: "Le impostazioni backup sono state salvate",
      });
      setShowConfigDialog(false);
    } else {
      toast({
        title: "Errore",
        description: "Errore nell'aggiornamento della configurazione",
        variant: "destructive"
      });
    }
  };

  // Elimina backup
  const deleteBackup = (backupId: string) => {
    if (confirm("Sei sicuro di voler eliminare questo backup?")) {
      const result = BackupService.deleteBackup(backupId);
      if (result.success) {
        toast({
          title: "🗑️ Backup Eliminato",
          description: result.message,
        });
        loadData();
      } else {
        toast({
          title: "Errore",
          description: result.message,
          variant: "destructive"
        });
      }
    }
  };

  // Ripristina backup
  const restoreBackup = async () => {
    if (!selectedBackup) return;

    setIsLoading(true);
    try {
      const result = await BackupService.restoreBackup(
        selectedBackup.id,
        {
          selectiveRestore: selectiveRestoreKeys.length > 0 ? selectiveRestoreKeys : undefined,
          createRestorePoint: true
        }
      );

      if (result.success) {
        toast({
          title: "✅ Restore Completato!",
          description: result.message,
        });
        setShowRestoreDialog(false);
        setSelectedBackup(null);
        setSelectiveRestoreKeys([]);
        loadData();
        // Refresh della pagina per mostrare i dati ripristinati
        setTimeout(() => window.location.reload(), 1000);
      } else {
        toast({
          title: "Errore",
          description: result.message,
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Errore",
        description: "Errore nel ripristino del backup",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Download backup
  const downloadBackup = (backupId: string) => {
    try {
      BackupService.downloadBackup(backupId);
      toast({
        title: "📥 Download Avviato",
        description: "Il backup è stato scaricato",
      });
    } catch (error) {
      toast({
        title: "Errore",
        description: "Errore nel download del backup",
        variant: "destructive"
      });
    }
  };

  // Import backup
  const importBackup = async () => {
    if (!importData.trim()) {
      toast({
        title: "Errore",
        description: "Inserisci i dati del backup da importare",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const result = await BackupService.importBackup(importData);
      if (result.success) {
        toast({
          title: "✅ Backup Importato!",
          description: result.message,
        });
        setImportData('');
        setShowImportDialog(false);
        loadData();
      } else {
        toast({
          title: "Errore",
          description: result.message,
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Errore",
        description: "Errore nell'importazione del backup",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Verifica integrità dati
  const checkDataIntegrity = () => {
    setIsLoading(true);
    try {
      const report = BackupService.checkDataIntegrity();
      setIntegrityReport(report);

      if (report.isValid) {
        toast({
          title: "✅ Integrità Verificata",
          description: `Tutti i ${report.summary.validRecords} record sono validi`,
        });
      } else {
        toast({
          title: "⚠️ Problemi Rilevati",
          description: `${report.errors.length} errori trovati nei dati`,
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Errore",
        description: "Errore nella verifica di integrità",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getBackupTypeBadge = (type: string) => {
    switch (type) {
      case 'automatic':
        return <Badge variant="secondary">🤖 Automatico</Badge>;
      case 'manual':
        return <Badge variant="outline">👤 Manuale</Badge>;
      case 'scheduled':
        return <Badge className="bg-blue-600">⏰ Programmato</Badge>;
      default:
        return <Badge variant="outline">{type}</Badge>;
    }
  };

  if (!stats || !config) {
    return (
      <div className="space-y-6">
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Caricamento sistema backup...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Sistema Backup & Sincronizzazione</h1>
        <p className="text-gray-600">
          Proteggi i dati dell'associazione con backup automatici e ripristini sicuri
        </p>
      </div>

      {/* Statistiche Principali */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Backup Totali</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{stats.totalBackups}</div>
            <p className="text-sm text-gray-600">
              {stats.averageSize > 0 && `Media: ${formatBytes(stats.averageSize)}`}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Spazio Utilizzato</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{formatBytes(stats.totalSize)}</div>
            <p className="text-sm text-gray-600">Dati protetti</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Ultimo Backup</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold text-purple-600">
              {stats.lastBackup
                ? new Date(stats.lastBackup).toLocaleString('it-IT')
                : 'Nessuno'
              }
            </div>
            <p className="text-sm text-gray-600">
              {config.autoBackupEnabled ? `Prossimo: ${config.backupFrequency}` : 'Manuale'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Stato Sistema</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${config.autoBackupEnabled ? 'bg-green-500' : 'bg-gray-400'}`}></div>
              <span className="font-bold text-gray-900">
                {config.autoBackupEnabled ? 'Attivo' : 'Inattivo'}
              </span>
            </div>
            <p className="text-sm text-gray-600">
              {config.autoBackupEnabled ? `Backup ${config.backupFrequency}` : 'Solo manuali'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Azioni Rapide */}
      <Card>
        <CardHeader>
          <CardTitle>🚀 Azioni Rapide</CardTitle>
          <CardDescription>
            Operazioni immediate sul sistema di backup
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Button
              onClick={createManualBackup}
              disabled={isLoading}
              className="bg-green-600 hover:bg-green-700"
            >
              {isLoading ? "⏳ Creando..." : "💾 Crea Backup Ora"}
            </Button>

            <Button
              onClick={checkDataIntegrity}
              disabled={isLoading}
              variant="outline"
              className="border-blue-600 text-blue-600 hover:bg-blue-50"
            >
              🔍 Verifica Integrità
            </Button>

            <Dialog open={showConfigDialog} onOpenChange={setShowConfigDialog}>
              <DialogTrigger asChild>
                <Button variant="outline">⚙️ Configurazioni</Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Configurazioni Backup</DialogTitle>
                  <DialogDescription>
                    Gestisci le impostazioni del sistema di backup
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="auto-backup">Backup Automatici</Label>
                    <Switch
                      id="auto-backup"
                      checked={config.autoBackupEnabled}
                      onCheckedChange={(enabled) => updateConfiguration({ autoBackupEnabled: enabled })}
                    />
                  </div>

                  <div>
                    <Label>Frequenza Backup</Label>
                    <Select
                      value={config.backupFrequency}
                      onValueChange={(frequency) => updateConfiguration({ backupFrequency: frequency as any })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hourly">⏰ Ogni ora</SelectItem>
                        <SelectItem value="daily">📅 Giornaliera</SelectItem>
                        <SelectItem value="weekly">📆 Settimanale</SelectItem>
                        <SelectItem value="monthly">🗓️ Mensile</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Backup Massimi</Label>
                    <Input
                      type="number"
                      value={config.maxBackups}
                      onChange={(e) => updateConfiguration({ maxBackups: Number.parseInt(e.target.value) })}
                      min={1}
                      max={100}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="compression">Compressione</Label>
                    <Switch
                      id="compression"
                      checked={config.compressionEnabled}
                      onCheckedChange={(enabled) => updateConfiguration({ compressionEnabled: enabled })}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="integrity">Verifica Integrità</Label>
                    <Switch
                      id="integrity"
                      checked={config.dataIntegrityChecks}
                      onCheckedChange={(enabled) => updateConfiguration({ dataIntegrityChecks: enabled })}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="notifications">Notifiche</Label>
                    <Switch
                      id="notifications"
                      checked={config.notifyOnBackup}
                      onCheckedChange={(enabled) => updateConfiguration({ notifyOnBackup: enabled })}
                    />
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
              <DialogTrigger asChild>
                <Button variant="outline">📤 Importa Backup</Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Importa Backup</DialogTitle>
                  <DialogDescription>
                    Carica un backup precedentemente esportato
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Dati Backup (JSON)</Label>
                    <Textarea
                      value={importData}
                      onChange={(e) => setImportData(e.target.value)}
                      placeholder="Incolla qui i dati JSON del backup..."
                      rows={10}
                      className="font-mono text-sm"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={importBackup} disabled={isLoading}>
                      {isLoading ? "⏳ Importando..." : "📥 Importa"}
                    </Button>
                    <Button variant="outline" onClick={() => setShowImportDialog(false)}>
                      Annulla
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {/* Form Backup Manuale */}
          <div className="mt-6 pt-4 border-t">
            <Label>Descrizione Backup (opzionale)</Label>
            <div className="flex gap-2 mt-2">
              <Input
                value={backupDescription}
                onChange={(e) => setBackupDescription(e.target.value)}
                placeholder="Es: Backup prima aggiornamento sistema..."
                className="flex-1"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs Principali */}
      <Tabs defaultValue="backups" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="backups">📦 Lista Backup</TabsTrigger>
          <TabsTrigger value="integrity">🔍 Integrità Dati</TabsTrigger>
          <TabsTrigger value="stats">📊 Statistiche</TabsTrigger>
        </TabsList>

        {/* Tab Lista Backup */}
        <TabsContent value="backups" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Lista Backup ({backupList.length})</CardTitle>
              <CardDescription>
                Gestisci tutti i backup salvati nel sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              {backupList.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data/Ora</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Descrizione</TableHead>
                      <TableHead>Dimensioni</TableHead>
                      <TableHead>Creato da</TableHead>
                      <TableHead>Azioni</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {backupList.map(({ id, backup }) => (
                      <TableRow key={id}>
                        <TableCell>
                          <div className="font-medium">
                            {new Date(backup.timestamp).toLocaleDateString('it-IT')}
                          </div>
                          <div className="text-sm text-gray-500">
                            {new Date(backup.timestamp).toLocaleTimeString('it-IT')}
                          </div>
                        </TableCell>
                        <TableCell>
                          {getBackupTypeBadge(backup.metadata.type)}
                        </TableCell>
                        <TableCell>
                          <div className="max-w-xs truncate" title={backup.metadata.description}>
                            {backup.metadata.description}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">
                            {formatBytes(backup.metadata.size)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">{backup.metadata.createdBy}</div>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1 flex-wrap">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setSelectedBackup({ id, backup });
                                setShowRestoreDialog(true);
                              }}
                              className="text-xs"
                            >
                              🔄 Ripristina
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => downloadBackup(id)}
                              className="text-xs"
                            >
                              📥 Download
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => deleteBackup(id)}
                              className="text-xs"
                            >
                              🗑️
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-12 text-gray-500">
                  📦 Nessun backup disponibile
                  <br />
                  <Button
                    onClick={createManualBackup}
                    className="mt-4"
                    disabled={isLoading}
                  >
                    Crea il Primo Backup
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab Integrità Dati */}
        <TabsContent value="integrity" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Verifica Integrità Dati</CardTitle>
              <CardDescription>
                Controlla la validità e coerenza di tutti i dati dell'associazione
              </CardDescription>
            </CardHeader>
            <CardContent>
              {integrityReport ? (
                <div className="space-y-4">
                  {/* Riepilogo */}
                  <Alert className={integrityReport.isValid ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}>
                    <AlertDescription className="font-medium">
                      {integrityReport.isValid ? (
                        <span className="text-green-800">✅ Tutti i dati sono integri e validi</span>
                      ) : (
                        <span className="text-red-800">⚠️ Rilevati problemi nei dati</span>
                      )}
                    </AlertDescription>
                  </Alert>

                  {/* Statistiche */}
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{integrityReport.summary.totalRecords}</div>
                      <div className="text-sm text-blue-800">Totali</div>
                    </div>
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{integrityReport.summary.validRecords}</div>
                      <div className="text-sm text-green-800">Validi</div>
                    </div>
                    <div className="text-center p-3 bg-red-50 rounded-lg">
                      <div className="text-2xl font-bold text-red-600">{integrityReport.summary.invalidRecords}</div>
                      <div className="text-sm text-red-800">Invalidi</div>
                    </div>
                    <div className="text-center p-3 bg-yellow-50 rounded-lg">
                      <div className="text-2xl font-bold text-yellow-600">{integrityReport.summary.duplicates}</div>
                      <div className="text-sm text-yellow-800">Duplicati</div>
                    </div>
                    <div className="text-center p-3 bg-orange-50 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">{integrityReport.summary.missingReferences}</div>
                      <div className="text-sm text-orange-800">Ref. Mancanti</div>
                    </div>
                  </div>

                  {/* Tabelle Verificate */}
                  <div>
                    <h4 className="font-medium mb-2">Tabelle Verificate:</h4>
                    <div className="flex flex-wrap gap-2">
                      {integrityReport.checkedTables.map(table => (
                        <Badge key={table} variant="outline">{table}</Badge>
                      ))}
                    </div>
                  </div>

                  {/* Errori */}
                  {integrityReport.errors.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2 text-red-800">Errori Rilevati:</h4>
                      <div className="space-y-1">
                        {integrityReport.errors.map((error, index) => (
                          <div key={index} className="text-sm text-red-700 bg-red-50 p-2 rounded">
                            {error}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Avvisi */}
                  {integrityReport.warnings.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2 text-yellow-800">Avvisi:</h4>
                      <div className="space-y-1">
                        {integrityReport.warnings.map((warning, index) => (
                          <div key={index} className="text-sm text-yellow-700 bg-yellow-50 p-2 rounded">
                            {warning}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  🔍 Clicca "Verifica Integrità" per controllare i dati
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab Statistiche */}
        <TabsContent value="stats" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Statistiche Dettagliate</CardTitle>
              <CardDescription>
                Analytics approfonditi sul sistema di backup
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium">Performance</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Tasso di Successo</span>
                      <span className="font-bold">{stats.successRate}%</span>
                    </div>
                    <Progress value={stats.successRate} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Utilizzo Spazio</span>
                      <span className="font-bold">{formatBytes(stats.totalSize)}</span>
                    </div>
                    <Progress value={Math.min((stats.totalSize / (50 * 1024 * 1024)) * 100, 100)} className="h-2" />
                    <p className="text-xs text-gray-500">Limite: 50MB</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Informazioni Sistema</h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span>Primo Backup:</span>
                      <span className="font-mono">
                        {stats.oldestBackup
                          ? new Date(stats.oldestBackup).toLocaleDateString('it-IT')
                          : 'N/A'
                        }
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Prossimo Automatico:</span>
                      <span className="font-mono">
                        {stats.nextScheduledBackup
                          ? new Date(stats.nextScheduledBackup).toLocaleDateString('it-IT')
                          : 'N/A'
                        }
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Controlli Integrità:</span>
                      <span className="font-mono">
                        ✅ {stats.integrityChecksPassed} | ❌ {stats.integrityChecksFailed}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Timeline Backup */}
              {backupList.length > 0 && (
                <div className="mt-8">
                  <h4 className="font-medium mb-4">Timeline Backup</h4>
                  <div className="space-y-2">
                    {backupList.slice(0, 10).map(({ id, backup }) => (
                      <div key={id} className="flex items-center gap-4 text-sm">
                        <div className="w-16 text-gray-500">
                          {new Date(backup.timestamp).toLocaleDateString('it-IT')}
                        </div>
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <div className="flex-1">
                          {backup.metadata.description}
                        </div>
                        <div className="text-gray-500">
                          {formatBytes(backup.metadata.size)}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Dialog Restore */}
      <Dialog open={showRestoreDialog} onOpenChange={setShowRestoreDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Ripristina Backup</DialogTitle>
            <DialogDescription>
              Ripristina i dati dal backup selezionato
            </DialogDescription>
          </DialogHeader>
          {selectedBackup && (
            <div className="space-y-4">
              <div className="p-3 bg-gray-50 rounded-lg text-sm">
                <div className="font-medium">{selectedBackup.backup.metadata.description}</div>
                <div className="text-gray-600">
                  {new Date(selectedBackup.backup.timestamp).toLocaleString('it-IT')} • {formatBytes(selectedBackup.backup.metadata.size)}
                </div>
              </div>

              <Alert>
                <AlertDescription>
                  ⚠️ <strong>Attenzione:</strong> Il ripristino sovrascriverà i dati attuali.
                  Verrà automaticamente creato un punto di ripristino prima di procedere.
                </AlertDescription>
              </Alert>

              <div className="space-y-2">
                <Label>Sezioni da ripristinare (lascia vuoto per tutto):</Label>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  {Object.keys(selectedBackup.backup.data).map(key => (
                    <label key={key} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={selectiveRestoreKeys.includes(key)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectiveRestoreKeys([...selectiveRestoreKeys, key]);
                          } else {
                            setSelectiveRestoreKeys(selectiveRestoreKeys.filter(k => k !== key));
                          }
                        }}
                      />
                      <span className="capitalize">{key}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex gap-2">
                <Button onClick={restoreBackup} disabled={isLoading}>
                  {isLoading ? "⏳ Ripristinando..." : "🔄 Ripristina"}
                </Button>
                <Button variant="outline" onClick={() => setShowRestoreDialog(false)}>
                  Annulla
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
