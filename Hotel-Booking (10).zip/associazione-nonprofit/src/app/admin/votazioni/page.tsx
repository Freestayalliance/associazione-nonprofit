"use client"

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { VotingAdminService, type AdminVoting, type VotingType, type VotingStatus, type Candidate, type VotingOption } from '@/services/VotingAdminService';
import { AdminNotificationService } from '@/services/AdminNotificationService';

export default function GestioneVotazioni() {
  const [votings, setVotings] = useState<AdminVoting[]>([]);
  const [dialogAperto, setDialogAperto] = useState(false);
  const [candidateDialogOpen, setCandidateDialogOpen] = useState(false);
  const [optionsDialogOpen, setOptionsDialogOpen] = useState(false);
  const [selectedVoting, setSelectedVoting] = useState<AdminVoting | null>(null);
  const [filtroStato, setFiltroStato] = useState<VotingStatus | 'all'>('all');
  const [filtroTipo, setFiltroTipo] = useState<VotingType | 'all'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const [nuovaVotazione, setNuovaVotazione] = useState({
    title: '',
    description: '',
    type: 'membership' as VotingType,
    startDate: '',
    endDate: '',
    allowMultipleVotes: false,
    requiresApproval: true,
    isAnonymous: true,
    minimumParticipation: 50,
    enableStartNotification: true,
    enableReminderNotifications: true,
    enableEndNotification: true,
    maxSelections: 1,
    minSelections: 1,
    allowAbstention: true,
    requiresMotivation: false
  });

  const [newCandidate, setNewCandidate] = useState({
    name: '',
    description: '',
    qualifications: [''],
    contactInfo: ''
  });

  const [newOption, setNewOption] = useState({
    text: '',
    description: '',
    order: 1
  });

  const { toast } = useToast();
  const votingService = VotingAdminService.getInstance();
  const notificationService = AdminNotificationService.getInstance();

  // Carica votazioni all'avvio
  useEffect(() => {
    const unsubscribe = votingService.addListener((votings) => {
      setVotings(votings);
    });

    return unsubscribe;
  }, []);

  const handleCreaVotazione = async () => {
    if (!nuovaVotazione.title || !nuovaVotazione.description) {
      toast({
        title: "Errore",
        description: "Titolo e descrizione sono obbligatori",
        variant: "destructive"
      });
      return;
    }

    try {
      const voting: Omit<AdminVoting, 'id' | 'createdAt' | 'updatedAt' | 'auditLog'> = {
        title: nuovaVotazione.title,
        description: nuovaVotazione.description,
        type: nuovaVotazione.type,
        status: 'draft',
        startDate: nuovaVotazione.startDate || new Date().toISOString(),
        endDate: nuovaVotazione.endDate || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        createdBy: 'admin',
        allowMultipleVotes: nuovaVotazione.allowMultipleVotes,
        requiresApproval: nuovaVotazione.requiresApproval,
        isAnonymous: nuovaVotazione.isAnonymous,
        minimumParticipation: nuovaVotazione.minimumParticipation,
        candidates: [],
        options: [],
        votingRules: {
          maxSelections: nuovaVotazione.maxSelections,
          minSelections: nuovaVotazione.minSelections,
          allowAbstention: nuovaVotazione.allowAbstention,
          requiresMotivation: nuovaVotazione.requiresMotivation
        },
        notifications: {
          enableStartNotification: nuovaVotazione.enableStartNotification,
          enableReminderNotifications: nuovaVotazione.enableReminderNotifications,
          enableEndNotification: nuovaVotazione.enableEndNotification,
          reminderDays: [3, 1]
        }
      };

      await votingService.createVoting(voting);

      // Reset form
      setNuovaVotazione({
        title: '',
        description: '',
        type: 'membership',
        startDate: '',
        endDate: '',
        allowMultipleVotes: false,
        requiresApproval: true,
        isAnonymous: true,
        minimumParticipation: 50,
        enableStartNotification: true,
        enableReminderNotifications: true,
        enableEndNotification: true,
        maxSelections: 1,
        minSelections: 1,
        allowAbstention: true,
        requiresMotivation: false
      });
      setDialogAperto(false);

      toast({
        title: "Votazione creata",
        description: "La nuova votazione è stata salvata come bozza",
      });
    } catch (error) {
      toast({
        title: "Errore",
        description: "Errore durante la creazione della votazione",
        variant: "destructive"
      });
    }
  };

  const cambiaStatoVotazione = async (id: string, nuovoStato: VotingStatus) => {
    try {
      if (nuovoStato === 'active') {
        await votingService.activateVoting(id, 'admin');
      } else if (nuovoStato === 'closed') {
        await votingService.closeVoting(id, 'admin');
      } else if (nuovoStato === 'archived') {
        await votingService.archiveVoting(id, 'admin');
      }

      const azione = nuovoStato === 'active' ? 'attivata' :
                    nuovoStato === 'closed' ? 'chiusa' :
                    nuovoStato === 'archived' ? 'archiviata' : 'aggiornata';

      toast({
        title: `Votazione ${azione}`,
        description: `Lo stato della votazione è stato aggiornato`,
      });
    } catch (error) {
      toast({
        title: "Errore",
        description: "Errore durante l'aggiornamento dello stato",
        variant: "destructive"
      });
    }
  };

  const eliminaVotazione = async (id: string) => {
    if (confirm('Sei sicuro di voler eliminare questa votazione?')) {
      try {
        await votingService.deleteVoting(id, 'admin');
        toast({
          title: "Votazione eliminata",
          description: "La votazione è stata rimossa",
        });
      } catch (error) {
        toast({
          title: "Errore",
          description: (error as Error).message,
          variant: "destructive"
        });
      }
    }
  };

  const addCandidate = (votingId: string) => {
    if (!newCandidate.name) return;

    const voting = votings.find(v => v.id === votingId);
    if (!voting) return;

    const candidate: Candidate = {
      id: Date.now().toString(),
      name: newCandidate.name,
      description: newCandidate.description,
      qualifications: newCandidate.qualifications.filter(q => q.trim() !== ''),
      contactInfo: newCandidate.contactInfo
    };

    const updatedCandidates = [...(voting.candidates || []), candidate];

    votingService.updateVoting(votingId, { candidates: updatedCandidates }, 'admin');

    setNewCandidate({
      name: '',
      description: '',
      qualifications: [''],
      contactInfo: ''
    });
    setCandidateDialogOpen(false);

    toast({
      title: "Candidato aggiunto",
      description: `${candidate.name} è stato aggiunto alla votazione`,
    });
  };

  const addOption = (votingId: string) => {
    if (!newOption.text) return;

    const voting = votings.find(v => v.id === votingId);
    if (!voting) return;

    const option: VotingOption = {
      id: Date.now().toString(),
      text: newOption.text,
      description: newOption.description,
      order: newOption.order
    };

    const updatedOptions = [...(voting.options || []), option];

    votingService.updateVoting(votingId, { options: updatedOptions }, 'admin');

    setNewOption({
      text: '',
      description: '',
      order: 1
    });
    setOptionsDialogOpen(false);

    toast({
      title: "Opzione aggiunta",
      description: `L'opzione "${option.text}" è stata aggiunta`,
    });
  };

  // Filtra votazioni
  const votazioniFiltrate = votings.filter(v => {
    if (filtroStato !== 'all' && v.status !== filtroStato) return false;
    if (filtroTipo !== 'all' && v.type !== filtroTipo) return false;
    if (searchTerm && !v.title.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !v.description.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    return true;
  });

  const getStatoBadge = (stato: VotingStatus) => {
    switch (stato) {
      case 'active':
        return <Badge className="bg-green-600 text-white">🟢 Attiva</Badge>;
      case 'closed':
        return <Badge variant="secondary">🔴 Chiusa</Badge>;
      case 'draft':
        return <Badge variant="outline">📝 Bozza</Badge>;
      case 'archived':
        return <Badge className="bg-gray-600 text-white">📦 Archiviata</Badge>;
      default:
        return <Badge variant="secondary">{stato}</Badge>;
    }
  };

  const getTipoBadge = (tipo: VotingType) => {
    const badges = {
      membership: <Badge className="bg-blue-600 text-white">👥 Ammissione</Badge>,
      proposal: <Badge className="bg-purple-600 text-white">💡 Proposta</Badge>,
      budget: <Badge className="bg-yellow-600 text-white">💰 Bilancio</Badge>,
      board: <Badge className="bg-indigo-600 text-white">👨‍💼 Consiglio</Badge>,
      policy: <Badge className="bg-red-600 text-white">📋 Normativa</Badge>,
      emergency: <Badge className="bg-orange-600 text-white">🚨 Emergenza</Badge>
    };
    return badges[tipo] || <Badge variant="secondary">{tipo}</Badge>;
  };

  const stats = votingService.getVotingStatistics();

  return (
    <div>
      {/* Header Navigazione Admin */}
      <div style={{
        backgroundColor: '#f8fafc',
        borderBottom: '2px solid #e2e8f0',
        padding: '16px 24px',
        marginBottom: '24px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <a
            href="/admin"
            style={{
              backgroundColor: '#3b82f6',
              color: 'white',
              padding: '8px 16px',
              borderRadius: '6px',
              textDecoration: 'none',
              fontSize: '14px',
              fontWeight: '500',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            ← 📊 Dashboard Admin
          </a>
          <span style={{ color: '#64748b', fontSize: '14px' }}>/</span>
          <span style={{ color: '#334155', fontSize: '14px', fontWeight: '500' }}>🗳️ Gestione Votazioni Avanzata</span>
        </div>
      </div>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Gestione Votazioni Avanzata</h1>
            <p className="text-gray-600">Sistema completo per gestire votazioni, candidati e risultati</p>
          </div>

          <Dialog open={dialogAperto} onOpenChange={setDialogAperto}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                ➕ Nuova Votazione
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Crea Nuova Votazione</DialogTitle>
                <DialogDescription>
                  Configura tutti i parametri per la nuova votazione
                </DialogDescription>
              </DialogHeader>

              <Tabs defaultValue="base" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="base">Informazioni Base</TabsTrigger>
                  <TabsTrigger value="config">Configurazione</TabsTrigger>
                  <TabsTrigger value="notifiche">Notifiche</TabsTrigger>
                </TabsList>

                <TabsContent value="base" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Titolo</Label>
                    <Input
                      id="title"
                      value={nuovaVotazione.title}
                      onChange={(e) => setNuovaVotazione({...nuovaVotazione, title: e.target.value})}
                      placeholder="es. Ammissione Giovanni Bianchi"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Descrizione</Label>
                    <Textarea
                      id="description"
                      value={nuovaVotazione.description}
                      onChange={(e) => setNuovaVotazione({...nuovaVotazione, description: e.target.value})}
                      placeholder="Descrizione dettagliata della votazione"
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="type">Tipo Votazione</Label>
                    <Select value={nuovaVotazione.type} onValueChange={(value: VotingType) => setNuovaVotazione({...nuovaVotazione, type: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="membership">👥 Ammissione Socio</SelectItem>
                        <SelectItem value="proposal">💡 Proposta Progetto</SelectItem>
                        <SelectItem value="budget">💰 Approvazione Bilancio</SelectItem>
                        <SelectItem value="board">👨‍💼 Elezione Consiglio</SelectItem>
                        <SelectItem value="policy">📋 Modifica Normative</SelectItem>
                        <SelectItem value="emergency">🚨 Delibera d'Urgenza</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="startDate">Data Inizio</Label>
                      <Input
                        id="startDate"
                        type="datetime-local"
                        value={nuovaVotazione.startDate}
                        onChange={(e) => setNuovaVotazione({...nuovaVotazione, startDate: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="endDate">Data Fine</Label>
                      <Input
                        id="endDate"
                        type="datetime-local"
                        value={nuovaVotazione.endDate}
                        onChange={(e) => setNuovaVotazione({...nuovaVotazione, endDate: e.target.value})}
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="config" className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="allowMultipleVotes">Consenti voti multipli</Label>
                      <Switch
                        id="allowMultipleVotes"
                        checked={nuovaVotazione.allowMultipleVotes}
                        onCheckedChange={(checked) => setNuovaVotazione({...nuovaVotazione, allowMultipleVotes: checked})}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="requiresApproval">Richiede approvazione</Label>
                      <Switch
                        id="requiresApproval"
                        checked={nuovaVotazione.requiresApproval}
                        onCheckedChange={(checked) => setNuovaVotazione({...nuovaVotazione, requiresApproval: checked})}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="isAnonymous">Voto anonimo</Label>
                      <Switch
                        id="isAnonymous"
                        checked={nuovaVotazione.isAnonymous}
                        onCheckedChange={(checked) => setNuovaVotazione({...nuovaVotazione, isAnonymous: checked})}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="allowAbstention">Consenti astensione</Label>
                      <Switch
                        id="allowAbstention"
                        checked={nuovaVotazione.allowAbstention}
                        onCheckedChange={(checked) => setNuovaVotazione({...nuovaVotazione, allowAbstention: checked})}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="requiresMotivation">Richiede motivazione</Label>
                      <Switch
                        id="requiresMotivation"
                        checked={nuovaVotazione.requiresMotivation}
                        onCheckedChange={(checked) => setNuovaVotazione({...nuovaVotazione, requiresMotivation: checked})}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="minimumParticipation">Partecipazione minima (%)</Label>
                      <Input
                        id="minimumParticipation"
                        type="number"
                        min="0"
                        max="100"
                        value={nuovaVotazione.minimumParticipation}
                        onChange={(e) => setNuovaVotazione({...nuovaVotazione, minimumParticipation: Number.parseInt(e.target.value)})}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="maxSelections">Selezioni massime</Label>
                        <Input
                          id="maxSelections"
                          type="number"
                          min="1"
                          value={nuovaVotazione.maxSelections}
                          onChange={(e) => setNuovaVotazione({...nuovaVotazione, maxSelections: Number.parseInt(e.target.value)})}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="minSelections">Selezioni minime</Label>
                        <Input
                          id="minSelections"
                          type="number"
                          min="0"
                          value={nuovaVotazione.minSelections}
                          onChange={(e) => setNuovaVotazione({...nuovaVotazione, minSelections: Number.parseInt(e.target.value)})}
                        />
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="notifiche" className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="enableStartNotification">Notifica inizio votazione</Label>
                      <Switch
                        id="enableStartNotification"
                        checked={nuovaVotazione.enableStartNotification}
                        onCheckedChange={(checked) => setNuovaVotazione({...nuovaVotazione, enableStartNotification: checked})}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="enableReminderNotifications">Notifiche promemoria</Label>
                      <Switch
                        id="enableReminderNotifications"
                        checked={nuovaVotazione.enableReminderNotifications}
                        onCheckedChange={(checked) => setNuovaVotazione({...nuovaVotazione, enableReminderNotifications: checked})}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="enableEndNotification">Notifica fine votazione</Label>
                      <Switch
                        id="enableEndNotification"
                        checked={nuovaVotazione.enableEndNotification}
                        onCheckedChange={(checked) => setNuovaVotazione({...nuovaVotazione, enableEndNotification: checked})}
                      />
                    </div>
                  </div>
                </TabsContent>
              </Tabs>

              <Button onClick={handleCreaVotazione} className="w-full">
                Crea Votazione
              </Button>
            </DialogContent>
          </Dialog>
        </div>

        {/* Statistiche Avanzate */}
        <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Totali</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{stats.total}</div>
              <p className="text-sm text-gray-600">Votazioni</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Attive</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{stats.activeVotings.length}</div>
              <p className="text-sm text-gray-600">In corso</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Bozze</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600">{stats.byStatus.draft || 0}</div>
              <p className="text-sm text-gray-600">Da pubblicare</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Chiuse</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-600">{stats.byStatus.closed || 0}</div>
              <p className="text-sm text-gray-600">Terminate</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Archiviate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-600">{stats.byStatus.archived || 0}</div>
              <p className="text-sm text-gray-600">Archivio</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">In Arrivo</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-indigo-600">{stats.upcomingVotings.length}</div>
              <p className="text-sm text-gray-600">Programmate</p>
            </CardContent>
          </Card>
        </div>

        {/* Filtri Avanzati */}
        <Card>
          <CardHeader>
            <CardTitle>Filtri e Ricerca</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-1">
                  <Label htmlFor="search">Ricerca</Label>
                  <Input
                    id="search"
                    placeholder="Cerca per titolo o descrizione..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="stato">Stato</Label>
                  <Select value={filtroStato} onValueChange={(value: VotingStatus | 'all') => setFiltroStato(value)}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tutti gli stati</SelectItem>
                      <SelectItem value="draft">Bozze</SelectItem>
                      <SelectItem value="active">Attive</SelectItem>
                      <SelectItem value="closed">Chiuse</SelectItem>
                      <SelectItem value="archived">Archiviate</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="tipo">Tipo</Label>
                  <Select value={filtroTipo} onValueChange={(value: VotingType | 'all') => setFiltroTipo(value)}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tutti i tipi</SelectItem>
                      <SelectItem value="membership">Ammissione</SelectItem>
                      <SelectItem value="proposal">Proposta</SelectItem>
                      <SelectItem value="budget">Bilancio</SelectItem>
                      <SelectItem value="board">Consiglio</SelectItem>
                      <SelectItem value="policy">Normative</SelectItem>
                      <SelectItem value="emergency">Emergenza</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabella Votazioni Avanzata */}
        <Card>
          <CardHeader>
            <CardTitle>Elenco Votazioni ({votazioniFiltrate.length})</CardTitle>
            <CardDescription>
              Gestione completa di tutte le votazioni dell'associazione
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Titolo & Tipo</TableHead>
                  <TableHead>Stato</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Configurazione</TableHead>
                  <TableHead>Risultati</TableHead>
                  <TableHead>Azioni</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {votazioniFiltrate.map((voting) => {
                  const results = votingService.getVotingResults(voting.id);
                  return (
                    <TableRow key={voting.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{voting.title}</div>
                          <div className="text-sm text-gray-600">{voting.description}</div>
                          <div className="mt-1">{getTipoBadge(voting.type)}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {getStatoBadge(voting.status)}
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>Creata: {new Date(voting.createdAt).toLocaleDateString('it-IT')}</div>
                          <div className="text-blue-600">Inizio: {new Date(voting.startDate).toLocaleDateString('it-IT')}</div>
                          <div className="text-red-600">Fine: {new Date(voting.endDate).toLocaleDateString('it-IT')}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm space-y-1">
                          <div>🎯 Min partecipazione: {voting.minimumParticipation}%</div>
                          <div>🔒 Anonimo: {voting.isAnonymous ? 'Sì' : 'No'}</div>
                          <div>✅ Astensione: {voting.votingRules.allowAbstention ? 'Sì' : 'No'}</div>
                          {voting.candidates && voting.candidates.length > 0 && (
                            <div>👥 Candidati: {voting.candidates.length}</div>
                          )}
                          {voting.options && voting.options.length > 0 && (
                            <div>⚪ Opzioni: {voting.options.length}</div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {results ? (
                          <div className="text-sm">
                            <div className="font-medium">Totale: {results.totalVotes}</div>
                            <div>Partecipazione: {results.participationRate.toFixed(1)}%</div>
                            {results.results.length > 0 && (
                              <div className="mt-1 space-y-1">
                                {results.results.slice(0, 2).map((result, index) => (
                                  <div key={index} className="flex justify-between">
                                    <span className="truncate max-w-20">{result.name}:</span>
                                    <span>{result.percentage.toFixed(1)}%</span>
                                  </div>
                                ))}
                                {results.results.length > 2 && <div className="text-gray-500">...</div>}
                              </div>
                            )}
                          </div>
                        ) : (
                          <span className="text-gray-500">Nessun risultato</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1 flex-wrap">
                          {voting.status === 'draft' && (
                            <Button
                              size="sm"
                              onClick={() => cambiaStatoVotazione(voting.id, 'active')}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              🟢 Attiva
                            </Button>
                          )}
                          {voting.status === 'active' && (
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => cambiaStatoVotazione(voting.id, 'closed')}
                            >
                              🔴 Chiudi
                            </Button>
                          )}
                          {voting.status === 'closed' && (
                            <>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => cambiaStatoVotazione(voting.id, 'active')}
                              >
                                🔄 Riapri
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => cambiaStatoVotazione(voting.id, 'archived')}
                              >
                                📦 Archivia
                              </Button>
                            </>
                          )}

                          {/* Gestione candidati per votazioni membership */}
                          {voting.type === 'membership' && (
                            <Dialog open={candidateDialogOpen && selectedVoting?.id === voting.id} onOpenChange={(open) => {
                              setCandidateDialogOpen(open);
                              if (open) setSelectedVoting(voting);
                            }}>
                              <DialogTrigger asChild>
                                <Button size="sm" variant="outline">
                                  👥 Candidati ({voting.candidates?.length || 0})
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Gestione Candidati</DialogTitle>
                                  <DialogDescription>
                                    Aggiungi o modifica i candidati per questa votazione
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div className="space-y-2">
                                    <Label>Nome Candidato</Label>
                                    <Input
                                      value={newCandidate.name}
                                      onChange={(e) => setNewCandidate({...newCandidate, name: e.target.value})}
                                      placeholder="Nome e cognome"
                                    />
                                  </div>
                                  <div className="space-y-2">
                                    <Label>Descrizione</Label>
                                    <Textarea
                                      value={newCandidate.description}
                                      onChange={(e) => setNewCandidate({...newCandidate, description: e.target.value})}
                                      placeholder="Descrizione del candidato"
                                    />
                                  </div>
                                  <div className="space-y-2">
                                    <Label>Qualifiche</Label>
                                    {newCandidate.qualifications.map((qualification, index) => (
                                      <div key={index} className="flex gap-2">
                                        <Input
                                          value={qualification}
                                          onChange={(e) => {
                                            const newQualifications = [...newCandidate.qualifications];
                                            newQualifications[index] = e.target.value;
                                            setNewCandidate({...newCandidate, qualifications: newQualifications});
                                          }}
                                          placeholder="Qualifica"
                                        />
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          onClick={() => {
                                            const newQualifications = newCandidate.qualifications.filter((_, i) => i !== index);
                                            setNewCandidate({...newCandidate, qualifications: newQualifications});
                                          }}
                                        >
                                          ❌
                                        </Button>
                                      </div>
                                    ))}
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => setNewCandidate({...newCandidate, qualifications: [...newCandidate.qualifications, '']})}
                                    >
                                      ➕ Aggiungi Qualifica
                                    </Button>
                                  </div>
                                  <div className="space-y-2">
                                    <Label>Contatto</Label>
                                    <Input
                                      value={newCandidate.contactInfo}
                                      onChange={(e) => setNewCandidate({...newCandidate, contactInfo: e.target.value})}
                                      placeholder="Email o telefono"
                                    />
                                  </div>
                                  <Button onClick={() => addCandidate(voting.id)} className="w-full">
                                    Aggiungi Candidato
                                  </Button>
                                </div>
                              </DialogContent>
                            </Dialog>
                          )}

                          {/* Gestione opzioni per altri tipi di votazione */}
                          {voting.type !== 'membership' && (
                            <Dialog open={optionsDialogOpen && selectedVoting?.id === voting.id} onOpenChange={(open) => {
                              setOptionsDialogOpen(open);
                              if (open) setSelectedVoting(voting);
                            }}>
                              <DialogTrigger asChild>
                                <Button size="sm" variant="outline">
                                  ⚪ Opzioni ({voting.options?.length || 0})
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Gestione Opzioni</DialogTitle>
                                  <DialogDescription>
                                    Aggiungi o modifica le opzioni di voto
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div className="space-y-2">
                                    <Label>Testo Opzione</Label>
                                    <Input
                                      value={newOption.text}
                                      onChange={(e) => setNewOption({...newOption, text: e.target.value})}
                                      placeholder="Testo dell'opzione"
                                    />
                                  </div>
                                  <div className="space-y-2">
                                    <Label>Descrizione</Label>
                                    <Textarea
                                      value={newOption.description}
                                      onChange={(e) => setNewOption({...newOption, description: e.target.value})}
                                      placeholder="Descrizione dettagliata"
                                    />
                                  </div>
                                  <div className="space-y-2">
                                    <Label>Ordine</Label>
                                    <Input
                                      type="number"
                                      value={newOption.order}
                                      onChange={(e) => setNewOption({...newOption, order: Number.parseInt(e.target.value)})}
                                    />
                                  </div>
                                  <Button onClick={() => addOption(voting.id)} className="w-full">
                                    Aggiungi Opzione
                                  </Button>
                                </div>
                              </DialogContent>
                            </Dialog>
                          )}

                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => eliminaVotazione(voting.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            🗑️
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>

            {votazioniFiltrate.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <p>Nessuna votazione trovata per i filtri selezionati</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Link Votazioni Pubbliche */}
        <Card>
          <CardHeader>
            <CardTitle>🌐 Integrazione Sito Pubblico</CardTitle>
            <CardDescription>
              Gestisci l'integrazione con la sezione votazioni pubblica
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Button asChild variant="outline">
                <a href="/votazioni" target="_blank" rel="noreferrer">
                  👁️ Visualizza Votazioni Pubbliche
                </a>
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  // Forza sincronizzazione con notifiche
                  window.dispatchEvent(new Event('votazioni-aggiornate'));
                  toast({
                    title: "Sincronizzazione completata",
                    description: "Le votazioni sono state sincronizzate con il sito pubblico",
                  });
                }}
              >
                🔄 Sincronizza Sistema Pubblico
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  const data = votingService.exportVotings();
                  const blob = new Blob([data], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `votazioni-export-${new Date().toISOString().split('T')[0]}.json`;
                  a.click();
                  URL.revokeObjectURL(url);
                  toast({
                    title: "Export completato",
                    description: "I dati delle votazioni sono stati esportati",
                  });
                }}
              >
                📊 Export Dati
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
