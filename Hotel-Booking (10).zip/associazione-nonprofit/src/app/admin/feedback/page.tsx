"use client"

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface FeedbackData {
  id: string;
  timestamp: string;
  page: string;
  rating: number;
  usability: number;
  content: number;
  design: number;
  comments: string;
  wouldRecommend: boolean;
  userType: string;
  email?: string;
}

export default function FeedbackAdminPage() {
  const [feedbacks, setFeedbacks] = useState<FeedbackData[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    averageRating: 0,
    averageUsability: 0,
    averageContent: 0,
    averageDesign: 0,
    wouldRecommendPercent: 0,
    userTypes: {} as Record<string, number>,
    pages: {} as Record<string, number>
  });

  useEffect(() => {
    loadFeedbacks();
  }, []);

  const loadFeedbacks = () => {
    try {
      const data = JSON.parse(localStorage.getItem('demo-feedback') || '[]');
      setFeedbacks(data.sort((a: FeedbackData, b: FeedbackData) =>
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      ));
      calculateStats(data);
    } catch (error) {
      console.error('Errore nel caricamento feedback:', error);
    }
  };

  const calculateStats = (data: FeedbackData[]) => {
    if (data.length === 0) {
      setStats({
        total: 0,
        averageRating: 0,
        averageUsability: 0,
        averageContent: 0,
        averageDesign: 0,
        wouldRecommendPercent: 0,
        userTypes: {},
        pages: {}
      });
      return;
    }

    const total = data.length;
    const averageRating = data.reduce((sum, f) => sum + f.rating, 0) / total;
    const averageUsability = data.reduce((sum, f) => sum + f.usability, 0) / total;
    const averageContent = data.reduce((sum, f) => sum + f.content, 0) / total;
    const averageDesign = data.reduce((sum, f) => sum + f.design, 0) / total;
    const wouldRecommend = data.filter(f => f.wouldRecommend).length;
    const wouldRecommendPercent = (wouldRecommend / total) * 100;

    const userTypes: Record<string, number> = {};
    const pages: Record<string, number> = {};

    data.forEach(f => {
      if (f.userType) {
        userTypes[f.userType] = (userTypes[f.userType] || 0) + 1;
      }
      pages[f.page] = (pages[f.page] || 0) + 1;
    });

    setStats({
      total,
      averageRating,
      averageUsability,
      averageContent,
      averageDesign,
      wouldRecommendPercent,
      userTypes,
      pages
    });
  };

  const clearAllFeedbacks = () => {
    if (confirm('Sei sicuro di voler eliminare tutti i feedback?')) {
      localStorage.removeItem('demo-feedback');
      setFeedbacks([]);
      calculateStats([]);
    }
  };

  const getPageDisplayName = (page: string) => {
    const pageNames: Record<string, string> = {
      'demo-main': '🎮 Demo Principale',
      'free4stay-homepage': '🏠 Free4Stay Homepage',
      'free4stay-hotels': '🏨 Lista Hotel',
      'free4stay-confirmation': '✅ Conferma Prenotazione',
      'free4stay-full-booked': '😢 Hotel Al Completo'
    };
    return pageNames[page] || page;
  };

  const StarDisplay = ({ rating }: { rating: number }) => (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <span
          key={star}
          className={star <= rating ? 'text-yellow-500' : 'text-gray-300'}
        >
          ⭐
        </span>
      ))}
      <span className="ml-2 text-sm font-medium">{rating.toFixed(1)}</span>
    </div>
  );

  return (
    <div>
      {/* Header Navigazione Admin */}
      <div style={{
        backgroundColor: '#f8fafc',
        borderBottom: '2px solid #e2e8f0',
        padding: '16px 24px',
        marginBottom: '24px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <a
            href="/admin"
            style={{
              backgroundColor: '#3b82f6',
              color: 'white',
              padding: '8px 16px',
              borderRadius: '6px',
              textDecoration: 'none',
              fontSize: '14px',
              fontWeight: '500',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            ← 📊 Dashboard Admin
          </a>
          <span style={{ color: '#64748b', fontSize: '14px' }}>/</span>
          <span style={{ color: '#334155', fontSize: '14px', fontWeight: '500' }}>💬 Feedback Demo</span>
        </div>
      </div>

      <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold">💬 Feedback Demo</h1>
          <p className="text-gray-600 mt-2">
            Analisi dei feedback raccolti dagli utenti del demo
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={loadFeedbacks} variant="outline">
            🔄 Aggiorna
          </Button>
          <Button onClick={clearAllFeedbacks} variant="destructive">
            🗑️ Svuota Tutto
          </Button>
        </div>
      </div>

      {/* Statistiche */}
      {stats.total > 0 && (
        <div className="grid md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">📊 Totale Feedback</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{stats.total}</div>
              <div className="text-sm text-gray-600 mt-1">Feedback ricevuti</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">⭐ Valutazione Media</CardTitle>
            </CardHeader>
            <CardContent>
              <StarDisplay rating={stats.averageRating} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">👍 Raccomandazioni</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                {stats.wouldRecommendPercent.toFixed(0)}%
              </div>
              <div className="text-sm text-gray-600 mt-1">Utenti che raccomandano</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">🎯 Usabilità Media</CardTitle>
            </CardHeader>
            <CardContent>
              <StarDisplay rating={stats.averageUsability} />
            </CardContent>
          </Card>
        </div>
      )}

      {/* Dettaglio Valutazioni */}
      {stats.total > 0 && (
        <div className="grid md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">📝 Qualità Contenuti</CardTitle>
            </CardHeader>
            <CardContent>
              <StarDisplay rating={stats.averageContent} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">🎨 Design & UI</CardTitle>
            </CardHeader>
            <CardContent>
              <StarDisplay rating={stats.averageDesign} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">👤 Tipi di Utenti</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {Object.entries(stats.userTypes).map(([type, count]) => (
                  <div key={type} className="flex justify-between items-center">
                    <span className="text-sm">{type}</span>
                    <Badge variant="outline">{count}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Lista Feedback */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl">📋 Feedback Dettagliati</CardTitle>
          <CardDescription>
            Tutti i feedback ricevuti in ordine cronologico
          </CardDescription>
        </CardHeader>
        <CardContent>
          {feedbacks.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-4xl mb-4">💭</div>
              <p className="text-gray-500">Nessun feedback ricevuto ancora</p>
              <p className="text-sm text-gray-400 mt-2">
                I feedback degli utenti appariranno qui automaticamente
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {feedbacks.map((feedback, index) => (
                <div key={feedback.id} className="border rounded-lg p-6 space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline">#{feedbacks.length - index}</Badge>
                      <div>
                        <div className="font-medium">{getPageDisplayName(feedback.page)}</div>
                        <div className="text-sm text-gray-500">
                          {new Date(feedback.timestamp).toLocaleString('it-IT')}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      {feedback.userType && (
                        <Badge variant="secondary">{feedback.userType}</Badge>
                      )}
                      <StarDisplay rating={feedback.rating} />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">🎯 Usabilità:</span>
                      <StarDisplay rating={feedback.usability} />
                    </div>
                    <div>
                      <span className="text-gray-600">📝 Contenuti:</span>
                      <StarDisplay rating={feedback.content} />
                    </div>
                    <div>
                      <span className="text-gray-600">🎨 Design:</span>
                      <StarDisplay rating={feedback.design} />
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <span className="text-sm text-gray-600">Raccomandazione:</span>
                    <Badge variant={feedback.wouldRecommend ? "default" : "destructive"}>
                      {feedback.wouldRecommend ? "👍 Sì" : "👎 No"}
                    </Badge>
                  </div>

                  {feedback.comments && (
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="text-sm text-gray-600 mb-2">💭 Commenti:</div>
                      <p className="text-sm italic">"{feedback.comments}"</p>
                    </div>
                  )}

                  {feedback.email && (
                    <div className="text-sm text-gray-600">
                      📧 Contatto: {feedback.email}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      </div>
    </div>
  );
}
