"use client"

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import analyticsService, { type AnalyticsReport, PageView, type UserAction, UserSession, PerformanceMetric } from '@/services/AnalyticsService';

export default function DashboardAnalytics() {
  const [isLoading, setIsLoading] = useState(true);
  const [reportPeriod, setReportPeriod] = useState<'today' | 'week' | 'month' | 'year'>('week');
  const [report, setReport] = useState<AnalyticsReport | null>(null);
  const [realTimeStats, setRealTimeStats] = useState<any>(null);
  const [selectedTab, setSelectedTab] = useState('overview');

  const { toast } = useToast();

  useEffect(() => {
    loadAnalytics();

    // Auto-refresh real-time stats ogni 30 secondi
    const interval = setInterval(() => {
      if (selectedTab === 'realtime') {
        loadRealTimeStats();
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [reportPeriod, selectedTab]);

  const loadAnalytics = async () => {
    setIsLoading(true);
    try {
      const reportData = analyticsService.generateReport(reportPeriod);
      setReport(reportData);

      if (selectedTab === 'realtime') {
        loadRealTimeStats();
      }
    } catch (error) {
      console.error('Errore caricamento analytics:', error);
      toast({
        title: "Errore",
        description: "Errore nel caricamento dei dati analytics",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadRealTimeStats = () => {
    try {
      const stats = analyticsService.getRealTimeStats();
      setRealTimeStats(stats);
    } catch (error) {
      console.error('Errore caricamento real-time stats:', error);
    }
  };

  const formatDuration = (seconds: number): string => {
    if (seconds < 60) return `${Math.round(seconds)}s`;
    if (seconds < 3600) return `${Math.round(seconds / 60)}m`;
    return `${Math.round(seconds / 3600)}h`;
  };

  const formatPercentage = (value: number): string => {
    return `${Math.round(value * 100) / 100}%`;
  };

  const getChangeIcon = (change: number): string => {
    if (change > 0) return '📈';
    if (change < 0) return '📉';
    return '➡️';
  };

  const getChangeColor = (change: number): string => {
    if (change > 0) return 'text-green-600';
    if (change < 0) return 'text-red-600';
    return 'text-gray-600';
  };

  const getPerformanceColor = (score: number): string => {
    if (score >= 90) return 'text-green-600';
    if (score >= 75) return 'text-yellow-600';
    if (score >= 50) return 'text-orange-600';
    return 'text-red-600';
  };

  const getDeviceIcon = (device: string): string => {
    switch (device.toLowerCase()) {
      case 'mobile': return '📱';
      case 'tablet': return '📲';
      case 'desktop': return '💻';
      default: return '🖥️';
    }
  };

  const getBrowserIcon = (browser: string): string => {
    switch (browser.toLowerCase()) {
      case 'chrome': return '🌐';
      case 'firefox': return '🦊';
      case 'safari': return '🧭';
      case 'edge': return '🔷';
      default: return '🌍';
    }
  };

  const exportReport = () => {
    if (!report) return;

    const exportData = {
      report,
      exportDate: new Date().toISOString(),
      period: reportPeriod
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analytics-report-${reportPeriod}-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "✅ Report esportato!",
      description: `Report ${reportPeriod} esportato con successo`,
    });
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard Analytics</h1>
          <p className="text-gray-600">Caricamento dati analytics...</p>
        </div>
        <div className="flex justify-center py-16">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">📊 Dashboard Analytics</h1>
        <p className="text-gray-600">
          Monitora performance, comportamento utenti e crescita del sito in tempo reale
        </p>
      </div>

      {/* Quick Stats - Always Visible */}
      {report && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Visite Totali</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{report.totalViews.toLocaleString()}</div>
              <div className="flex items-center gap-2 text-sm">
                <span className={getChangeColor(report.periodComparison.viewsChange)}>
                  {getChangeIcon(report.periodComparison.viewsChange)} {Math.abs(report.periodComparison.viewsChange)}%
                </span>
                <span className="text-gray-600">vs periodo precedente</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Visitatori Unici</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{report.uniqueVisitors.toLocaleString()}</div>
              <div className="flex items-center gap-2 text-sm">
                <span className={getChangeColor(report.periodComparison.visitorsChange)}>
                  {getChangeIcon(report.periodComparison.visitorsChange)} {Math.abs(report.periodComparison.visitorsChange)}%
                </span>
                <span className="text-gray-600">vs periodo precedente</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Durata Media</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-600">{formatDuration(report.averageSessionDuration)}</div>
              <div className="flex items-center gap-2 text-sm">
                <span className={getChangeColor(report.periodComparison.durationChange)}>
                  {getChangeIcon(report.periodComparison.durationChange)} {Math.abs(report.periodComparison.durationChange)}%
                </span>
                <span className="text-gray-600">vs periodo precedente</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Performance Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-3xl font-bold ${getPerformanceColor(report.performanceScore)}`}>
                {Math.round(report.performanceScore)}/100
              </div>
              <div className="text-sm text-gray-600">
                Load time: {Math.round(report.averageLoadTime)}ms
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Main Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <TabsList className="grid grid-cols-2 lg:grid-cols-5 w-full sm:w-auto">
            <TabsTrigger value="overview">📊 Overview</TabsTrigger>
            <TabsTrigger value="realtime">🔴 Real-time</TabsTrigger>
            <TabsTrigger value="audience">👥 Audience</TabsTrigger>
            <TabsTrigger value="behavior">🎯 Behavior</TabsTrigger>
            <TabsTrigger value="performance">⚡ Performance</TabsTrigger>
          </TabsList>

          <div className="flex items-center gap-4">
            <Select value={reportPeriod} onValueChange={(value: any) => setReportPeriod(value)}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Oggi</SelectItem>
                <SelectItem value="week">Settimana</SelectItem>
                <SelectItem value="month">Mese</SelectItem>
                <SelectItem value="year">Anno</SelectItem>
              </SelectContent>
            </Select>

            <Button onClick={exportReport} variant="outline" size="sm">
              📥 Export
            </Button>

            <Button onClick={() => loadAnalytics()} variant="outline" size="sm">
              🔄 Aggiorna
            </Button>
          </div>
        </div>

        {/* Tab Overview */}
        <TabsContent value="overview" className="space-y-6">
          {report && (
            <>
              {/* Top Pages */}
              <Card>
                <CardHeader>
                  <CardTitle>📄 Pagine più Visitate</CardTitle>
                  <CardDescription>
                    Le pagine con più traffico nel periodo selezionato
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Pagina</TableHead>
                        <TableHead>Visite</TableHead>
                        <TableHead>Visitatori Unici</TableHead>
                        <TableHead>% del Totale</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {report.topPages.map((page, index) => (
                        <TableRow key={page.path}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{page.title}</div>
                              <div className="text-sm text-gray-600">{page.path}</div>
                            </div>
                          </TableCell>
                          <TableCell className="font-medium">{page.views.toLocaleString()}</TableCell>
                          <TableCell>{page.uniqueViews.toLocaleString()}</TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {Math.round((page.views / report.totalViews) * 100)}%
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>

              {/* Traffic Sources */}
              <Card>
                <CardHeader>
                  <CardTitle>🌐 Sorgenti di Traffico</CardTitle>
                  <CardDescription>
                    Da dove arrivano i visitatori
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Sorgente</TableHead>
                        <TableHead>Visite</TableHead>
                        <TableHead>% del Totale</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {report.topReferrers.map((referrer, index) => (
                        <TableRow key={referrer.referrer}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <span>{referrer.referrer === 'direct' ? '🔗' : '🌐'}</span>
                              <span>{referrer.referrer === 'direct' ? 'Diretto' : referrer.referrer}</span>
                            </div>
                          </TableCell>
                          <TableCell className="font-medium">{referrer.visits.toLocaleString()}</TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {Math.round((referrer.visits / report.totalSessions) * 100)}%
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        {/* Tab Real-time */}
        <TabsContent value="realtime" className="space-y-6">
          {realTimeStats && (
            <>
              {/* Real-time Overview */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">🔴 Utenti Attivi</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-red-600">{realTimeStats.activeUsers}</div>
                    <p className="text-sm text-gray-600">Online ora</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">👁️ Visualizzazioni</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-blue-600">{realTimeStats.currentPageViews}</div>
                    <p className="text-sm text-gray-600">Ultimi 5 minuti</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">🎯 Azioni</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-green-600">{realTimeStats.recentActions.length}</div>
                    <p className="text-sm text-gray-600">Interazioni recenti</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">⚡ System Load</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className={`text-3xl font-bold ${realTimeStats.systemLoad > 80 ? 'text-red-600' : realTimeStats.systemLoad > 60 ? 'text-yellow-600' : 'text-green-600'}`}>
                      {realTimeStats.systemLoad}%
                    </div>
                    <p className="text-sm text-gray-600">Carico sistema</p>
                  </CardContent>
                </Card>
              </div>

              {/* Active Pages */}
              <Card>
                <CardHeader>
                  <CardTitle>📱 Pagine Attive</CardTitle>
                  <CardDescription>
                    Pagine visualizzate negli ultimi 5 minuti
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Pagina</TableHead>
                        <TableHead>Utenti Attivi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {realTimeStats.topActivePages.map((page: any, index: number) => (
                        <TableRow key={page.path}>
                          <TableCell className="font-medium">{page.path}</TableCell>
                          <TableCell>
                            <Badge className="bg-red-600">{page.users} 👤</Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>

              {/* Recent Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>🎯 Azioni Recenti</CardTitle>
                  <CardDescription>
                    Ultimi comportamenti degli utenti
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {realTimeStats.recentActions.map((action: UserAction, index: number) => (
                      <div key={action.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <span className="text-lg">
                            {action.type === 'click' ? '👆' :
                             action.type === 'scroll' ? '📜' :
                             action.type === 'vote' ? '🗳️' :
                             action.type === 'comment' ? '💬' :
                             action.type === 'search' ? '🔍' : '🎯'}
                          </span>
                          <div>
                            <div className="font-medium capitalize">{action.type.replace('_', ' ')}</div>
                            <div className="text-sm text-gray-600">{action.target}</div>
                          </div>
                        </div>
                        <div className="text-sm text-gray-500">
                          {new Date(action.timestamp).toLocaleTimeString('it-IT')}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        {/* Tab Audience */}
        <TabsContent value="audience" className="space-y-6">
          {report && (
            <>
              {/* Device Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>📱 Dispositivi</CardTitle>
                    <CardDescription>
                      Breakdown per tipo dispositivo
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {Object.entries(report.deviceBreakdown).map(([device, count]) => (
                        <div key={device} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span>{getDeviceIcon(device)}</span>
                            <span className="capitalize">{device}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{count}</Badge>
                            <span className="text-sm text-gray-600">
                              {Math.round((count / report.totalSessions) * 100)}%
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>🌐 Browser</CardTitle>
                    <CardDescription>
                      Breakdown per browser
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {Object.entries(report.browserBreakdown).map(([browser, count]) => (
                        <div key={browser} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span>{getBrowserIcon(browser)}</span>
                            <span>{browser}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{count}</Badge>
                            <span className="text-sm text-gray-600">
                              {Math.round((count / report.totalSessions) * 100)}%
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>💻 Sistema Operativo</CardTitle>
                    <CardDescription>
                      Breakdown per OS
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {Object.entries(report.osBreakdown).map(([os, count]) => (
                        <div key={os} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span>
                              {os.includes('Windows') ? '🪟' :
                               os.includes('Mac') ? '🍎' :
                               os.includes('Linux') ? '🐧' :
                               os.includes('Android') ? '🤖' :
                               os.includes('iOS') ? '📱' : '💻'}
                            </span>
                            <span>{os}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{count}</Badge>
                            <span className="text-sm text-gray-600">
                              {Math.round((count / report.totalSessions) * 100)}%
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Session Metrics */}
              <Card>
                <CardHeader>
                  <CardTitle>📊 Metriche Sessione</CardTitle>
                  <CardDescription>
                    Comportamento e engagement degli utenti
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{report.totalSessions.toLocaleString()}</div>
                      <div className="text-sm text-blue-800">Sessioni Totali</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{formatDuration(report.averageSessionDuration)}</div>
                      <div className="text-sm text-green-800">Durata Media</div>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">{formatPercentage(report.bounceRate)}</div>
                      <div className="text-sm text-purple-800">Bounce Rate</div>
                    </div>
                    <div className="text-center p-4 bg-orange-50 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">{Math.round(report.totalViews / report.totalSessions * 100) / 100}</div>
                      <div className="text-sm text-orange-800">Pagine/Sessione</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        {/* Tab Behavior */}
        <TabsContent value="behavior" className="space-y-6">
          {report && (
            <>
              {/* Top Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>🎯 Azioni Principali</CardTitle>
                  <CardDescription>
                    Cosa fanno gli utenti sul sito
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Tipo Azione</TableHead>
                        <TableHead>Occorrenze</TableHead>
                        <TableHead>% del Totale</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {report.topActions.map((action, index) => (
                        <TableRow key={action.type}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <span>
                                {action.type === 'click' ? '👆' :
                                 action.type === 'scroll' ? '📜' :
                                 action.type === 'vote' ? '🗳️' :
                                 action.type === 'comment' ? '💬' :
                                 action.type === 'search' ? '🔍' : '🎯'}
                              </span>
                              <span className="capitalize">{action.type.replace('_', ' ')}</span>
                            </div>
                          </TableCell>
                          <TableCell className="font-medium">{action.count.toLocaleString()}</TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {Math.round((action.count / report.topActions.reduce((sum, a) => sum + a.count, 0)) * 100)}%
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>

              {/* Search Queries */}
              {report.searchQueries.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>🔍 Query di Ricerca</CardTitle>
                    <CardDescription>
                      Cosa cercano gli utenti
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Query</TableHead>
                          <TableHead>Ricerche</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {report.searchQueries.map((query, index) => (
                          <TableRow key={query.query}>
                            <TableCell className="font-medium">"{query.query}"</TableCell>
                            <TableCell>
                              <Badge variant="outline">{query.count}</Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </TabsContent>

        {/* Tab Performance */}
        <TabsContent value="performance" className="space-y-6">
          {report && (
            <Card>
              <CardHeader>
                <CardTitle>⚡ Performance del Sito</CardTitle>
                <CardDescription>
                  Metriche di velocità e user experience
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className={`text-3xl font-bold ${getPerformanceColor(report.performanceScore)}`}>
                      {Math.round(report.performanceScore)}/100
                    </div>
                    <div className="text-sm text-blue-800">Performance Score</div>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{Math.round(report.averageLoadTime)}ms</div>
                    <div className="text-sm text-green-800">Tempo Caricamento</div>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">
                      {report.averageLoadTime <= 2000 ? '🚀' : report.averageLoadTime <= 4000 ? '⚡' : '🐌'}
                    </div>
                    <div className="text-sm text-purple-800">
                      {report.averageLoadTime <= 2000 ? 'Eccellente' :
                       report.averageLoadTime <= 4000 ? 'Buono' : 'Da Migliorare'}
                    </div>
                  </div>
                </div>

                <div className="mt-8 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium mb-4">📋 Raccomandazioni Performance</h4>
                  <div className="space-y-2 text-sm">
                    {report.averageLoadTime > 3000 && (
                      <div className="flex items-center gap-2 text-red-600">
                        <span>⚠️</span>
                        <span>Tempo di caricamento elevato - ottimizzare immagini e risorse</span>
                      </div>
                    )}
                    {report.performanceScore < 75 && (
                      <div className="flex items-center gap-2 text-yellow-600">
                        <span>💡</span>
                        <span>Score performance sotto la media - considerare lazy loading</span>
                      </div>
                    )}
                    {report.bounceRate > 70 && (
                      <div className="flex items-center gap-2 text-orange-600">
                        <span>📈</span>
                        <span>Bounce rate elevato - migliorare contenuti e UX</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2 text-green-600">
                      <span>✅</span>
                      <span>Sistema analytics attivo e funzionante</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
