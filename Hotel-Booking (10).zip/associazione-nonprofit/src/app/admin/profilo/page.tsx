"use client"

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

// Mock per le definizioni dei ruoli
const getRoleDefinition = (role: string) => {
  switch (role) {
    case 'admin':
      return {
        name: 'Super Admin',
        description: 'Accesso completo al sistema',
        color: 'bg-purple-600',
        icon: '👨‍💼'
      };
    case 'moderator':
      return {
        name: 'Moderatore',
        description: 'Gestione contenuti e utenti',
        color: 'bg-blue-600',
        icon: '🛡️'
      };
    default:
      return {
        name: 'Amministratore',
        description: 'Accesso amministrativo',
        color: 'bg-gray-600',
        icon: '👤'
      };
  }
};

// Utility per generare codici sicuri
const generateSecureCode = (length = 6): string => {
  return Math.random().toString(36).substr(2, length).toUpperCase();
};

const generateBackupCode = (): string => {
  return Array.from({length: 8}, () => Math.random().toString(36).substr(2, 4)).join('-').toUpperCase();
};

// Hash password semplificato (in produzione usare bcrypt)
const hashPassword = (password: string): string => {
  // Simulazione hash - in produzione usare una libreria sicura
  let hash = 0;
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash).toString(16);
};

export default function ProfiloAdmin() {
  const [adminUser, setAdminUser] = useState<any>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [currentTab, setCurrentTab] = useState('profile');

  // Form dati profilo
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    bio: '',
    phone: '',
    department: '',
    timezone: 'Europe/Rome'
  });

  // Form cambio password
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  // Autenticazione a due fattori
  const [twoFactorForm, setTwoFactorForm] = useState({
    isEnabled: false,
    secretKey: '',
    verificationCode: '',
    backupCodes: [] as string[]
  });

  // Impostazioni notifiche
  const [notificationSettings, setNotificationSettings] = useState({
    desktopNotifications: true,
    emailNotifications: true,
    newVotes: true,
    newMembers: true,
    payments: true,
    systemAlerts: true,
    urgentOnly: false,
    autoBackup: true,
    syncEnabled: true
  });

  // Impostazioni sicurezza
  const [securitySettings, setSecuritySettings] = useState({
    twoFactorAuth: false,
    sessionTimeout: 30,
    loginAlerts: true,
    requirePasswordChange: false,
    lockoutAfterFailedAttempts: 5,
    securityQuestions: false
  });

  // Stati UI
  const [isPasswordDialogOpen, setIsPasswordDialogOpen] = useState(false);
  const [is2FADialogOpen, setIs2FADialogOpen] = useState(false);
  const [isTestingBackup, setIsTestingBackup] = useState(false);
  const [lastBackupTime, setLastBackupTime] = useState<Date | null>(null);

  const { toast } = useToast();

  // Carica dati utente e impostazioni all'avvio
  useEffect(() => {
    loadUserData();
    loadSettings();
    loadBackupHistory();

    // Auto backup ogni 5 minuti se abilitato
    const backupInterval = setInterval(() => {
      if (notificationSettings.autoBackup) {
        performAutoBackup();
      }
    }, 5 * 60 * 1000);

    // Sync con altri admin ogni 30 secondi se abilitato
    const syncInterval = setInterval(() => {
      if (notificationSettings.syncEnabled) {
        syncWithOtherAdmins();
      }
    }, 30 * 1000);

    return () => {
      clearInterval(backupInterval);
      clearInterval(syncInterval);
    };
  }, [notificationSettings.autoBackup, notificationSettings.syncEnabled]);

  const loadUserData = () => {
    const savedUser = localStorage.getItem('adminUser');
    if (savedUser) {
      try {
        const user = JSON.parse(savedUser);
        const completeUser = {
          id: user.id || 1,
          name: user.name || 'Admin',
          email: user.email || 'admin@associazione.org',
          role: user.role || 'admin',
          loginTime: user.loginTime || Date.now(),
          permissions: user.permissions || ['all'],
          passwordHash: user.passwordHash || hashPassword('admin123'),
          lastPasswordChange: user.lastPasswordChange || Date.now(),
          failedLoginAttempts: user.failedLoginAttempts || 0,
          ...user
        };
        setAdminUser(completeUser);
        setFormData({
          name: completeUser.name || '',
          email: completeUser.email || '',
          bio: completeUser.bio || '',
          phone: completeUser.phone || '',
          department: completeUser.department || '',
          timezone: completeUser.timezone || 'Europe/Rome'
        });
      } catch (error) {
        console.error('Errore caricamento profilo:', error);
      }
    }
  };

  const loadSettings = () => {
    // Carica impostazioni notifiche
    const savedNotifications = localStorage.getItem('admin-notification-settings');
    if (savedNotifications) {
      try {
        setNotificationSettings(JSON.parse(savedNotifications));
      } catch (error) {
        console.error('Errore caricamento impostazioni notifiche:', error);
      }
    }

    // Carica impostazioni sicurezza
    const savedSecurity = localStorage.getItem('admin-security-settings');
    if (savedSecurity) {
      try {
        setSecuritySettings(JSON.parse(savedSecurity));
      } catch (error) {
        console.error('Errore caricamento impostazioni sicurezza:', error);
      }
    }

    // Carica impostazioni 2FA
    const saved2FA = localStorage.getItem('admin-2fa-settings');
    if (saved2FA) {
      try {
        setTwoFactorForm(JSON.parse(saved2FA));
      } catch (error) {
        console.error('Errore caricamento 2FA:', error);
      }
    }
  };

  const loadBackupHistory = () => {
    const lastBackup = localStorage.getItem('admin-last-backup');
    if (lastBackup) {
      setLastBackupTime(new Date(lastBackup));
    }
  };

  // Salvataggio profilo
  const handleSaveProfile = () => {
    if (!adminUser) return;

    const updatedUser = {
      ...adminUser,
      ...formData,
      lastActivity: Date.now()
    };

    localStorage.setItem('adminUser', JSON.stringify(updatedUser));
    setAdminUser(updatedUser);
    setIsEditing(false);

    // Log dell'attività
    logActivity('edit', 'Aggiornamento profilo utente');

    toast({
      title: "✅ Profilo aggiornato",
      description: "Le modifiche sono state salvate con successo",
    });

    // Sync automatico
    if (notificationSettings.syncEnabled) {
      syncWithOtherAdmins();
    }
  };

  // Cambio password
  const handleChangePassword = () => {
    if (!adminUser) return;

    // Validazioni
    if (!passwordForm.currentPassword || !passwordForm.newPassword || !passwordForm.confirmPassword) {
      toast({
        title: "❌ Errore",
        description: "Compila tutti i campi password",
        variant: "destructive",
      });
      return;
    }

    if (hashPassword(passwordForm.currentPassword) !== adminUser.passwordHash) {
      toast({
        title: "❌ Password attuale errata",
        description: "La password attuale non è corretta",
        variant: "destructive",
      });
      return;
    }

    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast({
        title: "❌ Password non corrispondono",
        description: "La nuova password e la conferma non corrispondono",
        variant: "destructive",
      });
      return;
    }

    if (passwordForm.newPassword.length < 8) {
      toast({
        title: "❌ Password troppo debole",
        description: "La password deve contenere almeno 8 caratteri",
        variant: "destructive",
      });
      return;
    }

    // Aggiorna password
    const updatedUser = {
      ...adminUser,
      passwordHash: hashPassword(passwordForm.newPassword),
      lastPasswordChange: Date.now(),
      failedLoginAttempts: 0
    };

    localStorage.setItem('adminUser', JSON.stringify(updatedUser));
    setAdminUser(updatedUser);
    setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    setIsPasswordDialogOpen(false);

    logActivity('security', 'Cambio password');

    toast({
      title: "🔐 Password cambiata",
      description: "La password è stata aggiornata con successo",
    });
  };

  // Abilita/Disabilita 2FA
  const handleToggle2FA = () => {
    if (!twoFactorForm.isEnabled) {
      // Abilita 2FA
      const secretKey = generateSecureCode(16);
      const backupCodes = Array.from({length: 10}, () => generateBackupCode());

      const new2FA = {
        isEnabled: true,
        secretKey,
        verificationCode: '',
        backupCodes
      };

      setTwoFactorForm(new2FA);
      localStorage.setItem('admin-2fa-settings', JSON.stringify(new2FA));

      const updatedSecurity = { ...securitySettings, twoFactorAuth: true };
      setSecuritySettings(updatedSecurity);
      localStorage.setItem('admin-security-settings', JSON.stringify(updatedSecurity));

      logActivity('security', 'Abilitazione autenticazione a due fattori');

      toast({
        title: "🔐 2FA Abilitato",
        description: "Autenticazione a due fattori attivata. Salva i codici di backup!",
      });
    } else {
      // Disabilita 2FA
      const new2FA = {
        isEnabled: false,
        secretKey: '',
        verificationCode: '',
        backupCodes: []
      };

      setTwoFactorForm(new2FA);
      localStorage.setItem('admin-2fa-settings', JSON.stringify(new2FA));

      const updatedSecurity = { ...securitySettings, twoFactorAuth: false };
      setSecuritySettings(updatedSecurity);
      localStorage.setItem('admin-security-settings', JSON.stringify(updatedSecurity));

      logActivity('security', 'Disabilitazione autenticazione a due fattori');

      toast({
        title: "🔓 2FA Disabilitato",
        description: "Autenticazione a due fattori disattivata",
      });
    }
    setIs2FADialogOpen(false);
  };

  // Backup automatico
  const performAutoBackup = () => {
    try {
      const backupData = {
        timestamp: new Date().toISOString(),
        user: adminUser,
        settings: {
          notifications: notificationSettings,
          security: securitySettings,
          twoFactor: twoFactorForm
        },
        activityLog: JSON.parse(localStorage.getItem('admin-activity-log') || '[]').slice(0, 100),
        version: '1.0'
      };

      const backupKey = `admin-backup-${Date.now()}`;
      localStorage.setItem(backupKey, JSON.stringify(backupData));
      localStorage.setItem('admin-last-backup', new Date().toISOString());
      setLastBackupTime(new Date());

      // Mantieni solo gli ultimi 5 backup
      const allKeys = Object.keys(localStorage).filter(key => key.startsWith('admin-backup-'));
      if (allKeys.length > 5) {
        const oldestKeys = allKeys.sort().slice(0, -5);
        oldestKeys.forEach(key => localStorage.removeItem(key));
      }

      logActivity('system', 'Backup automatico eseguito');
    } catch (error) {
      console.error('Errore backup automatico:', error);
    }
  };

  // Backup manuale
  const performManualBackup = () => {
    setIsTestingBackup(true);

    setTimeout(() => {
      performAutoBackup();
      setIsTestingBackup(false);

      toast({
        title: "💾 Backup completato",
        description: "Backup manuale eseguito con successo",
      });
    }, 2000);
  };

  // Sincronizzazione con altri admin
  const syncWithOtherAdmins = () => {
    try {
      // Simula sincronizzazione con server/database
      const syncData = {
        lastSync: new Date().toISOString(),
        adminId: adminUser?.id,
        settings: {
          notifications: notificationSettings,
          security: securitySettings
        }
      };

      localStorage.setItem('admin-sync-data', JSON.stringify(syncData));

      // Simula ricezione dati da altri admin
      const receivedUpdates = localStorage.getItem('admin-sync-received');
      if (receivedUpdates) {
        try {
          const updates = JSON.parse(receivedUpdates);
          // Applica aggiornamenti se necessario
          console.log('Sync ricevuto:', updates);
        } catch (error) {
          console.error('Errore sync ricevuto:', error);
        }
      }
    } catch (error) {
      console.error('Errore sincronizzazione:', error);
    }
  };

  // Test sincronizzazione manuale
  const testSync = () => {
    syncWithOtherAdmins();
    toast({
      title: "🔄 Sincronizzazione",
      description: "Sincronizzazione con altri admin completata",
    });
  };

  // Salvataggio impostazioni
  const handleSaveNotifications = () => {
    localStorage.setItem('admin-notification-settings', JSON.stringify(notificationSettings));
    logActivity('config', 'Aggiornamento impostazioni notifiche');

    toast({
      title: "🔔 Notifiche salvate",
      description: "Le impostazioni notifiche sono state aggiornate",
    });
  };

  const handleSaveSecurity = () => {
    localStorage.setItem('admin-security-settings', JSON.stringify(securitySettings));
    logActivity('security', 'Aggiornamento impostazioni sicurezza');

    toast({
      title: "🛡️ Sicurezza salvata",
      description: "Le impostazioni di sicurezza sono state aggiornate",
    });
  };

  // Test notifiche
  const testNotification = () => {
    toast({
      title: "🧪 Test Notifica",
      description: "Sistema di notifiche funzionante!",
    });
  };

  // Export dati completo
  const exportAllData = () => {
    const exportData = {
      profile: formData,
      user: adminUser,
      notifications: notificationSettings,
      security: securitySettings,
      twoFactor: { ...twoFactorForm, secretKey: '***HIDDEN***' }, // Nascondi chiave segreta
      activityLog: JSON.parse(localStorage.getItem('admin-activity-log') || '[]'),
      backupHistory: lastBackupTime,
      exportDate: new Date().toISOString(),
      version: '2.0'
    };

    const dataStr = JSON.stringify(exportData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `admin-profile-export-${new Date().toISOString().split('T')[0]}.json`;
    link.click();

    logActivity('export', 'Export completo dati profilo');

    toast({
      title: "📤 Export completato",
      description: "Tutti i dati sono stati esportati",
    });
  };

  // Utility per log attività
  const logActivity = (action: string, details: string) => {
    if (!adminUser) return;

    const activityLog = JSON.parse(localStorage.getItem('admin-activity-log') || '[]');
    activityLog.unshift({
      id: Date.now(),
      userId: adminUser.id,
      userName: adminUser.name,
      action,
      details,
      timestamp: new Date().toISOString(),
      ip: 'Local',
      status: 'success'
    });
    localStorage.setItem('admin-activity-log', JSON.stringify(activityLog));
  };

  // Ripristino da backup
  const restoreFromBackup = () => {
    const backupKeys = Object.keys(localStorage).filter(key => key.startsWith('admin-backup-'));
    if (backupKeys.length === 0) {
      toast({
        title: "❌ Nessun backup",
        description: "Non sono stati trovati backup disponibili",
        variant: "destructive",
      });
      return;
    }

    const latestBackup = backupKeys.sort().pop();
    if (latestBackup) {
      try {
        const backupData = JSON.parse(localStorage.getItem(latestBackup) || '{}');

        // Ripristina dati (conferma dall'utente in produzione)
        if (confirm('Ripristinare l\'ultimo backup? Questo sovrascriverà le impostazioni attuali.')) {
          if (backupData.settings) {
            setNotificationSettings(backupData.settings.notifications || notificationSettings);
            setSecuritySettings(backupData.settings.security || securitySettings);
            setTwoFactorForm(backupData.settings.twoFactor || twoFactorForm);

            localStorage.setItem('admin-notification-settings', JSON.stringify(backupData.settings.notifications));
            localStorage.setItem('admin-security-settings', JSON.stringify(backupData.settings.security));
            localStorage.setItem('admin-2fa-settings', JSON.stringify(backupData.settings.twoFactor));
          }

          logActivity('system', 'Ripristino da backup');

          toast({
            title: "♻️ Backup ripristinato",
            description: "Impostazioni ripristinate dall'ultimo backup",
          });
        }
      } catch (error) {
        toast({
          title: "❌ Errore ripristino",
          description: "Impossibile ripristinare il backup",
          variant: "destructive",
        });
      }
    }
  };

  if (!adminUser) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4" />
          <p>Caricamento profilo avanzato...</p>
        </div>
      </div>
    );
  }

  const roleInfo = getRoleDefinition(adminUser.role);

  return (
    <div>
      {/* Header Navigazione Admin */}
      <div style={{
        backgroundColor: '#f8fafc',
        borderBottom: '2px solid #e2e8f0',
        padding: '16px 24px',
        marginBottom: '24px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <a
            href="/admin"
            style={{
              backgroundColor: '#3b82f6',
              color: 'white',
              padding: '8px 16px',
              borderRadius: '6px',
              textDecoration: 'none',
              fontSize: '14px',
              fontWeight: '500',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}
          >
            ← 📊 Dashboard Admin
          </a>
          <span style={{ color: '#64748b', fontSize: '14px' }}>/</span>
          <span style={{ color: '#334155', fontSize: '14px', fontWeight: '500' }}>⚙️ Profilo Avanzato</span>
        </div>
      </div>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Profilo Admin Avanzato</h1>
            <p className="text-gray-600">Gestione completa account, sicurezza e sincronizzazione</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={testNotification} variant="outline" size="sm">
              🧪 Test
            </Button>
            <Button onClick={testSync} variant="outline" size="sm">
              🔄 Sync
            </Button>
            <Button
              onClick={performManualBackup}
              variant="outline"
              size="sm"
              disabled={isTestingBackup}
            >
              {isTestingBackup ? '⏳' : '💾'} Backup
            </Button>
          </div>
        </div>

        {/* Status Dashboard */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card className="bg-blue-50">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">
                {(() => {
                  const log = JSON.parse(localStorage.getItem('admin-activity-log') || '[]');
                  return log.filter((entry: any) => entry.userId === adminUser.id).length;
                })()}
              </div>
              <div className="text-sm text-gray-600">Azioni Totali</div>
            </CardContent>
          </Card>

          <Card className="bg-green-50">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">
                {twoFactorForm.isEnabled ? '🔐' : '🔓'}
              </div>
              <div className="text-sm text-gray-600">
                2FA {twoFactorForm.isEnabled ? 'Attivo' : 'Inattivo'}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-orange-50">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">
                {lastBackupTime ? '✅' : '❌'}
              </div>
              <div className="text-sm text-gray-600">
                {lastBackupTime ? 'Backup OK' : 'Nessun Backup'}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-purple-50">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">
                {notificationSettings.syncEnabled ? '🔄' : '⏸️'}
              </div>
              <div className="text-sm text-gray-600">
                Sync {notificationSettings.syncEnabled ? 'Attivo' : 'Pausa'}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs per organizzare le sezioni */}
        <Tabs value={currentTab} onValueChange={setCurrentTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="profile">👤 Profilo</TabsTrigger>
            <TabsTrigger value="security">🛡️ Sicurezza</TabsTrigger>
            <TabsTrigger value="notifications">🔔 Notifiche</TabsTrigger>
            <TabsTrigger value="backup">💾 Backup</TabsTrigger>
            <TabsTrigger value="sync">🔄 Sync</TabsTrigger>
          </TabsList>

          {/* Tab Profilo */}
          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <div className={`h-10 w-10 rounded-full ${roleInfo.color} flex items-center justify-center`}>
                        <span className="text-white font-bold">
                          {roleInfo.icon}
                        </span>
                      </div>
                      Informazioni Profilo
                    </CardTitle>
                    <CardDescription>
                      Aggiorna le tue informazioni personali
                    </CardDescription>
                  </div>
                  <Button
                    onClick={() => setIsEditing(!isEditing)}
                    variant={isEditing ? "outline" : "default"}
                  >
                    {isEditing ? "Annulla" : "✏️ Modifica"}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Badge Ruolo */}
                <div className="flex items-center gap-4">
                  <Badge className={`${roleInfo.color} text-white`}>
                    {roleInfo.icon} {roleInfo.name}
                  </Badge>
                  <span className="text-sm text-gray-600">{roleInfo.description}</span>
                </div>

                {/* Form Dati */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome Completo</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      disabled={!isEditing}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      disabled={!isEditing}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Telefono</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      disabled={!isEditing}
                      placeholder="+39 ..."
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="department">Dipartimento</Label>
                    <Input
                      id="department"
                      value={formData.department}
                      onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                      disabled={!isEditing}
                      placeholder="es. Amministrazione"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio">Biografia</Label>
                  <Textarea
                    id="bio"
                    value={formData.bio}
                    onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                    disabled={!isEditing}
                    placeholder="Breve descrizione del tuo ruolo..."
                    rows={3}
                  />
                </div>

                {isEditing && (
                  <Button onClick={handleSaveProfile} className="w-full">
                    💾 Salva Modifiche Profilo
                  </Button>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab Sicurezza */}
          <TabsContent value="security" className="space-y-6">
            {/* Cambio Password */}
            <Card>
              <CardHeader>
                <CardTitle>🔐 Gestione Password</CardTitle>
                <CardDescription>
                  Cambia la password del tuo account admin
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">Password ultima modifica</p>
                    <p className="text-sm text-gray-600">
                      {new Date(adminUser.lastPasswordChange).toLocaleDateString('it-IT')}
                    </p>
                  </div>
                  <Dialog open={isPasswordDialogOpen} onOpenChange={setIsPasswordDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>🔑 Cambia Password</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>🔐 Cambio Password</DialogTitle>
                        <DialogDescription>
                          Inserisci la password attuale e quella nuova
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="current-password">Password Attuale</Label>
                          <Input
                            id="current-password"
                            type="password"
                            value={passwordForm.currentPassword}
                            onChange={(e) => setPasswordForm({...passwordForm, currentPassword: e.target.value})}
                            placeholder="Password attuale"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="new-password">Nuova Password</Label>
                          <Input
                            id="new-password"
                            type="password"
                            value={passwordForm.newPassword}
                            onChange={(e) => setPasswordForm({...passwordForm, newPassword: e.target.value})}
                            placeholder="Almeno 8 caratteri"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="confirm-password">Conferma Password</Label>
                          <Input
                            id="confirm-password"
                            type="password"
                            value={passwordForm.confirmPassword}
                            onChange={(e) => setPasswordForm({...passwordForm, confirmPassword: e.target.value})}
                            placeholder="Ripeti la nuova password"
                          />
                        </div>
                        <Button onClick={handleChangePassword} className="w-full">
                          🔐 Cambia Password
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>

            {/* Autenticazione a Due Fattori */}
            <Card>
              <CardHeader>
                <CardTitle>🛡️ Autenticazione a Due Fattori (2FA)</CardTitle>
                <CardDescription>
                  Aggiungi un livello extra di sicurezza al tuo account
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">
                      2FA {twoFactorForm.isEnabled ? 'Abilitato' : 'Disabilitato'}
                    </p>
                    <p className="text-sm text-gray-600">
                      {twoFactorForm.isEnabled
                        ? 'Account protetto con autenticazione a due fattori'
                        : 'Abilita 2FA per maggiore sicurezza'
                      }
                    </p>
                  </div>
                  <Dialog open={is2FADialogOpen} onOpenChange={setIs2FADialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant={twoFactorForm.isEnabled ? "destructive" : "default"}>
                        {twoFactorForm.isEnabled ? '🔓 Disabilita 2FA' : '🔐 Abilita 2FA'}
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>
                          {twoFactorForm.isEnabled ? '🔓 Disabilita 2FA' : '🔐 Abilita 2FA'}
                        </DialogTitle>
                        <DialogDescription>
                          {twoFactorForm.isEnabled
                            ? 'Sei sicuro di voler disabilitare l\'autenticazione a due fattori?'
                            : 'Configura l\'autenticazione a due fattori per maggiore sicurezza'
                          }
                        </DialogDescription>
                      </DialogHeader>

                      {!twoFactorForm.isEnabled && (
                        <div className="space-y-4">
                          <div className="p-4 bg-blue-50 rounded-lg">
                            <h4 className="font-medium mb-2">🔑 Chiave Segreta</h4>
                            <p className="text-sm text-gray-600 mb-2">
                              Usa questa chiave con la tua app di autenticazione:
                            </p>
                            <code className="text-xs bg-gray-100 p-2 rounded block">
                              {generateSecureCode(16)}
                            </code>
                          </div>

                          <div className="p-4 bg-yellow-50 rounded-lg">
                            <h4 className="font-medium mb-2">🆘 Codici di Backup</h4>
                            <p className="text-sm text-gray-600 mb-2">
                              Salva questi codici in un posto sicuro:
                            </p>
                            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                              {Array.from({length: 6}, () => generateBackupCode()).map((code, i) => (
                                <code key={i} className="bg-gray-100 p-1 rounded">{code}</code>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}

                      <Button onClick={handleToggle2FA} className="w-full">
                        {twoFactorForm.isEnabled ? '🔓 Disabilita 2FA' : '🔐 Abilita 2FA'}
                      </Button>
                    </DialogContent>
                  </Dialog>
                </div>

                {/* Mostra codici di backup se 2FA è abilitato */}
                {twoFactorForm.isEnabled && twoFactorForm.backupCodes.length > 0 && (
                  <div className="p-4 bg-yellow-50 rounded-lg">
                    <h4 className="font-medium mb-2">🆘 Codici di Backup Attivi</h4>
                    <p className="text-sm text-gray-600 mb-2">
                      Hai {twoFactorForm.backupCodes.length} codici di backup disponibili
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => toast({
                        title: "📋 Codici di Backup",
                        description: "I codici sono stati salvati nelle impostazioni 2FA",
                      })}
                    >
                      📋 Mostra Codici
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Altre Impostazioni Sicurezza */}
            <Card>
              <CardHeader>
                <CardTitle>⚙️ Impostazioni Sicurezza</CardTitle>
                <CardDescription>
                  Configura le altre opzioni di sicurezza
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="login-alerts">Avvisi di Login</Label>
                    <p className="text-sm text-gray-600">Notifica per accessi al tuo account</p>
                  </div>
                  <Switch
                    id="login-alerts"
                    checked={securitySettings.loginAlerts}
                    onCheckedChange={(checked) =>
                      setSecuritySettings({ ...securitySettings, loginAlerts: checked })
                    }
                  />
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label htmlFor="session-timeout">Timeout Sessione (minuti)</Label>
                  <Input
                    id="session-timeout"
                    type="number"
                    value={securitySettings.sessionTimeout}
                    onChange={(e) =>
                      setSecuritySettings({ ...securitySettings, sessionTimeout: Number.parseInt(e.target.value) || 30 })
                    }
                    min="5"
                    max="480"
                  />
                  <p className="text-xs text-gray-500">
                    La sessione scadrà dopo questo periodo di inattività
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="failed-attempts">Tentativi falliti prima del blocco</Label>
                  <Input
                    id="failed-attempts"
                    type="number"
                    value={securitySettings.lockoutAfterFailedAttempts}
                    onChange={(e) =>
                      setSecuritySettings({ ...securitySettings, lockoutAfterFailedAttempts: Number.parseInt(e.target.value) || 5 })
                    }
                    min="1"
                    max="10"
                  />
                </div>

                <Button onClick={handleSaveSecurity} className="w-full">
                  🛡️ Salva Impostazioni Sicurezza
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab Notifiche */}
          <TabsContent value="notifications" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>🔔 Impostazioni Notifiche Avanzate</CardTitle>
                <CardDescription>
                  Configura quando e come ricevere le notifiche
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="desktop-notifications">Notifiche Desktop</Label>
                      <p className="text-sm text-gray-600">Mostra notifiche desktop quando disponibili</p>
                    </div>
                    <Switch
                      id="desktop-notifications"
                      checked={notificationSettings.desktopNotifications}
                      onCheckedChange={(checked) =>
                        setNotificationSettings({ ...notificationSettings, desktopNotifications: checked })
                      }
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="new-votes">Nuove Votazioni</Label>
                      <p className="text-sm text-gray-600">Notifica per nuovi voti registrati</p>
                    </div>
                    <Switch
                      id="new-votes"
                      checked={notificationSettings.newVotes}
                      onCheckedChange={(checked) =>
                        setNotificationSettings({ ...notificationSettings, newVotes: checked })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="new-members">Nuovi Soci</Label>
                      <p className="text-sm text-gray-600">Notifica per nuove registrazioni</p>
                    </div>
                    <Switch
                      id="new-members"
                      checked={notificationSettings.newMembers}
                      onCheckedChange={(checked) =>
                        setNotificationSettings({ ...notificationSettings, newMembers: checked })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="payments">Pagamenti</Label>
                      <p className="text-sm text-gray-600">Notifica per nuovi pagamenti ricevuti</p>
                    </div>
                    <Switch
                      id="payments"
                      checked={notificationSettings.payments}
                      onCheckedChange={(checked) =>
                        setNotificationSettings({ ...notificationSettings, payments: checked })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="system-alerts">Avvisi Sistema</Label>
                      <p className="text-sm text-gray-600">Notifiche di sistema e manuttenzione</p>
                    </div>
                    <Switch
                      id="system-alerts"
                      checked={notificationSettings.systemAlerts}
                      onCheckedChange={(checked) =>
                        setNotificationSettings({ ...notificationSettings, systemAlerts: checked })
                      }
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="auto-backup">Backup Automatico</Label>
                      <p className="text-sm text-gray-600">Esegui backup automatici ogni 5 minuti</p>
                    </div>
                    <Switch
                      id="auto-backup"
                      checked={notificationSettings.autoBackup}
                      onCheckedChange={(checked) =>
                        setNotificationSettings({ ...notificationSettings, autoBackup: checked })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="sync-enabled">Sincronizzazione</Label>
                      <p className="text-sm text-gray-600">Sincronizza con altri admin ogni 30 secondi</p>
                    </div>
                    <Switch
                      id="sync-enabled"
                      checked={notificationSettings.syncEnabled}
                      onCheckedChange={(checked) =>
                        setNotificationSettings({ ...notificationSettings, syncEnabled: checked })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="urgent-only">Solo Urgenti</Label>
                      <p className="text-sm text-gray-600">Ricevi solo notifiche urgenti</p>
                    </div>
                    <Switch
                      id="urgent-only"
                      checked={notificationSettings.urgentOnly}
                      onCheckedChange={(checked) =>
                        setNotificationSettings({ ...notificationSettings, urgentOnly: checked })
                      }
                    />
                  </div>
                </div>

                <Button onClick={handleSaveNotifications} className="w-full">
                  🔔 Salva Impostazioni Notifiche
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab Backup */}
          <TabsContent value="backup" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>💾 Sistema Backup Avanzato</CardTitle>
                <CardDescription>
                  Gestione backup automatici e manuali delle configurazioni
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Status Backup */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-medium mb-2">📅 Ultimo Backup</h4>
                    <p className="text-sm text-gray-600">
                      {lastBackupTime
                        ? lastBackupTime.toLocaleString('it-IT')
                        : 'Nessun backup eseguito'
                      }
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg">
                    <h4 className="font-medium mb-2">⚡ Backup Automatico</h4>
                    <p className="text-sm text-gray-600">
                      {notificationSettings.autoBackup ? 'Attivo - ogni 5 minuti' : 'Disattivato'}
                    </p>
                  </div>
                </div>

                {/* Azioni Backup */}
                <div className="space-y-4">
                  <div className="flex gap-2">
                    <Button
                      onClick={performManualBackup}
                      className="flex-1"
                      disabled={isTestingBackup}
                    >
                      {isTestingBackup ? '⏳ Backup in corso...' : '💾 Backup Manuale'}
                    </Button>
                    <Button onClick={restoreFromBackup} variant="outline" className="flex-1">
                      ♻️ Ripristina Backup
                    </Button>
                  </div>

                  <Separator />

                  <div className="p-4 bg-yellow-50 rounded-lg">
                    <h4 className="font-medium mb-2">⚠️ Informazioni Backup</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• I backup includono profilo, impostazioni e log attività</li>
                      <li>• Vengono mantenuti automaticamente gli ultimi 5 backup</li>
                      <li>• I backup sono salvati in locale nel browser</li>
                      <li>• Per backup su server esterno, usa l'export completo</li>
                    </ul>
                  </div>

                  <Button onClick={exportAllData} variant="outline" className="w-full">
                    📤 Export Completo Dati
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab Sincronizzazione */}
          <TabsContent value="sync" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>🔄 Sincronizzazione Multi-Admin</CardTitle>
                <CardDescription>
                  Sincronizza impostazioni e dati con altri amministratori
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Status Sync */}
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 bg-purple-50 rounded-lg text-center">
                    <div className="text-2xl font-bold text-purple-600">
                      {notificationSettings.syncEnabled ? '🟢' : '🔴'}
                    </div>
                    <div className="text-sm text-gray-600">
                      Sync {notificationSettings.syncEnabled ? 'Attivo' : 'Disattivo'}
                    </div>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-lg text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {(() => {
                        const syncData = localStorage.getItem('admin-sync-data');
                        if (syncData) {
                          const data = JSON.parse(syncData);
                          const lastSync = new Date(data.lastSync);
                          const now = new Date();
                          const diffMinutes = Math.floor((now.getTime() - lastSync.getTime()) / (1000 * 60));
                          return diffMinutes < 1 ? '🕐' : `${diffMinutes}m`;
                        }
                        return '❌';
                      })()}
                    </div>
                    <div className="text-sm text-gray-600">Ultima Sync</div>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg text-center">
                    <div className="text-2xl font-bold text-green-600">1</div>
                    <div className="text-sm text-gray-600">Admin Online</div>
                  </div>
                </div>

                {/* Configurazione Sync */}
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-medium mb-2">🔄 Modalità Sincronizzazione</h4>
                    <div className="space-y-2">
                      <label className="flex items-center space-x-2">
                        <input type="radio" checked={true} onChange={() => {}} />
                        <span className="text-sm">Automatica (ogni 30 secondi)</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <input type="radio" checked={false} onChange={() => {}} />
                        <span className="text-sm">Solo manuale</span>
                      </label>
                    </div>
                  </div>

                  <div className="p-4 bg-green-50 rounded-lg">
                    <h4 className="font-medium mb-2">📤 Dati Sincronizzati</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
                      <div>✅ Impostazioni notifiche</div>
                      <div>✅ Configurazioni sicurezza</div>
                      <div>✅ Preferenze UI</div>
                      <div>✅ Log attività (ultimi 100)</div>
                      <div>❌ Password e 2FA</div>
                      <div>❌ Dati personali</div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button onClick={testSync} className="flex-1">
                      🔄 Sincronizza Ora
                    </Button>
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        // Reset dati sync
                        localStorage.removeItem('admin-sync-data');
                        localStorage.removeItem('admin-sync-received');
                        toast({
                          title: "🔄 Sync Reset",
                          description: "Dati di sincronizzazione resettati",
                        });
                      }}
                    >
                      🗑️ Reset Sync
                    </Button>
                  </div>

                  <div className="p-4 bg-yellow-50 rounded-lg">
                    <h4 className="font-medium mb-2">⚠️ Note Sincronizzazione</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• La sincronizzazione è simulata in questa demo</li>
                      <li>• In produzione richiederebbe un server centrale</li>
                      <li>• Le password e i dati 2FA non sono mai sincronizzati</li>
                      <li>• Ogni admin mantiene il controllo sui propri dati sensibili</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
