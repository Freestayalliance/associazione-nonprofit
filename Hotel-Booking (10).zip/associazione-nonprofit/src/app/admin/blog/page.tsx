"use client"

import { useState, useEffect } from 'react';

interface Articolo {
  id: number;
  titolo: string;
  riassunto: string;
  contenuto: string;
  data: string;
  categoria: string;
  autore: string;
  stato: string;
  visite: number;
  commenti: number;
  immagine: string;
  immagini: string[]; // Array di URL immagini
  tags: string[]; // Array di tags
  metaDescription: string; // Per SEO
  slug: string; // Per URL SEO-friendly
}
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import blogCommentService, { type BlogComment, type CommentStats } from '@/services/BlogCommentService';

// Articoli di esempio iniziali
const articoliIniziali = [
  {
    id: 1,
    titolo: "Trasparenza: Il Nostro Bilancio del Primo Anno",
    riassunto: "Ecco tutti i numeri del nostro primo anno di attività. Dalla raccolta fondi ai progetti realizzati.",
    contenuto: "Il nostro primo anno è stato straordinario. Abbiamo raccolto €25,400 grazie alle quote associative e alle donazioni dei partner. Ogni euro è stato investito in progetti concreti per la comunità.",
    data: "2024-12-01",
    categoria: "Trasparenza",
    autore: "Vittoria Sgura",
    stato: "pubblicato",
    visite: 234,
    commenti: 12,
    immagine: "📊",
    tags: ["bilancio", "trasparenza", "primo-anno", "risultati", "finanze"],
    metaDescription: "Scopri il bilancio completo del primo anno della nostra associazione non-profit: €25,400 raccolti e investiti in progetti comunitari concreti.",
    slug: "trasparenza-bilancio-primo-anno",
    immagini: [
      "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=800&h=600&fit=crop"
    ]
  },
  {
    id: 2,
    titolo: "Nuovo Sistema di Votazione Online",
    riassunto: "Abbiamo implementato un nuovo sistema per rendere le votazioni ancora più semplici e sicure per tutti i soci.",
    contenuto: "La democrazia digitale è il futuro. Il nostro nuovo sistema di votazione permette a tutti i soci di partecipare attivamente alle decisioni dell'associazione.",
    data: "2024-11-28",
    categoria: "Tecnologia",
    autore: "Michael Franceschini",
    stato: "pubblicato",
    visite: 156,
    commenti: 8,
    immagine: "🗳️",
    tags: ["votazioni", "tecnologia", "democrazia-digitale", "innovazione", "partecipazione"],
    metaDescription: "Scopri il nuovo sistema di votazione online che rende la partecipazione democratica più accessibile e sicura per tutti i soci dell'associazione.",
    slug: "sistema-votazione-online",
    immagini: [
      "https://images.unsplash.com/photo-1586671267731-da2cf3ceeb80?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1503945438517-f85a938ade2e?w=800&h=600&fit=crop"
    ]
  }
];

const categorie = ["Trasparenza", "Tecnologia", "Partnership", "Eventi", "Partecipazione"];

export default function GestioneBlog() {
  const [articoli, setArticoli] = useState(articoliIniziali);
  const [dialogAperto, setDialogAperto] = useState(false);
  const [modalitaEdit, setModalitaEdit] = useState(false);
  const [articoloCorrente, setArticoloCorrente] = useState<Articolo | null>(null);
  const [filtroStato, setFiltroStato] = useState('tutti');
  const [ricerca, setRicerca] = useState('');
  const [nuovoArticolo, setNuovoArticolo] = useState({
    titolo: '',
    riassunto: '',
    contenuto: '',
    categoria: 'Trasparenza',
    immagine: '📝'
  });

  // Stato per gestione immagini
  const [immaginiArticolo, setImmaginiArticolo] = useState<string[]>([]);
  const [uploadingImage, setUploadingImage] = useState(false);

  // Stati per commenti
  const [commenti, setCommenti] = useState<BlogComment[]>([]);
  const [commentStats, setCommentStats] = useState<CommentStats | null>(null);
  const [filtroCommenti, setFiltroCommenti] = useState('tutti');
  const [commentoHighlight, setCommentoHighlight] = useState<string | null>(null);

  // Stati per configurazione blog
  const [autoApproveComments, setAutoApproveComments] = useState(false);

  const { toast } = useToast();

  // Carica articoli e commenti dal localStorage all'avvio
  useEffect(() => {
    const articoliSalvati = localStorage.getItem('blog-articoli');
    if (articoliSalvati) {
      const articoliCaricati = JSON.parse(articoliSalvati).map((articolo: any) => ({
        ...articolo,
        immagini: articolo.immagini || [],
        tags: articolo.tags || [],
        metaDescription: articolo.metaDescription || '',
        slug: articolo.slug || ''
      }));
      setArticoli(articoliCaricati);
    } else {
      // Salva articoli iniziali
      localStorage.setItem('blog-articoli', JSON.stringify(articoliIniziali));
    }

    // Carica commenti e statistiche
    loadCommenti();

    // Carica configurazione blog
    loadConfigurazione();

    // Controlla se c'è un commento da evidenziare (da notifica)
    const urlParams = new URLSearchParams(window.location.search);
    const highlight = urlParams.get('highlight');
    if (highlight) {
      setCommentoHighlight(highlight);
    }
  }, []);

  const loadCommenti = () => {
    const commentiData = blogCommentService.getCommentsForModeration();
    const stats = blogCommentService.getCommentStats();
    setCommenti(commentiData);
    setCommentStats(stats);
  };

  const loadConfigurazione = () => {
    const config = blogCommentService.getConfig();
    setAutoApproveComments(config.autoApproveComments || false);
  };

  const toggleAutoApproveComments = (enabled: boolean) => {
    const result = blogCommentService.updateConfig({ autoApproveComments: enabled });

    if (result.success) {
      setAutoApproveComments(enabled);
      toast({
        title: enabled ? "✅ Approvazione Automatica ATTIVATA" : "🛡️ Moderazione Manuale ATTIVATA",
        description: result.message,
      });
    } else {
      toast({
        title: "Errore",
        description: result.message,
        variant: "destructive"
      });
    }
  };

  // Salva articoli nel localStorage
  const salvaArticoli = (nuoviArticoli: Articolo[]) => {
    setArticoli(nuoviArticoli);
    localStorage.setItem('blog-articoli', JSON.stringify(nuoviArticoli));
  };

  const articoliFiltrati = articoli.filter(articolo => {
    const corrispondeRicerca = articolo.titolo.toLowerCase().includes(ricerca.toLowerCase()) ||
                              articolo.categoria.toLowerCase().includes(ricerca.toLowerCase());
    const corrispondeStato = filtroStato === 'tutti' || articolo.stato === filtroStato;
    return corrispondeRicerca && corrispondeStato;
  });

  const aggiungiArticolo = () => {
    if (!nuovoArticolo.titolo || !nuovoArticolo.contenuto) {
      toast({
        title: "Errore",
        description: "Titolo e contenuto sono obbligatori",
        variant: "destructive"
      });
      return;
    }

    const articolo = {
      id: articoli.length + 1,
      titolo: nuovoArticolo.titolo,
      riassunto: nuovoArticolo.riassunto || `${nuovoArticolo.contenuto.substring(0, 150)}...`,
      contenuto: nuovoArticolo.contenuto,
      categoria: nuovoArticolo.categoria,
      immagine: nuovoArticolo.immagine,
      immagini: immaginiArticolo.length > 0 ? [...immaginiArticolo] : [],
      data: new Date().toISOString().split('T')[0],
      autore: "Admin", // TODO: Prendere dall'utente loggato
      stato: "pubblicato",
      visite: 0,
      commenti: 0,
      tags: [],
      metaDescription: nuovoArticolo.riassunto || `${nuovoArticolo.contenuto.substring(0, 150)}...`,
      slug: nuovoArticolo.titolo.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
    };

    salvaArticoli([...articoli, articolo]);
    setNuovoArticolo({ titolo: '', riassunto: '', contenuto: '', categoria: 'Trasparenza', immagine: '📝' });
    setImmaginiArticolo([]);
    setDialogAperto(false);

    toast({
      title: "✅ Articolo pubblicato!",
      description: `"${articolo.titolo}" è stato pubblicato con successo`,
    });
  };

  const modificaArticolo = (articolo: Articolo) => {
    setArticoloCorrente(articolo);
    setNuovoArticolo({
      titolo: articolo.titolo,
      riassunto: articolo.riassunto,
      contenuto: articolo.contenuto,
      categoria: articolo.categoria,
      immagine: articolo.immagine
    });
    setImmaginiArticolo(articolo.immagini || []);
    setModalitaEdit(true);
    setDialogAperto(true);
  };

  const salvaModifiche = () => {
    if (!nuovoArticolo.titolo || !nuovoArticolo.contenuto) {
      toast({
        title: "Errore",
        description: "Titolo e contenuto sono obbligatori",
        variant: "destructive"
      });
      return;
    }

    if (!articoloCorrente) {
      toast({
        title: "Errore",
        description: "Nessun articolo selezionato per la modifica",
        variant: "destructive"
      });
      return;
    }

    const articoliAggiornati = articoli.map(a =>
      a.id === articoloCorrente.id
        ? {
            ...a,
            titolo: nuovoArticolo.titolo,
            riassunto: nuovoArticolo.riassunto || `${nuovoArticolo.contenuto.substring(0, 150)}...`,
            contenuto: nuovoArticolo.contenuto,
            categoria: nuovoArticolo.categoria,
            immagine: nuovoArticolo.immagine,
            immagini: immaginiArticolo.length > 0 ? [...immaginiArticolo] : []
          }
        : a
    );

    salvaArticoli(articoliAggiornati);
    resetForm();

    toast({
      title: "✅ Articolo aggiornato!",
      description: "Le modifiche sono state salvate",
    });
  };

  const eliminaArticolo = (id: number) => {
    if (confirm("Sei sicuro di voler eliminare questo articolo?")) {
      const articoliAggiornati = articoli.filter(a => a.id !== id);
      salvaArticoli(articoliAggiornati);

      toast({
        title: "🗑️ Articolo eliminato",
        description: "L'articolo è stato rimosso dal blog",
      });
    }
  };

  const cambiaStato = (id: number, nuovoStato: string) => {
    const articoliAggiornati = articoli.map(a =>
      a.id === id ? { ...a, stato: nuovoStato } : a
    );
    salvaArticoli(articoliAggiornati);

    toast({
      title: "Stato aggiornato",
      description: `Articolo ${nuovoStato}`,
    });
  };

  const resetForm = () => {
    setNuovoArticolo({ titolo: '', riassunto: '', contenuto: '', categoria: 'Trasparenza', immagine: '📝' });
    setImmaginiArticolo([]);
    setArticoloCorrente(null);
    setModalitaEdit(false);
    setDialogAperto(false);
  };

  const getStatoBadge = (stato: string) => {
    switch (stato) {
      case 'pubblicato':
        return <Badge className="bg-green-600">🌐 Pubblicato</Badge>;
      case 'bozza':
        return <Badge variant="secondary">📝 Bozza</Badge>;
      case 'archiviato':
        return <Badge variant="outline">📦 Archiviato</Badge>;
      default:
        return <Badge variant="outline">{stato}</Badge>;
    }
  };

  // Funzioni per gestione immagini
  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setUploadingImage(true);

    try {
      const newImages: string[] = [];

      for (let i = 0; i < Math.min(files.length, 5); i++) { // Massimo 5 immagini
        const file = files[i];

        // Validazione tipo file
        if (!file.type.startsWith('image/')) {
          toast({
            title: "Errore",
            description: `${file.name} non è un'immagine valida`,
            variant: "destructive"
          });
          continue;
        }

        // Validazione dimensione (max 2MB)
        if (file.size > 2 * 1024 * 1024) {
          toast({
            title: "Errore",
            description: `${file.name} è troppo grande (max 2MB)`,
            variant: "destructive"
          });
          continue;
        }

        // Converti in base64
        const base64 = await fileToBase64(file);
        newImages.push(base64);
      }

      setImmaginiArticolo(prev => [...prev, ...newImages].slice(0, 5)); // Massimo 5 totali

      if (newImages.length > 0) {
        toast({
          title: "✅ Immagini caricate!",
          description: `${newImages.length} immagine/i aggiunte al blog`,
        });
      }

    } catch (error) {
      toast({
        title: "Errore",
        description: "Errore nel caricamento delle immagini",
        variant: "destructive"
      });
    } finally {
      setUploadingImage(false);
      // Reset input
      event.target.value = '';
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const rimuoviImmagine = (index: number) => {
    setImmaginiArticolo(prev => prev.filter((_, i) => i !== index));
    toast({
      title: "🗑️ Immagine rimossa",
      description: "L'immagine è stata eliminata dal blog",
    });
  };

  // Funzioni per gestione commenti
  const moderaCommento = async (commentId: string, azione: 'approva' | 'rifiuta', motivo?: string) => {
    const result = blogCommentService.moderateComment(commentId, azione, 'admin', motivo);

    if (result.success) {
      loadCommenti();
      toast({
        title: `✅ ${azione === 'approva' ? 'Approvato' : 'Rifiutato'}`,
        description: result.message,
      });
    } else {
      toast({
        title: "Errore",
        description: result.message,
        variant: "destructive"
      });
    }
  };

  const eliminaCommento = (commentId: string) => {
    if (confirm("Sei sicuro di voler eliminare questo commento e tutte le sue risposte?")) {
      const result = blogCommentService.deleteComment(commentId, '', true);

      if (result.success) {
        loadCommenti();
        toast({
          title: "🗑️ Commento eliminato",
          description: result.message,
        });
      } else {
        toast({
          title: "Errore",
          description: result.message,
          variant: "destructive"
        });
      }
    }
  };

  // Approva tutti i commenti in moderazione
  const approvaTuttiCommenti = () => {
    if (confirm(`Sei sicuro di voler approvare automaticamente tutti i ${commentStats?.inModerazione || 0} commenti in moderazione?`)) {
      const result = blogCommentService.approveAllPendingComments('admin');

      if (result.success) {
        loadCommenti();
        toast({
          title: "✅ Approvazione automatica completata!",
          description: result.message,
        });
      } else {
        toast({
          title: "Errore",
          description: result.message,
          variant: "destructive"
        });
      }
    }
  };

  // Elimina tutti i commenti segnalati
  const eliminaCommentiSegnalati = () => {
    const commentiSegnalati = commenti.filter(c => c.flagged).map(c => c.id);
    if (commentiSegnalati.length === 0) {
      toast({
        title: "Info",
        description: "Nessun commento segnalato da eliminare",
      });
      return;
    }

    if (confirm(`Sei sicuro di voler eliminare tutti i ${commentiSegnalati.length} commenti segnalati?`)) {
      const result = blogCommentService.deleteMultipleComments(commentiSegnalati, true);

      if (result.success) {
        loadCommenti();
        toast({
          title: "🗑️ Commenti segnalati eliminati",
          description: result.message,
        });
      } else {
        toast({
          title: "Errore",
          description: result.message,
          variant: "destructive"
        });
      }
    }
  };

  const commentiFiltratiAdmin = commenti.filter(commento => {
    switch (filtroCommenti) {
      case 'in_moderazione':
        return commento.stato === 'in_moderazione';
      case 'flagged':
        return commento.flagged;
      default:
        return true;
    }
  });

  const getCommentoBadge = (commento: BlogComment) => {
    if (commento.flagged) {
      return <Badge variant="destructive">🚩 Segnalato</Badge>;
    }
    switch (commento.stato) {
      case 'approvato':
        return <Badge className="bg-green-600">✅ Approvato</Badge>;
      case 'in_moderazione':
        return <Badge variant="secondary">⏳ In Moderazione</Badge>;
      case 'rifiutato':
        return <Badge variant="outline">❌ Rifiutato</Badge>;
      default:
        return <Badge variant="outline">{commento.stato}</Badge>;
    }
  };

  const getRuoloBadge = (ruolo: string) => {
    switch (ruolo) {
      case 'socio':
        return <Badge variant="outline" className="bg-blue-50">👤 Socio</Badge>;
      case 'albergatore':
        return <Badge variant="outline" className="bg-green-50">🏨 Albergatore</Badge>;
      case 'admin':
        return <Badge variant="outline" className="bg-purple-50">👑 Admin</Badge>;
      case 'guest':
        return <Badge variant="outline" className="bg-gray-50">👥 Ospite</Badge>;
      default:
        return <Badge variant="outline">{ruolo}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Gestione Blog</h1>
        <p className="text-gray-600">
          Scrivi articoli, gestisci contenuti e modera commenti
        </p>
      </div>

      {/* Statistiche */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Articoli Totali</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{articoli.length}</div>
            <p className="text-sm text-gray-600">Pubblicati</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Visite Totali</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">
              {articoli.reduce((sum, a) => sum + a.visite, 0)}
            </div>
            <p className="text-sm text-gray-600">Visualizzazioni</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Commenti</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-600">
              {commentStats?.approvati || 0}
            </div>
            <p className="text-sm text-gray-600">
              {commentStats?.inModerazione || 0} da moderare
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Categorie</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">{categorie.length}</div>
            <p className="text-sm text-gray-600">Attive</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs Principali */}
      <Tabs defaultValue="articoli" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="articoli">📝 Articoli</TabsTrigger>
          <TabsTrigger value="commenti">💬 Commenti</TabsTrigger>
          <TabsTrigger value="statistiche">📊 Statistiche</TabsTrigger>
        </TabsList>

        {/* Tab Articoli */}
        <TabsContent value="articoli" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Gestione Articoli ({articoli.length})</CardTitle>
              <CardDescription>
                Scrivi, modifica e pubblica articoli del blog
              </CardDescription>
              <div className="flex justify-between items-center">
                <div className="flex gap-4">
                  <Input
                    placeholder="Cerca articoli..."
                    value={ricerca}
                    onChange={(e) => setRicerca(e.target.value)}
                    className="max-w-sm"
                  />
                  <Select value={filtroStato} onValueChange={setFiltroStato}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="tutti">Tutti ({articoli.length})</SelectItem>
                      <SelectItem value="pubblicato">Pubblicati ({articoli.filter(a => a.stato === 'pubblicato').length})</SelectItem>
                      <SelectItem value="bozza">Bozze ({articoli.filter(a => a.stato === 'bozza').length})</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Dialog open={dialogAperto} onOpenChange={(open) => {
                  if (!open) resetForm();
                  setDialogAperto(open);
                }}>
                  <DialogTrigger asChild>
                    <Button className="bg-green-600 hover:bg-green-700">
                      ✍️ Nuovo Articolo
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>
                        {modalitaEdit ? "Modifica Articolo" : "Nuovo Articolo"}
                      </DialogTitle>
                      <DialogDescription>
                        {modalitaEdit ? "Aggiorna il contenuto dell'articolo" : "Scrivi un nuovo articolo per il blog"}
                      </DialogDescription>
                    </DialogHeader>

                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="titolo">Titolo Articolo</Label>
                          <Input
                            id="titolo"
                            value={nuovoArticolo.titolo}
                            onChange={(e) => setNuovoArticolo({...nuovoArticolo, titolo: e.target.value})}
                            placeholder="Inserisci il titolo..."
                          />
                        </div>
                        <div>
                          <Label htmlFor="categoria">Categoria</Label>
                          <Select value={nuovoArticolo.categoria} onValueChange={(value) => setNuovoArticolo({...nuovoArticolo, categoria: value})}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {categorie.map(cat => (
                                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="immagine">Emoji/Icona</Label>
                          <Input
                            id="immagine"
                            value={nuovoArticolo.immagine}
                            onChange={(e) => setNuovoArticolo({...nuovoArticolo, immagine: e.target.value})}
                            placeholder="📝"
                          />
                        </div>
                        <div>
                          <Label htmlFor="riassunto">Riassunto (opzionale)</Label>
                          <Input
                            id="riassunto"
                            value={nuovoArticolo.riassunto}
                            onChange={(e) => setNuovoArticolo({...nuovoArticolo, riassunto: e.target.value})}
                            placeholder="Breve descrizione..."
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="contenuto">Contenuto Articolo</Label>
                        <Textarea
                          id="contenuto"
                          value={nuovoArticolo.contenuto}
                          onChange={(e) => setNuovoArticolo({...nuovoArticolo, contenuto: e.target.value})}
                          placeholder="Scrivi il contenuto dell'articolo..."
                          rows={10}
                          className="resize-none"
                        />
                        <p className="text-sm text-gray-500 mt-1">
                          Caratteri: {nuovoArticolo.contenuto.length}
                        </p>
                      </div>

                      {/* Sezione Upload Immagini */}
                      <div>
                        <Label htmlFor="immagini">📸 Immagini Articolo (opzionale)</Label>
                        <div className="space-y-4">
                          {/* Upload Input con Drag & Drop */}
                          <div className="space-y-4">
                            {/* Drag & Drop Area */}
                            <div
                              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                                uploadingImage || immaginiArticolo.length >= 5
                                  ? 'border-gray-300 bg-gray-50'
                                  : 'border-blue-300 bg-blue-50 hover:border-blue-400 hover:bg-blue-100 cursor-pointer'
                              }`}
                              onClick={() => !uploadingImage && immaginiArticolo.length < 5 && document.getElementById('immagini')?.click()}
                              onDragOver={(e) => {
                                e.preventDefault();
                                if (!uploadingImage && immaginiArticolo.length < 5) {
                                  e.currentTarget.classList.add('border-blue-500', 'bg-blue-100');
                                }
                              }}
                              onDragLeave={(e) => {
                                e.preventDefault();
                                e.currentTarget.classList.remove('border-blue-500', 'bg-blue-100');
                              }}
                              onDrop={(e) => {
                                e.preventDefault();
                                e.currentTarget.classList.remove('border-blue-500', 'bg-blue-100');
                                if (!uploadingImage && immaginiArticolo.length < 5) {
                                  const files = Array.from(e.dataTransfer.files).filter(file => file.type.startsWith('image/'));
                                  if (files.length > 0) {
                                    // Simula l'evento di input file
                                    const input = document.getElementById('immagini') as HTMLInputElement;
                                    const dt = new DataTransfer();
                                    files.forEach(file => dt.items.add(file));
                                    input.files = dt.files;
                                    handleImageUpload({ target: input } as any);
                                  }
                                }
                              }}
                            >
                              <div className="space-y-3">
                                <div className="text-4xl">
                                  {uploadingImage ? "⏳" : immaginiArticolo.length >= 5 ? "📸" : "📤"}
                                </div>
                                <div>
                                  <p className="text-lg font-medium text-gray-700">
                                    {uploadingImage
                                      ? "Caricamento in corso..."
                                      : immaginiArticolo.length >= 5
                                      ? "Limite massimo raggiunto (5 foto)"
                                      : "Trascina le foto qui o clicca per selezionare"
                                    }
                                  </p>
                                  {!uploadingImage && immaginiArticolo.length < 5 && (
                                    <p className="text-sm text-gray-500 mt-1">
                                      Supporta JPG, PNG, GIF • Max 2MB per file • Fino a 5 immagini
                                    </p>
                                  )}
                                </div>
                                {!uploadingImage && immaginiArticolo.length < 5 && (
                                  <Button
                                    type="button"
                                    variant="outline"
                                    size="sm"
                                    className="mt-3"
                                  >
                                    📁 Scegli Foto dal Computer
                                  </Button>
                                )}
                              </div>
                            </div>

                            {/* Hidden File Input */}
                            <Input
                              id="immagini"
                              type="file"
                              accept="image/*"
                              multiple
                              onChange={handleImageUpload}
                              disabled={uploadingImage || immaginiArticolo.length >= 5}
                              className="hidden"
                            />
                          </div>

                          {/* Info */}
                          <div className="text-sm text-gray-600 bg-green-50 p-4 rounded-lg border border-green-200">
                            <p className="font-bold text-green-800 mb-2">📸 Come Aggiungere Foto al Tuo Articolo:</p>
                            <div className="space-y-2 text-green-700">
                              <p><strong>Metodo 1:</strong> 🖱️ <strong>Clicca</strong> nell'area tratteggiata sopra → Seleziona le foto dal computer</p>
                              <p><strong>Metodo 2:</strong> 🖱️ <strong>Trascina</strong> le foto direttamente dall'Esplora File nell'area sopra</p>
                              <div className="bg-white p-2 rounded text-xs mt-3">
                                <strong>✅ Requisiti:</strong> JPG/PNG/GIF • Max 2MB • Fino a 5 foto • Le foto saranno visibili nella galleria dell'articolo pubblicato
                              </div>
                            </div>
                          </div>

                          {/* Anteprima Immagini Caricate */}
                          {immaginiArticolo.length > 0 && (
                            <div>
                              <p className="text-sm font-medium text-gray-700 mb-3">
                                📸 Immagini Caricate ({immaginiArticolo.length}/5):
                              </p>
                              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                {immaginiArticolo.map((immagine, index) => (
                                  <div key={index} className="relative group">
                                    <img
                                      src={immagine}
                                      alt={`Immagine ${index + 1}`}
                                      className="w-full h-32 object-cover rounded-lg border"
                                    />
                                    <Button
                                      type="button"
                                      variant="destructive"
                                      size="sm"
                                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                                      onClick={() => rimuoviImmagine(index)}
                                    >
                                      🗑️
                                    </Button>
                                    <div className="absolute bottom-2 left-2 bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
                                      Foto {index + 1}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex gap-4">
                        <Button
                          onClick={modalitaEdit ? salvaModifiche : aggiungiArticolo}
                          className="flex-1"
                        >
                          {modalitaEdit ? "💾 Salva Modifiche" : "📝 Pubblica Articolo"}
                        </Button>
                        <Button variant="outline" onClick={resetForm}>
                          Annulla
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Articolo</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Stato</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Engagement</TableHead>
                    <TableHead>Azioni</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {articoliFiltrati.map((articolo) => (
                    <TableRow key={articolo.id}>
                      <TableCell>
                        <div className="flex items-start gap-3">
                          <div className="text-2xl">{articolo.immagine}</div>
                          <div>
                            <div className="font-medium">{articolo.titolo}</div>
                            <div className="text-sm text-gray-600 max-w-md">
                              {articolo.riassunto}
                            </div>
                            <div className="text-xs text-gray-500">
                              di {articolo.autore}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{articolo.categoria}</Badge>
                      </TableCell>
                      <TableCell>
                        {getStatoBadge(articolo.stato)}
                      </TableCell>
                      <TableCell>{articolo.data}</TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>👁️ {articolo.visite} visite</div>
                          <div>💬 {articolo.commenti} commenti</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1 flex-wrap">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => modificaArticolo(articolo)}
                            className="text-xs"
                          >
                            ✏️ Modifica
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => cambiaStato(articolo.id, articolo.stato === 'pubblicato' ? 'bozza' : 'pubblicato')}
                            className="text-xs"
                          >
                            {articolo.stato === 'pubblicato' ? '📦 Archivia' : '🌐 Pubblica'}
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => eliminaArticolo(articolo.id)}
                            className="text-xs"
                          >
                            🗑️ Elimina
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab Commenti */}
        <TabsContent value="commenti" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Moderazione Commenti ({commenti.length})</CardTitle>
              <CardDescription>
                Modera i commenti degli utenti sui tuoi articoli
              </CardDescription>
              <div className="flex flex-wrap gap-2">
                <Select value={filtroCommenti} onValueChange={setFiltroCommenti}>
                  <SelectTrigger className="w-64">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tutti">Tutti ({commenti.length})</SelectItem>
                    <SelectItem value="in_moderazione">In Moderazione ({commentStats?.inModerazione || 0})</SelectItem>
                    <SelectItem value="flagged">Segnalati ({commenti.filter(c => c.flagged).length})</SelectItem>
                  </SelectContent>
                </Select>

                {/* Toggle Approvazione Automatica */}
                <div className="flex items-center gap-3 px-4 py-2 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-blue-900">
                      {autoApproveComments ? "🚀 Approvazione Automatica" : "🛡️ Moderazione Manuale"}
                    </span>
                    <span className="text-xs text-blue-700">
                      {autoApproveComments
                        ? "I commenti vanno online immediatamente"
                        : "I commenti richiedono approvazione admin"
                      }
                    </span>
                  </div>
                  <Switch
                    checked={autoApproveComments}
                    onCheckedChange={toggleAutoApproveComments}
                    className="data-[state=checked]:bg-green-600"
                  />
                </div>

                {/* Pulsanti Azioni Rapide */}
                {(commentStats?.inModerazione || 0) > 0 && (
                  <Button
                    onClick={approvaTuttiCommenti}
                    className="bg-green-600 hover:bg-green-700"
                    size="sm"
                  >
                    ✅ Approva Tutti ({commentStats?.inModerazione})
                  </Button>
                )}

                {commenti.filter(c => c.flagged).length > 0 && (
                  <Button
                    onClick={eliminaCommentiSegnalati}
                    variant="destructive"
                    size="sm"
                  >
                    🗑️ Elimina Segnalati ({commenti.filter(c => c.flagged).length})
                  </Button>
                )}

                <Button
                  variant="outline"
                  onClick={() => {
                    loadCommenti();
                    toast({ title: "🔄 Dati aggiornati", description: "Commenti ricaricati" });
                  }}
                  size="sm"
                >
                  🔄 Aggiorna
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {commentiFiltratiAdmin.length > 0 ? (
                <div className="space-y-4">
                  {commentiFiltratiAdmin.map((commento) => (
                    <Card
                      key={commento.id}
                      className={`p-4 ${commentoHighlight === commento.id ? 'ring-2 ring-blue-500' : ''} ${commento.flagged ? 'border-red-200 bg-red-50' : ''}`}
                    >
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex items-center gap-3">
                          <div>
                            <div className="font-medium">{commento.autore}</div>
                            <div className="text-sm text-gray-600">{commento.email}</div>
                          </div>
                          {getRuoloBadge(commento.ruolo)}
                          {getCommentoBadge(commento)}
                        </div>
                        <div className="text-sm text-gray-500">
                          Articolo ID: {commento.articoloId}
                          <br />
                          {new Date(commento.timestamp).toLocaleString('it-IT')}
                        </div>
                      </div>

                      <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                        <p className="text-gray-800">{commento.contenuto}</p>
                        {commento.risposteA && (
                          <div className="mt-2 text-xs text-blue-600">
                            ↳ Risposta al commento {commento.risposteA}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          <span>👍 {commento.likes} likes</span>
                          {commento.flagged && <span>🚩 Segnalato</span>}
                          {commento.motivoRifiuto && <span>❌ {commento.motivoRifiuto}</span>}
                        </div>

                        <div className="flex gap-2">
                          {commento.stato === 'in_moderazione' && (
                            <>
                              <Button
                                size="sm"
                                onClick={() => moderaCommento(commento.id, 'approva')}
                                className="bg-green-600 hover:bg-green-700 text-xs"
                              >
                                ✅ Approva
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => {
                                  const motivo = prompt("Motivo del rifiuto (opzionale):");
                                  moderaCommento(commento.id, 'rifiuta', motivo || undefined);
                                }}
                                className="text-xs"
                              >
                                ❌ Rifiuta
                              </Button>
                            </>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => eliminaCommento(commento.id)}
                            className="text-xs"
                          >
                            🗑️ Elimina
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-gray-500">
                  {filtroCommenti === 'tutti'
                    ? "📭 Nessun commento da moderare"
                    : `📭 Nessun commento ${filtroCommenti === 'in_moderazione' ? 'in moderazione' : 'segnalato'}`
                  }
                  <br />
                  <span className="text-sm">I commenti appariranno qui quando gli utenti li invieranno</span>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Statistiche Commenti */}
          {commentStats && (
            <Card>
              <CardHeader>
                <CardTitle>Statistiche Commenti</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{commentStats.totali}</div>
                    <div className="text-sm text-blue-800">Totali</div>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{commentStats.approvati}</div>
                    <div className="text-sm text-green-800">Approvati</div>
                  </div>
                  <div className="text-center p-3 bg-yellow-50 rounded-lg">
                    <div className="text-2xl font-bold text-yellow-600">{commentStats.inModerazione}</div>
                    <div className="text-sm text-yellow-800">In Moderazione</div>
                  </div>
                  <div className="text-center p-3 bg-red-50 rounded-lg">
                    <div className="text-2xl font-bold text-red-600">{commentStats.rifiutati}</div>
                    <div className="text-sm text-red-800">Rifiutati</div>
                  </div>
                </div>

                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium mb-3">Commenti per Ruolo</h4>
                    <div className="space-y-2">
                      {Object.entries(commentStats.perRuolo).map(([ruolo, count]) => (
                        <div key={ruolo} className="flex justify-between items-center">
                          <span className="text-sm capitalize">{ruolo}</span>
                          <Badge variant="outline">{count}</Badge>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-3">Articoli più Commentati</h4>
                    <div className="space-y-2">
                      {Object.entries(commentStats.perArticolo)
                        .sort(([,a], [,b]) => (b as number) - (a as number))
                        .slice(0, 5)
                        .map(([articoloId, count]) => {
                          const articolo = articoli.find(a => a.id === Number.parseInt(articoloId));
                          return (
                            <div key={articoloId} className="flex justify-between items-center">
                              <span className="text-sm truncate max-w-[200px]">
                                {articolo?.titolo || `Articolo ${articoloId}`}
                              </span>
                              <Badge variant="outline">{count as number}</Badge>
                            </div>
                          );
                        })}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Tab Statistiche */}
        <TabsContent value="statistiche" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Statistiche Dettagliate</CardTitle>
              <CardDescription>
                Analytics approfonditi sul tuo blog
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium">Articoli per Categoria</h4>
                  {categorie.map(categoria => {
                    const count = articoli.filter(a => a.categoria === categoria).length;
                    return (
                      <div key={categoria} className="flex justify-between items-center">
                        <span className="text-sm">{categoria}</span>
                        <Badge variant="outline">{count}</Badge>
                      </div>
                    );
                  })}
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Articoli più Popolari</h4>
                  {articoli
                    .sort((a, b) => b.visite - a.visite)
                    .slice(0, 5)
                    .map(articolo => (
                      <div key={articolo.id} className="flex justify-between items-center">
                        <span className="text-sm truncate max-w-[200px]">{articolo.titolo}</span>
                        <Badge variant="outline">👁️ {articolo.visite}</Badge>
                      </div>
                    ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
