export default function TestBasic() {
  return <h1 style={{color: 'red', fontSize: '50px', backgroundColor: 'yellow', padding: '50px'}}>BASIC TEST WORKS!</h1>;
}
