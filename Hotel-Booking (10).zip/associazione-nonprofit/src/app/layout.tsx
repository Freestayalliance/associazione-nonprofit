import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import ClientBody from "./ClientBody";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { NotificationProvider } from "@/contexts/NotificationContext";
import { NotificationToast } from "@/components/NotificationToast";
import { Toaster } from "@/components/ui/toaster";
import AnalyticsProvider from "@/components/AnalyticsProvider";
import PartnerBanner from "@/components/PartnerBanner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "FREE STAY ALLIANCE | Trasparenza e Partecipazione",
  description: "Un'alleanza dedicata al supporto della comunità attraverso trasparenza, partecipazione e responsabilità sociale.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="it" className={`${geistSans.variable} ${geistMono.variable}`}>
      <body suppressHydrationWarning className="antialiased">
        <ClientBody>
          <AnalyticsProvider>
            <NotificationProvider>
              <div className="min-h-screen flex flex-col">
                <Header />
                <PartnerBanner />
                <main className="flex-1">
                  {children}
                </main>
                <Footer />
              </div>
              <NotificationToast />
              <Toaster />
            </NotificationProvider>
          </AnalyticsProvider>
        </ClientBody>
      </body>
    </html>
  );
}
