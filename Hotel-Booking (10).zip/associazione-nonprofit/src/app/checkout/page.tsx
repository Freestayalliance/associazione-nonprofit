"use client"

import { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import PaymentService, { type PaymentIntent } from '@/services/PaymentService';
import Link from "next/link";

function CheckoutContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();

  // Stati del form
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    postalCode: '',
    membershipType: 'annual', // annual, monthly
    agreeTerms: false,
    agreePrivacy: false
  });

  // Stati pagamento
  const [paymentData, setPaymentData] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardholderName: ''
  });

  // Stati UI
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const [paymentIntent, setPaymentIntent] = useState<PaymentIntent | null>(null);
  const [step, setStep] = useState<'details' | 'payment' | 'processing'>('details');

  // Configurazione prezzi
  const config = PaymentService.getConfig();
  const prices = {
    annual: config.membershipFees.annual,
    monthly: config.membershipFees.monthly
  };

  // Pre-riempi dai parametri URL se disponibili
  useEffect(() => {
    const name = searchParams.get('name');
    const email = searchParams.get('email');
    const type = searchParams.get('type');

    if (name || email || type) {
      setFormData(prev => ({
        ...prev,
        ...(name && { name }),
        ...(email && { email }),
        ...(type && { membershipType: type })
      }));
    }
  }, [searchParams]);

  const validateForm = (): boolean => {
    const newErrors: string[] = [];

    // Validazione dati personali
    if (!formData.name.trim()) newErrors.push('Nome è obbligatorio');
    if (!formData.email.trim()) newErrors.push('Email è obbligatoria');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.push('Email non valida');
    if (!formData.phone.trim()) newErrors.push('Telefono è obbligatorio');
    if (!formData.address.trim()) newErrors.push('Indirizzo è obbligatorio');
    if (!formData.city.trim()) newErrors.push('Città è obbligatoria');
    if (!formData.postalCode.trim()) newErrors.push('CAP è obbligatorio');
    if (!formData.agreeTerms) newErrors.push('Devi accettare i termini di servizio');
    if (!formData.agreePrivacy) newErrors.push('Devi accettare la privacy policy');

    setErrors(newErrors);
    return newErrors.length === 0;
  };

  const validatePayment = (): boolean => {
    const newErrors: string[] = [];

    // Validazione carta di credito (pattern semplificati per demo)
    if (!paymentData.cardNumber.replace(/\s/g, '')) newErrors.push('Numero carta è obbligatorio');
    if (paymentData.cardNumber.replace(/\s/g, '').length < 13) newErrors.push('Numero carta non valido');
    if (!paymentData.expiryDate) newErrors.push('Data scadenza è obbligatoria');
    if (!paymentData.cvv || paymentData.cvv.length < 3) newErrors.push('CVV non valido');
    if (!paymentData.cardholderName.trim()) newErrors.push('Nome titolare è obbligatorio');

    setErrors(newErrors);
    return newErrors.length === 0;
  };

  const handleDetailsSubmit = async () => {
    if (!validateForm()) return;

    setIsLoading(true);
    try {
      // Crea Payment Intent
      const amount = prices[formData.membershipType as keyof typeof prices];
      const description = `Quota associativa ${formData.membershipType === 'annual' ? 'annuale' : 'mensile'}`;

      const result = await PaymentService.createPaymentIntent(
        amount,
        description,
        {
          type: 'membership_fee',
          period: formData.membershipType as 'annual' | 'monthly',
          membershipYear: new Date().getFullYear().toString()
        },
        {
          id: `user_${Date.now()}`,
          email: formData.email,
          name: formData.name
        }
      );

      if (result.success && result.paymentIntent) {
        setPaymentIntent(result.paymentIntent);
        setStep('payment');
        toast({
          title: "✅ Dati confermati",
          description: "Procedi con il pagamento per completare l'iscrizione",
        });
      } else {
        throw new Error(result.error || 'Errore nella creazione del pagamento');
      }

    } catch (error) {
      console.error('Errore:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore. Riprova.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handlePaymentSubmit = async () => {
    if (!validatePayment() || !paymentIntent) return;

    setIsLoading(true);
    setStep('processing');

    try {
      // Simula elaborazione carta
      const result = await PaymentService.confirmPayment(
        paymentIntent.id,
        'pm_demo_card_visa'
      );

      if (result.success) {
        toast({
          title: "🎉 Pagamento completato!",
          description: "Benvenuto nella nostra associazione!",
        });

        // Reindirizza alla pagina di successo
        setTimeout(() => {
          router.push(`/checkout/success?payment_intent=${paymentIntent.id}`);
        }, 1500);

      } else {
        throw new Error(result.error || 'Pagamento fallito');
      }

    } catch (error) {
      console.error('Errore pagamento:', error);
      setStep('payment');
      toast({
        title: "❌ Pagamento fallito",
        description: (error as Error)?.message || "Controlla i dati della carta e riprova",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const formatExpiryDate = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return v.substring(0, 2) + (v.length > 2 ? '/' + v.substring(2, 4) : '');
    }
    return v;
  };

  const currentPrice = prices[formData.membershipType as keyof typeof prices];

  return (
    <div className="container px-4 py-8 max-w-4xl mx-auto">
      {/* Header */}
      <div className="text-center mb-8">
        <Badge variant="secondary" className="mb-4">
          💳 Pagamento Sicuro
        </Badge>
        <h1 className="text-3xl md:text-4xl font-bold mb-4">
          Completa la Tua <span className="text-blue-600">Iscrizione</span>
        </h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Unisciti alla nostra associazione con un pagamento sicuro al 100%.
          I tuoi dati sono protetti e crittografati.
        </p>
      </div>

      {/* Breadcrumb Steps */}
      <div className="flex items-center justify-center mb-8">
        <div className="flex items-center gap-4">
          <div className={`flex items-center gap-2 ${step === 'details' ? 'text-blue-600' : step === 'payment' || step === 'processing' ? 'text-green-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step === 'details' ? 'bg-blue-600 text-white' : step === 'payment' || step === 'processing' ? 'bg-green-600 text-white' : 'bg-gray-200'}`}>
              {step === 'payment' || step === 'processing' ? '✓' : '1'}
            </div>
            <span className="font-medium">Dati Personali</span>
          </div>
          <div className="w-8 h-px bg-gray-300"></div>
          <div className={`flex items-center gap-2 ${step === 'payment' ? 'text-blue-600' : step === 'processing' ? 'text-green-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step === 'payment' ? 'bg-blue-600 text-white' : step === 'processing' ? 'bg-green-600 text-white' : 'bg-gray-200'}`}>
              {step === 'processing' ? '✓' : '2'}
            </div>
            <span className="font-medium">Pagamento</span>
          </div>
          <div className="w-8 h-px bg-gray-300"></div>
          <div className={`flex items-center gap-2 ${step === 'processing' ? 'text-blue-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step === 'processing' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
              3
            </div>
            <span className="font-medium">Conferma</span>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Form principale */}
        <div className="lg:col-span-2">
          {/* Step 1: Dati Personali */}
          {step === 'details' && (
            <Card>
              <CardHeader>
                <CardTitle>📝 Dati Personali</CardTitle>
                <CardDescription>
                  Inserisci i tuoi dati per l'iscrizione all'associazione
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Errori */}
                {errors.length > 0 && (
                  <Alert variant="destructive">
                    <AlertDescription>
                      <ul className="list-disc ml-4">
                        {errors.map((error, index) => (
                          <li key={index}>{error}</li>
                        ))}
                      </ul>
                    </AlertDescription>
                  </Alert>
                )}

                {/* Tipo iscrizione */}
                <div>
                  <Label>Tipo di Iscrizione</Label>
                  <Select
                    value={formData.membershipType}
                    onValueChange={(value) => setFormData({...formData, membershipType: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="annual">
                        📅 Annuale - {PaymentService.formatPrice(prices.annual)}
                        <span className="text-green-600 ml-2">(Risparmia il 15%)</span>
                      </SelectItem>
                      <SelectItem value="monthly">
                        📆 Mensile - {PaymentService.formatPrice(prices.monthly)}
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Dati personali */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Nome Completo *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      placeholder="Mario Rossi"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      placeholder="mario@esempio.com"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="phone">Telefono *</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    placeholder="+39 123 456 7890"
                  />
                </div>

                <div>
                  <Label htmlFor="address">Indirizzo *</Label>
                  <Input
                    id="address"
                    value={formData.address}
                    onChange={(e) => setFormData({...formData, address: e.target.value})}
                    placeholder="Via Roma 123"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="city">Città *</Label>
                    <Input
                      id="city"
                      value={formData.city}
                      onChange={(e) => setFormData({...formData, city: e.target.value})}
                      placeholder="Milano"
                    />
                  </div>
                  <div>
                    <Label htmlFor="postalCode">CAP *</Label>
                    <Input
                      id="postalCode"
                      value={formData.postalCode}
                      onChange={(e) => setFormData({...formData, postalCode: e.target.value})}
                      placeholder="20121"
                    />
                  </div>
                </div>

                {/* Consensi */}
                <div className="space-y-4">
                  <div className="flex items-start space-x-2">
                    <Checkbox
                      id="terms"
                      checked={formData.agreeTerms}
                      onCheckedChange={(checked) => setFormData({...formData, agreeTerms: checked as boolean})}
                    />
                    <label htmlFor="terms" className="text-sm leading-5">
                      Accetto i <Link href="/documentazione" className="text-blue-600 hover:underline">termini di servizio</Link> e lo statuto dell'associazione *
                    </label>
                  </div>

                  <div className="flex items-start space-x-2">
                    <Checkbox
                      id="privacy"
                      checked={formData.agreePrivacy}
                      onCheckedChange={(checked) => setFormData({...formData, agreePrivacy: checked as boolean})}
                    />
                    <label htmlFor="privacy" className="text-sm leading-5">
                      Accetto il trattamento dei dati personali secondo la <Link href="/privacy" className="text-blue-600 hover:underline">privacy policy</Link> *
                    </label>
                  </div>
                </div>

                <Button
                  onClick={handleDetailsSubmit}
                  disabled={isLoading}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  size="lg"
                >
                  {isLoading ? "⏳ Elaborazione..." : "Continua al Pagamento →"}
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Step 2: Pagamento */}
          {step === 'payment' && (
            <Card>
              <CardHeader>
                <CardTitle>💳 Informazioni di Pagamento</CardTitle>
                <CardDescription>
                  I tuoi dati di pagamento sono protetti con crittografia SSL
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Errori */}
                {errors.length > 0 && (
                  <Alert variant="destructive">
                    <AlertDescription>
                      <ul className="list-disc ml-4">
                        {errors.map((error, index) => (
                          <li key={index}>{error}</li>
                        ))}
                      </ul>
                    </AlertDescription>
                  </Alert>
                )}

                {/* Demo Alert */}
                <Alert className="border-yellow-200 bg-yellow-50">
                  <AlertDescription className="text-yellow-800">
                    <strong>🧪 Modalità Demo:</strong> Usa il numero carta <code>4242 4242 4242 4242</code>
                    con qualsiasi data futura e CVV per simulare un pagamento di successo.
                  </AlertDescription>
                </Alert>

                <div>
                  <Label htmlFor="cardholderName">Nome Titolare Carta *</Label>
                  <Input
                    id="cardholderName"
                    value={paymentData.cardholderName}
                    onChange={(e) => setPaymentData({...paymentData, cardholderName: e.target.value})}
                    placeholder="Nome Cognome"
                  />
                </div>

                <div>
                  <Label htmlFor="cardNumber">Numero Carta *</Label>
                  <Input
                    id="cardNumber"
                    value={paymentData.cardNumber}
                    onChange={(e) => setPaymentData({...paymentData, cardNumber: formatCardNumber(e.target.value)})}
                    placeholder="1234 5678 9012 3456"
                    maxLength={19}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="expiryDate">Scadenza *</Label>
                    <Input
                      id="expiryDate"
                      value={paymentData.expiryDate}
                      onChange={(e) => setPaymentData({...paymentData, expiryDate: formatExpiryDate(e.target.value)})}
                      placeholder="MM/AA"
                      maxLength={5}
                    />
                  </div>
                  <div>
                    <Label htmlFor="cvv">CVV *</Label>
                    <Input
                      id="cvv"
                      value={paymentData.cvv}
                      onChange={(e) => setPaymentData({...paymentData, cvv: e.target.value.replace(/\D/g, '')})}
                      placeholder="123"
                      maxLength={4}
                    />
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button
                    variant="outline"
                    onClick={() => setStep('details')}
                    className="flex-1"
                  >
                    ← Indietro
                  </Button>
                  <Button
                    onClick={handlePaymentSubmit}
                    disabled={isLoading}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    size="lg"
                  >
                    {isLoading ? "⏳ Elaborazione..." : `Paga ${PaymentService.formatPrice(currentPrice)}`}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 3: Processing */}
          {step === 'processing' && (
            <Card>
              <CardContent className="text-center py-12">
                <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-6"></div>
                <h3 className="text-xl font-bold mb-2">Elaborazione Pagamento...</h3>
                <p className="text-gray-600 mb-4">
                  Stiamo elaborando il tuo pagamento in modo sicuro.
                  Non chiudere questa pagina.
                </p>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-blue-800">
                    💳 Importo: <strong>{PaymentService.formatPrice(currentPrice)}</strong><br />
                    🏦 Metodo: Carta di Credito<br />
                    🔒 Connessione sicura SSL
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar - Riepilogo */}
        <div className="lg:col-span-1">
          <Card className="sticky top-8">
            <CardHeader>
              <CardTitle>📋 Riepilogo Ordine</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Iscrizione {formData.membershipType === 'annual' ? 'Annuale' : 'Mensile'}</span>
                <span className="font-medium">{PaymentService.formatPrice(currentPrice)}</span>
              </div>

              {formData.membershipType === 'annual' && (
                <div className="flex justify-between items-center text-green-600 text-sm">
                  <span>Sconto annuale (15%)</span>
                  <span>-{PaymentService.formatPrice(prices.monthly * 12 - prices.annual)}</span>
                </div>
              )}

              <Separator />

              <div className="flex justify-between items-center font-bold text-lg">
                <span>Totale</span>
                <span className="text-blue-600">{PaymentService.formatPrice(currentPrice)}</span>
              </div>

              <div className="text-sm text-gray-600 space-y-2">
                <p><strong>✅ Cosa Include:</strong></p>
                <ul className="list-disc ml-4 space-y-1">
                  <li>Partecipazione alle votazioni</li>
                  <li>Accesso a tutti i progetti</li>
                  <li>Newsletter esclusiva</li>
                  <li>Supporto della comunità</li>
                  <li>Trasparenza finanziaria totale</li>
                </ul>
              </div>

              <div className="bg-green-50 p-3 rounded-lg text-sm">
                <p className="text-green-800">
                  <strong>🔒 Pagamento Sicuro</strong><br />
                  Tutti i pagamenti sono elaborati in modo sicuro con crittografia SSL end-to-end.
                </p>
              </div>

              <div className="text-xs text-gray-500">
                Hai domande? <Link href="/contatti" className="text-blue-600 hover:underline">Contattaci</Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default function CheckoutPage() {
  return (
    <Suspense fallback={
      <div className="container px-4 py-8">
        <div className="flex justify-center items-center min-h-64">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Caricamento...</p>
          </div>
        </div>
      </div>
    }>
      <CheckoutContent />
    </Suspense>
  );
}
