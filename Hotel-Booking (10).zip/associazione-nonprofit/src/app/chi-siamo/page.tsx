import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import Link from "next/link";

export default function ChiSiamo() {
  return (
    <div className="container px-4 py-8">
      {/* Hero Section */}
      <section className="text-center py-16 space-y-6">
        <Badge variant="secondary" className="mb-4">
          Chi Siamo / Perché Esistiamo
        </Badge>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
          FREE STAY <span className="text-blue-600">ALLIANCE</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
          Siamo Michael e Vittoria, albergatori indipendenti, marito e moglie, con una missione semplice ma rivoluzionaria:
          <strong> restituire agli albergatori il controllo delle proprie prenotazioni e del proprio lavoro.</strong>
        </p>
      </section>

      {/* Chi Siamo */}
      <section className="py-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-6">👫 Chi Siamo</h2>
            <div className="space-y-4 text-gray-700">
              <p className="text-lg">
                Non siamo politici, né tecnici esterni. Non abbiamo interessi nascosti o sponsor.
              </p>
              <p className="text-lg">
                <strong>Abbiamo vissuto sulla nostra pelle ciò che vivete anche voi:</strong> un sistema che ci impoverisce,
                ci rende schiavi e ci costringe a lavorare per altri, lasciandoci sempre con meno margine,
                meno libertà e più burocrazia.
              </p>
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-50 to-green-50 p-8 rounded-lg">
            <div className="text-center space-y-4">
              <div className="text-6xl mb-4">🏨</div>
              <h3 className="text-xl font-bold text-blue-900">Michael & Vittoria</h3>
              <p className="text-blue-700">Albergatori Indipendenti</p>
              <p className="text-sm text-blue-600">
                "Abbiamo fondato questa alleanza perché crediamo che gli albergatori
                meritino di tornare padroni del proprio lavoro"
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Il Problema */}
      <section className="py-16 bg-red-50">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 text-red-800">🚨 Il Problema</h2>
          <p className="text-red-600 max-w-3xl mx-auto text-lg">
            <strong>Ogni anno, fino al 20% del fatturato delle nostre strutture finisce in mano a multinazionali estere come Booking.com.</strong>
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="border-red-200">
            <CardHeader>
              <CardTitle className="text-red-800">💸 Miliardi di Euro Persi</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-red-700">
                <li>• Non restano nel nostro territorio</li>
                <li>• Non creano ricchezza per le nostre comunità</li>
                <li>• Rafforzano i nostri concorrenti internazionali mentre noi restiamo fermi</li>
                <li>• Ci impongono condizioni arbitrarie e non negoziabili</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-red-200">
            <CardHeader>
              <CardTitle className="text-red-800">🏛️ Stato Italiano Assente</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-red-700">
                Nel frattempo, lo Stato italiano ci ha lasciati soli, ignorando le nostre richieste e introducendo
                norme sempre più assurde, come la <strong>tassa di soggiorno con doppia contabilità</strong>,
                che ci trasforma in esattori e ci sottrae tempo e risorse preziose.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* La Soluzione */}
      <section className="py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 text-green-800">✅ La Soluzione</h2>
          <p className="text-green-600 max-w-3xl mx-auto text-lg">
            Una piattaforma indipendente e un'associazione senza scopo di lucro
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-bold mb-6">🏛️ FreeStay Alliance</h3>
            <p className="text-lg mb-6">Abbiamo fondato FreeStay Alliance, un'associazione non-profit che:</p>

            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <span className="text-green-600 text-xl">🚫</span>
                <p>Non ha gerarchie o presidenti che decidono per tutti</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-600 text-xl">🏨</span>
                <p>È gestita esclusivamente da albergatori</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-600 text-xl">💎</span>
                <p>Garantisce trasparenza totale dei fondi</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="text-green-600 text-xl">🛠️</span>
                <p>Nasce per costruire una piattaforma etica di prenotazione: niente commissioni, controllo totale, sistema semplice</p>
              </div>
            </div>
          </div>

          <Card className="bg-green-50 border-green-200">
            <CardHeader>
              <CardTitle className="text-green-800">📋 Come Funziona</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-green-600">✅</span>
                <p className="text-green-700"><strong>Ogni albergatore è socio</strong> e ha voce e voto</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-600">✅</span>
                <p className="text-green-700">I contributi sono <strong>liberi e totalmente detraibili al 100%</strong></p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-600">✅</span>
                <p className="text-green-700"><strong>Nessuna spesa fissa</strong> o vincoli obbligatori</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-600">✅</span>
                <p className="text-green-700">Nessuno potrà mai vendere la piattaforma a soggetti terzi: <strong>lo statuto lo vieta</strong></p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-600">✅</span>
                <p className="text-green-700"><strong>La piattaforma è nostra</strong>, e resterà per sempre di chi la usa</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Obiettivi Concreti */}
      <section className="py-16 bg-blue-50">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 text-blue-800">🎯 Obiettivi Concreti</h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="border-blue-200">
            <CardHeader>
              <CardTitle className="text-blue-800">📱 Prenotazioni Dirette</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-blue-700">
                <li>• Prenotazioni dirette, senza commissioni</li>
                <li>• Maggior guadagno per le strutture</li>
                <li>• Prezzi più bassi per i clienti</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-blue-200">
            <CardHeader>
              <CardTitle className="text-blue-800">🏛️ Supporto Istituzionale</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-blue-700">
                <li>• Gestione facilitata della tassa di soggiorno</li>
                <li>• Pressione politica per eliminarla o modificarla</li>
                <li>• Supporto legale e fiscale per abusi burocratici</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-blue-200">
            <CardHeader>
              <CardTitle className="text-blue-800">🤝 Community</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-blue-700">
                <li>• Una community di confronto e aiuto tra pari</li>
                <li>• Rete viva, operativa e concreta</li>
                <li>• Tutela del futuro del lavoro</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Perché Aderire */}
      <section className="py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">🤝 Perché Aderire</h2>
          <p className="text-gray-600 max-w-3xl mx-auto text-lg">
            <strong>Unisciti se:</strong>
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-blue-600 font-bold">✓</span>
              </div>
              <p className="text-lg">Ti sei stancato di lavorare per Booking & Co.</p>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-blue-600 font-bold">✓</span>
              </div>
              <p className="text-lg">Vuoi tornare a decidere del tuo futuro</p>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-blue-600 font-bold">✓</span>
              </div>
              <p className="text-lg">Vuoi investire nei tuoi guadagni, non regalarli a multinazionali</p>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-blue-600 font-bold">✓</span>
              </div>
              <p className="text-lg">Vuoi essere parte di una rete viva, operativa e concreta</p>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-blue-600 font-bold">✓</span>
              </div>
              <p className="text-lg">Vuoi tutelare il futuro del tuo lavoro e dei tuoi figli</p>
            </div>
          </div>

          <Card className="bg-yellow-50 border-yellow-200">
            <CardHeader>
              <CardTitle className="text-yellow-800">⚠️ Il Tempo Stringe</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-yellow-700">
                Quel <strong>15-20% che perdiamo ogni anno</strong> non è solo mancato guadagno.
                È ricchezza che alimenta i nostri concorrenti, ci rende più poveri, meno competitivi,
                e rallenta lo sviluppo delle nostre strutture e del nostro territorio.
              </p>
              <p className="text-yellow-700">
                <strong>E più aspettiamo, più sarà difficile tornare indietro:</strong> le piattaforme si evolvono,
                i loro sistemi diventano più sofisticati, e noi sempre più invisibili.
                Non avremo una seconda occasione.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Cosa Chiediamo */}
      <section className="py-16 bg-green-50">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 text-green-800">💪 Cosa Chiediamo</h2>
          <p className="text-green-600 max-w-2xl mx-auto text-xl">
            <strong>Solo una cosa: partecipazione.</strong>
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="border-green-200">
            <CardContent className="pt-8">
              <div className="text-center space-y-6">
                <p className="text-lg text-green-700">
                  Non servono grandi cifre, ma un piccolo contributo economico
                  <strong> (detraibile al 100%)</strong> e una volontà comune di cambiare.
                </p>

                <p className="text-lg text-green-700">
                  Questo è un <strong>movimento di persone vere</strong>, che conoscono il valore del lavoro,
                  della fatica, dell'ospitalità. Se ci uniamo, possiamo davvero cambiare le regole del gioco.
                </p>

                <div className="pt-6">
                  <Button asChild className="bg-green-600 hover:bg-green-700" size="lg">
                    <Link href="/associati">
                      🤝 Diventa Socio - €20/anno (100% detraibile)
                    </Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Perché le Associazioni Esistenti Non Bastano */}
      <section className="py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">🤔 Perché le Associazioni Esistenti Non Bastano Più</h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            In Italia (e non solo) esistono già decine di associazioni di categoria, consorzi, reti territoriali.
            Eppure il problema centrale non è mai stato affrontato davvero:
            <strong> la dipendenza totale dagli intermediari digitali.</strong>
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="border-gray-200">
            <CardHeader>
              <CardTitle className="text-gray-800">❌ Perché Non Funziona?</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-red-500">•</span>
                  <span>La maggior parte di queste realtà non ha <strong>potere operativo</strong> né strumenti concreti</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500">•</span>
                  <span>Molte sono oggi guidate da persone che <strong>non fanno realmente il nostro mestiere</strong></span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500">•</span>
                  <span>Gli incarichi sono formali, senza <strong>responsabilità dirette</strong> o obiettivi misurabili</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500">•</span>
                  <span>Il loro scopo è <strong>non sconvolgere l'equilibrio esistente</strong></span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-blue-800">✅ Il Nostro Approccio</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 text-blue-700">
                <li className="flex items-start gap-2">
                  <span className="text-blue-600">•</span>
                  <span><strong>Azione concreta:</strong> Costruiamo una piattaforma reale</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600">•</span>
                  <span><strong>Gestione diretta:</strong> Solo albergatori prendono decisioni</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600">•</span>
                  <span><strong>Obiettivi misurabili:</strong> Zero commissioni, controllo totale</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600">•</span>
                  <span><strong>Rivoluzione:</strong> Cambiamo davvero le regole del gioco</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Call to Action Finale */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-green-600 text-white">
        <div className="text-center space-y-8">
          <h2 className="text-3xl font-bold">🚀 Insieme Possiamo Cambiare Tutto</h2>
          <p className="text-xl max-w-3xl mx-auto">
            Il futuro del settore alberghiero dipende dalle scelte che facciamo oggi.
            Unisciti alla rivoluzione che restituisce il controllo agli albergatori.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild className="bg-white text-blue-600 hover:bg-gray-100" size="lg">
              <Link href="/associati">
                🤝 Diventa Socio Ora
              </Link>
            </Button>

            <Button asChild variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600" size="lg">
              <Link href="/trasparenza">
                💎 Vedi la Trasparenza
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
