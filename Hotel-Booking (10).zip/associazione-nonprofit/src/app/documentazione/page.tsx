"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import Link from "next/link";
import { useState } from "react";

export default function Documentazione() {
  const [showStatuto, setShowStatuto] = useState(false);
  const [showAttoCostitutivo, setShowAttoCostitutivo] = useState(false);

  return (
    <div className="container px-4 py-8">
      {/* Hero Section */}
      <section className="text-center py-16 space-y-6">
        <Badge variant="secondary" className="mb-4">
          Centro Documentazione
        </Badge>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
          <span className="text-blue-600">Documentazione</span> Completa
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
          Tutte le informazioni, regolamenti, guide e moduli necessari per la vita associativa.
          Trasparenza e facilità di accesso per tutti i soci.
        </p>
      </section>

      {/* Documenti Fondativi - Sezione Principale */}
      <section className="py-16 space-y-8">
        {/* Atto Costitutivo */}
        <Card className="border-2 border-green-200">
          <CardHeader>
            <CardTitle className="text-3xl text-green-600 flex items-center gap-2">
              📜 Atto Costitutivo dell'Associazione "FreeStay Alliance"
            </CardTitle>
            <CardDescription className="text-lg">
              Documento di fondazione ufficiale - Data costituzione: 21 giugno 2025
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-6">
              <div className="text-sm text-gray-600">
                <p><strong>Data costituzione:</strong> 21 giugno 2025</p>
                <p><strong>Luogo:</strong> Salorno (BZ), Via Aldo Moro 20</p>
                <p><strong>Soci fondatori:</strong> Michael Franceschini, Vittoria Sgura, Valerio Rossi</p>
              </div>
              <Button
                onClick={() => setShowAttoCostitutivo(!showAttoCostitutivo)}
                className={showAttoCostitutivo ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"}
              >
                {showAttoCostitutivo ? "📜 Chiudi Atto" : "📜 Leggi Atto Costitutivo"}
              </Button>
            </div>

            {showAttoCostitutivo && (
              <div className="bg-green-50 p-6 rounded-lg border">
                <div className="prose max-w-none text-sm space-y-6">

                  <div className="text-center mb-6">
                    <h3 className="text-xl font-bold text-green-800 mb-2">
                      ATTO COSTITUTIVO DELL'ASSOCIAZIONE "FREESTAY ALLIANCE"
                    </h3>
                    <p className="text-green-700">
                      <strong>L'anno 2025, il giorno 21 del mese di giugno</strong>, in <strong>Salorno (BZ), Via Aldo Moro 20</strong>,
                      si sono riuniti i signori:
                    </p>
                  </div>

                  <div className="bg-white p-4 rounded-lg border border-green-200">
                    <h4 className="text-lg font-bold text-green-800 mb-3">🏛️ Soci Fondatori</h4>
                    <div className="space-y-2 text-green-700">
                      <p><strong>1. Michael Franceschini</strong>, nato a Bolzano il [DATA], residente a [INDIRIZZO], C.F. [CODICE FISCALE]</p>
                      <p><strong>2. Vittoria Sgura</strong>, nata a [LUOGO] il [DATA], residente a [INDIRIZZO], C.F. [CODICE FISCALE]</p>
                      <p><strong>3. Valerio Rossi</strong>, nato a [LUOGO] il [DATA], residente a [INDIRIZZO], C.F. [CODICE FISCALE]</p>
                    </div>
                    <div className="mt-4 p-3 bg-yellow-50 rounded border border-yellow-200">
                      <p className="text-yellow-800 text-xs">
                        <strong>ℹ️ Nota:</strong> I dati personali completi sono depositati presso la sede legale per ragioni di privacy.
                      </p>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border border-green-200">
                    <p className="text-green-700 mb-4">
                      <strong>I suddetti, con il presente atto, convengono e stipulano quanto segue:</strong>
                    </p>

                    <div className="space-y-4">
                      <div>
                        <h4 className="text-base font-bold text-green-800 mb-2">Art. 1 – Costituzione</h4>
                        <p className="text-green-700">
                          È costituita, ai sensi del <strong>D.Lgs. 117/2017</strong>, l'associazione non riconosciuta denominata
                          <strong> "FreeStay Alliance"</strong>. L'associazione è <strong>apartitica, aconfessionale e non ha scopo di lucro</strong>.
                        </p>
                      </div>

                      <Separator />

                      <div>
                        <h4 className="text-base font-bold text-green-800 mb-2">Art. 2 – Sede</h4>
                        <p className="text-green-700">
                          L'associazione ha <strong>sede legale in Via Aldo Moro 20, 39040 Salorno (BZ)</strong>.
                        </p>
                      </div>

                      <Separator />

                      <div>
                        <h4 className="text-base font-bold text-green-800 mb-2">Art. 3 – Scopi</h4>
                        <p className="text-green-700">
                          L'associazione persegue <strong>finalità civiche, solidaristiche e di utilità sociale</strong>, in particolare
                          la <strong>creazione e gestione di una piattaforma digitale etica e autonoma per il settore turistico</strong>,
                          favorendo l'<strong>indipendenza economica e gestionale degli albergatori</strong>.
                        </p>
                      </div>

                      <Separator />

                      <div>
                        <h4 className="text-base font-bold text-green-800 mb-2">Art. 4 – Statuto</h4>
                        <p className="text-green-700">
                          L'associazione è regolata dallo <strong>statuto allegato al presente atto</strong> e che ne forma parte integrante.
                          I presenti fondatori lo <strong>approvano e lo sottoscrivono integralmente</strong>.
                        </p>
                      </div>

                      <Separator />

                      <div>
                        <h4 className="text-base font-bold text-green-800 mb-2">Art. 5 – Durata</h4>
                        <p className="text-green-700">
                          La <strong>durata dell'associazione è illimitata</strong>.
                        </p>
                      </div>

                      <Separator />

                      <div>
                        <h4 className="text-base font-bold text-green-800 mb-2">Art. 6 – Adesioni e cariche</h4>
                        <p className="text-green-700">
                          I presenti fondatori dichiarano di <strong>aderire all'associazione in qualità di soci fondatori</strong>.
                          Si rimandano le nomine e le attribuzioni operative alla <strong>prima assemblea dei soci, da convocarsi entro 60 giorni</strong>.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border border-green-200">
                    <p className="text-center text-green-700 mb-4">
                      <strong>Letto, approvato e sottoscritto in data 21/06/2025.</strong>
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                      <div className="text-center p-3 bg-green-50 rounded">
                        <div className="border-b-2 border-green-300 pb-2 mb-2">
                          <span className="text-green-800 font-semibold">Michael Franceschini</span>
                        </div>
                        <p className="text-xs text-green-600">Socio Fondatore</p>
                      </div>

                      <div className="text-center p-3 bg-green-50 rounded">
                        <div className="border-b-2 border-green-300 pb-2 mb-2">
                          <span className="text-green-800 font-semibold">Vittoria Sgura</span>
                        </div>
                        <p className="text-xs text-green-600">Socio Fondatore</p>
                      </div>

                      <div className="text-center p-3 bg-green-50 rounded">
                        <div className="border-b-2 border-green-300 pb-2 mb-2">
                          <span className="text-green-800 font-semibold">Valerio Rossi</span>
                        </div>
                        <p className="text-xs text-green-600">Socio Fondatore</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-green-50 p-4 rounded-lg mt-6 border border-green-200">
                    <p className="text-green-800 text-sm text-center">
                      <strong>📜 Documento ufficiale di fondazione</strong><br />
                      Depositato presso la sede legale in Via Aldo Moro 20, 39040 Salorno (BZ)<br />
                      Per copie autentiche contattare: info@freestayalliance.org
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Statuto */}
        <Card className="border-2 border-blue-200">
          <CardHeader>
            <CardTitle className="text-3xl text-blue-600 flex items-center gap-2">
              🏛️ Statuto dell'Associazione "FreeStay Alliance"
            </CardTitle>
            <CardDescription className="text-lg">
              Regolamento interno dell'associazione - Approvato dai soci fondatori
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-6">
              <div className="text-sm text-gray-600">
                <p><strong>Sede legale:</strong> Via Aldo Moro 20, 39040 Salorno (BZ)</p>
                <p><strong>Denominazione:</strong> FreeStay Alliance - Associazione non riconosciuta</p>
                <p><strong>Riferimento normativo:</strong> D.Lgs. 117/2017</p>
              </div>
              <Button
                onClick={() => setShowStatuto(!showStatuto)}
                className={showStatuto ? "bg-red-600 hover:bg-red-700" : "bg-blue-600 hover:bg-blue-700"}
              >
                {showStatuto ? "📖 Chiudi Statuto" : "📖 Leggi Statuto Completo"}
              </Button>
            </div>

            {showStatuto && (
              <div className="bg-gray-50 p-6 rounded-lg border">
                <div className="prose max-w-none text-sm space-y-6">

                  <div>
                    <h3 className="text-lg font-bold text-blue-800 mb-3">Art. 1 – Denominazione e sede</h3>
                    <p className="text-gray-700 leading-relaxed">
                      È costituita, ai sensi del D.Lgs. 117/2017, l'associazione non riconosciuta denominata <strong>"FreeStay Alliance"</strong>,
                      con sede legale in <strong>Via Aldo Moro 20, 39040 Salorno (BZ)</strong>. L'associazione potrà istituire sedi operative in Italia e all'estero.
                    </p>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-bold text-blue-800 mb-3">Art. 2 – Scopo e finalità</h3>
                    <p className="text-gray-700 leading-relaxed">
                      L'associazione non ha scopo di lucro e persegue finalità civiche, solidaristiche e di utilità sociale, attraverso la promozione,
                      la progettazione, la realizzazione e la gestione di una <strong>piattaforma digitale etica, autonoma e partecipata per le prenotazioni turistiche</strong>.
                      L'obiettivo è <strong>ridurre la dipendenza degli albergatori da piattaforme multinazionali</strong> e restituire autonomia economica e strategica al comparto turistico.
                    </p>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-bold text-blue-800 mb-3">Art. 3 – Attività</h3>
                    <p className="text-gray-700 leading-relaxed mb-3">L'associazione potrà svolgere attività di:</p>
                    <ul className="list-disc pl-6 space-y-1 text-gray-700">
                      <li>raccolta fondi tramite donazioni ed erogazioni liberali</li>
                      <li>sviluppo e gestione software</li>
                      <li>consulenza, formazione e supporto legale e fiscale agli albergatori</li>
                      <li>promozione e sensibilizzazione sui temi della sovranità digitale e del turismo etico</li>
                      <li>realizzazione di eventi, incontri, campagne</li>
                      <li>partecipazione a bandi pubblici e ricezione del 5x1000</li>
                    </ul>
                    <p className="text-gray-700 mt-3">
                      Ogni attività sarà svolta nel rispetto del principio di <strong>non lucro e di trasparenza</strong>.
                    </p>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-bold text-blue-800 mb-3">Art. 4 – Soci</h3>
                    <p className="text-gray-700 leading-relaxed mb-3">Possono essere soci fondatori, ordinari o sostenitori:</p>
                    <ul className="list-disc pl-6 space-y-1 text-gray-700">
                      <li><strong>gli albergatori o gestori di strutture ricettive</strong></li>
                      <li>enti, imprese e soggetti esterni che condividano gli scopi dell'associazione</li>
                    </ul>
                    <p className="text-gray-700 mt-3">
                      I soci fondatori hanno <strong>diritto permanente di voto e partecipazione</strong>.
                      I soci sostenitori non albergatori non possono assumere ruoli di controllo ma possono offrire contributi tecnici o finanziari.
                    </p>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-bold text-blue-800 mb-3">Art. 5 – Contributi associativi</h3>
                    <p className="text-gray-700 leading-relaxed">
                      L'associazione prevede un <strong>contributo iniziale suggerito pari a 1.000 €</strong>, detraibile secondo l'art. 83 del D.Lgs. 117/2017.
                      Ulteriori contributi, anche periodici o straordinari, potranno essere stabiliti dall'assemblea dei soci.
                    </p>
                    <div className="bg-yellow-50 p-4 rounded-lg mt-3 border border-yellow-200">
                      <p className="text-yellow-800 text-sm">
                        <strong>ℹ️ Nota:</strong> Il contributo di €1.000 è suggerito per i soci fondatori.
                        Per i soci ordinari sono previsti contributi più accessibili (€20/anno) come definito nei regolamenti operativi.
                      </p>
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-bold text-blue-800 mb-3">Art. 6 – Organi dell'associazione</h3>
                    <p className="text-gray-700 leading-relaxed mb-3">Sono organi dell'associazione:</p>
                    <ul className="list-disc pl-6 space-y-1 text-gray-700">
                      <li>Assemblea dei Soci</li>
                      <li>Consiglio Direttivo</li>
                      <li>Coordinatore Operativo (eletto o designato dai fondatori)</li>
                    </ul>
                    <p className="text-gray-700 mt-3">
                      Tutti gli organi operano in forma <strong>collegiale e trasparente</strong>.
                    </p>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-bold text-blue-800 mb-3">Art. 7 – Coordinamento fondativo</h3>
                    <p className="text-gray-700 leading-relaxed">
                      Fino al raggiungimento degli obiettivi iniziali (creazione e lancio della piattaforma digitale), l'associazione riconosce
                      al socio fondatore <strong>Michael Franceschini un ruolo guida strategico e operativo</strong>, garantendo la sua permanenza
                      nelle attività direttive principali. Eventuali modifiche strutturali alla missione potranno essere discusse solo dopo
                      l'attivazione completa della piattaforma e con l'approvazione di almeno il <strong>75% dei soci attivi</strong>.
                    </p>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-bold text-blue-800 mb-3">Art. 8 – Missione strategica futura</h3>
                    <p className="text-gray-700 leading-relaxed">
                      L'associazione potrà deliberare in futuro, su proposta motivata del Consiglio Direttivo e con l'approvazione dell'Assemblea,
                      una <strong>missione strategica di impatto superiore</strong>, da realizzarsi solo una volta completata l'autonomia funzionale
                      e finanziaria della piattaforma. I contenuti di tale missione potranno essere inizialmente riservati ai soli fondatori e
                      comunicati ufficialmente solo dopo l'approvazione dei soci.
                    </p>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-bold text-blue-800 mb-3">Art. 9 – Risorse economiche</h3>
                    <p className="text-gray-700 leading-relaxed mb-3">L'associazione trae le risorse economiche da:</p>
                    <ul className="list-disc pl-6 space-y-1 text-gray-700">
                      <li>contributi dei soci</li>
                      <li>erogazioni liberali e donazioni</li>
                      <li>proventi da attività marginali o commerciali accessorie</li>
                      <li>5x1000 e bandi pubblici</li>
                    </ul>
                    <p className="text-gray-700 mt-3">
                      Ogni entrata è soggetta a <strong>rendicontazione e trasparenza</strong> verso i soci.
                    </p>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-bold text-blue-800 mb-3">Art. 10 – Modifiche statutarie</h3>
                    <p className="text-gray-700 leading-relaxed">
                      Lo statuto può essere modificato su proposta del Consiglio Direttivo e con approvazione di almeno
                      <strong> i due terzi dei soci aventi diritto al voto</strong>.
                    </p>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-bold text-blue-800 mb-3">Art. 11 – Scioglimento</h3>
                    <p className="text-gray-700 leading-relaxed">
                      In caso di scioglimento, l'assemblea delibererà la destinazione del patrimonio residuo a enti con finalità analoghe
                      o a fini di utilità sociale, previo parere dell'Ufficio del RUNTS.
                    </p>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg mt-6 border border-blue-200">
                    <p className="text-blue-800 text-sm text-center">
                      <strong>📋 Documento ufficiale vigente</strong><br />
                      Per consultazioni legali o copie certificate, contattare la sede legale in Via Aldo Moro 20, 39040 Salorno (BZ)
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </section>

      {/* Sezioni Principali */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
        {/* Regolamenti */}
        <Card className="border-2 border-blue-200 hover:shadow-lg transition-shadow">
          <CardHeader>
            <CardTitle className="text-2xl text-blue-600 flex items-center gap-2">
              📋 Regolamenti
            </CardTitle>
            <CardDescription>
              Statuto, regolamento interno e normative dell'associazione
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="font-medium">Atto Costitutivo</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowAttoCostitutivo(true)}
                >
                  📜 Leggi
                </Button>
              </div>
              <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                <span className="font-medium">Statuto Associazione</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowStatuto(true)}
                >
                  📖 Leggi
                </Button>
              </div>
              <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                <span className="font-medium">Regolamento Interno</span>
                <Button variant="outline" size="sm">
                  📄 PDF
                </Button>
              </div>
              <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                <span className="font-medium">Codice Etico</span>
                <Button variant="outline" size="sm">
                  📄 PDF
                </Button>
              </div>
              <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                <span className="font-medium">Privacy Policy</span>
                <Button variant="outline" size="sm" asChild>
                  <Link href="/privacy">
                    🔗 Leggi
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Guide e Procedure */}
        <Card className="border-2 border-green-200 hover:shadow-lg transition-shadow">
          <CardHeader>
            <CardTitle className="text-2xl text-green-600 flex items-center gap-2">
              📚 Guide e Procedure
            </CardTitle>
            <CardDescription>
              Manuali operativi e guide passo-passo per i soci
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="font-medium">Guida Nuovo Socio</span>
                <Button variant="outline" size="sm">
                  📖 Leggi
                </Button>
              </div>
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="font-medium">Come Votare</span>
                <Button variant="outline" size="sm" asChild>
                  <Link href="/votazioni">
                    🔗 Vai
                  </Link>
                </Button>
              </div>
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="font-medium">Procedura Rimborsi</span>
                <Button variant="outline" size="sm">
                  📄 PDF
                </Button>
              </div>
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="font-medium">Gestione Eventi</span>
                <Button variant="outline" size="sm">
                  📄 PDF
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Modulistica */}
        <Card className="border-2 border-purple-200 hover:shadow-lg transition-shadow">
          <CardHeader>
            <CardTitle className="text-2xl text-purple-600 flex items-center gap-2">
              📝 Modulistica
            </CardTitle>
            <CardDescription>
              Moduli e documenti da compilare per varie procedure
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                <span className="font-medium">Richiesta Iscrizione</span>
                <Button variant="outline" size="sm" asChild>
                  <Link href="/associati">
                    🔗 Compila
                  </Link>
                </Button>
              </div>
              <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                <span className="font-medium">Proposta Progetto</span>
                <Button variant="outline" size="sm">
                  📄 DOCX
                </Button>
              </div>
              <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                <span className="font-medium">Richiesta Rimborso</span>
                <Button variant="outline" size="sm">
                  📄 PDF
                </Button>
              </div>
              <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                <span className="font-medium">Candidatura Cariche</span>
                <Button variant="outline" size="sm">
                  📄 PDF
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Documenti Ufficiali */}
      <section className="py-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              🏛️ Documenti Ufficiali
            </CardTitle>
            <CardDescription>
              Atti costitutivi, bilanci e documentazione legale
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Atti Costitutivi</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center p-3 border rounded-lg">
                    <div>
                      <span className="font-medium">Atto Costitutivo</span>
                      <p className="text-sm text-gray-600">Salorno (BZ) - 2024</p>
                    </div>
                    <Button variant="outline" size="sm">
                      📄 PDF
                    </Button>
                  </div>
                  <div className="flex justify-between items-center p-3 border rounded-lg">
                    <div>
                      <span className="font-medium">Iscrizione Registro</span>
                      <p className="text-sm text-gray-600">RUNTS - In corso</p>
                    </div>
                    <Button variant="outline" size="sm">
                      📄 PDF
                    </Button>
                  </div>
                  <div className="flex justify-between items-center p-3 border rounded-lg">
                    <div>
                      <span className="font-medium">Codice Fiscale</span>
                      <p className="text-sm text-gray-600">In fase di attribuzione</p>
                    </div>
                    <Button variant="outline" size="sm">
                      📄 PDF
                    </Button>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Bilanci e Rendiconti</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center p-3 border rounded-lg">
                    <div>
                      <span className="font-medium">Bilancio 2024</span>
                      <p className="text-sm text-gray-600">Bilancio consuntivo</p>
                    </div>
                    <Button variant="outline" size="sm" asChild>
                      <Link href="/trasparenza">
                        🔗 Visualizza
                      </Link>
                    </Button>
                  </div>
                  <div className="flex justify-between items-center p-3 border rounded-lg">
                    <div>
                      <span className="font-medium">Relazione Attività 2024</span>
                      <p className="text-sm text-gray-600">Report annuale</p>
                    </div>
                    <Button variant="outline" size="sm">
                      📄 PDF
                    </Button>
                  </div>
                  <div className="flex justify-between items-center p-3 border rounded-lg">
                    <div>
                      <span className="font-medium">Rendiconto Trasparente</span>
                      <p className="text-sm text-gray-600">Live dashboard</p>
                    </div>
                    <Button variant="outline" size="sm" asChild>
                      <Link href="/trasparenza">
                        🔗 Visualizza
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* FAQ e Supporto */}
      <section className="py-8">
        <div className="grid md:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl flex items-center gap-2">
                ❓ Domande Frequenti
              </CardTitle>
              <CardDescription>
                Risposte alle domande più comuni degli albergatori
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <details className="p-3 border rounded-lg">
                  <summary className="font-medium cursor-pointer">
                    Come posso diventare socio?
                  </summary>
                  <p className="text-sm text-gray-600 mt-2">
                    Puoi iscriverti compilando il modulo nella pagina "Associati"
                    e versando la quota annuale di €20 (per soci ordinari).
                  </p>
                </details>
                <details className="p-3 border rounded-lg">
                  <summary className="font-medium cursor-pointer">
                    Qual è la differenza tra i contributi?
                  </summary>
                  <p className="text-sm text-gray-600 mt-2">
                    Lo statuto prevede €1.000 per soci fondatori, ma per albergatori
                    ordinari è stata definita una quota accessibile di €20/anno.
                  </p>
                </details>
                <details className="p-3 border rounded-lg">
                  <summary className="font-medium cursor-pointer">
                    Quando sarà pronta la piattaforma?
                  </summary>
                  <p className="text-sm text-gray-600 mt-2">
                    La piattaforma di prenotazioni dirette è in sviluppo.
                    I soci riceveranno aggiornamenti regolari sui progressi.
                  </p>
                </details>
                <details className="p-3 border rounded-lg">
                  <summary className="font-medium cursor-pointer">
                    La piattaforma avrà commissioni?
                  </summary>
                  <p className="text-sm text-gray-600 mt-2">
                    No, l'obiettivo è zero commissioni per gli albergatori soci.
                    La piattaforma sarà sostenuta dai contributi associativi.
                  </p>
                </details>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl flex items-center gap-2">
                🆘 Supporto e Contatti
              </CardTitle>
              <CardDescription>
                Hai bisogno di aiuto? Contattaci
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-semibold text-blue-800 mb-2">📧 Email Supporto</h4>
                  <p className="text-sm text-blue-700">
                    <strong>Generale:</strong> info@freestayalliance.org<br />
                    <strong>Amministrazione:</strong> admin@freestayalliance.org<br />
                    <strong>Tecnico:</strong> tech@freestayalliance.org
                  </p>
                </div>

                <div className="p-4 bg-green-50 rounded-lg">
                  <h4 className="font-semibold text-green-800 mb-2">📞 Telefono</h4>
                  <p className="text-sm text-green-700">
                    <strong>Segreteria:</strong> In fase di attivazione<br />
                    <strong>Emergenze:</strong> Contattare via email
                  </p>
                </div>

                <div className="p-4 bg-purple-50 rounded-lg">
                  <h4 className="font-semibold text-purple-800 mb-2">🏢 Sede Legale</h4>
                  <p className="text-sm text-purple-700">
                    Via Aldo Moro 20<br />
                    39040 Salorno (BZ)<br />
                    Italia
                  </p>
                </div>

                <Button asChild className="w-full">
                  <Link href="/contatti">
                    📞 Vai alla Pagina Contatti
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Note Legali */}
      <section className="py-8">
        <Card className="bg-gray-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              ⚖️ Note Legali e Disclaimer
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6 text-sm">
              <div>
                <h3 className="font-semibold mb-2">Validità Documenti</h3>
                <p className="text-gray-600">
                  Tutti i documenti presenti in questa sezione sono aggiornati
                  e rappresentano la versione ufficiale vigente. In caso di
                  discrepanze, fa fede la versione cartacea depositata presso la sede.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Aggiornamenti</h3>
                <p className="text-gray-600">
                  La documentazione viene aggiornata regolarmente.
                  Eventuali modifiche sono comunicate ai soci tramite
                  newsletter e notifiche del sito.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Download e Utilizzo</h3>
                <p className="text-gray-600">
                  I documenti sono scaricabili gratuitamente dai soci.
                  È vietata la distribuzione non autorizzata o l'uso
                  commerciale dei contenuti.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Supporto Tecnico</h3>
                <p className="text-gray-600">
                  Per problemi di download o visualizzazione dei documenti,
                  contatta il supporto tecnico all'indirizzo tech@freestayalliance.org.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
