export default function AdminBypass() {
  return (
    <div style={{
      padding: '50px',
      backgroundColor: '#fef3c7',
      minHeight: '100vh',
      fontFamily: 'Arial'
    }}>
      <h1 style={{
        color: '#92400e',
        fontSize: '40px',
        textAlign: 'center',
        marginBottom: '30px'
      }}>
        🔓 ADMIN BYPASS TEST
      </h1>

      <div style={{
        backgroundColor: 'white',
        padding: '30px',
        borderRadius: '10px',
        border: '3px solid #f59e0b',
        maxWidth: '600px',
        margin: '0 auto'
      }}>
        <h2 style={{ color: '#374151', marginBottom: '20px' }}>Status Test:</h2>

        <div style={{ marginBottom: '15px' }}>
          <span style={{ color: '#16a34a', fontWeight: 'bold' }}>✅ HTML rendering: </span>
          <span>FUNZIONA</span>
        </div>

        <div style={{ marginBottom: '15px' }}>
          <span style={{ color: '#16a34a', fontWeight: 'bold' }}>✅ Next.js routing: </span>
          <span>FUNZIONA</span>
        </div>

        <div style={{ marginBottom: '15px' }}>
          <span style={{ color: '#16a34a', fontWeight: 'bold' }}>✅ CSS styling: </span>
          <span>FUNZIONA</span>
        </div>

        <div style={{ marginBottom: '25px' }}>
          <span style={{ color: '#dc2626', fontWeight: 'bold' }}>🔍 Testing: </span>
          <span>Layout Admin Components</span>
        </div>

        <div style={{
          backgroundColor: '#fef2f2',
          padding: '15px',
          borderRadius: '6px',
          border: '1px solid #fca5a5'
        }}>
          <p style={{ margin: 0, color: '#991b1b' }}>
            <strong>Diagnosi:</strong> Se vedi questa pagina ma /admin è bianca,
            il problema è nel AdminLayoutSimple o nei componenti React complessi.
          </p>
        </div>
      </div>
    </div>
  );
}
