"use client"

import { useState } from 'react';
import Link from 'next/link';

// Credenziali semplici
const DEMO_USERS: Record<string, { password: string; user: { id: number; email: string; name: string; role: string } }> = {
  'admin@associazione.org': {
    password: 'admin123',
    user: {
      id: 1,
      email: 'admin@associazione.org',
      name: 'Michael Franceschini',
      role: 'admin'
    }
  }
};

export default function AdminLoginBypass() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simula una chiamata API
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Controlla le credenziali
    const userAccount = DEMO_USERS[email];
    if (userAccount && userAccount.password === password) {
      // Salva l'utente nel localStorage
      const adminUser = {
        ...userAccount.user,
        loginTime: Date.now(),
        keepLoggedIn: true,
        lastActivity: Date.now()
      };

      localStorage.setItem('adminUser', JSON.stringify(adminUser));

      // Reindirizza alla dashboard admin
      window.location.href = '/admin';
    } else {
      setError('Email o password non validi');
    }

    setIsLoading(false);
  };

  return (
    <html>
      <head>
        <title>Login Admin Bypass</title>
      </head>
      <body style={{
        margin: 0,
        padding: 0,
        fontFamily: 'system-ui, -apple-system, sans-serif',
        backgroundColor: '#f3f4f6',
        minHeight: '100vh'
      }}>
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#f3f4f6',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '40px',
            borderRadius: '12px',
            border: '2px solid #3b82f6',
            boxShadow: '0 10px 25px rgba(0, 0, 0, 0.1)',
            width: '100%',
            maxWidth: '400px'
          }}>
            {/* Success Banner */}
            <div style={{
              backgroundColor: '#dcfce7',
              padding: '12px',
              borderRadius: '8px',
              border: '2px solid #16a34a',
              marginBottom: '24px',
              textAlign: 'center'
            }}>
              <h2 style={{
                color: '#166534',
                fontSize: '18px',
                margin: '0',
                fontWeight: 'bold'
              }}>
                ✅ LOGIN BYPASS FUNZIONA!
              </h2>
            </div>

            {/* Header */}
            <div style={{ textAlign: 'center', marginBottom: '32px' }}>
              <h1 style={{
                fontSize: '24px',
                fontWeight: 'bold',
                color: '#111827',
                margin: '0 0 8px 0'
              }}>🔐 Login Admin (Bypass)</h1>
              <p style={{
                color: '#6b7280',
                margin: 0,
                fontSize: '14px'
              }}>Se vedi questo, il problema era nel layout admin</p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} style={{ marginBottom: '24px' }}>
              {/* Email Field */}
              <div style={{ marginBottom: '16px' }}>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '600',
                  color: '#374151',
                  marginBottom: '6px'
                }}>
                  📧 Email:
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@associazione.org"
                  required
                  style={{
                    width: '100%',
                    padding: '12px',
                    border: '2px solid #d1d5db',
                    borderRadius: '8px',
                    fontSize: '16px',
                    boxSizing: 'border-box',
                    outline: 'none'
                  }}
                />
              </div>

              {/* Password Field */}
              <div style={{ marginBottom: '20px' }}>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '600',
                  color: '#374151',
                  marginBottom: '6px'
                }}>
                  🔒 Password:
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="admin123"
                  required
                  style={{
                    width: '100%',
                    padding: '12px',
                    border: '2px solid #d1d5db',
                    borderRadius: '8px',
                    fontSize: '16px',
                    boxSizing: 'border-box',
                    outline: 'none'
                  }}
                />
              </div>

              {/* Error Message */}
              {error && (
                <div style={{
                  fontSize: '14px',
                  color: '#dc2626',
                  backgroundColor: '#fef2f2',
                  padding: '12px',
                  borderRadius: '8px',
                  marginBottom: '16px',
                  border: '1px solid #fca5a5'
                }}>
                  ❌ {error}
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                style={{
                  width: '100%',
                  backgroundColor: isLoading ? '#9ca3af' : '#3b82f6',
                  color: 'white',
                  padding: '14px 20px',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '16px',
                  fontWeight: 'bold',
                  cursor: isLoading ? 'not-allowed' : 'pointer'
                }}
              >
                {isLoading ? '⏳ Accesso in corso...' : '🚀 Accedi'}
              </button>
            </form>

            {/* Demo Credentials */}
            <div style={{
              backgroundColor: '#fef3c7',
              padding: '16px',
              borderRadius: '8px',
              border: '2px solid #f59e0b'
            }}>
              <h3 style={{
                fontSize: '16px',
                fontWeight: 'bold',
                color: '#92400e',
                margin: '0 0 10px 0'
              }}>🔑 Credenziali Demo:</h3>
              <div style={{
                fontSize: '14px',
                color: '#78350f'
              }}>
                <p style={{ margin: '5px 0' }}><strong>Email:</strong> admin@associazione.org</p>
                <p style={{ margin: '5px 0' }}><strong>Password:</strong> admin123</p>
              </div>
            </div>

            {/* Footer */}
            <div style={{
              textAlign: 'center',
              marginTop: '20px'
            }}>
              <a
                href="/"
                style={{
                  fontSize: '14px',
                  color: '#3b82f6',
                  textDecoration: 'none'
                }}
              >
                🏠 Torna alla Homepage
              </a>
            </div>
          </div>
        </div>
      </body>
    </html>
  );
}
