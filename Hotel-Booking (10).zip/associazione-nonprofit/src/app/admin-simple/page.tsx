import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Link from 'next/link';

export default function AdminSimple() {
  return (
    <html>
      <head>
        <title>Admin Test</title>
      </head>
      <body style={{
        fontFamily: 'Arial',
        padding: '50px',
        backgroundColor: '#f0f9ff',
        margin: 0
      }}>
        <div style={{
          backgroundColor: 'white',
          padding: '40px',
          borderRadius: '10px',
          boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
        }}>
          <h1 style={{
            color: 'green',
            fontSize: '48px',
            textAlign: 'center',
            margin: '0 0 30px 0'
          }}>
            ✅ ADMIN FUNZIONA!
          </h1>

          <div style={{
            backgroundColor: '#dcfce7',
            padding: '20px',
            border: '2px solid #16a34a',
            borderRadius: '8px',
            marginBottom: '30px',
            textAlign: 'center'
          }}>
            <h2 style={{ color: '#166534', margin: '0 0 10px 0' }}>🎉 Test Riuscito!</h2>
            <p style={{ fontSize: '18px', color: '#15803d', margin: 0 }}>
              Se vedi questo, l'admin funziona perfettamente.
            </p>
          </div>

          <div style={{ marginBottom: '30px' }}>
            <h3 style={{ color: '#374151', marginBottom: '15px' }}>📋 Prossimi Test:</h3>
            <ul style={{ color: '#4b5563', lineHeight: '1.6' }}>
              <li>✅ Routing admin funziona</li>
              <li>✅ Next.js rendering funziona</li>
              <li>✅ HTML/CSS funziona</li>
              <li>🔄 Ora testiamo il layout complesso</li>
            </ul>
          </div>

          <div style={{
            display: 'flex',
            gap: '15px',
            flexWrap: 'wrap',
            justifyContent: 'center'
          }}>
            <a
              href="/"
              style={{
                backgroundColor: '#3b82f6',
                color: 'white',
                padding: '12px 24px',
                textDecoration: 'none',
                borderRadius: '6px',
                fontWeight: 'bold'
              }}
            >
              🏠 Homepage
            </a>

            <a
              href="/admin/login"
              style={{
                backgroundColor: '#10b981',
                color: 'white',
                padding: '12px 24px',
                textDecoration: 'none',
                borderRadius: '6px',
                fontWeight: 'bold'
              }}
            >
              🔑 Login Admin
            </a>

            <a
              href="/test-basic"
              style={{
                backgroundColor: '#f59e0b',
                color: 'white',
                padding: '12px 24px',
                textDecoration: 'none',
                borderRadius: '6px',
                fontWeight: 'bold'
              }}
            >
              🧪 Test Basic
            </a>
          </div>
        </div>
      </body>
    </html>
  );
}
