// Service Worker per gestire le Push Notifications

const CACHE_NAME = 'associazione-v1';
const STATIC_CACHE = [
  '/',
  '/manifest.json'
];

// Installazione del Service Worker
self.addEventListener('install', (event) => {
  console.log('[SW] Service Worker installing...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[SW] Caching static assets');
        return cache.addAll(STATIC_CACHE);
      })
      .then(() => {
        console.log('[SW] Installation complete');
        return self.skipWaiting();
      })
  );
});

// Attivazione del Service Worker
self.addEventListener('activate', (event) => {
  console.log('[SW] Service Worker activating...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('[SW] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      console.log('[SW] Activation complete');
      return self.clients.claim();
    })
  );
});

// Gestione delle Push Notifications
self.addEventListener('push', (event) => {
  console.log('[SW] Push notification received');

  let notificationData = {
    title: 'Associazione Non-Profit',
    body: 'Hai ricevuto una nuova notifica',
    icon: '/favicon.ico',
    badge: '/favicon.ico',
    tag: 'associazione-notification',
    data: {
      url: '/'
    }
  };

  // Se il push contiene dati, li utilizziamo
  if (event.data) {
    try {
      const pushData = event.data.json();
      notificationData = {
        ...notificationData,
        ...pushData
      };
    } catch (error) {
      console.log('[SW] Error parsing push data:', error);
    }
  }

  // Personalizza l'icona e i dati in base al tipo di notifica
  if (notificationData.type) {
    switch (notificationData.type) {
      case 'new_vote':
        notificationData.icon = '/voting-icon.png';
        notificationData.badge = '/voting-badge.png';
        notificationData.data.url = '/votazioni';
        break;
      case 'vote_ending':
        notificationData.icon = '/clock-icon.png';
        notificationData.badge = '/clock-badge.png';
        notificationData.data.url = '/votazioni';
        break;
      case 'vote_result':
        notificationData.icon = '/result-icon.png';
        notificationData.badge = '/result-badge.png';
        notificationData.data.url = '/votazioni';
        break;
      default:
        break;
    }
  }

  // Mostra la notifica
  event.waitUntil(
    self.registration.showNotification(notificationData.title, {
      body: notificationData.body,
      icon: notificationData.icon,
      badge: notificationData.badge,
      tag: notificationData.tag,
      data: notificationData.data,
      requireInteraction: notificationData.priority === 'high',
      actions: [
        {
          action: 'view',
          title: 'Visualizza',
          icon: '/view-icon.png'
        },
        {
          action: 'dismiss',
          title: 'Ignora',
          icon: '/dismiss-icon.png'
        }
      ],
      vibrate: notificationData.priority === 'high' ? [200, 100, 200] : [100],
      sound: notificationData.priority === 'high' ? '/notification-high.mp3' : '/notification.mp3'
    })
  );
});

// Gestione del click sulle notifiche
self.addEventListener('notificationclick', (event) => {
  console.log('[SW] Notification clicked:', event.notification.tag);

  event.notification.close();

  if (event.action === 'dismiss') {
    return;
  }

  // Determina l'URL da aprire
  const urlToOpen = event.notification.data?.url || '/';

  event.waitUntil(
    clients.matchAll({ type: 'window' }).then((clientList) => {
      // Se c'è già una finestra aperta, la porta in primo piano
      for (const client of clientList) {
        if (client.url === urlToOpen && 'focus' in client) {
          return client.focus();
        }
      }

      // Altrimenti apri una nuova finestra
      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })
  );
});

// Gestione della chiusura delle notifiche
self.addEventListener('notificationclose', (event) => {
  console.log('[SW] Notification closed:', event.notification.tag);

  // Invia analytics sulla chiusura della notifica
  event.waitUntil(
    fetch('/api/analytics/notification-closed', {
      method: 'POST',
      body: JSON.stringify({
        tag: event.notification.tag,
        timestamp: new Date().toISOString()
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    }).catch(() => {
      // Ignora errori di analytics
      console.log('[SW] Analytics request failed');
    })
  );
});

// Gestione dei messaggi dal client
self.addEventListener('message', (event) => {
  console.log('[SW] Message received:', event.data);

  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }

  if (event.data && event.data.type === 'GET_VERSION') {
    event.ports[0].postMessage({ version: 'v1.0.0' });
  }
});

// Sincronizzazione in background
self.addEventListener('sync', (event) => {
  console.log('[SW] Background sync triggered:', event.tag);

  if (event.tag === 'background-notification-sync') {
    event.waitUntil(
      fetch('/api/notifications/check')
        .then(response => response.json())
        .then(data => {
          if (data.hasNewNotifications) {
            return self.registration.showNotification('Nuove Notifiche', {
              body: `Hai ${data.count} nuove notifiche`,
              icon: '/favicon.ico',
              tag: 'sync-notification'
            });
          }
        })
        .catch(error => {
          console.log('[SW] Background sync failed:', error);
        })
    );
  }
});

// Gestione degli errori
self.addEventListener('error', (event) => {
  console.error('[SW] Service Worker error:', event.error);
});

self.addEventListener('unhandledrejection', (event) => {
  console.error('[SW] Service Worker unhandled rejection:', event.reason);
});

console.log('[SW] Service Worker loaded successfully');
