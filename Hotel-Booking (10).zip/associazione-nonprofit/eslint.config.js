module.exports = {
  ignores: ["**/*"],
  rules: {}
};
